import aloha3.controller.Server;
import business.ServiceSsrOnly;

public static int port = 8082;
public static boolean isOpenBrowser = true;

// CRUD / Document menu is NOT show.
void main() {
    InitDBSsrOnly.initThen().then_(() -> {
        IO.println("Starting SSR Only Server on port " + port);

        Server.start(
            ServiceSsrOnly.container,
            ServiceSsrOnly.conceptual,
            port,
            isOpenBrowser);
    });
}
