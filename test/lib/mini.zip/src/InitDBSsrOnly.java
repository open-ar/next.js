import aloha.mapping.write.Persist;
import aloha3.module.object.record.master.coc.Atomic;
import aloha3.tool.AbstractInitDB;
import mapping.Properties;
import record.User;

public class InitDBSsrOnly extends AbstractInitDB {
    static {
        assertEnablePreview();
    }

    public static 
    Persist.Nothing
    initThen() {
        return new InitDBSsrOnly().run();
    }

    @Override
    protected Package[]
    recordPackagesToInitialize() {
        return new Package[]{
            Atomic.class.getPackage(),
            User.class.getPackage()};
    }

    @Override
    protected Properties
    properties() {
        return new Properties();
    }

    static void 
    assertEnablePreview() {
        try {
            Class.forName("aloha.mapping.Incubator");
        } catch (Throwable e) {
            System.err.println("Preview features are not enabled. Try running with '--enable-preview'. ");
            throw new RuntimeException(e);
        }
    }
}
