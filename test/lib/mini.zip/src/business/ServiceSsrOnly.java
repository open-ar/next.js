package business;

import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.ServiceContainer.Conceptual;
import aloha3.module.function.business.master.CoreMgr;
import business.mdm.UserField;
import record.User;

public class ServiceSsrOnly {

    public static final ServiceContainer container;
    public static final Conceptual conceptual;

    static {
        container = new ServiceContainer();
        container.eagerLoad(Accessor.class);
        conceptual = new Conceptual(container);
        // conceptual.eagerLoad(ConceptualAccessor.class); // Skip Apply
    }

    public static class Accessor
        implements ServiceContainer.Accessor {

        public static 
        CoreMgr.StarView<
            User,
            UserField>
        userMgr() {
            return container.getOrAddCoreMgrOf(UserField.class);
        }
    } // Accessor
}
