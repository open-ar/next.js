package business.txm;

import aloha3.document.business.txm.AbstractSubmitField;
import record.Submit;

public final class SubmitField extends AbstractSubmitField {

    public final Member.Mandatory<String> VersionCode = attr(Submit.VersionCode.class);
}
