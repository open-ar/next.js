
package business.txm;

import aloha3.module.object.view.TxStarView;
import record.Apply;

public final class ApplyField
    extends TxStarView.FieldOf.AndIntFK<Apply> {

    public Member.Mandatory<Long> ApplyId() { return super.PK(); }
    public Member.Mandatory<Integer> UserId() { return super.FK(); }
    public final Member.Mandatory<Long> DocumentId = attrLongAFK(Apply.Document.class);
}
