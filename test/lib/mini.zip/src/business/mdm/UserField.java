package business.mdm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.StarView;
import record.User;

public final class UserField
    extends StarView.FieldOf<User> {

    public Mandatory<Integer> UserId() {
        return coreMember();
    }
    public final Mandatory<String> Name = attr(User.Name.class);
}
