package business;

import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.ServiceContainer.Conceptual;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import business.mdm.UserField;
import business.txm.ApplyField;
import record.Apply;
import record.User;

public class Service {

    public static final ServiceContainer container;
    public static final Conceptual conceptual;

    static {
        container = new ServiceContainer();
        container.eagerLoad(Accessor.class);
        conceptual = new Conceptual(container);
        conceptual.eagerLoad(ConceptualAccessor.class);
    }

    public static class Accessor
        implements ServiceContainer.Accessor {

        public static 
        CoreMgr.StarView<
            User,
            UserField>
        userMgr() {
            return container.getOrAddCoreMgrOf(UserField.class);
        }
    } // Accessor

    public static class ConceptualAccessor
        implements Conceptual.Accessor {

        public static 
        TxIntFKMgr.StarView.Flowable<
            Apply,
            User, 
            ApplyField>
        applyMgr() {

            return
                container.getOrAddTxIntFKMgrFlowable(ApplyField.class);
        }
    } // ConceptualAccessor
}
