package record;

import aloha3.module.object.record.transaction.TxAttributeEntity;

public class Submit {
    public static final class VersionCode
        extends TxAttributeEntity.Of<aloha3.document.record.Submit, String> {
    }
}
