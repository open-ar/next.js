package record;

import aloha3.module.object.record.transaction.TxAttributeEntityLongAFK;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.opt.spec.MakeFlowable;
import mapping.Properties;

public final class Apply
    extends TxEntityIntFK.On<User>
    implements
        MakeFlowable<Apply>{

    @Override
    public Properties.DB_GROUP dbGroup() {
        return Properties.DB_GROUP.APPLY;
    }

    public static final class Document
        extends TxAttributeEntityLongAFK.Of<Apply, aloha3.document.record.Document> {
    }
}
