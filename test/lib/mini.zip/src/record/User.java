package record;

import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import mapping.Properties.DB_GROUP;

public final class User extends CoreEntity {
    @Override
    public DB_GROUP dbGroup() {
        return DB_GROUP.USER;
    }

    public User() {
        super("APP_USER");
    }

    public static final class Name
        extends AttributeEntity.Of<User, String> {
    }
}
