package mapping;

import aloha.concurrent.Context;
import aloha.mapping.IDbGroup;
import aloha.mapping.IPool;
import aloha.mapping.IProperties;
import aloha.mapping.Pools;

public class Properties
    implements IProperties.SingleResourceMap<Properties.DB_GROUP> {

    public static final String JDBC_URL = "jdbc:h2:~/bos-mini-doc-v3;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;AUTO_SERVER=TRUE;";
    public static final String USER_NAME = "sa";
    public static final String PASSWORD = "";

    @Override
    public String jdbcDriver() {
        return "org.h2.Driver";
    }

    @Override
    public void init(Builder<DB_GROUP> builder) {
        builder.
            forAllDbGroups(
                Pools.
                    addFirstPool(
                        IPool.DB_LOCATION.LOCAL,
                        JDBC_URL,
                        USER_NAME,
                        PASSWORD,
                        Context.numberOfCoresPerNUMANode(),
                        IPool.MODE.READ_WRITE).
                    done());
    }

    @Override
    public Class<DB_GROUP> dbGroupType() {
        return DB_GROUP.class;
    }

    public enum DB_GROUP implements IDbGroup {
        USER,
        APPLY,
        MISC
    }

    @Override
    public
    TX_TIME_NAME_SPELL
    txTimeNameSpell() {
        return TX_TIME_NAME_SPELL.SHORT;
    }

    @Override
    public
    PRINT_SQL
    debug() {
        return PRINT_SQL.EXCEPT_OF_SELECT;
    }
}
