import aloha3.controller.Server;
import business.Service;
import business.txm.SubmitField;

public static int port = 8081;
public static boolean isOpenBrowser = true;

void main() {
    InitDB.
        initThen().
        then_(DataLoad::loadTxModel).
        then_(() ->
            IO.println("Click http://localhost:" + port + " for Out-Of-Order streaming by template engine without JavaScript")).
        then_(() ->
            Server.start(
                Service.container,
                Service.conceptual,
                aloha3.document.business.Service.get(
                    Service.container,
                    Service.conceptual,
                    SubmitField.class),
                port,
                isOpenBrowser));
}
