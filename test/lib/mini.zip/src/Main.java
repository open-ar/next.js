import aloha3.controller.Server;
import business.Service;

public static int port = 8081;
public static boolean isOpenBrowser = true;

void main() {
    InitDB.
        initThen().
        then_(DataLoadFormElementOnly::load).
        then_(() ->
            IO.println("Click http://localhost:" + port + " for Out-Of-Order streaming by template engine without JavaScript")).
        then_(() ->
            Server.start(
                Service.container,
                Service.conceptual,
                port,
                isOpenBrowser));
}
