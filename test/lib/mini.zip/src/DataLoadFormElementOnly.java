import aloha.module.func.Func;
import aloha.module.object.DateTime;
import aloha.module.object.Type;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.record.FormElement;
import aloha3.module.object.view.StarView;
import business.Service;
import business.mdm.UserField;
import business.txm.SubmitField;
import record.User;

public class DataLoadFormElementOnly {

    static void
    load() {
        Func.accept(
            aloha3.document.business.Service.get(
                Service.container,
                Service.conceptual,
                SubmitField.class),
            aloha3.document.business.Service::register,
            aloha3.document.business.Service::initRootFormElement,
        service -> createFormElement(service, "Reservation Holder", Type.RefType.STRING),

        service -> createFormElement(service, "Reservation Date", Type.RefType.YMD),
        service -> createFormElement(service, "Check-In Date", Type.RefType.YMD),
        service -> createFormElement(service, "Check-Out Date", Type.RefType.YMD),

        service -> createFormElement(service, "Guest Information", Type.RefType.LONG),
        service -> createFormElement(service, "Guest Name", Type.RefType.STRING),
        service -> createFormElement(service, "Guest Birthday", Type.RefType.YMD),
        service -> createFormElement(service, "Guest Passport Number", Type.RefType.LONG),
        _ ->
                Service.Accessor.userMgr().saveThen(
            StarView.Write.Prepare.Builder.
                create(UserField.class).
                setMandatory(f -> f.Name, User.Name.class, "User 1").
                build(),
            DateTime.YMDHMS.current()));
    }

    private static 
    void
    createFormElement(
        aloha3.document.business.Service<SubmitField> service,
        String name,
        Type.RefType refType) {

        service.formElementMgr().
            saveThen(
                StarView.Write.Prepare.Builder.
                    create(FormElementField.class).
                    setMandatory(f -> f.Name, FormElement.Name.class, name).
                    setMandatoryValue(f -> f.RefType, refType).
                    build(),
                DateTime.YMDHMS.current()).
            apply(coreRead ->
                service.formElementMgr().
                    createView(
                        coreRead,
                        DateTime.YMDHMS.current()));
    }
}
