import aloha.module.object.DateTime;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple;
import aloha.module.object.Type;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.record.Document;
import aloha3.document.record.Enum.REQUIRED;
import aloha3.document.record.Form;
import aloha3.document.record.FormElement;
import aloha3.document.record.NestedElement;
import aloha3.document.record.Submit;
import aloha3.document.record.SubmitLineItem;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.master.coc.WorkFlowField;
import aloha3.module.object.Views;
import aloha3.module.object.model.read.Tree.StarArrow;
import aloha3.module.object.model.write.Tree;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;
import business.Service;
import business.mdm.UserField;
import business.txm.ApplyField;
import business.txm.SubmitField;
import record.Apply;
import record.User;

import java.util.Arrays;
import java.util.function.Consumer;

import static aloha3.controller.query.RegisterDocumentController.saveSubmitLineItemTxModel;
import static aloha3.controller.query.vo.RegisterDocumentAddView.getNestedElement;
import static business.Service.ConceptualAccessor.applyMgr;

public class DataLoad {

    public static final String WORK_FLOW_EXAMPLE_1 = "WorkFlow Example 1";
    public static final String WORK_FLOW_EXAMPLE_2 = "WorkFlow Example 2";

    public enum STATE {
        APPLY,
        IN_PROGRESS,
        CANCEL,
        REJECTED,
        RE_APPLY,
        COMPLETED,
    }

    static void createDemoWorkflows() {
        aloha3.module.function.business.conceptual.WorkFlow.createNewWorkFlow(
            WORK_FLOW_EXAMPLE_1,
            Tuple.Pair.of(STATE.APPLY, STATE.CANCEL),
            Tuple.Pair.of(STATE.APPLY, STATE.IN_PROGRESS),
            Tuple.Pair.of(STATE.IN_PROGRESS, STATE.REJECTED),
            Tuple.Pair.of(STATE.IN_PROGRESS, STATE.COMPLETED),
            Tuple.Pair.of(STATE.REJECTED, STATE.RE_APPLY),
            Tuple.Pair.of(STATE.RE_APPLY, STATE.IN_PROGRESS));
        aloha3.module.function.business.conceptual.WorkFlow.createNewWorkFlow(
            WORK_FLOW_EXAMPLE_2,
            Tuple.Pair.of(STATE.APPLY, STATE.IN_PROGRESS),
            Tuple.Pair.of(STATE.IN_PROGRESS, STATE.REJECTED),
            Tuple.Pair.of(STATE.IN_PROGRESS, STATE.COMPLETED),
            Tuple.Pair.of(STATE.IN_PROGRESS, STATE.CANCEL),
            Tuple.Pair.of(STATE.REJECTED, STATE.RE_APPLY),
            Tuple.Pair.of(STATE.RE_APPLY, STATE.IN_PROGRESS));
    }

    private static 
    StarView.Read<FormElementField>
    createFormElement(
        aloha3.document.business.Service<SubmitField> submitFieldService,
        String name,
        Type.RefType refType) {

        return
            submitFieldService.formElementMgr().
                saveThen(
                    StarView.Write.Prepare.Builder.
                        create(FormElementField.class).
                        setMandatory(f -> f.Name, FormElement.Name.class, name).
                        setMandatoryValue(f -> f.RefType, refType).
                        build(),
                    DateTime.YMDHMS.current()).
                apply(coreRead ->
                    submitFieldService.formElementMgr().
                        createView(
                            coreRead,
                            DateTime.YMDHMS.current()));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <
        T extends Comparable<? super T>>
    TxModel.ChildValue<NestedElement, String>
    getChildValue(
        StarView.Hierarchy.Read<NestedElementField> fc,
        T value) {
        return new TxModel.ChildValue<>(
            (Record.SinglePK)fc.pivotRead(),
            value.toString());
    }

    @SafeVarargs
    private static 
    TxModel<SubmitField, SubmitLineItem>
    newSubmitDocumentLineItemModel(
        String versionCode,
        TxIntFK.Write<Document> documentWrite,
        TxModel.ChildValue<NestedElement, String> v,
        TxModel.ChildValue<NestedElement, String>... vs) {

        aloha3.document.business.Service<SubmitField> submitFieldService = aloha3.document.business.Service.get(
            Service.container,
            Service.conceptual,
            SubmitField.class);

        TxLongFK.Write<Submit> submitWrite =
            TxLongFK.Write.create(
                submitFieldService.submitFamily().entity(),
                documentWrite.getTxId(),
                DateTime.YMDHMS.current());

        TxStarView.Write.New<SubmitField> newSubmitView =
            TxStarView.Write.New.Builder.
                create(
                    SubmitField.class,
                    submitWrite).
                setMandatoryValue(f -> f.VersionCode, versionCode).
                build();

        // Wrap all ChildValue with ChildValueWithIndex (arrayIndex=1 for simple demo
        // data)
        var vWithIndex = new aloha3.controller.query.vo.form.FormValues.ChildValueWithIndex(v, (byte) 1);
        var vsWithIndex = Arrays.stream(vs)
                .map(cv -> new aloha3.controller.query.vo.form.FormValues.ChildValueWithIndex(
                        cv, (byte) 1))
                .toArray(aloha3.controller.query.vo.form.FormValues.ChildValueWithIndex[]::new);

        return saveSubmitLineItemTxModel(submitFieldService, newSubmitView, documentWrite.getTxId(), _ -> false, vWithIndex, vsWithIndex);
    }

    static void
    loadTxModel() {
        aloha3.document.business.Service<SubmitField> submitFieldService = aloha3.document.business.Service.get(
            Service.container,
            Service.conceptual,
            SubmitField.class);
        submitFieldService.register();
        // ER:
        // Master Form <= NestedElement => FormElement
        // Tx     Document(FK to formId) => Submit(ext + ver code) =>  DocumentLineItem
        // Tx     Apply(AFK to documentId)

        // 1) Create Form with FormElements
        Core.Read<Form> form1 =
            submitFieldService.formMgr().
                saveThen(
                    StarView.Write.Prepare.Builder.
                        create(FormField.class).
                        setMandatory(f -> f.Name, Form.Name.class, "Reservation Form").
                        setMandatory(f -> f.GraphId, Form.GraphId.class, 10).
                        build(),
                    DateTime.YMDHMS.current()).
                get();

        var formElement = submitFieldService.initRootFormElement();
        var formElementName = createFormElement(submitFieldService, "Reservation Holder", Type.RefType.STRING);
        
        var formElementReservationData = createFormElement(submitFieldService, "Reservation Date", Type.RefType.YMD);
        var formElementCheckInData = createFormElement(submitFieldService, "Check-In Date", Type.RefType.YMD);
        var formElementCheckOutData = createFormElement(submitFieldService, "Check-Out Date", Type.RefType.YMD);
        
        var formElementGuestInformation = createFormElement(submitFieldService, "Guest Information", Type.RefType.LONG);
        var formElementGuestName = createFormElement(submitFieldService, "Guest Name", Type.RefType.STRING);
        var formElementGuestBirthday = createFormElement(submitFieldService, "Guest Birthday", Type.RefType.YMD);
        var formElementGuestPassportNumber = createFormElement(submitFieldService, "Guest Passport Number", Type.RefType.LONG);

        var regTime = DateTime.YMDHMS.current();
        
        // Build a tree
        Tree.StarArrow<FormElementField, NestedElement, NestedElementField> tree = Tree.StarArrow.
            create(
                formElement,
                NestedElementField.class,
                regTime).
            addLeaf(
                formElementName, starArrowNestedElement(1, REQUIRED.MANDATORY)).
            addBranch(
                formElementReservationData, starArrowNestedElement(1, REQUIRED.MANDATORY),
                branches ->
                    branches.
                        addLeaf(formElementCheckInData, starArrowNestedElement(1, REQUIRED.MANDATORY)).
                        addLeaf(formElementCheckOutData, starArrowNestedElement(1, REQUIRED.MANDATORY))).
            addBranch(
                formElementGuestInformation, starArrowNestedElement(2, REQUIRED.MANDATORY),
                branches ->
                    branches.
                        addLeaf(formElementGuestName, starArrowNestedElement(1, REQUIRED.MANDATORY)).
                        addLeaf(formElementGuestBirthday, starArrowNestedElement(1, REQUIRED.OPTIONAL)).
                        addLeaf(formElementGuestPassportNumber, starArrowNestedElement(1, REQUIRED.MANDATORY)));
        Core.Read<Graph> graphRead = submitFieldService.nestedElementTree().
            save(tree).
            get();
        StarArrow<FormElementField, NestedElementField> treeRead = submitFieldService.nestedElementTree().createModel(graphRead, regTime).mustNonNull();

        var relName = getNestedElement(treeRead, formElementGuestName);
        var relBirth = getNestedElement(treeRead, formElementGuestBirthday);
        var relAge = getNestedElement(treeRead, formElementGuestPassportNumber);
        IO.println("[DEBUG] Created Form Graph Id: " + graphRead.getRowId());

        // 2) Create Document with FK to Form
        TxIntFK.Write<Document> documentWrite = submitFieldService.documentMgr().create(form1, DateTime.YMDHMS.current());

        // 3) Create Submit with ApplyId & Document with DocumentLineItems(afk to FormElement with it's value)
        DataLoad.createDemoWorkflows();
        StarView.Read<WorkFlowField> workFlowViewRead = WorkFlow.workFlowOf(
            DataLoad.WORK_FLOW_EXAMPLE_1, DateTime.YMDHMS.current()).mustNonNull();

        Core.Read<User> userRead = Service.Accessor.userMgr().saveThen(
            StarView.Write.Prepare.Builder.
                create(UserField.class).
                setMandatory(f -> f.Name, User.Name.class, "User 1").
                build(),
            DateTime.YMDHMS.current()).get();

        // TxIntFK.Read<Apply> applyRead = WorkFlow.WithForeignAttribute.createOrThrow(
        //     ApplyField.class, // 1) Class<F> fieldClass, // F extends TxStarView.Field0f.AndIntFK<E> // E extends TxEntityIntFK.On<M> & MakeFlowable<E>,
        //     TxStarView.Write.Prepare.Builder::build,// 7) Function< TxStarView.Write.Prepare.Builder<E,F>, TxStarView.Write.Prepare<E,F>> setAttributeMore>
        //     userRead, // 8) aloha3.module.object.record.master.read.meta.Read<M> pivotRead,
        //     workFlowViewRead, // 9) StarView.Read<WorkFlowField> workFlowRead,
        //     AbstractGraph::node, // 10) Function<Chain.Star<StateField>, StarView.Read<StateField>> initialState,
        //     applyMgr(), // 11) FlowableWriteMgt.TxIntFK<E,M,F> flowableMgr)
        //     workflowDomain ->
        //         workflowDomain.link(
        //             Apply.Document.class, // 5) Class<A> linkClass, // A extends TxAttributeEntityLongAFK.Of<E, FP>,
        //             documentWrite, // 3) Write.WithTimestamp<FP> foreignTx,
        //             DocumentField.class, // 2) Class<FPF> foreignFieldClass, // FPF extends AbstractField & TxStarView.Field<FP>> // FP extends SealedTxParent‹?>,
        //             documentBuilder -> 
        //                 submitFieldService.documentMgr().save(documentBuilder.build())));// // 4) Consumer<TxStarView.Write.New.Builder<FP,FPF>> saveForeign,

        // IO.println("===== Current state of Apply 1: " + WorkFlow.current(applyRead, applyMgr()) + " ===");


        TxIntFK.Read<Apply> applyRead = WorkFlow.WithForeignAttribute.create(
            documentWrite,
            () ->
                // Save Tx model: Submit(ext + ver code) => DocumentLineItem, like input from browser
                submitFieldService.submitFamily().save(
                    newSubmitDocumentLineItemModel(
                        "v1",
                        documentWrite,
                        getChildValue(relName, "John"),
                        getChildValue(relBirth, DateTime.YMD.create(19900101)),
                        getChildValue(relAge, 10))),
            Apply.Document.class,
            doc ->
                TxStarView.Write.Prepare.Builder.
                    create(ApplyField.class).
                    setMandatoryValue(f -> f.DocumentId, doc.getTxId()).
                    build(),
            userRead,
            workFlowViewRead,
            applyMgr());

        TxStarView.Read<DocumentField> documentRead = 
            submitFieldService.documentMgr().save(
                TxStarView.Write.New.Builder
                    .create(DocumentField.class, documentWrite)
                    .build()).
            applyTo(id ->
                submitFieldService.documentMgr().createView(id).mustNonNull()).
            get();


        // Simulate create = new Submit + DocumentLineItems
        // submitFieldService.submitFamily().save(
        //     newSubmitDocumentLineItemModel(
        //         "v1",
        //         documentWrite,
        //         // Name (1 values)
        //         getChildValue(relName, "John"),
        //         // Reservation Date (3 values)
        //         getChildValue(relReservationData, DateTime.YMD.create(20250801)),
        //         getChildValue(relReservationData, DateTime.YMD.create(20250802)),
        //         getChildValue(relReservationData, DateTime.YMD.create(20250803)),
        //         // Phone number (2 value)
        //         getChildValue(relPhoneNumber, 81_03_1234_5678L),
        //         getChildValue(relPhoneNumber, 81_070_1234_5678L)));
        //
        // // Update without state transition
        // sleep1s();
        // // Save Tx model: Submit(ext + ver code) => DocumentLineItem, like input from browser
        // submitFieldService.submitFamily().save(
        //     newSubmitDocumentLineItemModel(
        //         "v2",
        //         documentWrite,
        //         // Name (2 values)
        //         getChildValue(relName, "John"),
        //         // UPDATE Reservation Date (3 values)
        //         getChildValue(relReservationData, DateTime.YMD.create(20250901)),
        //         getChildValue(relReservationData, DateTime.YMD.create(20250902)),
        //         getChildValue(relReservationData, DateTime.YMD.create(20250903)),
        //         // Phone number (2 value)
        //         getChildValue(relPhoneNumber, 81_03_1234_5678L),
        //         getChildValue(relPhoneNumber, 81_070_1234_5678L)));
        //
        // IO.println("===== Current state of Apply 2: " + WorkFlow.current(applyRead, applyMgr()) + " ===");
        //
        // sleep1s();
        // // Update with state transition
        // WorkFlow.WithForeignAttribute.update(
        //     // Read.TxTime<E> flowableRead, 
        //     applyRead,
        //     // DateTime.YMDHMS now, 
        //     DateTime.YMDHMS.current(),
        //     // StarView.Read<StateField> toState, 
        //     selectNextStateByName(
        //         applyRead,
        //         STATE.IN_PROGRESS.name()).mustNonNull(),
        //     // FlowableMgt<E> flowableMgr, 
        //     applyMgr(),
        //     // VoidFunction saveForeign, 
        //     ()-> 
        //         submitFieldService.submitFamily().save(
        //             newSubmitDocumentLineItemModel(
        //                 "v3",
        //                 documentWrite,
        //                 // UPDATE Update Name (1 values)
        //                 getChildValue(relName, "Johnny"),
        //                 // Reservation Date (3 values)
        //                 getChildValue(relReservationData, DateTime.YMD.create(20250901)),
        //                 getChildValue(relReservationData, DateTime.YMD.create(20250902)),
        //                 getChildValue(relReservationData, DateTime.YMD.create(20250903)),
        //                 // Phone number (2 value)
        //                 getChildValue(relPhoneNumber, 81_03_1111_2222L),
        //                 getChildValue(relPhoneNumber, 81_080_3333_4444L))),
        //     // Class<A> linkClass
        //     Apply.Document.class);
        
        // Read test
        IO.println("=== Read Apply Id: " + applyRead.getTxId() + " ===");
        IO.println("===== Read Document Line Items of Document Id: " + documentRead.txRead().getRowId() + " ===");

        // AlohaDocument.
        //     readDocumentsOnlyWithLatestSubmit(
        //         ImmutVOs.create(documentRead),
        //         submitFieldService).
        //     foreach(IO::println);

        NonEmptyVOs<TxStarView.Read<DocumentField>> readNonEmptyVOs = NonEmptyVOs.of(documentRead);
        var readNonEmpty = submitFieldService.readLatestSubmits(Views.T.create(readNonEmptyVOs));
        readNonEmpty.foreach(IO::println);

        IO.println("===== Current state of Apply 3: " + WorkFlow.current(applyRead, applyMgr()) + " ===");

        // AlohaDocument.
        //     readDocumentsOnlyWithLatestSubmit(
        //         ImmutVOs.create(documentRead), 
        //         submitFieldService).
        //     foreach(IO::println);
    }

    private static 
    Consumer<StarView.Hierarchy.Write.Prepare.Builder<NestedElement, NestedElementField>>
    starArrowNestedElement(int value, REQUIRED optional) {
        return builder -> {
            builder.setOptional(f -> f.ArrayMaxSize, NestedElement.ArrayMaxSize.class,(byte)value);
            builder.setOptionalValue(f -> f.Required, optional);
        };
    }
}
