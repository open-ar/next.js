void main() throws java.sql.SQLException {
    org.h2.tools.Console.main(
        "-webAllowOthers",
        "-url", mapping.Properties.JDBC_URL,
        "-user", mapping.Properties.USER_NAME,
        "-password", mapping.Properties.PASSWORD,
        "-browser");
}
