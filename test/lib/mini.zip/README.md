# 2025/10/08 ver

## 操作手順：

1. Main起動
2. http://localhost:8081/

## 変更点

- aloha-documentで任意フォームを作成・データ登録できる機能追加
    - 確認手順
      1. `CRUD / Master`メニューで
      　 `Form (CORE)`、`FormElement (CORE)`、`FormComposed (RELATION)`を選択し、
        フォームの定義を行う
      2. `CRUD / Document`メニューで、定義されたフォームを選択し、ドキュメントの登録・参照を行う
      3. `CRUD / Workflow Transition`メニューで、登録されたドキュメントで申請を行う
```

＊デモの目的

```
