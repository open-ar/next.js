@echo off
setlocal

set "LIBS=lib\aloha-query-ssr-1.0-all.jar;lib\aloha-1.0.jar;lib\aloha-stream-1.0.jar;lib\aloha-template-1.0-all.jar;lib\h2-2.2.224.jar;lib\javax.json-1.1.jar"

echo Compiling MainSsrOnly...
if exist target\classes-ssr-only rmdir /s /q target\classes-ssr-only
mkdir target\classes-ssr-only

javac --enable-preview --release 25 -cp "%LIBS%" -d target\classes-ssr-only ^
    src\mapping\*.java ^
    src\record\User.java ^
    src\business\mdm\*.java ^
    src\business\ServiceSsrOnly.java ^
    src\InitDBSsrOnly.java ^
    src\MainSsrOnly.java

if %errorlevel% neq 0 exit /b %errorlevel%

echo Running MainSsrOnly...
java --enable-preview -cp "target\classes-ssr-only;%LIBS%" MainSsrOnly

endlocal
