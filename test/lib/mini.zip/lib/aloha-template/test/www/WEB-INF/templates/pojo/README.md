# OGNL Expression Test Program

## Overview

This test program is used to verify the fixed OGNL expression evaluation functionality, ensuring that the BOS framework's modified Thymeleaf can correctly handle various expressions.

## File Description

### Java Files
- `Main.java` - Original complex test program (requires complete BOS framework dependencies)
- `MainPojo.java` - Simplified test program (uses only Java standard library)

### Template Files
- `test1.html` - Basic variable access test
- `test2.html` - List method call test
- `test3.html` - List index access test
- `test4.html` - webc:each iteration test
- `test5.html` - Complex nested access test

## Running Tests

### Run Simplified Test Program
```bash
cd .cursor/aloha-template/test/src
javac MainPojo.java
java -cp . MainPojo
```

### Run Complete Test Program (requires BOS framework)
```bash
cd .cursor/aloha-template/test
javac -cp "../../lib/*" src/Main.java
java -cp "../../lib/*:src" Main
```

## Test Content

### 1. Basic Variable Access
- ✅ Object property access: `form.formName`
- ✅ Simple variable access: `testString`, `testNumber`
- ✅ List variable access: `simpleList`, `numberList`

### 2. List Method Calls
- ✅ `form.rootNodes.size()` - Returns list size
- ✅ `form.rootNodes.isEmpty()` - Checks if list is empty
- ✅ `form.rootNodes.toString()` - Returns list string representation
- ✅ Method calls in `webc:text` attributes

### 3. List Index Access
- ✅ `form.rootNodes[0]` - Access first element
- ✅ `form.rootNodes[1]` - Access second element
- ✅ `form.rootNodes[2]` - Access third element
- ✅ Nested property access: `form.rootNodes[0].label`

### 4. webc:each Iteration
- ✅ `webc:each="node : ${form.rootNodes}"` - List iteration
- ✅ Iteration variable access: `${node.label}`, `${node.type}`
- ✅ Iteration state access: `${nodeStat.index}`

### 5. Complex Nested Access
- ✅ Multi-level nested properties: `form.rootNodes[1].children.size()`
- ✅ Child node iteration: `form.rootNodes[1].children`
- ✅ Conditional rendering: `webc:if="${list.size() > 0}"`

## Test Data

### FormView Structure
```
FormView
├── formName: "Reservation Form"
├── rootNodes: List<FormNode>
│   ├── [0] Name (STRING, required=true)
│   ├── [1] Reservation Date (YMD, required=false)
│   │   ├── Check-in Date (YMD)
│   │   └── Check-out Date (YMD)
│   └── [2] Phone Number (LONG, required=false)
│       ├── Mobile (LONG)
│       └── Home (LONG)
└── rootNodesString: ["a", "b", "c"]
```

### Other Test Data
- `simpleList`: `["item1", "item2", "item3"]`
- `numberList`: `[1, 2, 3, 4, 5]`
- `emptyList`: `[]`
- `testString`: `"Hello World"`
- `testNumber`: `42`

## Expected Results

All tests should run successfully without errors. If the following situations occur, it may indicate that the fixes have issues:

1. **NullPointerException** - Context variable mapping problem
2. **IllegalAccessException** - Java module system access restrictions
3. **NoSuchMethodException** - Index access syntax problem
4. **TemplateProcessingException** - OGNL expression evaluation problem

## Troubleshooting

If tests fail, please check:

1. **Compilation Success** - Ensure there are no syntax errors
2. **Dependencies Correct** - Ensure all necessary jar files are in the classpath
3. **Fixes Applied** - Ensure the fixes in `AlohaVariableExpressionEvaluator.java` have been applied
4. **Java Version** - Ensure using Java 9+ version

## Related Documentation

- [Beginner's Guide](../../../../.cursor/rules/新手入门指南.md)
- [Technical Reference Manual](../../../../.cursor/rules/技术参考手册.md)
- [Troubleshooting Guide](../../../../.cursor/rules/故障排除指南.md)
- [Investigation Report](../../../../.cursor/rules/Thymeleaf_OGNL_Issue_Investigation_Report.md)

---

**Last Updated**: 2025-10-23