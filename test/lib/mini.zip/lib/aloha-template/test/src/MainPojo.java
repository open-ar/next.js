import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * MainPojo.java - Simplified OGNL Expression Test Program
 * 
 * Used to test the fixed OGNL expression evaluation functionality, including:
 * - Java Record field access
 * - List method calls (size, isEmpty, toString)
 * - List index access ([0], [1])
 * - Basic OGNL expression functionality
 */
public class MainPojo {

    public static void main(String[] args) throws IOException {
        
        System.out.println("=== OGNL Expression Test Started ===");
        
        // Create test data - simulate FormView and FormNode
        var name = new FormNode("Name", "STRING", true, 1, List.of());
        
        var checkin = new FormNode("Check-in Date", "YMD", false, 1, List.of());
        var checkout = new FormNode("Check-out Date", "YMD", false, 1, List.of());
        var reservationDate = new FormNode(
            "Reservation Date", "YMD", false, 1,
            List.of(checkin, checkout)
        );

        var mobile = new FormNode("Mobile", "LONG", false, 1, List.of());
        var home = new FormNode("Home", "LONG", false, 1, List.of());
        var phone = new FormNode(
            "Phone Number", "LONG", false, 2,
            List.of(mobile, home)
        );

        // Create FormView object
        var formView = new FormView(
            "Reservation Form", 
            List.of(name, reservationDate, phone),
            List.of("a", "b", "c")
        );

        // Create other test data
        var simpleList = List.of("item1", "item2", "item3");
        var numberList = List.of(1, 2, 3, 4, 5);
        var emptyList = List.<String>of();

        // Build test context
        Map<String, Object> context = new HashMap<>();
        context.put("form", formView);
        context.put("simpleList", simpleList);
        context.put("numberList", numberList);
        context.put("emptyList", emptyList);
        context.put("testString", "Hello World");
        context.put("testNumber", 42);

        System.out.println("FormView object: " + formView);
        System.out.println("rootNodes size: " + formView.rootNodes().size());
        System.out.println("rootNodes content: " + formView.rootNodes());
        System.out.println();

        // Test 1: Basic variable access
        System.out.println("=== Test 1: Basic Variable Access ===");
        testBasicAccess(context);
        System.out.println();

        // Test 2: List method calls
        System.out.println("=== Test 2: List Method Calls ===");
        testListMethods(context);
        System.out.println();

        // Test 3: List index access
        System.out.println("=== Test 3: List Index Access ===");
        testListIndexAccess(context);
        System.out.println();

        // Test 4: Nested property access
        System.out.println("=== Test 4: Nested Property Access ===");
        testNestedAccess(context);
        System.out.println();

        System.out.println("=== OGNL Expression Test Completed ===");
    }

    private static void testBasicAccess(Map<String, Object> context) {
        System.out.println("form object: " + context.get("form"));
        System.out.println("testString: " + context.get("testString"));
        System.out.println("testNumber: " + context.get("testNumber"));
        System.out.println("simpleList: " + context.get("simpleList"));
        System.out.println("numberList: " + context.get("numberList"));
        System.out.println("emptyList: " + context.get("emptyList"));
    }

    private static void testListMethods(Map<String, Object> context) {
        @SuppressWarnings("unchecked")
        List<FormNode> rootNodes = (List<FormNode>) ((FormView) context.get("form")).rootNodes();
        
        System.out.println("form.rootNodes type: " + rootNodes.getClass().getName());
        System.out.println("form.rootNodes size: " + rootNodes.size());
        System.out.println("form.rootNodes isEmpty: " + rootNodes.isEmpty());
        System.out.println("form.rootNodes toString: " + rootNodes.toString());
        
        @SuppressWarnings("unchecked")
        List<String> simpleList = (List<String>) context.get("simpleList");
        System.out.println("simpleList size: " + simpleList.size());
        System.out.println("simpleList isEmpty: " + simpleList.isEmpty());
        System.out.println("simpleList toString: " + simpleList.toString());
        
        @SuppressWarnings("unchecked")
        List<Integer> numberList = (List<Integer>) context.get("numberList");
        System.out.println("numberList size: " + numberList.size());
        System.out.println("numberList isEmpty: " + numberList.isEmpty());
        System.out.println("numberList toString: " + numberList.toString());
        
        @SuppressWarnings("unchecked")
        List<String> emptyList = (List<String>) context.get("emptyList");
        System.out.println("emptyList size: " + emptyList.size());
        System.out.println("emptyList isEmpty: " + emptyList.isEmpty());
        System.out.println("emptyList toString: " + emptyList.toString());
    }

    private static void testListIndexAccess(Map<String, Object> context) {
        @SuppressWarnings("unchecked")
        List<FormNode> rootNodes = (List<FormNode>) ((FormView) context.get("form")).rootNodes();
        
        System.out.println("form.rootNodes[0]: " + rootNodes.get(0));
        System.out.println("form.rootNodes[1]: " + rootNodes.get(1));
        System.out.println("form.rootNodes[2]: " + rootNodes.get(2));
        
        @SuppressWarnings("unchecked")
        List<String> simpleList = (List<String>) context.get("simpleList");
        System.out.println("simpleList[0]: " + simpleList.get(0));
        System.out.println("simpleList[1]: " + simpleList.get(1));
        System.out.println("simpleList[2]: " + simpleList.get(2));
        
        @SuppressWarnings("unchecked")
        List<Integer> numberList = (List<Integer>) context.get("numberList");
        System.out.println("numberList[0]: " + numberList.get(0));
        System.out.println("numberList[1]: " + numberList.get(1));
        System.out.println("numberList[2]: " + numberList.get(2));
        System.out.println("numberList[3]: " + numberList.get(3));
        System.out.println("numberList[4]: " + numberList.get(4));
    }

    private static void testNestedAccess(Map<String, Object> context) {
        @SuppressWarnings("unchecked")
        List<FormNode> rootNodes = (List<FormNode>) ((FormView) context.get("form")).rootNodes();
        
        // Test nested property access
        FormNode firstNode = rootNodes.get(0);
        System.out.println("form.rootNodes[0].label: " + firstNode.label());
        System.out.println("form.rootNodes[0].type: " + firstNode.type());
        System.out.println("form.rootNodes[0].required: " + firstNode.required());
        System.out.println("form.rootNodes[0].arrayMaxSize: " + firstNode.arrayMaxSize());
        System.out.println("form.rootNodes[0].children: " + firstNode.children());
        
        // Test second node's children
        FormNode secondNode = rootNodes.get(1);
        System.out.println("form.rootNodes[1].label: " + secondNode.label());
        System.out.println("form.rootNodes[1].children.size(): " + secondNode.children().size());
        
        // Test children iteration
        System.out.println("form.rootNodes[1].children iteration:");
        for (FormNode child : secondNode.children()) {
            System.out.println("  - " + child.label() + " (" + child.type() + ")");
        }
        
        // Test third node
        FormNode thirdNode = rootNodes.get(2);
        System.out.println("form.rootNodes[2].label: " + thirdNode.label());
        System.out.println("form.rootNodes[2].children.size(): " + thirdNode.children().size());
        
        // Test children iteration
        System.out.println("form.rootNodes[2].children iteration:");
        for (FormNode child : thirdNode.children()) {
            System.out.println("  - " + child.label() + " (" + child.type() + ")");
        }
    }

    /**
     * Form node record class
     */
    public record FormNode(
        String label,
        String type,
        boolean required,
        int arrayMaxSize,
        List<FormNode> children
    ) {}

    /**
     * Form view record class
     */
    public record FormView(
        String formName,
        List<FormNode> rootNodes,
        List<String> rootNodesString
    ) {}
}
