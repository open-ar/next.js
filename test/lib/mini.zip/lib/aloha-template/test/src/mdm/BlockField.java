package mdm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.StarView;
import record.Block;

public final class BlockField
    extends StarView.FieldOf<Block> {

    public Mandatory<Integer> BlockId() { return coreMember(); }
    public final Mandatory<Integer> SpeciesId = attr(Block.RefSpecies.class);
    public final Mandatory<String> Block = attr(Block.Name.class);
    public final Mandatory<String> Name = attr(Block.Name.class);
}

