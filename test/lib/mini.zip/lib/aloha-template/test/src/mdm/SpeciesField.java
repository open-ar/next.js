package mdm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView;
import record.Enum.Genus;
import record.Species;

public final class SpeciesField
    extends StarView.FieldOf<Species> {

    public Mandatory<Integer> SpeciesId() { return coreMember(); }
    public final Mandatory<String> Name = attr(Species.Name.class);
}
