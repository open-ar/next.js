package record;

import aloha.mapping.IDbGroup;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.AttributeEntityAFK;
import aloha3.module.object.record.master.CoreEntity;
import mapping.Properties;

public final class Block extends CoreEntity {
    @Override
    public IDbGroup dbGroup() {
        return Properties.DB_GROUP.SPECIES;
    }

    public static final class RefSpecies
        extends AttributeEntityAFK.Of<Block, Species> {
    }
    public static final class Name
        extends AttributeEntity.Of<Block, String> {}
}
