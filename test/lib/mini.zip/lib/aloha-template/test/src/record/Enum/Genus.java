package record.Enum;

import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutableArray;

public enum Genus implements IdentifiableEnum<Genus> {

    HOMO(1),ANIMAL(2);

    private final byte id;
    Genus(int id) {
        this.id = (byte)id;
    }
    @Override
    public byte id() {
        return this.id;
    }
    @Override
    public Genus of(byte id) {
        return IdentifiableEnum.find(id,array);
    }
    public static final ImmutableArray<Genus> array =
        IdentifiableEnum.toArray(Genus.class);
}
