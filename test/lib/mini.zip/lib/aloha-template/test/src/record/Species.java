package record;

import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import mapping.Properties.DB_GROUP;

public final class Species extends CoreEntity {
    @Override
    public DB_GROUP dbGroup() {
        return DB_GROUP.SPECIES;
    }

    public static final class Name
        extends AttributeEntity.Of<Species, String> {}
    public static final class Genus
        extends FixedAttributeEntity.EnumOf<Species,record.Enum.Genus> {}
}
