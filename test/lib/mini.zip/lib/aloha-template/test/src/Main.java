import aloha.mapping.IDbGroup;
import aloha.module.object.*;
import aloha.module.object.record.IColumn;
import aloha.module.object.record.IForeignKey;
import aloha.module.object.record.master.IMasterKey;
import aloha3.module.object.model.AbstractOneToMany;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.record.meta.master.Attribute;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.View;
import aloha3.tool.template.Context;
import aloha3.tool.template.Engine;
import org.thymeleaf.ITemplateEngine;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {

    public static void main(String[] args) throws IOException {

        Path userDir = Paths.get(
            System.getProperty("user.dir"),
            "test");

        System.out.println(userDir.toAbsolutePath());

        View<UserField> user = View.Builder.
            create(UserField.class).
            setMandatoryValue(f->f.Id,5963).
            setOptionalValue(f->f.Pwd,"Secret").
            setOptionalValue(f->f.BirthDay, DateTime.YMD.create(19700101)).
            setMandatoryValue(f->f.User,"User1").
            setMandatoryValue(f->f.RefType, Type.RefType.YMD).
            build();
        View<UserField> user2 = View.Builder.
            create(UserField.class).
            setMandatoryValue(f->f.Id,2).
            setMandatoryValue(f->f.User,"User2").
            setMandatoryValue(f->f.RefType, Type.RefType.YMD).
            setOptionalValue(f->f.Max,(byte)2).
            build();

        var utils = Context.UtilityBuilder.
            create(UTIL_KEY.class).
            add(Dates.class).
            add(Values.class).
            add(Predicates.class).
            done();
        utils.forEach((k,v)->System.out.println(k+":"+v.getClass().getSimpleName()));

        Context ctx = Context.Builder.create().
            add("reftype", Type.RefType.YMD).
            add("today", DateTime.YMD.today()).
            add(user2).
            add(NonEmptyVOs.of(user,user2)).
            add("test","yuzo").
            add("o2o", OneToOne.of(user,user2)).
            add("o2a", OneToOne.of(user,
                    Attribute.Write.createWithoutPreparePK(
                        new User.Name(),
                        1,
                        "UserName",
                        DateTime.YMDHMS.current()))).
            add("o2o_of_o_o2o", OneToOne.of(user2,OneToOne.of(user,user2))).
            add("o2os", NonEmptyVOs.of(OneToOne.of(user2,OneToOne.of(user,user2)))).
            add("v2o", OneToOne.LeftValue.of("123",user)).
            add("o2MayZero", OneToOne.MayZero.of(user,user2)).
            add("o2MayZeroHistory", OneToOne.MayZero.of(user,new HistoryRecord(1970))).
            add("cdcs", NonEmptyVOs.of(
                new CDC(
                    OneToOne.of(user,user2),
                    NonEmptyVOs.of(OneToOne.LeftValue.of("123",user))))).
            add("cdc2s", NonEmptyVOs.of(
                new CDC2(
                    new View2(user,new HistoryRecord(123)),
                    NonEmptyVOs.of(new HistoryRecord(456))))).
            build();
        ITemplateEngine engine = Engine.
            buildTemplateEngine(new Engine.WebApplication(userDir));

        if ( new HistoryRecord(123) instanceof Record<?> rec) {
            System.out.println(rec.getClass().getName());
        } else if (Record.class.isAssignableFrom(HistoryRecord.class) ){
            System.out.println("yes:" + Record.class.isAssignableFrom(HistoryRecord.class));
        }

        /*
        String out = engine.
            process("home_mini", ctx);
        System.out.println(out);
        */

        /*
        String out = engine.
            process("usr :: copy(1970,'secret')", ctx);
        System.out.println(out);
        */

        String out = engine.
            process("user", ctx);
        System.out.println(out);

        // engine.processThrottled("home",ctx).processAll()

        System.exit(0);
    }
    public enum UTIL_KEY implements Context.UtilityKey {
        DATE,VALUE,PREDICATE
    }
    public static final class Dates implements Context.StateLessUtility<UTIL_KEY> {
        public String format(DateTime.YMD ymd) {
            return
                ymd.getYear() + "/" +
                ymd.getMonth() + "/" +
                ymd.getDate();
        }
        public String formatJP(DateTime.YMD ymd) {
            return
                ymd.getYear() + "年" +
                    ymd.getMonth() + "月" +
                    ymd.getDate() + "日";
        }
        public int toDecimalIfNullZero(DateTime.YMD mayNull) {
            return mayNull == null ?  0 : mayNull.decimal() ;
        }
        @Override
        public UTIL_KEY key() {
            return UTIL_KEY.DATE;
        }
    }
    public static final class Values implements Context.StateLessUtility<UTIL_KEY> {
        public String format(Comparable<?> value) {
            return switch (value) {
                case DateTime.YMD ymd-> new Dates().format(ymd);
                case Number n-> "number:" + n;
                case String s->s;
                default->
                    throw new RuntimeException("Unknown Type:" + value.getClass().getName());
            };
        }
        public Integer[] numberSeqTo(Byte mayNullValue) {
            if ( mayNullValue == null ) return new Integer[]{1};
            final Integer[] array = new Integer[mayNullValue];
            for(int i = 0 ; i < array.length ; i++) {
                array[i] = i + 1;
            }
            return array;
        }
        @Override
        public UTIL_KEY key() {
            return UTIL_KEY.VALUE;
        }
    }
    public static final class Predicates implements Context.StateLessUtility<UTIL_KEY> {

        public boolean rightZero(OneToOne.MayZero<?,?> mayZero) {
            return mayZero.right.unsafeIsNull();
        }
        public boolean rightExist(OneToOne.MayZero<?,?> mayZero) {
            return mayZero.right.unsafeIsNull();
        }
        public boolean equals(Type.RefType refType, String name) {
            return refType.name().equalsIgnoreCase(name);
        }
        @Override
        public UTIL_KEY key() {
            return UTIL_KEY.PREDICATE;
        }
    }

    public static final class UserField
        extends AbstractField {

        public final Member.Mandatory<Integer> Id = mandatory("Id",Integer.class);
        public final Member.Optional<String> Pwd = optional("Pwd",String.class);
        public final Member.Optional<DateTime.YMD> BirthDay = optional("BirthDay", DateTime.YMD.class);
        public final Member.Mandatory<String> User = mandatory("User",String.class);
        public final Member.Mandatory<Type.RefType> RefType = mandatory("RefType",Type.RefType.class);
        public final Member.Optional<Byte> Max = optional("Max",Byte.class);
    }

    public static final class CDC
        extends AbstractOneToMany<
            OneToOne<View<UserField>,View<UserField>>,
            ImmutVOs<OneToOne.LeftValue<String,View<UserField>>>,
            OneToOne.LeftValue<String,View<UserField>>>
        implements ValueObject{
       public CDC(
            OneToOne<View<UserField>, View<UserField>> one,
            ImmutVOs<OneToOne.LeftValue<String, View<UserField>>> many) {
            super(one, many);
        }
    }
    public static final class CDC2
        extends AbstractOneToMany<
            View2,
            ImmutVOs<HistoryRecord>,
            HistoryRecord>
            implements ValueObject{
        public CDC2(
            View2 one,
            ImmutVOs<HistoryRecord> many) {
            super(one, many);
        }
    }
    public static final class View2
        extends AbstractView<UserField> {

        private final HistoryRecord historyRecord;
        public View2(
            AbstractView<UserField> copyFrom,
            HistoryRecord historyRecord) {

            super(copyFrom);
            this.historyRecord =historyRecord;
        }
        public HistoryRecord history() {
            return this.historyRecord;
        }
    }
    public static final class HistoryRecord
        implements Record, IForeignKey.IntValue, IMasterKey.IRegTime {

        private final int fkValue;
        HistoryRecord(int fkValue) {
            this.fkValue = fkValue;
        }
        @Override
        public TYPE type() {
            throw new RuntimeException("never");
        }
        @Override
        public ImmutableArray<IColumn> columnArray() {
            throw new RuntimeException("never");
        }
        @Override
        public int foreignKeyValue() {
            return this.fkValue;
        }
        @Override
        public IColumn getForeignKeyColumn() {
            throw new RuntimeException("never");
        }
        @Override
        public int compareTo(Object o) {
            throw new RuntimeException("never");
        }
        @Override
        public DateTime.YMDHMS getRegTime() {
            return DateTime.YMDHMS.current();
        }
        @Override
        public long getRegTimeAsLong() {
            return getRegTime().getAsLong();
        }
    }
    public static final class User
        extends CoreEntity{
        @Override
        public IDbGroup dbGroup() {
            return null;
        }
        public static final class Name
            extends AttributeEntity.Of<User,String> {

            public final Attribute<String> Value = attr();
        }
    }


}
