public class Foo {
    public Baa baa;
    
    // public Baa getBaa() {
    //     return baa;
    // }
    
    public void setBaa(Baa baa) {
        this.baa = baa;
    }
}