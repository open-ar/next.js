public class Baa {
    public String someMethod() {
        return "Some Value";
    }
}