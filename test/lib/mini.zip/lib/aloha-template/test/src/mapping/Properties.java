package mapping;

import aloha.concurrent.Context;
import aloha.mapping.DBConnectProp;
import aloha.mapping.IDbGroup;
import aloha.mapping.IDbNumber;
import aloha.mapping.IPool;
import aloha.mapping.IPools;
import aloha.mapping.IProperties;
import aloha.mapping.Pools;
import java.util.Map;

public class Properties implements IProperties.SingleResourceMap<Properties.DB_GROUP>  {

    public static enum DB_GROUP implements IDbGroup {
        SPECIES,
        MISC
    }
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "org.h2.Driver";
    //static final String JDBC_URL = "jdbc:h2:~/stream-template-server;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;AUTO_SERVER=TRUE;";
    static final String JDBC_URL = "jdbc:h2:~/aloha-template;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;AUTO_SERVER=TRUE;";

  @Override
  public String jdbcDriver() {
    return JDBC_DRIVER;
  }
    @Override
    public void init(Map<IDbGroup, IPools> resources) {

        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        DBConnectProp dbProp = new DBConnectProp(
            IDbNumber.DB_NUMBER.ONE,
            IPool.DB_LOCATION.LOCAL,
            JDBC_URL,
            "sa",
            "",
            Context.numberOfCoresPerNUMANode(),
            IPool.MODE.READ_WRITE);

        IPools pools = new
            Pools(
            dbProp
        );

        for (DB_GROUP dbGroup : DB_GROUP.values()) {
            resources.put(dbGroup, pools);
        }
    }

    @Override
    public Class<DB_GROUP> dbGroupType() {
        return DB_GROUP.class;
    }

    @Override
    public void init(Builder<DB_GROUP> builder) {
        builder.
            forAllDbGroups(
                Pools.
                    addFirstPool(
                        IPool.DB_LOCATION.LOCAL,
                        JDBC_URL,
                        "sa",
                        "",
                        Context.numberOfCoresPerNUMANode(),
                        IPool.MODE.READ_WRITE).
                    done());
    }

    @Override
    public
    PRINT_SQL
    debug() {
        return PRINT_SQL.ALL;
    }

    @Override
    public
    byte
    NUMERIC_PRECISION() {
        return 18;
    }
}
