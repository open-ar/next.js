public class Obj {
    public Foo foo;
    
    // public Foo getFoo() {
    //     return foo;
    // }
    
    public void setFoo(Foo foo) {
        this.foo = foo;
    }
}