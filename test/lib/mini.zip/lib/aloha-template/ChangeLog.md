# 2025/11/17 ver 

- Java recordのアクセスをサポートする
  - webcから`record.fieldName`でアクセス可能
  - webcから`dates.formatISO(record.fieldName)`のようなメソッド引数からのアクセスも可能

# 2025/10/08 ver 

- add `${#numbers.sequence(formInclude, toInclude)}` support for inclusive range
- add `${#strings.split(str, delimiter)}` support for multi-character delimiter

# 2025/04/12 ver 

- debug modeのサーバ起動オプション追加: ONの場合は、自動的にhtmlにテンプレートファイルパスと対象行数を追加する
