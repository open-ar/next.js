/*
 * =============================================================================
 *
 *   Copyright (c) 2011-2018, The THYMELEAF team (http://www.thymeleaf.org)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package org.thymeleaf.standard.expression;

import aloha.StaticCache;
import aloha.module.object.MayNullVO;
import aloha.module.object.Monad;
import aloha3.module.object.model.AbstractOneToMany;
import aloha3.module.object.model.AbstractOneToOne;
import aloha3.module.object.model.MayNull;
import aloha3.module.object.record.meta.AttributeRecord;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.Unsafe;
import aloha3.tool.template.Engine;
import ognl.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.EngineContext;
import org.thymeleaf.context.IContext;
import org.thymeleaf.context.IExpressionContext;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.exceptions.TemplateProcessingException;
import org.thymeleaf.standard.util.StandardExpressionUtils;
import org.thymeleaf.util.ExpressionUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * <p>
 *   Evaluator for variable expressions ({@code ${...}}) in Thymeleaf Standard Expressions, using the
 *   OGNL expression language.
 * </p>
 * <p>
 *   Note a class with this name existed since 2.0.9, but it was completely reimplemented
 *   in Thymeleaf 3.0
 * </p>
 *
 * @author Daniel Fern&aacute;ndez
 * 
 * @since 3.0.0
 *
 */
public final class AlohaVariableExpressionEvaluator
    implements IStandardVariableExpressionEvaluator {
    
    
    private static final Logger logger = LoggerFactory.getLogger(AlohaVariableExpressionEvaluator.class);

    private static final String EXPRESSION_CACHE_TYPE_OGNL = "ognl";

    private static Map<String,Object> CONTEXT_VARIABLES_MAP_NOEXPOBJECTS_RESTRICTIONS =
        (Map<String,Object>) (Map<?,?>)Collections.singletonMap(
            OGNLContextPropertyAccessor.RESTRICT_REQUEST_PARAMETERS,
            OGNLContextPropertyAccessor.RESTRICT_REQUEST_PARAMETERS);

    private static MemberAccess MEMBER_ACCESS = new ThymeleafACLMemberAccess();
    private static ThymeleafACLClassResolver CLASS_RESOLVER = new ThymeleafACLClassResolver();

    private final boolean applyOGNLShortcuts;

    public AlohaVariableExpressionEvaluator(final boolean applyOGNLShortcuts) {

        super();

        this.applyOGNLShortcuts = applyOGNLShortcuts;

        /*
         * INITIALIZE AND REGISTER THE PROPERTY ACCESSOR
         */
        final OGNLContextPropertyAccessor accessor = new OGNLContextPropertyAccessor();
        OgnlRuntime.setPropertyAccessor(IContext.class, accessor);

    }

    public Object evaluate(
        final IExpressionContext context,
        final IStandardVariableExpression expression,
        final StandardExpressionExecutionContext expContext) {
        return evaluate(context, expression, expContext, this.applyOGNLShortcuts);
    }

    private static Object evaluate(
        final IExpressionContext context,
        final IStandardVariableExpression expression,
        final StandardExpressionExecutionContext expContext,
        final boolean applyOGNLShortcuts) {
       
        try {

            if (logger.isTraceEnabled()) {
                logger.trace("[THYMELEAF][{}] OGNL expression: evaluating expression \"{}\" on target", TemplateEngine.threadIndex(), expression.getExpression());
            }

            final IEngineConfiguration configuration = context.getConfiguration();

            String exp = expression.getExpression();

            final boolean useSelectionAsRoot = expression.getUseSelectionAsRoot();

            if (exp == null) {
                throw new TemplateProcessingException("Expression content is null, which is not allowed");
            }

            final ComputedOGNLExpression parsedExpression =
                    obtainComputedOGNLExpression(configuration, expression, exp, expContext, applyOGNLShortcuts);

            final Map<String,Object> contextVariablesMap;

            if (parsedExpression.mightNeedExpressionObjects) {

                // The IExpressionObjects implementation returned by processing contexts that include the Standard
                // Dialects will be lazy in the creation of expression objects (i.e. they won't be created until really
                // needed). And in order for this behaviour to be accepted by OGNL, we will be wrapping this object
                // inside an implementation of Map<String,Object>, which will afterwards be fed to the constructor
                // of an OgnlContext object.

                // Note this will never happen with shortcut expressions, as the '#' character with which all
                // expression object names start is not allowed by the OGNLShortcutExpression parser.

                contextVariablesMap = new OGNLExpressionObjectsWrapper(context.getExpressionObjects());

                // We might need to apply restrictions on the request parameters. In the case of OGNL, the only way we
                // can actually communicate with the PropertyAccessor, (OGNLVariablesMapPropertyAccessor), which is the
                // agent in charge of applying such restrictions, is by adding a context variable that the property accessor
                // can later lookup during evaluation.
                if (expContext.getRestrictVariableAccess()) {
                    contextVariablesMap.put(OGNLContextPropertyAccessor.RESTRICT_REQUEST_PARAMETERS, OGNLContextPropertyAccessor.RESTRICT_REQUEST_PARAMETERS);
                } else {
                    contextVariablesMap.remove(OGNLContextPropertyAccessor.RESTRICT_REQUEST_PARAMETERS);
                }

            } else {

                if (expContext.getRestrictVariableAccess()) {
                    contextVariablesMap = CONTEXT_VARIABLES_MAP_NOEXPOBJECTS_RESTRICTIONS;
                } else {
                    // Even when expression objects are not required, provide a basic context variables map
                    // to ensure OGNL can correctly resolve variable references, including iteration variables
                    contextVariablesMap = new java.util.HashMap<>();
                    
                    // Add all variables from the Thymeleaf context, including iteration variables
                    if (context instanceof ITemplateContext) {
                        ITemplateContext templateContext = (ITemplateContext) context;
                        for (String varName : templateContext.getVariableNames()) {
                            contextVariablesMap.put(varName, templateContext.getVariable(varName));
                        }
                    }
                }

            }

            // The root object on which we will evaluate expressions will depend on whether a selection target is
            // active or not...
            final ITemplateContext templateContext = (context instanceof ITemplateContext ? (ITemplateContext) context : null);
            final Object evaluationRoot =
                    (useSelectionAsRoot && templateContext != null && templateContext.hasSelectionTarget()? templateContext.getSelectionTarget() : templateContext);

            // Execute the expression!
            final Object result;
            try {
                result = executeExpression(configuration, parsedExpression.expression, contextVariablesMap, evaluationRoot);
            } catch (final OGNLShortcutExpression.OGNLShortcutExpressionNotApplicableException notApplicable) {
                // We tried to apply shortcuts, but it is not possible for this expression even if it parsed OK,
                // so we need to empty the cache and try again disabling shortcuts. Once processed for the first time,
                // an OGNL (non-shortcut) parsed expression will already be cached and this exception will not be
                // thrown again
                invalidateComputedOGNLExpression(configuration, expression, exp);
                return evaluate(context, expression, expContext, false);
            }

            if (!expContext.getPerformTypeConversion()) {
                return result;
            }

            final IStandardConversionService conversionService =
                    StandardExpressions.getConversionService(configuration);

            return conversionService.convert(context, result, String.class);
            
        } catch (final Exception e) {
            e.printStackTrace();
            throw new TemplateProcessingException(
                "Exception evaluating OGNL expression: \"" + expression.getExpression() + "\"", e);
        }
    }

    private static ComputedOGNLExpression obtainComputedOGNLExpression(
            final IEngineConfiguration configuration,
            final IStandardVariableExpression expression, final String exp,
            final StandardExpressionExecutionContext expContext,
            final boolean applyOGNLShortcuts) throws OgnlException {

        // If restrictions apply, we want to avoid applying shortcuts so that we delegate to OGNL validation
        // of method calls and references to allowed classes.
        final boolean doApplyOGNLShortcuts =
            applyOGNLShortcuts &&
                !expContext.getRestrictVariableAccess() && !expContext.getRestrictInstantiationAndStatic();

        if (expContext.getRestrictInstantiationAndStatic()
                && StandardExpressionUtils.containsOGNLInstantiationOrStaticOrParam(exp)) {
            throw new TemplateProcessingException(
                "Instantiation of new objects and access to static classes or parameters is forbidden in this context");
        }

        if (expression instanceof VariableExpression) {

            final VariableExpression vexpression = (VariableExpression) expression;

            Object cachedExpression = vexpression.getCachedExpression();
            if (cachedExpression != null && cachedExpression instanceof ComputedOGNLExpression) {
                return (ComputedOGNLExpression) cachedExpression;
            }
            cachedExpression = parseComputedOGNLExpression(configuration, exp, doApplyOGNLShortcuts);
            if (cachedExpression != null) {
                vexpression.setCachedExpression(cachedExpression);
            }
            return (ComputedOGNLExpression) cachedExpression;
        }

        if (expression instanceof SelectionVariableExpression) {

            final SelectionVariableExpression vexpression = (SelectionVariableExpression) expression;

            Object cachedExpression = vexpression.getCachedExpression();
            if (cachedExpression != null && cachedExpression instanceof ComputedOGNLExpression) {
                return (ComputedOGNLExpression) cachedExpression;
            }
            cachedExpression = parseComputedOGNLExpression(configuration, exp, doApplyOGNLShortcuts);
            if (cachedExpression != null) {
                vexpression.setCachedExpression(cachedExpression);
            }
            return (ComputedOGNLExpression) cachedExpression;
        }
        return parseComputedOGNLExpression(configuration, exp, doApplyOGNLShortcuts);
    }

    private static ComputedOGNLExpression parseComputedOGNLExpression(
            final IEngineConfiguration configuration,
            final String exp, final boolean applyOGNLShortcuts)
            throws OgnlException {

        ComputedOGNLExpression parsedExpression =
                (ComputedOGNLExpression) ExpressionCache.getFromCache(configuration, exp, EXPRESSION_CACHE_TYPE_OGNL);
        if (parsedExpression != null) {
            return parsedExpression;
        }
        // The result of parsing might be an OGNL expression AST or a ShortcutOGNLExpression (for simple cases)
        parsedExpression = parseExpression(exp, applyOGNLShortcuts);
        ExpressionCache.putIntoCache(configuration, exp, parsedExpression, EXPRESSION_CACHE_TYPE_OGNL);
        return parsedExpression;
    }

    private static void invalidateComputedOGNLExpression(
            final IEngineConfiguration configuration, final IStandardVariableExpression expression, final String exp) {

        if (expression instanceof VariableExpression) {
            final VariableExpression vexpression = (VariableExpression) expression;
            vexpression.setCachedExpression(null);
        } else if (expression instanceof SelectionVariableExpression) {
            final SelectionVariableExpression vexpression = (SelectionVariableExpression) expression;
            vexpression.setCachedExpression(null);
        }
        ExpressionCache.removeFromCache(configuration, exp, EXPRESSION_CACHE_TYPE_OGNL);

    }
    @Override
    public String toString() {
        return "AlohaVariableExpressionEvaluator";
    }

    private static ComputedOGNLExpression parseExpression(
            final String expression, final boolean applyOGNLShortcuts)
            throws OgnlException {

        final boolean mightNeedExpressionObjects = StandardExpressionUtils.mightNeedExpressionObjects(expression);

        if (applyOGNLShortcuts) {
            final String[] parsedExpression = OGNLShortcutExpression.parse(expression);
            if (parsedExpression != null) {
                return new ComputedOGNLExpression(new AlohaShortcutExpression(parsedExpression), mightNeedExpressionObjects);
                //return new ComputedOGNLExpression(new OGNLShortcutExpression(parsedExpression), mightNeedExpressionObjects);
            }
        }
        return new ComputedOGNLExpression(Ognl.parseExpression(expression), mightNeedExpressionObjects);
    }

    private static final StaticCache<
        String,
        Method>
        outerObjectMethods = StaticCache.create();
    private static Object executeExpression(
        final IEngineConfiguration configuration, final Object parsedExpression,
        final Map<String,Object> context, final Object root)
        throws Exception {

        if(root instanceof AbstractOneToOne<?,?> o2o) {
            return switch(parsedExpression) {
                case ASTMethod astMethod-> o2o.getClass().getMethod(astMethod.getMethodName()).invoke(o2o);
                case ASTChain astChain-> handle(o2o,astChain,0);
                case AlohaShortcutExpression shortcutExpression->handle(o2o,shortcutExpression.expressionLevels,0);
                default -> throw new RuntimeException("unknown type:" + parsedExpression.getClass().getName());
            };
        }
        if (parsedExpression instanceof ASTChain astChain &&
                astChain.jjtGetNumChildren() > 1 &&
                ((EngineContext) root).getVariable(astChain.jjtGetChild(0).toString()) instanceof AbstractOneToMany<?,?,?> o2m )
            return handle(o2m,astChain);
        if (parsedExpression instanceof AlohaShortcutExpression shortcutExpression &&
                shortcutExpression.expressionLevels.length > 1 &&
                ((EngineContext) root).getVariable(shortcutExpression.expressionLevels[0]) instanceof AbstractOneToMany<?,?,?> o2m )
            return handle(o2m,shortcutExpression.expressionLevels);
        if (parsedExpression instanceof ASTChain astChain &&
            astChain.jjtGetNumChildren() > 1 &&
             ((EngineContext) root).getVariable(astChain.jjtGetChild(0).toString()) instanceof AbstractOneToOne<?,?> o2o ) {
            Object result = handle(o2o, astChain);
            String method = astChain.jjtGetChild(astChain.jjtGetNumChildren() -1).toString();
            if (method.endsWith("()")) {
                method = method.substring(0, method.length() - 2);
                return result.getClass().getMethod(method).invoke(result);
            }
            return result;
        }
        if (parsedExpression instanceof AlohaShortcutExpression shortcutExpression &&
                shortcutExpression.expressionLevels.length > 1 &&
                ((EngineContext) root).getVariable(shortcutExpression.expressionLevels[0]) instanceof AbstractOneToOne<?,?> o2o )
            return handle(o2o,shortcutExpression.expressionLevels);
        if (parsedExpression instanceof ASTChain astChain
                && astChain.jjtGetNumChildren() == 3 ) {
            Node outerObjName = astChain.jjtGetChild(0);
            Node node1 = astChain.jjtGetChild(1);
            Object result = get(
                outerObjName.toString(),
                node1.toString(),
                ((EngineContext)root));
            if ( result == null ) return null; // May Optional
            String method = astChain.jjtGetChild(2).toString();
            if (method.endsWith("()"))
                method = method.substring(0,method.length()-2);
            // Check for list or array index access
            if (method.startsWith("[") && method.endsWith("]")) {
                try {
                    int index = Integer.parseInt(method.substring(1, method.length() - 1));
                    if (result instanceof java.util.List) {
                        java.util.List<?> list = (java.util.List<?>) result;
                        return list.get(index);
                    } else if (result instanceof Object[]) {
                        Object[] array = (Object[]) result;
                        return array[index];
                    }
                } catch (NumberFormatException | IndexOutOfBoundsException e) {
                    throw new RuntimeException("Invalid index access: " + method, e);
                }
            }
            
            try {
                return result.getClass().getMethod(method).invoke(result);
            } catch (IllegalAccessException e) {
                // Try to access private/protected method
                try {
                    var methodObj = result.getClass().getMethod(method);
                    methodObj.setAccessible(true);
                    return methodObj.invoke(result);
                } catch (Exception e2) {
                    throw e;
                }
            }
        }
        if (parsedExpression instanceof ASTChain astChain
                && astChain.jjtGetNumChildren() == 2 ) {

            if (parsedExpression.toString().startsWith("#numbers.sequence(")) {
                String s = parsedExpression.toString();
                String subExpression = s.substring(s.indexOf(",")+1,s.indexOf(")")).trim();
                String chain[] = subExpression.split("\\.");
                if ( chain.length != 0) {
                    Object head = ((EngineContext) root).getVariable(chain[0]);
                    Integer first = Integer.parseInt(s.substring(s.indexOf("(")+1,s.indexOf(",")).trim());
                    final Integer last;
                    if ( head instanceof AbstractView<?> v) {
                        last = get(v,null,chain[1]);
                    } else if ( head instanceof AbstractOneToOne<?,?> o2o) {
                        last = (Integer)handle(o2o,chain);
                    } else if ( head instanceof String idx) {
                        last = Integer.parseInt(idx);
                    } else if ( head instanceof Integer idx) {
                        last = idx;
                    } else if ( head instanceof Byte idx) {
                        last = idx.intValue();
                    } else if ( head instanceof java.math.BigInteger idx) {
                        last = idx.intValue();
                    } else
                        throw new RuntimeException("unknown type:" + head.getClass().getName());
                    Integer[] array = new Integer[last-first+1];
                    for(int i = 0 ; i < array.length ; i++ ) {
                        array[i] = first + i;
                    }
                    return array;
                }
                //int i = Integer.parseInt(subExpression.trim());
            }

            if (parsedExpression.toString().startsWith("#strings.split(")) {
                String s = parsedExpression.toString();
                // `#strings.split(schema.enumValues, ',')` -> `schema.enumValues, ','`
                String subExpression = s.substring(s.indexOf("(")+1, s.lastIndexOf(")")).trim();

                // `schema.enumValues, ','` -> [`schema.enumValues`, `','`]
                String[] parts = subExpression.split(",", 2);
                if (parts.length != 2) {
                    throw new RuntimeException("#strings.split need 2 parameters");
                }

                String strExpression = parts[0].trim();
                String delimiterExpression = parts[1].trim();

                // `schema.enumValues` -> [`schema`, `enumValues`]
                String chain[] = strExpression.split("\\.");
                Object head = ((EngineContext) root).getVariable(chain[0]);
                String value;
                if ( head instanceof AbstractView<?> v) {
                    value = get(v,null,chain[1]);
                } else if ( head instanceof AbstractOneToOne<?,?> o2o) {
                    value = handle(o2o,chain).toString();
                } else
                    throw new RuntimeException("unknown type:" + head.getClass().getName());

                // `','` -> `,`
                String delimiter;
                if (delimiterExpression.startsWith("'") && delimiterExpression.endsWith("'")) {
                    delimiter = delimiterExpression.substring(1, delimiterExpression.length()-1);
                } else {
                    Object delimObj = ((EngineContext) root).getVariable(delimiterExpression);
                    delimiter = delimObj == null ? "" : delimObj.toString();
                }

                String[] array = value.split(delimiter);
                return array;
            }

            Node outerObjName = astChain.jjtGetChild(0);
            Node node1 = astChain.jjtGetChild(1);
            String outerMethodName_InnerObj = node1.toString();
            int indexOfFrom = outerMethodName_InnerObj.indexOf(("("));
            if ( indexOfFrom == -1 ) {
                try {
                    return
                        get(
                            outerObjName.toString(),
                            node1.toString(),
                            ((EngineContext)root));
                } catch (Exception e) {
                    return handleDefault(parsedExpression, context, root);
                }
            }

            String outerMethodName = outerMethodName_InnerObj.substring(0,indexOfFrom);
            String innerObjAndAttr = outerMethodName_InnerObj.substring(indexOfFrom+1,outerMethodName_InnerObj.length()-1);
            String[] chain = innerObjAndAttr.split("\\.");
            if (chain.length > 1 ) {
                EngineContext ctx = (EngineContext) root;
                Object outerObj = ctx.getVariable(outerObjName.toString());
                Method m = outerObjectMethods.getOrCompute(
                    outerObjName + "." + outerMethodName,
                    name ->
                    {
                        for (Method method : outerObj.getClass().getDeclaredMethods()) {
                            if (method.getName().equalsIgnoreCase(outerMethodName)) {
                                return method;
                            }
                        }
                        throw new RuntimeException("Method Not Found:" + name);
                    });
                Object head = ctx.getVariable(chain[0]);
                Object innerResult;
                if (head instanceof AbstractOneToOne<?,?> o2o) {
                    innerResult = handle(o2o, chain);
                } else if (head instanceof AbstractView<?>) {
                    innerResult = get(chain[0], chain[1], ctx);
                } else if (head == null) {
                    innerResult = null;
                } else {
                    return handleDefault(parsedExpression, context, root);
                }

                try {
                    return m.invoke(outerObj, innerResult);
                } catch (Exception e) {
                    return null;
                }
            }
        } else if (parsedExpression instanceof AlohaShortcutExpression expression) {
            return handleAloha(configuration,expression,context,root);
        }
        Object f =  handleDefault(parsedExpression,context,root);
        return f;
    }
    private static Object handle(AbstractOneToMany<?,?,?> o2m, ASTChain astChain) {
        return handle(o2m,astChain,1);
    }
    private static Object handle(AbstractOneToMany<?,?,?> o2m, String[] chain) {
        return handle(o2m,chain,1);
    }
    private static Object handle(AbstractOneToOne<?,?> o2o, ASTChain astChain) {
        return handle(o2o,astChain,1);
    }
    private static Object handle(AbstractOneToOne<?,?> o2o, String[] chain) {
        return handle(o2o,chain,1);
    }
    private static Object handle(AbstractOneToMany<?,?,?> o2m, ASTChain astChain, int indexToOneToManyAccessor) {
        return switch (astChain.jjtGetChild(indexToOneToManyAccessor).toString()) {
            case "one()"->  handle(
                o2m.one,
                "one",
                astChain.jjtGetNumChildren(),
                indexToOneToManyAccessor,
                at->astChain.jjtGetChild(at).toString(),
                (inner_o2o,at)->handle(inner_o2o,astChain,at),
                (inner_o2m,at)->handle(inner_o2m,astChain,at));
            case "many()"-> o2m.many.unsafeGet();
            default->
                call(
                    o2m,
                    astChain.jjtGetChild(indexToOneToManyAccessor).toString(),
                    astChain.jjtGetNumChildren(),
                    indexToOneToManyAccessor,
                    (inner_o2o,at)->handle(inner_o2o,astChain,at));
        };
    }
    private static Object handle(AbstractOneToMany<?,?,?> o2m, String[] chain, int indexToOneToManyAccessor) {
        return switch (chain[indexToOneToManyAccessor]) {
            case "one"->  handle(
                o2m.one,
                "one",
                chain.length,
                indexToOneToManyAccessor,
                at->chain[at],
                (inner_o2o,at)->handle(inner_o2o,chain,at),
                (inner_o2m,at)->handle(inner_o2m,chain,at));
            case "many"-> o2m.many.unsafeGet();
            default->
                call(
                    o2m,
                    chain[indexToOneToManyAccessor],
                    chain.length,
                    indexToOneToManyAccessor,
                    (inner_o2o,at)->handle(inner_o2o,chain,at));
        };
    }
    private static Object
    call(
        AbstractOneToMany<?,?,?> o2m,
        String method,
        int chainSize,
        int currentIndex,
        BiFunction<AbstractOneToOne<?,?>,Integer,Object> recursiveCallo2o) {

        try {
            if (method.endsWith("()"))
                method = method.substring(0,method.length()-2);
            Object result = o2m.getClass().getMethod(method).invoke(o2m);
            return result instanceof Monad.MayEmpty<?> many ?
                many.unsafeGet() :
                result instanceof AbstractOneToOne<?,?> o2o && chainSize > currentIndex+1 ?
                    recursiveCallo2o.apply(o2o,currentIndex+1) : result;
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }
    private static Object handle(AbstractOneToOne<?,?> o2o, ASTChain astChain, int indexToOneToOneAccessor) {
        return switch (astChain.jjtGetChild(indexToOneToOneAccessor).toString()) {
            case "left()","left"->  handle(
                    o2o.left,
                    "left",
                    astChain.jjtGetNumChildren(),
                    indexToOneToOneAccessor,
                    at->astChain.jjtGetChild(at).toString(),
                    (inner_o2o,at)->handle(inner_o2o,astChain,at),
                    (inner_o2m,at)->handle(inner_o2m,astChain,at));
            case "right()","right"-> handle(
                    o2o.right,
                    "right",
                    astChain.jjtGetNumChildren(),
                    indexToOneToOneAccessor,
                    at->astChain.jjtGetChild(at).toString(),
                    (inner_o2o,at)->handle(inner_o2o,astChain,at),
                    (inner_o2m,at)->handle(inner_o2m,astChain,at));
            default-> throw new RuntimeException(astChain.jjtGetChild(indexToOneToOneAccessor).toString());
        };
    }
    private static Object handle(AbstractOneToOne<?,?> o2o, String[] chain, int indexToOneToOneAccessor) {
        return switch (chain[indexToOneToOneAccessor]) {
            case "left"->  handle(
                o2o.left,
                "left",
                chain.length,
                indexToOneToOneAccessor,
                at->chain[at],
                (inner_o2o,at)->handle(inner_o2o,chain,at),
                (inner_o2m,at)->handle(inner_o2m,chain,at));
            case "right"-> handle(
                o2o.right,
                "right",
                chain.length,
                indexToOneToOneAccessor,
                at->chain[at],
                (inner_o2o,at)->handle(inner_o2o,chain,at),
                (inner_o2m,at)->handle(inner_o2m,chain,at));
            default-> {
                try {
                    Object result =
                        o2o.getClass().getMethod(
                        chain[indexToOneToOneAccessor]).invoke(o2o);
                    yield handle(
                        result,
                        chain[indexToOneToOneAccessor],
                        chain.length,
                        indexToOneToOneAccessor,
                        at->chain[at],
                        (inner_o2o,at)->handle(inner_o2o,chain,at),
                        (inner_o2m,at)->handle(inner_o2m,chain,at));
                } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }
    private static <T> Object handle(
        Object which,
        String nameOfWhich,
        int chainSize,
        int index,
        Function<Integer,String> attrNameAt,
        BiFunction<AbstractOneToOne<?,?>,Integer,Object> recursiveCallo2o,
        BiFunction<AbstractOneToMany<?,?,?>,Integer,Object> recursiveCallo2m) {
        return which instanceof AbstractOneToOne<?,?> o2o ?
            chainSize == index+1 ? o2o : recursiveCallo2o.apply(o2o,index+1) :
            which instanceof AbstractOneToMany<?,?,?> o2m ?
                chainSize == index+1 ? o2m : recursiveCallo2m.apply(o2m,index+1) :
                chainSize == index+1 ?
                    getOrNull(which) :
                    handle(which,nameOfWhich,chainSize,index,attrNameAt);
    }
    private static Object handle(
        Object which,
        String nameOfWhich,
        int chainSize,
        int index,
        Function<Integer,String> attrNameAt) {

        Object result = get(which,nameOfWhich,attrNameAt.apply(index+1));
        if (result == null) return null;
        return switch (result) {
            case Record<?> record->
                handle(record,attrNameAt,chainSize,index);
            case AbstractView<?> view->
                get(view,nameOfWhich,attrNameAt.apply(index+2));
            default -> result;
        };
    }
    private static Object handle(
        Record<?> recordResult,
        Function<Integer,String> attrNameAt,
        int chainSize,
        int index) {

        return (index+2 < chainSize) ?
            get(
                recordResult,
                attrNameAt.apply(index+1),
                attrNameAt.apply(index+2)) :
            recordResult;
    }
    private static String getOrNull(Object which) {
        return switch (which) {
            case Comparable<?> c-> c.toString();
            case AbstractView<?> v-> v.toString();
            case MayNullVO<?> vo-> vo.apply(Object::toString,()->null);
            case AttributeRecord<?> r -> r.toString();
            default -> throw new IllegalStateException("Unexpected value: " + which);
        };
    }
    private static Object handleAloha(
        final IEngineConfiguration configuration,
        AlohaShortcutExpression expression,
        final Map<String,Object> context,
        final Object root) throws Exception {
        if ( expression.expressionLevels.length > 1) {
            return get(
                expression.expressionLevels[0],
                expression.expressionLevels[1],
                (EngineContext)root);
        }
        return expression.evaluate(configuration, context, root);
    }
    private static Object
    handleDefault(
        final Object parsedExpression,
        final Map<String,Object> context,
        final Object root) throws OgnlException {
        // We create the OgnlContext here instead of just sending the Map as context because that prevents OGNL from
        // creating the OgnlContext empty and then setting the context Map variables one by one
        final OgnlContext ognlContext = new OgnlContext(MEMBER_ACCESS, CLASS_RESOLVER, null, context);
        return Ognl.getValue(parsedExpression, ognlContext, root);
    }
    private static final StaticCache<
        String,
        MayNull<AbstractField.TypedMember<?>>>
        nameToMembers = StaticCache.create();

    private static
    <T>
    T
    get(String objName, String attrName, EngineContext context) {
        return get(context.getVariable(objName),objName, attrName);
    }
    private static
    <T>
    T
    get(Object obj, String objName, String attrName) {
        if (obj instanceof MayNullVO<?> mayNullVO) {
            return mayNullVO.apply(
                nn->get(nn,objName,attrName),
                ()->null);
        }
        final String normalizedAttrName =
            attrName != null && attrName.endsWith("()")
                ? attrName.substring(0, attrName.length() - 2)
                : attrName;
        return switch (obj) {
            case AbstractView<?> view -> get(view, objName, normalizedAttrName);
            case Record<?> record-> get(record,normalizedAttrName);
            default -> {
                // Process java objects like records
                try {
                    String methodName = normalizedAttrName;
                    var method = obj.getClass().getMethod(methodName);
                    Object result = method.invoke(obj);
                    yield (T) result;
                } catch (NoSuchMethodException e1) {
                    // Try reflection to access field directly
                    try {
                        var field = obj.getClass().getDeclaredField(normalizedAttrName);
                        field.setAccessible(true);
                        Object result = field.get(obj);
                        yield (T) result;
                    } catch (Exception e3) {
                        yield null;
                    }
                } catch (Exception e1) {
                    yield null;
                }
            }
        };
    }
    @SuppressWarnings("unchecked")
    static
    <T extends Comparable<? super T>>
    T
    get(AbstractView<?> view, String objName, String attrName) {
        final MayNull<AbstractField.TypedMember<?>> m;
        if( view.field() instanceof Field.ofStarView.Around<?,?> field) {
            if ( !field.entity().getClass().getSimpleName().equalsIgnoreCase(objName)
                    || Engine.mode == Engine.HOT_RELOAD.ON ) {
                m = member(view, attrName);
            } else {
                m = nameToMembers.getOrCompute(
                    objName + "." + attrName,
                    _ ->
                        member(view,  attrName));
            }
        } else {
            m = member(view,  attrName);
        }
        return (T) m.apply(
            tm->
                switch (tm) {
                    case AbstractField.Member.Mandatory<?> man->
                        view.mandatoryValue(_->(AbstractField.Member.Mandatory<T>)man);
                    case AbstractField.Member.Optional<?> opt->
                        view.optionalValue(_->(AbstractField.Member.Optional<T>)opt).apply(v->v,()->null);
                },
                ()-> {
                    try {
                        return view.getClass().getMethod(attrName).invoke(view);
                    } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                        throw new RuntimeException(e);
                    }
                });
    }
    @SuppressWarnings("unchecked")
    private static
    <T extends Comparable<? super T>>
    T
    get(Record<?> record, String methodName) {
        try {
            String normalizedMethodName = methodName != null && methodName.endsWith("()")
                ? methodName.substring(0, methodName.length() - 2)
                : methodName;
            if ( record instanceof AttributeRecord<?> a &&
                    record instanceof Record.SinglePK.WithEntity<?,?> e) {
                if (
                    e.entity().column().asIColumnArray().contains(c->c.getJavaName().equalsIgnoreCase(normalizedMethodName))) {
                    return (T) a.attributeValue();
                }
            }
            return (T) record.getClass().getMethod(normalizedMethodName).invoke(record);
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }
    private static
    MayNull<AbstractField.TypedMember<?>>
    member(AbstractView<?> view, String attrName) {
        for (AbstractField.Member.Mandatory<?> member : Unsafe.
                mandatoryMembersOf(view.field())) {
            if (member.javaName().equalsIgnoreCase(attrName)) {
                return MayNull.of(member);
            }
        }
        for (AbstractField.Member.Optional<?> member : Unsafe.
                optionalMembersOf(view.field())) {
            if (member.javaName().equalsIgnoreCase(attrName)) {
                return MayNull.of(member);
            }
        }
        return MayNull.nullInstance();
    }

    private static final class ComputedOGNLExpression {

        final Object expression;
        final boolean mightNeedExpressionObjects;

        ComputedOGNLExpression(final Object expression, final boolean mightNeedExpressionObjects) {
            super();
            this.expression = expression;
            this.mightNeedExpressionObjects = mightNeedExpressionObjects;
        }
    }

    static final class ThymeleafACLClassResolver implements ClassResolver {

        private final ClassResolver classResolver;

        public ThymeleafACLClassResolver() {
            super();
            this.classResolver = new ThymeleafDefaultClassResolver();
        }

        @Override
        public Class<?> classForName(final String className, final Map context) throws ClassNotFoundException {
            if (!ExpressionUtils.isTypeAllowed(className)) {
                throw new TemplateProcessingException(
                        String.format(
                                "Access is forbidden for type '%s' in this expression context.", className));

            }
            return this.classResolver.classForName(className, context);
        }
    }

    /*
     * We need to implement this instead of directly using OGNL's DefaultClassResolver because OGNL's
     * will always try to prepend "java.lang." to classes that it cannot find, which in our case is dangerous.     *
     * Other than that, the code in this class is the same as "ognl.DefaultClassResolver".
     */
    static final class ThymeleafDefaultClassResolver implements ClassResolver {

        private final ConcurrentHashMap<String, Class> classes = new ConcurrentHashMap<>(101);

        ThymeleafDefaultClassResolver() {
            super();
        }

        public Class classForName(final String className, final Map context) throws ClassNotFoundException {
            Class result = this.classes.get(className);
            if (result != null) {
                return result;
            }
            try {
                result = toClassForName(className);
            } catch (ClassNotFoundException e) {
                throw e;
            }
            this.classes.putIfAbsent(className, result);
            return result;
        }

        private Class toClassForName(String className) throws ClassNotFoundException {
            return Class.forName(className);
        }
    }

    static final class ThymeleafACLMemberAccess extends AbstractMemberAccess {

        ThymeleafACLMemberAccess() {
            super();
        }

        @Override
        public boolean isAccessible(final Map context, final Object target, final Member member, final String propertyName) {
            int modifiers = member.getModifiers();
            if (!Modifier.isPublic(modifiers)) {
                return false;
            }
            if (member instanceof Method) {
                if (!ExpressionUtils.isMemberAllowed(target, member.getName())) {
                    throw new TemplateProcessingException(
                            String.format(
                                    "Accessing member '%s' is forbidden for type '%s' in this expression context.",
                                    member.getName(), target.getClass()));
                }
            }
            return true;
        }
    }
}
