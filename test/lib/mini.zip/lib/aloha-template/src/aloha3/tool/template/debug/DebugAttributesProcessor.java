package aloha3.tool.template.debug;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.AbstractElementTagProcessor;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.templatemode.TemplateMode;

public class DebugAttributesProcessor extends AbstractElementTagProcessor {

    private static final String ATTR_SRC = "data-thymeleaf-src";

    public DebugAttributesProcessor(String dialectPrefix) {
        super(
            TemplateMode.HTML,
            dialectPrefix,
            null, // 匹配所有标签
            false,
            null,
            true,
            1000
        );
    }

    @Override
    protected void doProcess(
        ITemplateContext context,
        IProcessableElementTag tag,
        IElementTagStructureHandler structureHandler
    ) {
        final String templateName = context.getTemplateData().getTemplate();
        final String templateNameWithExt = templateName.endsWith(".html") ? templateName : templateName + ".html";
        final int line = tag.getLine();

        structureHandler.setAttribute(ATTR_SRC, templateNameWithExt + ":" + line);
    }
}