package aloha3.tool.template;

import aloha3.tool.template.debug.DebugDialect;
import org.thymeleaf.ITemplateEngine;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.standard.StandardDialect;
import org.thymeleaf.standard.expression.AlohaVariableExpressionEvaluator;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.WebApplicationTemplateResolver;
import org.thymeleaf.web.IWebApplication;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Engine {

    static Path path = null;

    public static final class WebApplication implements IWebApplication {

        private final Map<String,Object> attributeMap = new HashMap<>();
        final Path dir;

        public WebApplication(Path dir) {
            this.dir = dir;
            Engine.path = dir;
        }

        @Override
        public boolean containsAttribute(String name) {
            return attributeMap.containsKey(name);
        }
        @Override
        public int getAttributeCount() {
            return attributeMap.size();
        }
        @Override
        public Set<String> getAllAttributeNames() {
            return attributeMap.keySet();
        }
        @Override
        public Map<String, Object> getAttributeMap() {
            return attributeMap;
        }
        @Override
        public Object getAttributeValue(String name) {
            return attributeMap.get(name);
        }
        @Override
        public void setAttributeValue(String name, Object value) {
            attributeMap.put(name,value);
        }
        @Override
        public void removeAttribute(String name) {
            attributeMap.remove(name);
        }
        @Override
        public boolean resourceExists(String path) {
            return false;
        }
        @Override
        public InputStream getResourceAsStream(String path) {
            try {
                if (this.dir.getFileSystem().toString().endsWith(".jar")) {
                    // JARファイルの中のwwwフォルダの中のパス
                    String jarPath = "jar:file:" + this.dir.getFileSystem() + "!/www" + path;
                    // +2の目的：`!/www/...` から `www/...`を取得（「!/」を除去）
                    return this.getClass().getClassLoader().getResourceAsStream(
                        jarPath.substring(jarPath.indexOf("!") + 2));
                } else {
                    String relativePath = path.startsWith("/") ? path.substring(1) : path;
                    // wwwディレクトリの相対パスを結合
                    Path fullPath = this.dir.endsWith("www") ? this.dir.resolve(relativePath) : this.dir.resolve("www").resolve(relativePath);
                    return new FileInputStream(fullPath.toFile());
                }
            } catch (Exception e) {
                throw new RuntimeException("Failed to load resource: " + path, e);
            }
        }
    } // WebApplication
    public static final String DEFAULT_TEMPLATE_PREFIX = "/WEB-INF/templates/";
    public enum HOT_RELOAD { ON, OFF }
    public enum DEBUG { ON, OFF }
    public static 
    ITemplateEngine 
    buildTemplateEngine(final IWebApplication application) {
        
        return buildTemplateEngine(application,HOT_RELOAD.ON, DEBUG.ON);
    }
    public static HOT_RELOAD mode;
    public static 
    AlohaTemplateEngine 
    buildTemplateEngine(
        final IWebApplication application, 
        HOT_RELOAD hotReload, 
        DEBUG debug) {

        // テンプレートはアプリケーション（ServletContext）リソースとして解釈されます
        final WebApplicationTemplateResolver templateResolver =
            new WebApplicationTemplateResolver(application);

        // HTMLはデフォルトのモードなのですが、コードを理解しやすくするために
        // 設定しておきます
        templateResolver.setTemplateMode(TemplateMode.HTML);
        // "home"を"/WEB-INF/templates/home.html"に変換します
        templateResolver.setPrefix(DEFAULT_TEMPLATE_PREFIX);
        templateResolver.setSuffix(".html");
        // テンプレートキャッシュのTTLを1時間に設定します。
        // 未設定の場合、エントリーはLRUで追い出されるまで保持されます
        templateResolver.setCacheTTLMs(Long.valueOf(3600000L));

        // キャッシュはデフォルトでtrueにセットされています。
        // テンプレートの変更を自動的に反映したい場合はfalseにセットします。
        templateResolver.setCacheable(hotReload == HOT_RELOAD.OFF);
        mode = hotReload;
        templateResolver.setCharacterEncoding("utf-8");

        TemplateEngine templateEngine = new TemplateEngine();
        StandardDialect dialect = new Dialect("webc");
        dialect.setVariableExpressionEvaluator(new AlohaVariableExpressionEvaluator(true));
        templateEngine.setDialect(dialect);
        // DebugDialectの目的：thymeleafのhtmlにファイルと行数を追加する
        if (debug == DEBUG.ON) {
            templateEngine.addDialect(new DebugDialect());
        }
        templateEngine.setTemplateResolver(templateResolver);

        return new AlohaTemplateEngine(templateEngine);
    }
    private static final class Dialect
        extends StandardDialect {
        Dialect(String prefix) {
            super("Aloha",prefix,1000);
        }
    }
}
