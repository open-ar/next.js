package aloha3.tool.template;

import aloha.StaticCache;
import aloha.module.func.Func;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.Unsafe;
import org.thymeleaf.context.AbstractContext;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static java.beans.Introspector.decapitalize;

public class Context extends AbstractContext {

    private Context(final Locale locale, final Map<String, Object> variables) {
        super(locale, variables);
    }

    public static class Builder {
        @SuppressWarnings({"rawtypes","unchecked"})
        final Context ctx = new Context(Locale.JAPAN,(Map) utilityMap.get());

        public static Builder create(){ return new Builder(); }
        public Builder add(AbstractView<?> view) {
            return add(
                fieldNameExceptSuffix(view),
                view);
        }
        public Builder add(ImmutVOs<? extends AbstractView<?>> views) {
            return views.apply(
                nonEmpty->
                    add(fieldNameExceptSuffix(nonEmpty.first()) + "s",
                        views.asList()).
                    add(
                        fieldNameExceptSuffix(nonEmpty.first()) + "_columns",
                        Func.accept(
                            new ArrayList<>(),
                            names->
                                Unsafe.allMembersOf(nonEmpty.first().field()).
                                    forEach(member->names.add(member.javaName())))),
                ()->this);
        }
        public Builder add(String ctxName, ImmutVOs<? extends AbstractView<?>> views) {
            add(ctxName, views.asList());
            return views.apply(
                nonEmpty->
                    add(
                        ctxName + "_columns",
                        Func.accept(
                            new ArrayList<>(),
                            names->
                                Unsafe.allMembersOf(nonEmpty.first().field()).
                                    forEach(member->names.add(member.javaName())))),
                ()->this);
        }
        private String fieldNameExceptSuffix(AbstractView<?> view) {
            return Func.apply(
                view.field().getClass().getSimpleName(),
                fieldName->
                    decapitalize(
                        fieldName.
                            substring(
                                0,
                                fieldName.indexOf("Field"))));
        }
        public Builder add(String name, Object object) {
            if (object instanceof ImmutableArray<?> alohaArray) {
                object = alohaArray.asList();
            }

            if( object == null || object.toString().isEmpty() )
                object = " ";

            if ( ctx.containsVariable(name) )
                throw new RuntimeException("Already given :" + name +
                    "as " + ctx.getVariable(name).getClass().getName());

            ctx.setVariable(name,object);
            return this;
        }
        public Builder addStream(Runnable stream) {
            return add("stream",stream);
        }
        public Context build() {return ctx;}
    } //
    public static class UtilityBuilder<E extends Enum<E> & UtilityKey> {

        private UtilityBuilder(){}

        public static
        <E extends Enum<E> & UtilityKey>
        UtilityBuilder<E>
        create(Class<E> utilityKeyClass) {
            utilities.compareAndSet(null,new EnumMap<>(utilityKeyClass));
            return new UtilityBuilder<>();
        }
        private static final StaticCache<Class<? extends StateLessUtility<?>>,StateLessUtility<?>>
            utils = StaticCache.create();
        public
        UtilityBuilder<E>
        add(Class<? extends StateLessUtility<E>> utilClass) {
            @SuppressWarnings({"unchecked"})
            StateLessUtility<E> util = (StateLessUtility<E>) utils.getOrCompute(
                utilClass,
                _-> {
                    try {
                        return utilClass.getConstructor().newInstance();
                    } catch (InstantiationException | IllegalAccessException | InvocationTargetException |
                             NoSuchMethodException e) {
                        throw new RuntimeException(e);
                    }
                });
            E key = util.key();
            @SuppressWarnings({"rawtypes","unchecked"})
            EnumMap<E,StateLessUtility<E>> map = (EnumMap)utilities.get();
            if( map.containsKey(key) )
                throw new RuntimeException("Duplicated key:" + key.name());
            map.put(key, util);
            return this;
        }
        public Map<String,? extends StateLessUtility<?>> doneFunc() {
            return doneFunc("func");
        }
        public Map<String,? extends StateLessUtility<?>> doneFunc(String name) {

            Map<String,StateLessUtility<?>> mutable = new HashMap<>(toMap());
            mutable.put(name,new Func<E>());
            utilityMap.set(Collections.unmodifiableMap(mutable));
            return utilityMap.get();
        }
        @SuppressWarnings({"unchecked","rawtypes"})
        public Map<String,? extends StateLessUtility<E>> done() {

            utilityMap.set(toMap());
            return (Map) utilityMap.get();
        }
        public static final class Func<E extends Enum<E> & UtilityKey>
            implements StateLessUtility<E> {

            public String run(Runnable runnable) {
                runnable.run();
                return runnable.getClass().getName() + " completed";
            }
            @Override
            public E key() {
                throw new RuntimeException("never");
            }
        } // Func
    } // UtilityBuilder

    private static final AtomicReference<EnumMap<? extends UtilityKey,StateLessUtility<?>>>
        utilities = new AtomicReference<>();
    private static final AtomicReference<Map<String,StateLessUtility<?>>>
        utilityMap = new AtomicReference<>();
    private static Map<String,StateLessUtility<?>> toMap() {
        Map<String,StateLessUtility<?>> map = new HashMap<>();
        utilities.get().forEach(
            (k,v)->map.put(k.nameInContext(),v));
        return Collections.unmodifiableMap(map);
    }
    public interface UtilityKey {
        default String nameInContext() { return this.toString().toLowerCase() + "s"; }
    }
    public interface StateLessUtility<E extends Enum<?> & UtilityKey> {
        E key();
    }
}
