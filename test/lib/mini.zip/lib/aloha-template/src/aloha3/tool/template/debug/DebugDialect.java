package aloha3.tool.template.debug;

import org.thymeleaf.dialect.AbstractProcessorDialect;
import org.thymeleaf.processor.IProcessor;

import java.util.HashSet;
import java.util.Set;

public class DebugDialect extends AbstractProcessorDialect {

    public DebugDialect() {
        super("Aloha Debug", "debug", 1000);
    }

    @Override
    public Set<IProcessor> getProcessors(String dialectPrefix) {
        Set<IProcessor> processors = new HashSet<>();
        processors.add(new DebugAttributesProcessor(dialectPrefix));
        return processors;
    }
}