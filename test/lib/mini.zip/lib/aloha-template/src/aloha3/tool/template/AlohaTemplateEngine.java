package aloha3.tool.template;

import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.ITemplateEngine;
import org.thymeleaf.IThrottledTemplateProcessor;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.TemplateSpec;
import org.thymeleaf.context.IContext;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.Writer;
import java.util.HashSet;
import java.util.Set;

public record AlohaTemplateEngine(TemplateEngine templateEngine) implements ITemplateEngine {

    @Override
    public IEngineConfiguration getConfiguration() {
        return templateEngine.getConfiguration();
    }
    @Override
    public String process(String template, IContext context) {

        String[] ss = template.trim().split("::");

        if (ss.length == 1)
            return templateEngine.process(template, context);

        final int parameterStart = ss[1].trim().indexOf("(");
        Set<String> selectors = new HashSet<>();
        final Object[] values;
        if (parameterStart == -1) {
            selectors.add(ss[1].trim());
            return templateEngine.
                process(
                    ss[0].trim(),
                    selectors,
                    context);
        }
        final String method = ss[1].trim().substring(0, parameterStart);
        selectors.add(method);
        String mayParameters = ss[1].trim().
            substring(
                parameterStart + 1,
                ss[1].trim().indexOf(")"));
        String[] parameters = mayParameters.split(",");
        values = new Object[parameters.length];
        int i = 0;
        for(String parameter : parameters)
            if (parameter.startsWith("'") && parameter.endsWith("'"))
                values[i++] = parameter.substring(1,parameter.length()-1);
            else
                values[i++] = parameter;

        try (var fio = new FileInputStream(
            Engine.path + Engine.DEFAULT_TEMPLATE_PREFIX +
                ss[0].trim() + ".html")) {
            String read = new String(fio.readAllBytes());
            String methodStart = read.substring(read.indexOf(method));

            String mayVarNames = methodStart.
                substring(
                    methodStart.indexOf("(") + 1,
                    methodStart.indexOf(")"));
            String[] varNames = mayVarNames.split(",");
            i = 0;
            for (String varName : varNames)
                ((Context) context).
                    setVariable(
                        varName,
                        values[i++]);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return templateEngine.
            process(
                ss[0].trim(),
                selectors,
                context);
    }
    @Override
    public String process(String template, Set<String> templateSelectors, IContext context) {
        return templateEngine.process(template,templateSelectors,context);
    }
    @Override
    public String process(TemplateSpec templateSpec, IContext context) {
        return templateEngine.process(templateSpec,context);
    }
    @Override
    public void process(String template, IContext context, Writer writer) {
        templateEngine.process(template,context,writer);
    }
    @Override
    public void process(String template, Set<String> templateSelectors, IContext context, Writer writer) {
        templateEngine.process(template,templateSelectors,context,writer);
    }
    @Override
    public void process(TemplateSpec templateSpec, IContext context, Writer writer) {
        templateEngine.process(templateSpec,context,writer);
    }
    @Override
    public IThrottledTemplateProcessor processThrottled(String template, IContext context) {
        return templateEngine.processThrottled(template,context);
    }
    @Override
    public IThrottledTemplateProcessor processThrottled(String template, Set<String> templateSelectors, IContext context) {
        return templateEngine.processThrottled(template,templateSelectors,context);
    }
    @Override
    public IThrottledTemplateProcessor processThrottled(TemplateSpec templateSpec, IContext context) {
        return templateEngine.processThrottled(templateSpec,context);
    }
}
