package aloha3.controller.query.vo.form;

import aloha.module.object.ValueObject;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.document.record.NestedElement;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.view.TxStarView;

/**
 * Shared value objects and utilities for form values.
 */
public final class FormValues {

    private FormValues() {}

    /**
     * Extract IndexedValue from DocumentLineItem with arrayIndex support.
     * Handles backwards compatibility (default arrayIndex = 1).
     * 
     * This is shared utility used by both edit view and list view to ensure
     * consistent ArrayIndex extraction logic.
     */
    public static 
    IndexedValue 
    extractIndexedValue(
        TxStarView.Read<DocumentLineItemField> documentLineItemView) {
        
        return 
            new IndexedValue(
                documentLineItemView
                    .optionalValue(f -> f.ArrayIndex)
                    .apply(v -> v, () -> (byte) 1),
                documentLineItemView.mandatoryValue(f -> f.Value),
                documentLineItemView.txRead().getTxId());
    }

    /**
     * Value object representing a document line item value with its array index.
     * Used for sparse array support (歯抜け) - gaps in indices are natural.
     * 
     * @param arrayIndex 1-based index position (must be >= 1)
     * @param value      The actual value stored
     * @param documentLineItemId The ID of the document line item
     */
    public record 
    IndexedValue(
        byte arrayIndex, 
        String value, long 
        documentLineItemId
    ) implements ValueObject {
        
        public IndexedValue {
            if (arrayIndex < 1) {
                throw new IllegalArgumentException("arrayIndex must be >= 1");
            }
            if (value == null) {
                throw new IllegalArgumentException("value must not be null (use empty string if needed)");
            }
        }
    }

    /**
     * Wrapper for TxModel.ChildValue that includes arrayIndex.
     * Used during data persistence to save the array index along with the value.
     */
    public record 
    ChildValueWithIndex(
        TxModel.ChildValue<NestedElement, String> childValue,
        byte arrayIndex
    ) implements aloha.module.object.ValueObject {

        public ChildValueWithIndex {
            if (arrayIndex < 1) {
                throw new IllegalArgumentException("arrayIndex must be >= 1");
            }
        }
    }
}
