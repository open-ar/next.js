package aloha3.controller.query.vo;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha3.controller.query.vo.form.FormStructure;
import aloha3.controller.query.vo.form.FormValues;
import aloha3.controller.tool.query.VoUtils;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.module.object.model.OneToMany;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * View model for registerDocument list section.
 */
public record RegisterDocumentListView(List<DocumentListRow> rows) {

    private static final Logger logger = LoggerFactory.getLogger(RegisterDocumentListView.class);

    public static <
        F extends AbstractSubmitField> 
    RegisterDocumentListView 
    create(
        ImmutableArray<
            OneToMany<
                OneToOne<
                    OneToOne<
                        StarView.Read<FormField>,
                        TxStarView.Read<DocumentField>>, 
                    TxStarView.Read<F>>, 
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                OneToOne<
                                    TxStarView.Read<F>, 
                                    TxStarView.Read<DocumentLineItemField>>, 
                                StarView.Hierarchy.Read<NestedElementField>>, 
                            StarView.Read<FormElementField>>, 
                        TxStarView.Read<DocumentField>>, 
                    StarView.Read<FormField>>>> models,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
        Map<Integer, List<FormStructure.FormTree>> formTreesByFormId) {

        return 
            new RegisterDocumentListView(
                models.
                    asList().
                    stream().
                    map(model ->
                        DocumentListRow.create(model, submitAttrSchemas, formTreesByFormId)).
                    collect(Collectors.toList()));
    }

    public boolean isEmpty() {
        return rows.isEmpty();
    }

    public record 
    DocumentListRow(
        long documentId,
        int formId,
        String formName,
        long submitId,
        List<SubmitAttrValue> submitAttributes,
        List<FormTreeDetailNode> formTreeDetails) {

        public static <
            F extends AbstractSubmitField> 
        DocumentListRow 
        create(
            OneToMany<
                OneToOne<
                    OneToOne<
                        StarView.Read<FormField>, 
                        TxStarView.Read<DocumentField>>, 
                    TxStarView.Read<F>>, 
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                OneToOne<
                                    TxStarView.Read<F>,
                                    TxStarView.Read<DocumentLineItemField>>, 
                                StarView.Hierarchy.Read<NestedElementField>>,
                            StarView.Read<FormElementField>>, 
                        TxStarView.Read<DocumentField>>, 
                    StarView.Read<FormField>>> model,
            ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
            Map<Integer, List<FormStructure.FormTree>> formTreesByFormId) {

            var formView = model.one.left.left;
            var documentView = model.one.left.right;
            var submitView = model.one.right;
            long documentId = documentView.txRead().getTxId();
            int formId = formView.mandatoryValue(FormField::FormId);

            List<SubmitAttrValue> submitAttrs = SubmitAttrValue.create(submitView, submitAttrSchemas);
            LineItemBuckets buckets = LineItemBuckets.from(model.many);
            if (logger.isDebugEnabled()) {
                logger.debug("doc={} valueBuckets={}", documentId, buckets.describe());
                logger.debug("doc={} formId={} templates={}",
                        documentId,
                        formId,
                        describeTemplates(formTreesByFormId.get(formId)));
            }
            List<FormTreeDetailNode> formTreeDetails = FormTreeDetailNode.buildFromTemplates(
                    documentId,
                    formTreesByFormId.get(formId),
                    buckets);

            return 
                new DocumentListRow(
                    documentId,
                    formId,
                    formView.mandatoryValue(f -> f.Name),
                    submitView.txRead().getTxId(),
                    submitAttrs,
                    formTreeDetails);
        }
    }

    public record SubmitAttrValue(String field, String value) {

        public static 
        List<SubmitAttrValue> 
        create(
            TxStarView.Read<? extends AbstractSubmitField> submitView,
            ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas) {

            return submitAttrSchemas.asList().stream().map(schema -> {
                var fieldName = schema.mandatoryValue(f -> f.Field);
                return new SubmitAttrValue(fieldName, resolveSubmitAttr(submitView, fieldName));
            }).toList();
        }

        private static 
        String 
        resolveSubmitAttr(
            TxStarView.Read<? extends AbstractSubmitField> submitView,
            String fieldName) {

            Field memberField = findMemberField(submitView.field().getClass(), fieldName);
            if (memberField == null) {
                return "";
            }
            memberField.setAccessible(true);

            try {
                return submitView.mandatoryValue(f -> {
                    try {
                        @SuppressWarnings("unchecked")
                        AbstractField.Member.Mandatory<String> member = (AbstractField.Member.Mandatory<String>) memberField
                                .get(f);
                        return member;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                });
            } catch (RuntimeException ex) {
                return "";
            }
        }

        private static 
        Field 
        findMemberField(
            Class<?> clazz,
            String candidate) {

            List<String> names = List.of(candidate, VoUtils.capitalize(candidate), VoUtils.decapitalize(candidate));
            for (String name : names) {
                try {
                    Field field = clazz.getField(name);
                    if (AbstractField.Member.class.isAssignableFrom(field.getType())) {
                        return field;
                    }
                } catch (NoSuchFieldException ignored) {
                }
            }
            return null;
        }

    }

    public record 
    FormTreeDetailNode(
        FormStructure.FormTreeNode node,
        List<FormTreeDetailInstance> instances) {

        static 
        List<FormTreeDetailNode> 
        buildFromTemplates(
            long documentId,
            List<FormStructure.FormTree> templates,
            LineItemBuckets buckets) {

            if (templates == null || templates.isEmpty()) {
                return List.of();
            }

            return templates.stream().
                map(template -> 
                    buildNode(documentId, template.node(), template.instances(), buckets)).
                flatMap(Optional::stream).collect(Collectors.toList());
        }

        private static 
        Optional<FormTreeDetailNode> 
        buildNode(
            long documentId,
            FormStructure.FormTreeNode node,
            List<FormStructure.FormTreeNodeInstance> instances,
            LineItemBuckets buckets) {

            List<FormTreeDetailInstance> detailInstances = new ArrayList<>();
            for (FormStructure.FormTreeNodeInstance instance : instances) {
                List<FormTreeDetailNode> childNodes = instance.childGroups().stream().
                    map(group -> 
                        buildNode(documentId, group.node(), group.instances(), buckets)).
                    flatMap(Optional::stream).toList();

                if (node.hasChildren()) {
                    if (childNodes.isEmpty()) {
                        continue;
                    }
                    detailInstances.add(new FormTreeDetailInstance(
                            childNodes,
                            List.of()));
                } else {
                    Integer nestedElementId = node.nestedElementId();
                    if (nestedElementId == null) {
                        continue;
                    }
                    FormValues.IndexedValue value = buckets.findByArrayIndex(nestedElementId,
                            instance.inputIndex());
                    if (value == null) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("doc={} node={} nestedElementId={} has no remaining values",
                                    documentId, node.name(), nestedElementId);
                        }
                        continue;
                    }
                    if (logger.isDebugEnabled()) {
                        logger.debug("doc={} node={} nestedElementId={} uses arrayIndex={} value={}",
                                    documentId,
                                    node.name(),
                                    nestedElementId,
                                    value.arrayIndex(),
                                    value.value());
                    }
                    detailInstances.add(new FormTreeDetailInstance(
                            List.of(),
                            List.of(value)));
                }
            }

            if (detailInstances.isEmpty()) {
                return Optional.empty();
            }

            return Optional.of(new FormTreeDetailNode(node, detailInstances));
        }
    }

    public record 
    FormTreeDetailInstance(
        List<FormTreeDetailNode> childNodes,
        List<FormValues.IndexedValue> values) {

        public boolean hasChildren() {
            return !childNodes.isEmpty();
        }

        public boolean hasValues() {
            return !values.isEmpty();
        }

        public FormValues.IndexedValue firstValue() {
            return values.isEmpty() ? null : values.get(0);
        }
    }

    private static 
    String 
    describeTemplates(List<FormStructure.FormTree> templates) {
        if (templates == null || templates.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < templates.size(); i++) {
            describeNode(sb, templates.get(i).node(), "");
            if (i < templates.size() - 1) {
                sb.append("; ");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    private static void 
    describeNode(
        StringBuilder sb,
        FormStructure.FormTreeNode node,
        String indent) {

        sb.append(indent)
                .append(node.name())
                .append("(nestedElementId=").append(node.nestedElementId()).append(")");
        if (node.hasChildren()) {
            sb.append("{");
            for (int i = 0; i < node.children().size(); i++) {
                describeNode(sb, node.children().get(i), indent + "  ");
                if (i < node.children().size() - 1) {
                    sb.append(", ");
                }
            }
            sb.append("}");
        }
    }

    private record 
    LineItemBuckets(
        Map<Integer, List<FormValues.IndexedValue>> buckets) {

        static 
        <F extends AbstractSubmitField> 
        LineItemBuckets 
        from(
            ImmutVOs<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                OneToOne<
                                    TxStarView.Read<F>, 
                                    TxStarView.Read<DocumentLineItemField>>, 
                                StarView.Hierarchy.Read<NestedElementField>>, 
                            StarView.Read<FormElementField>>, 
                        TxStarView.Read<DocumentField>>, 
                    StarView.Read<FormField>>> many) {

            Map<Integer, List<FormValues.IndexedValue>> map = new LinkedHashMap<>();
            for (var line : many.asList()) {
                var nestedElementId = line.left.left.left.left.right
                        .mandatoryValue(DocumentLineItemField::NestedElementId);
                map.computeIfAbsent(nestedElementId, k -> new ArrayList<>()).add(extractLineItemValue(line));
            }
            return new LineItemBuckets(map);
        }

        private static 
        <F extends AbstractSubmitField> 
        FormValues.IndexedValue 
        extractLineItemValue(
            OneToOne<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                TxStarView.Read<F>, 
                                TxStarView.Read<DocumentLineItemField>>, 
                            StarView.Hierarchy.Read<NestedElementField>>, 
                        StarView.Read<FormElementField>>, 
                    TxStarView.Read<DocumentField>>, 
                StarView.Read<FormField>> line) {

            var documentLineItemView = line.left.left.left.left.right;
            // Use shared utility for consistent ArrayIndex extraction
            return FormValues.extractIndexedValue(documentLineItemView);
        }

        FormValues.IndexedValue 
        findByArrayIndex(Integer nestedElementId, int inputIndex) {
            var list = buckets.get(nestedElementId);
            if (list == null) {
                return null;
            }
            // Find value matching the arrayIndex (supports sparse arrays)
            return list.stream().filter(iv -> iv.arrayIndex() == (byte) inputIndex).findFirst().orElse(null);
        }

        String describe() {
            return
                buckets.entrySet().stream().map(entry -> 
                        entry.getKey() + ":" + entry.getValue().stream().map(FormValues.IndexedValue::value).toList()).
                    collect(Collectors.joining(", ", "[", "]"));
        }
    }
}
