package aloha3.controller.query.vo.form;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.Type;
import aloha.module.object.ValueObject;
import aloha3.controller.tool.meta.AlohaDocument;
import aloha3.document.business.Service;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.record.Enum.REQUIRED;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Shared form structure definitions and building logic.
 */
public final class FormStructure {

    private FormStructure() {}

    private static final String NESTED_ELEMENT_INPUT_PREFIX = "NestedElementId_";

    public static String buildInputName(Integer nestedElementId, int inputIndex) {
        if (nestedElementId == null || inputIndex <= 0) {
            return null;
        }
        return NESTED_ELEMENT_INPUT_PREFIX + nestedElementId + "_" + inputIndex;
    }

    public static 
    Map<Integer, List<FormElementInputRow>> 
    formElementsByFormId(
        Service<? extends AbstractSubmitField> submitFieldService) {

        return resolveFormElementInputs(0, submitFieldService).
            asList().stream().
            collect(
                Collectors.groupingBy(
                    FormElementInputRow::formId,
                    LinkedHashMap::new,
                    Collectors.toList()));
    }

    public static 
    Map<Integer, List<FormTree>> 
    formTreesByFormId(
        Map<Integer, List<FormElementInputRow>> formElementsByFormId) {

        return 
            formElementsByFormId.entrySet().stream().
                filter(entry -> entry.getKey() != null).
                collect(
                    Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> buildFormTree(entry.getValue()),
                        (existing, duplicate) -> existing,
                        LinkedHashMap::new));
    }

    public static 
    Map<Integer, List<FormTree>> 
    formTreesByFormId(
        Service<? extends AbstractSubmitField> submitFieldService) {

        return formTreesByFormId(formElementsByFormId(submitFieldService));
    }

    public static 
    List<FormTree> 
    formTreeForFormId(
        Integer formId,
        Service<? extends AbstractSubmitField> submitFieldService) {

        if (formId == null || formId == 0) {
            return new ArrayList<>();
        }
        return buildFormTree(resolveFormElementInputs(formId, submitFieldService));
    }

    private static 
    ImmutVOs<FormElementInputRow> 
    resolveFormElementInputs(
        Integer formId,
        Service<? extends AbstractSubmitField> submitFieldService) {

        return 
            AlohaDocument.
                allFormToFormElements(submitFieldService, DateTime.YMDHMS.current()).
                filter(o2o -> {
                    var formIdToKeep = o2o.left.left.mandatoryValue(FormField::FormId);
                    return formId == 0 || formIdToKeep.equals(formId);
                }).
                map(FormElementRow::create).
                map(FormElementInputRow::fromRow);
    }

    public static List<FormTree> buildFormTree(ImmutVOs<FormElementInputRow> formElements) {
        return buildFormTree(formElements.asList(), Map.of());
    }
    
    public static List<FormTree> buildFormTree(List<FormElementInputRow> formElements) {
        return buildFormTree(formElements, Map.of());
    }

    public static List<FormTree> buildFormTree(
        List<FormElementInputRow> formElements,
        Map<Integer, List<FormValues.IndexedValue>> valueBuckets) {
        if (formElements.isEmpty()) {
            return new ArrayList<>();
        }

        var byId = formElements.stream().collect(
            Collectors.toMap(
                FormElementInputRow::formElementId,
                Function.identity(),
                (existing, duplicate) -> existing, LinkedHashMap::new));

        var childrenByParent = formElements.stream().collect(
            Collectors.groupingBy(
                FormElementInputRow::parentFormElementId,
                LinkedHashMap::new,
                Collectors.toList()));

        return formElements.stream().filter(row -> isRootNode(row, byId)).distinct().map(row -> {
            var node = toTreeNode(row, childrenByParent);
            return new FormTree(node, instantiateNode(node, 1, valueBuckets));
        }).collect(Collectors.toList());
    }

    private static boolean isRootNode(FormElementInputRow row, Map<Integer, FormElementInputRow> byId) {
        Integer parentId = row.parentFormElementId();
        return parentId == null || !byId.containsKey(parentId);
    }

    private static 
    FormTreeNode 
    toTreeNode(
        FormElementInputRow row,
        Map<Integer, List<FormElementInputRow>> childrenByParent) {

        return 
            new FormTreeNode(
                row.formElementId(),
                row.parentFormElementId(),
                row.nestedElementId(),
                row.name(),
                row.refType(),
                row.inputType(),
                row.arrayMaxSize(),
                row.required(),
                childrenByParent.
                    getOrDefault(row.formElementId(), List.of()).
                    stream().
                    map(child ->
                        toTreeNode(child, childrenByParent)).
                    collect(Collectors.toList()));
    }

    private static 
    List<FormTreeNodeInstance> 
    instantiateNode(
        FormTreeNode node,
        int parentOccurrence,
        Map<Integer, List<FormValues.IndexedValue>> valueBuckets) {

        int repeat = node.arrayMaxSize() <= 0 ? 1 : node.arrayMaxSize();
        List<FormTreeNodeInstance> instances = new ArrayList<>();
        for (int i = 1; i <= repeat; i++) {
            int inputIndex = (parentOccurrence - 1) * repeat + i;

            List<FormTreeChildGroup> childGroups = node.children().stream().map(childNode -> 
                new FormTreeChildGroup(
                    childNode,
                    instantiateNode(childNode, inputIndex, valueBuckets))).collect(Collectors.toList());
            String value = null;
            if (!node.hasChildren() && node.nestedElementId() != null) {
                var indexedValues = valueBuckets.get(node.nestedElementId());
                if (indexedValues != null) {
                    // Find value for this specific inputIndex (supports sparse arrays / 歯抜け)
                    value = indexedValues.stream().
                        filter(iv -> iv.arrayIndex() == (byte) inputIndex).
                        map(FormValues.IndexedValue::value).
                        findFirst().
                        orElse(null);
                }
            }
            instances.add(new FormTreeNodeInstance(node, inputIndex, childGroups, value));
        }
        return instances;
    }

    public static 
    Map<Integer, List<FormValues.IndexedValue>> 
    createValueBuckets(
        Map<Integer, List<FormValues.IndexedValue>> valuesByNestedElementId) {

        if (valuesByNestedElementId == null || valuesByNestedElementId.isEmpty()) {
            return Map.of();
        }

        // Return defensive copy to support sparse arrays (歯抜け)
        return valuesByNestedElementId.entrySet().stream().collect(
            Collectors.toMap(
                Map.Entry::getKey,
                entry -> new ArrayList<>(entry.getValue()),
                (existing, duplicate) -> existing,
                LinkedHashMap::new));
    }

    public record FormElementInputRow(
        Integer formId,
        Integer formElementId,
        Integer parentFormElementId,
        Integer nestedElementId,
        String name,
        Type.RefType refType,
        InputType inputType,
        int arrayMaxSize,
        boolean required
    ) implements ValueObject {

        public static FormElementInputRow fromRow(FormElementRow row) {
            var nestedElement = row.nestedElement();
            var arraySize = row.arrayMaxSize() == null ? 1 : row.arrayMaxSize();
            var required = nestedElement.
                optionalValue(f -> f.Required).
                apply(
                    value -> 
                        value == REQUIRED.MANDATORY,
                    () -> false);
            return 
                new FormElementInputRow(
                    row.form().mandatoryValue(FormField::FormId),
                    row.formElementId(),
                    row.parentFormElementId(),
                    row.nestedElementId(),
                    row.name(),
                    row.refType(),
                    InputType.from(row.refType()),
                    arraySize,
                    required);
        }

        public enum InputType {
            TEXT("text"),
            NUMBER("number", "1"),
            DATE("date"),
            DATETIME("datetime-local");

            private final String htmlType;
            private final String step;

            InputType(String htmlType) {
                this(htmlType, null);
            }

            InputType(String htmlType, String step) {
                this.htmlType = htmlType;
                this.step = step;
            }

            public String htmlType() {
                return htmlType;
            }

            public String step() {
                return step;
            }

            static InputType from(Type.RefType refType) {
                return switch (refType) {
                    case INTEGER, LONG -> NUMBER;
                    case YMD -> DATE;
                    case YMDHMS -> DATETIME;
                    default -> TEXT;
                };
            }
        }
    }

    public record FormTree(FormTreeNode node, List<FormTreeNodeInstance> instances) {
    }

    public record 
    FormTreeNode(
        Integer formElementId,
        Integer parentFormElementId,
        Integer nestedElementId,
        String name,
        Type.RefType refType,
        FormElementInputRow.InputType inputType,
        int arrayMaxSize,
        boolean required,
        List<FormTreeNode> children
    ) implements ValueObject {

        public boolean hasChildren() {
            return !children.isEmpty();
        }
    }

    public record 
    FormTreeNodeInstance(
        FormTreeNode node,
        int inputIndex,
        List<FormTreeChildGroup> childGroups,
        String value) {

        public boolean hasChildren() {
            return !childGroups.isEmpty();
        }

        public boolean hasValue() {
            return value != null && !value.isEmpty();
        }

        public String inputName() {
            return buildInputName(node.nestedElementId(), inputIndex);
        }
    }

    public record 
    FormTreeChildGroup(
        FormTreeNode node,
        List<FormTreeNodeInstance> instances
    ) implements ValueObject {
    }
}
