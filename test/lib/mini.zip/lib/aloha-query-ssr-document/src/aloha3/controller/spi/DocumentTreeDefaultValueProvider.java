package aloha3.controller.spi;

import java.util.Map;

public class DocumentTreeDefaultValueProvider implements TreeDefaultValueProvider {
    @Override
    public Map<String, Map<String, String>> provideDefaultValues() {
        return Map.of("FormElement", Map.of("ArrayMaxSize", "1"));
    }
}
