package aloha3.controller.query.vo;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.query.vo.form.FormStructure;
import aloha3.controller.query.vo.form.FormValues;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaDocument;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.document.business.Service;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.template.Context;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.ID;
import static aloha3.controller.tool.meta.MappingConst.FORM_ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;

/**
 * Aggregates data required to render registerDocument page.
 */
public record RegisterDocumentPageView(
    Context context,
    Set<String> components) {

    public static 
    <F extends AbstractSubmitField> 
    RegisterDocumentPageView 
    create(
        String pivot,
        OperationType operation,
        Request request,
        Service<F> submitFieldService) {

        var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        var submitAttrSchemas = AlohaMeta.getViewInfos("Submit", container())
                .filter(v -> !v.mandatoryValue(f -> f.IsPK).val() &&
                        !v.mandatoryValue(f -> f.IsFK).val());
        Integer formId = request.unlessNull(FORM_ID, Integer::valueOf, 0);

        var allDocumentModels = AlohaDocument.allDocumentModels(submitFieldService);
        var formTreesByFormId = FormStructure.formTreesByFormId(submitFieldService);
        var documentListView = RegisterDocumentListView.create(
                allDocumentModels,
                submitAttrSchemas,
                formTreesByFormId);

        // Default to first available form if not specified
        if (formId == 0 && !formTreesByFormId.isEmpty()) {
            formId = formTreesByFormId.keySet().iterator().next();
        }

        Map<Integer, List<FormValues.IndexedValue>> valueBuckets = Map.of();
        TxStarView.Read<DocumentField> documentView = null;
        TxStarView.Read<F> submitView = null;
        Long editDocumentId = null;

        if (operation == OperationType.edit) {
            long requestedDocumentId = request.unlessNull(ID, Long::valueOf, 0L);
            if (requestedDocumentId <= 0) {
                throw new RuntimeException("Document id is required for edit operation");
            }
            var editModel = allDocumentModels.asList().stream().
                filter(model -> model.one().left().right().txRead().getTxId() == requestedDocumentId).
                findFirst().
                orElseThrow(() -> new RuntimeException("Document not found for id=" + requestedDocumentId));
            documentView = editModel.one().left().right();
            submitView = editModel.one().right();
            editDocumentId = documentView.txRead().getTxId();
            formId = documentView.mandatoryValue(DocumentField::FormId);
            Map<Integer, List<FormValues.IndexedValue>> valuesByNestedElementId = new LinkedHashMap<>();

            editModel.many().asList().
                // Sorting by documentLineItemId breaks the original submission order.
                // The database query already returns items in insertion order, which matches
                // the order they were submitted (e.g., _1, _2, _3).
                forEach(line -> {
                    var documentLineItemView = line.left().left().left().left().right();
                    Integer nestedElementId = documentLineItemView.mandatoryValue(DocumentLineItemField::NestedElementId);

                    // Use shared utility for consistent ArrayIndex extraction
                    FormValues.IndexedValue indexedValue = FormValues.extractIndexedValue(documentLineItemView);

                    // Store as List<IndexedValue> to support sparse arrays (歯抜け)
                    valuesByNestedElementId.
                        computeIfAbsent(nestedElementId, key -> new ArrayList<>()).
                        add(indexedValue);
                });

            valueBuckets = FormStructure.createValueBuckets(valuesByNestedElementId);
        }

        var addView = RegisterDocumentAddView.create(
            pivot,
            operation,
            formId,
            viewInfo,
            submitAttrSchemas,
            submitFieldService,
            valueBuckets);

        Context.Builder context = Context.Builder.create().
            add(PIVOT, pivot).
            add(FORM_ID, formId).
            add(OPERATION, operation.name()).
            add("view", addView).
            add("viewSchemas", addView.viewSchemas()).
            add("viewSchemasList", addView.viewSchemas().asList()).
            add("submitAttrSchemas", addView.submitAttrSchemas()).
            add("submitAttrSchemasList", addView.submitAttrSchemas().asList()).
            add("documentList", documentListView).
            add("formTree", addView.formTree()).
            add("documentView", documentView).
            add("submitView", submitView);

        if (editDocumentId != null) {
            context.add(ID, editDocumentId);
        }

        addFkAndAfkLookups(viewInfo, context);

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());

        return new RegisterDocumentPageView(context.build(), components);
    }

    public String render(String template) {
        return engine().process(template, components, context);
    }

    private static 
    void 
    addFkAndAfkLookups(
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo,
        Context.Builder context) {

        context.add("views_fk",
            getFkPivot(viewInfo).unlessNull(
                fkPivot -> AlohaCRUD.starViews(fkPivot, container()),
                ImmutVOs.emptyVOs()));

        getAfkPivots(viewInfo).foreach(
            afkPivot -> {
                var views = AlohaCRUD.starViews(afkPivot, container());
                context.add("views_afk_" + StringUtil.decapitalize(afkPivot) + "Id", views);
            });
    }

    private static 
    MayNullValue<String> 
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.find(
            view -> view.mandatoryValue(f -> f.IsFK) == Bool.TRUE).apply(
                view -> MayNullValue.of(
                    view.optionalValue(f -> f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static 
    ImmutValues<String> 
    getAfkPivots(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            filter(
                view -> view.mandatoryValue(f -> f.IsAFK) == Bool.TRUE).
            toValues(view -> view.optionalValue(f -> f.Foreign).assertNonNull());
    }
}
