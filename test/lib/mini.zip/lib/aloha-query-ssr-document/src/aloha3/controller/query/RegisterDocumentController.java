package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.query.vo.RegisterDocumentAddView;
import aloha3.controller.query.vo.RegisterDocumentPageView;
import aloha3.controller.query.vo.form.FormValues;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.document.business.Service;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.document.record.DocumentLineItem;
import aloha3.document.record.NestedElement;
import aloha3.document.record.SubmitLineItem;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.view.AbstractField.Member;
import aloha3.module.object.view.TxStarView;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.function.Function;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_NAV_MENU_HTML;
import static aloha3.controller.tool.meta.MappingConst.FORM_ID;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.meta.MetaManager.decapitalize;

/**
 * Experimental controller that renders registerDocument page with typed view
 * models.
 * Currently only supports the ADD flow so that we can iterate safely beside the
 * legacy implementation.
 */
public class RegisterDocumentController extends AbstractController {
    public static final RegisterDocumentController INSTANCE = new RegisterDocumentController();
    public static final String MAIN_TEMPLATE = "registerDocument.html";
    public static final String DOCUMENT = "document";
    
    private static Service<? extends AbstractSubmitField> service;

    public static void init(Service<? extends AbstractSubmitField> service) {
        RegisterDocumentController.service = service;
    }
    
    @SuppressWarnings("unchecked")
    private static <F extends AbstractSubmitField> Service<F> alohaDocumentService() {
        if (service == null) {
            throw new IllegalStateException("RegisterDocumentController.service is not initialized. Call init() first.");
        }
        return (Service<F>) service;
    }

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Tx";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void handlePost(Request request, Response response) {
        System.out.println("handle POST");
        request.unlessNull_(
            PIVOT,
            pivot -> {
                if (DOCUMENT.equalsIgnoreCase(pivot)) {
                    saveDocumentWithWorkflow(request);
                } else {
                    throw new RuntimeException("Unsupported pivot for POST: " + pivot);
                }
            });
        response.redirectTo(request.target());
    }

    public static void handlePut(Request request, Response response) {
        System.out.println("handle PUT");
        request.unlessNull_(
            PIVOT,
            pivot -> {
                if (DOCUMENT.equalsIgnoreCase(pivot)) {
                    updateDocumentWithWorkflow(request);
                } else {
                    throw new RuntimeException("Unsupported pivot for PUT: " + pivot);
                }
            });
        response.redirectTo(request.target());
    }

    private static 
    String 
    renderMainContent(
        String pivot,
        OperationType operation,
        Request request) {

        var submitFieldService = alohaDocumentService();
        var pageView = RegisterDocumentPageView.create(pivot, operation, request, submitFieldService);
        return pageView.render(MAIN_TEMPLATE);
    }

    private static 
    void 
    saveDocumentWithWorkflow(Request request) {
        var submitFieldService = alohaDocumentService();

        Integer formId = request.unlessNull(FORM_ID, Integer::valueOf, 0);
        var now = DateTime.YMDHMS.current();
        var formRead = submitFieldService.formMgr().createView(formId, now).mustNonNull();

        var documentWrite = submitFieldService.documentMgr().create(formRead.coreRead(), now);

        saveSubmitModel(request, submitFieldService, now, documentWrite.getTxId());
        submitFieldService.documentMgr().save(
                TxStarView.Write.New.Builder.create(
                        DocumentField.class,
                        documentWrite).build());
    }

    private static 
    void 
    updateDocumentWithWorkflow(Request request) {
        var submitFieldService = alohaDocumentService();

        Long documentId = request.unlessNull(IndexController.ID, Long::valueOf, 0L);
        var documentRead = submitFieldService.documentMgr().selectTx(documentId);
        documentRead.ifNull_(() -> {
            throw new RuntimeException("No input values found in the request");
        });

        saveSubmitModel(request, submitFieldService, DateTime.YMDHMS.current(), documentId);
    }

    @SuppressWarnings("unchecked")
    private static 
    void 
    saveSubmitModel(
        Request request,
        Service<AbstractSubmitField> submitFieldService,
        DateTime.YMDHMS now,
        Long documentId) {

        var formId = request.unlessNull(FORM_ID, Integer::valueOf, 0);
        var formRead = submitFieldService.formMgr().createView(formId, now).mustNonNull();
        var graphId = formRead.mandatoryValue(f -> f.GraphId);
        var graphRead = submitFieldService.nestedElementTree().selectGraph(graphId, now).mustNonNull();
        Tree.StarArrow<FormElementField, NestedElementField> treeRead = submitFieldService.nestedElementTree()
                .createModel(graphRead, now).mustNonNull();

        var childValues = RegisterDocumentAddView.collectChildValues(
                request.keyValues(),
                submitFieldService,
                now,
                treeRead,
                formId);
        if (childValues.isEmpty()) {
            throw new RuntimeException("No input values found in the request");
        }

        // Create strategy for checking if an item is single (ArrayMaxSize <= 1)
        Function<Integer, Boolean> isSingleItemStrategy = nestedElementId -> {
            try {
                return !RegisterDocumentAddView.isMultiItem(treeRead, nestedElementId);
            } catch (Exception e) {
                // Fallback or log error if needed, but for now assume single if not found to be safe? 
                // Or maybe default to false (multi) to preserve index?
                // Given the requirement is to NOT save index for single, default to false (save index) is safer for data loss prevention,
                // but might violate the requirement. 
                // Let's assume treeRead is complete as it was used to collect values.
                return true; 
            }
        };

        submitFieldService.submitFamily().save(
                newSubmitSubmitLineItemModel(
                        request,
                        documentId,
                        isSingleItemStrategy,
                        childValues.getFirst(),
                        childValues.
                            subList(1, childValues.size()).
                            toArray(new FormValues.ChildValueWithIndex[0])));
    }

    @SuppressWarnings("rawtypes")
    private static <
        SF extends AbstractSubmitField> 
    TxModel<SF, SubmitLineItem> 
    newSubmitSubmitLineItemModel(
        Request request,
        Long documentId,
        Function<Integer, Boolean> isSingleItemStrategy,
        FormValues.ChildValueWithIndex v,
        FormValues.ChildValueWithIndex... vs) {

        Service<SF> submitFieldService = alohaDocumentService();

        var submitSFBuilder = TxStarView.Write.New.Builder.create(
                submitFieldService.submitFieldClass(),
            TxLongFK.Write.create(
                submitFieldService.submitFamily().entity(),
                documentId,
                DateTime.YMDHMS.current()));

        submitFieldService.submitFamily().field().attributeMembers().foreach(member -> {
            var attrName = decapitalize(member.javaName());
            request.param(attrName).unlessNull_(value -> {
                if (member instanceof Member.Optional optionalMember) {
                    if (value.isBlank()) {
                        return;
                    }
                    submitSFBuilder.setOptionalValue(f -> optionalMember, value);
                }
                if (member instanceof Member.Mandatory mandatoryMember) {
                    submitSFBuilder.setMandatoryValue(f -> mandatoryMember, value);
                }
            });
        });

        return saveSubmitLineItemTxModel(submitFieldService, submitSFBuilder.build(), documentId, isSingleItemStrategy, v, vs);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static <
        SF extends AbstractSubmitField> 
    TxModel<SF, SubmitLineItem> 
    saveSubmitLineItemTxModel(
        Service<SF> submitFieldService,
        TxStarView.Write.New<SF> newSubmitView,
        Long documentId,
        Function<Integer, Boolean> isSingleItemStrategy,
        FormValues.ChildValueWithIndex v,
        FormValues.ChildValueWithIndex... vs) {

        NonEmptyVOs<TxIntFK.Read<DocumentLineItem>> vsNonEmpty = NonEmptyVOs.of(v, vs).map(withIndex -> {
            final var childValue = withIndex.childValue();
            final var value = childValue.value().trim();
            final var nestedElementId = ((Record.SinglePK.Master) childValue.afeRecord()).getRowId();
            final boolean isSingleItem = isSingleItemStrategy.apply(nestedElementId);

            return 
                findMatchedValueAndNestedElementId(
                        submitFieldService, 
                        childValue, 
                        value, 
                        documentId, 
                        (byte) withIndex.arrayIndex(),
                        isSingleItem).
                    apply(
                        matched -> (TxIntFK.Read) matched.first().txRead(),
                        () -> {
                            var builder = TxStarView.Write.Prepare.Builder.create(DocumentLineItemField.class).
                                setMandatory(f -> f.Value, DocumentLineItem.Value.class, value);
                            
                            if (!isSingleItem) {
                                builder.setOptionalValue(f -> f.ArrayIndex, (byte) withIndex.arrayIndex());
                            }
                            
                            return submitFieldService.documentLineItemMgr().saveThen(
                                builder.build(),
                                (Read<NestedElement>) withIndex.childValue().afeRecord(),
                                DateTime.YMDHMS.current()).get();
                        });
        });
        return TxModel.create(
                newSubmitView,
                SubmitLineItem.class,
                vsNonEmpty);
    }

    private static <
        SF extends AbstractSubmitField> 
    ImmutVOs<TxStarView.Read<DocumentLineItemField>> 
    findMatchedValueAndNestedElementId(
        Service<SF> submitFieldService,
        TxModel.ChildValue<NestedElement, String> childValue,
        String value,
        Long documentId,
        Byte arrayIndex,
        boolean isSingleItem) {

        if (documentId == null || documentId == 0L) {
            return ImmutVOs.emptyVOs();
        }

        final var nestedElementId = ((Record.SinglePK.Master) childValue.afeRecord()).getRowId();
        
        return submitFieldService.documentMgr().selectTx(documentId).apply(
            docRead -> {
                // Use the new service method to get all submits and related data
                var allData = submitFieldService.readAllSubmits(docRead);
                
                if (allData.asList().isEmpty()) {
                    return ImmutVOs.emptyVOs();
                }

                // Filter for matching DocumentLineItem
                var list = allData.asList().stream()
                    .map(model -> model.left.left.left.left.right) // Extract DocumentLineItemField
                    .filter(dliRead -> {
                        var dliValue = dliRead.mandatoryValue(f -> f.Value);
                        var dliNestedElementId = dliRead.mandatoryValue(f -> f.NestedElementId());
                        var dliArrayIndex = dliRead.optionalValue(f -> f.ArrayIndex).apply(v -> v, () -> (byte) 0);
                        
                        boolean indexMatch;
                        if (isSingleItem) {
                            // For single items, we ignore the array index (it might be 0 or 1 in DB)
                            // We only care that the NestedElementId matches
                            indexMatch = true;
                        } else {
                            indexMatch = dliArrayIndex.equals(arrayIndex);
                        }
                        
                        return dliNestedElementId.equals(nestedElementId) && 
                               dliValue.equals(value) && 
                               indexMatch;
                    })
                    .collect(java.util.stream.Collectors.toList());
                
                return ImmutVOs.create(list);
            },
            ImmutVOs::emptyVOs
        );
    }

    private static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.
                apply(
                    PIVOT,
                    pivot -> 
                        renderMainContent(
                            pivot,
                            OperationType.from(request),
                            request),
                    INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder.
                add("title", "Document List").
                add(
                    AlohaMeta.
                        getTxPivots(container()).
                        filter(t -> 
                            t.mandatoryValue(f -> f.Pivot).equalsIgnoreCase(DOCUMENT)));
        }
    }
}
