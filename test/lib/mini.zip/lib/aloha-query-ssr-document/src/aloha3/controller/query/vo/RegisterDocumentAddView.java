package aloha3.controller.query.vo;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.Tuple;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.query.vo.form.FormStructure;
import aloha3.controller.query.vo.form.FormValues;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.document.business.Service;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.record.NestedElement;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * View model for registerDocument add form.
 */
public record RegisterDocumentAddView(
    String pivot,
    OperationType operation,
    Integer formId,
    ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewSchemas,
    ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
    List<FormStructure.FormElementInputRow> formElements,
    List<FormStructure.FormTree> formTree) {

    public static 
    RegisterDocumentAddView 
    create(
        String pivot,
        OperationType operation,
        Integer formId,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewSchemas,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
        Service<? extends AbstractSubmitField> submitFieldService) {

        return create(
            pivot,
            operation,
            formId,
            viewSchemas,
            submitAttrSchemas,
            submitFieldService,
            Map.of());
    }

    public static 
    RegisterDocumentAddView 
    create(
        String pivot,
        OperationType operation,
        Integer formId,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewSchemas,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
        Service<? extends AbstractSubmitField> submitFieldService,
        Map<Integer, List<FormValues.IndexedValue>> valueBuckets) {

        var formElementsMap = FormStructure.formElementsByFormId(submitFieldService);
        var formElements = formElementsMap.getOrDefault(formId, new ArrayList<>());
        var formTree = FormStructure.buildFormTree(formElements, valueBuckets);
        
        return new RegisterDocumentAddView(
                pivot,
                operation,
                formId,
                viewSchemas,
                submitAttrSchemas,
                formElements,
                formTree);
    }

    public static List<FormValues.ChildValueWithIndex> collectChildValues(
            Map<String, String> keyValues,
            Service<? extends AbstractSubmitField> submitFieldService,
            DateTime.YMDHMS now,
            Tree.StarArrow<FormElementField, NestedElementField> treeRead,
            Integer formId) {

        if (keyValues == null || keyValues.isEmpty()) {
            return new ArrayList<>();
        }
        List<FormStructure.FormTree> formTrees = FormStructure.formTreeForFormId(formId, submitFieldService);
        if (formTrees.isEmpty()) {
            return new ArrayList<>();
        }
        List<FormValues.ChildValueWithIndex> collector = new ArrayList<>();
        for (FormStructure.FormTree formTree : formTrees) {
            collectChildValuesFromNode(
                    keyValues,
                    submitFieldService,
                    now,
                    treeRead,
                    formTree.node(),
                    formTree.instances(),
                    collector);
        }
        return collector;
    }

    private static void collectChildValuesFromNode(
            Map<String, String> keyValues,
            Service<? extends AbstractSubmitField> submitFieldService,
            DateTime.YMDHMS now,
            Tree.StarArrow<FormElementField, NestedElementField> treeRead,
            FormStructure.FormTreeNode node,
            List<FormStructure.FormTreeNodeInstance> instances,
            List<FormValues.ChildValueWithIndex> collector) {

        if (node == null || instances == null || instances.isEmpty()) {
            return;
        }
        if (node.hasChildren()) {
            for (FormStructure.FormTreeNodeInstance instance : instances) {
                for (FormStructure.FormTreeChildGroup childGroup : instance.childGroups()) {
                    collectChildValuesFromNode(
                            keyValues,
                            submitFieldService,
                            now,
                            treeRead,
                            childGroup.node(),
                            childGroup.instances(),
                            collector);
                }
            }
            return;
        }

        Integer nestedElementId = node.nestedElementId();
        if (nestedElementId == null) {
            return;
        }
        StarView.Hierarchy.Read<NestedElementField> relView = getNestedElementById(treeRead, nestedElementId);
        var formElementView = submitFieldService.formElementMgr()
                .createView(
                        relView.mandatoryValue(f -> f.unsafePivotAFKMember()).intValue(),
                        now)
                .mustNonNull();
        if (isRootFormElement(formElementView)) {
            return;
        }
        for (FormStructure.FormTreeNodeInstance instance : instances) {
            String key = FormStructure.buildInputName(nestedElementId, instance.inputIndex());
            if (key == null) {
                continue;
            }
            var rawValue = keyValues.get(key);

            // Skip empty values entirely - don't create DocumentLineItem child (BOS
            // constraint)
            // This creates sparse arrays (歯抜け) where indices can have gaps
            if (rawValue == null || rawValue.isBlank()) {
                continue;
            }

            // Format value
            String formatted = formatByRefType(formElementView, rawValue.trim());
            if (formatted.isBlank()) {
                continue; // Skip if formatting resulted in empty
            }

            // Save with arrayIndex - this is the key fix!
            byte arrayIndex = (byte) instance.inputIndex();
            var childValue = toChildValue(relView, formatted);
            collector.add(new FormValues.ChildValueWithIndex(childValue, arrayIndex));
        }
    }

    private static String formatByRefType(StarView.Read<FormElementField> formElementView, String value) {
        return switch (formElementView.mandatoryValue(f -> f.RefType)) {
            case YMD -> value.replaceAll("[/-]", "");
            case YMDHMS ->
                (value.replaceAll("T", "").replaceAll("[:-]", "") + "0000").substring(0, 14);
            default -> value;
        };
    }

    private static boolean isRootFormElement(StarView.Read<FormElementField> formElementView) {
        return Service.ROOT_FORM_ELEMENT.equals(
                formElementView.mandatoryValue(f -> f.Name));
    }

    private static <T extends Comparable<? super T>> TxModel.ChildValue<NestedElement, String> toChildValue(
            StarView.Hierarchy.Read<NestedElementField> fc,
            T value) {

        return new TxModel.ChildValue<>(
                (Record.SinglePK) fc.pivotRead(),
                value.toString());
    }

    public static 
    StarView.Hierarchy.Read<NestedElementField> 
    getNestedElement(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        StarView.Read<FormElementField> formElement) {

        return findNestedElement(treeRead, formElement)
                .orElseThrow(() -> new RuntimeException(
                        "NestedElement not found for FormElement: " + formElement.coreRead().coreId()));
    }

    public static 
    StarView.Hierarchy.Read<NestedElementField> 
    getNestedElementById(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        int nestedElementId) {

        return findNestedElementById(treeRead, nestedElementId).mustNonNull();
    }

    private static 
    Optional<StarView.Hierarchy.Read<NestedElementField>> 
    findNestedElement(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        StarView.Read<FormElementField> formElement) {

        var targetId = formElement.coreRead().coreId();

        Optional<StarView.Hierarchy.Read<NestedElementField>> leafResult = treeRead.arrowToLeaves().asList().stream()
                .filter(leaf -> leaf.right().mandatoryValue(FormElementField::FormElementId).equals(targetId))
                .map(Tuple.ImmutPair::left)
                .findFirst();

        if (leafResult.isPresent()) {
            return leafResult;
        }

        for (var branch : treeRead.arrowToBranches().asList()) {
            if (branch.right().from().mandatoryValue(FormElementField::FormElementId).equals(targetId)) {
                return Optional.of(branch.left());
            }

            Optional<StarView.Hierarchy.Read<NestedElementField>> branchResult = findNestedElement(branch.right(),
                    formElement);
            if (branchResult.isPresent()) {
                return branchResult;
            }
        }

        return Optional.empty();
    }

    private static 
    MayNullVO<StarView.Hierarchy.Read<NestedElementField>> 
    findNestedElementById(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        int nestedElementId) {

        Optional<StarView.Hierarchy.Read<NestedElementField>> leafResult = treeRead.arrowToLeaves().asList().stream().
            map(Tuple.ImmutPair::left).
            filter(leaf -> leaf.mandatoryValue(NestedElementField::NestedElementId).equals(nestedElementId)).
            findFirst();

        if (leafResult.isPresent()) {
            return MayNullVO.of(leafResult.get());
        }

        for (var branch : treeRead.arrowToBranches().asList()) {
            var branchNode = branch.left();
            if (branchNode.mandatoryValue(NestedElementField::NestedElementId).equals(nestedElementId)) {
                return MayNullVO.of(branchNode);
            }
            var branchResult = findNestedElementById(branch.right(), nestedElementId);
            if (!branchResult.unsafeIsNull()) {
                return branchResult;
            }
        }
        return MayNullVO.nullInstance();
    }

    public static boolean isMultiItem(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        int nestedElementId) {
        
        Boolean result = checkPathMultiplicity(treeRead, nestedElementId, false);
        return result != null && result;
    }

    private static Boolean checkPathMultiplicity(
            Tree.StarArrow<FormElementField, NestedElementField> tree,
            int targetId,
            boolean parentIsMulti) {

        // Check leaves
        for (var leaf : tree.arrowToLeaves().asList()) {
            var leafNode = leaf.left();
            if (leafNode.mandatoryValue(NestedElementField::NestedElementId).equals(targetId)) {
                boolean isLeafMulti = leafNode.optionalValue(f -> f.ArrayMaxSize).apply(v -> v, () -> (byte) 1) > 1;
                return parentIsMulti || isLeafMulti;
            }
        }

        // Check branches
        for (var branch : tree.arrowToBranches().asList()) {
            var branchNode = branch.left();
            boolean isBranchMulti = branchNode.optionalValue(f -> f.ArrayMaxSize).apply(v -> v, () -> (byte) 1) > 1;
            boolean currentPathMulti = parentIsMulti || isBranchMulti;
            
            if (branchNode.mandatoryValue(NestedElementField::NestedElementId).equals(targetId)) {
                return currentPathMulti;
            }
            
            Boolean result = checkPathMultiplicity(branch.right(), targetId, currentPathMulti);
            if (result != null) {
                return result;
            }
        }
        
        return null; // Not found in this subtree
    }

    public boolean hasFormElements() {
        return !formElements.isEmpty();
    }

    public boolean hasFormTree() {
        return !formTree.isEmpty();
    }
}
