package aloha3.controller.spi;

import aloha.module.object.ImmutVOs;
import aloha3.controller.Router;
import aloha3.controller.query.RegisterDocumentController;
import aloha3.document.business.Service;
import aloha3.document.business.txm.SubmitField;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.ServiceContainer.Conceptual;

public class DocumentPlugin implements AlohaQuerySsrPlugin {

    @Override
    public void init(ServiceContainer container, Conceptual conceptual) {
        var docService = Service.get(container, conceptual, SubmitField.class);
        RegisterDocumentController.init(docService);
    }

    @Override
    public void registerRoutes(Router router) {
        router.addRoute("/aloha-query/registerDocument/", 
            RegisterDocumentController::handle, 
            RegisterDocumentController::handlePost);
        router.addPut("/aloha-query/registerDocument/", RegisterDocumentController::handlePut);
    }

    @Override
    public ImmutVOs<MenuItem> getMenuItems() {
        return ImmutVOs.create(new MenuItem("CRUD", "Document", "/aloha-query/registerDocument/"));
    }
}
