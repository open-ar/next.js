# 2025/12/03 ver 初版作成

- aloha-documentからControllerおよびSPI実装を分離し、独立したプロジェクトとして切り出し
- Schema-Firstの原則に基づき、aloha-documentを純粋なモデルライブラリとし、UI/SSR依存部分を本プロジェクトに集約
