package aloha3.tool.stream.response.html;

import aloha3.tool.stream.response.Response;

/*
 * https://developer.mozilla.org/en-US/docs/Web/HTML/Element/
 */
public enum ELEMENT implements Response.Element {

    // https://developer.mozilla.org/en-US/docs/Web/HTML/Element#inline_text_semantics
    B("The Bring Attention To element", "<b>", "</b>"),
    EM("The Emphasis element", "<em>", "</em>"),
    STRONG("The Strong Importance element", "<strong>", "</strong>"),

    // https://developer.mozilla.org/en-US/docs/Web/HTML/Element#table_content
    TD("The Table Data Cell element", "<td>", "</td>");

    private final String description;
    private final String from;
    private final String to;

    ELEMENT(String description, String from, String to) {
        this.description = description;
        this.from = from;
        this.to = to;
    }

    @Override
    public String description() {
        return description;
    }

    @Override
    public String from() {
        return from;
    }

    @Override
    public String to() {
        return to;
    }
} // Element
