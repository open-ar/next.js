package aloha3.tool.stream.request;

import aloha.module.object.MayNullValue;

import java.io.BufferedReader;
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public record Request(
    String method, 
    String target, 
    String version, 
    BufferedReader br, 
    java.util.Map<String, String> headers, 
    java.util.Map<String, String> keyValues) {

    public static Request INVALID = new Request(null, null, null, null, new LinkedHashMap<>(), new LinkedHashMap<>());

    public 
    MayNullValue<String> 
    param(String key) {
        var uri = URI.create(target);
        var query = uri.getRawQuery();
        if (query != null) {
            var value = RequestParser.getParamFromQuery(query).get(key);
            if (value != null) {
                return MayNullValue.of(java.net.URLDecoder.decode(value, java.nio.charset.StandardCharsets.UTF_8));
            }
        }
        var bodyValue = keyValues.get(key);
        if (bodyValue != null) {
            return MayNullValue.of(java.net.URLDecoder.decode(bodyValue, java.nio.charset.StandardCharsets.UTF_8));
        }
        return MayNullValue.nullInstance();
    }

    public <
        R extends Comparable<? super R>>
    MayNullValue<R> 
    map(String key, Function<String, R> flatter) {
        return param(key).map(flatter);
    }

    public <
        R extends Comparable<? super R>>
    MayNullValue<R> 
    flatMap(String key, Function<String, ? extends MayNullValue<R>> flatter) {
        return param(key).flatMap(flatter);
    }

    public 
    String
    unlessNull(String key, String defaultValue) {
        return param(key).unlessNull(v -> v, defaultValue);
    }

    public 
    void
    unlessNull_(String key, Consumer<String> whileExisted) {
        param(key).unlessNull_(whileExisted);
    }

    public 
    void
    unlessNull_(
        String key1, 
        String key2, 
        BiConsumer<String, String> whileExisted) {
        
        param(key1).unlessNull_(v1 ->
                param(key2).unlessNull_(v2 -> 
                    whileExisted.accept(v1, v2)));
    }

    @FunctionalInterface
    public interface TriConsumer<T, U, V> {
        void accept(T t, U u, V v);
    }

    public 
    void
    unlessNull_(
        String key1, 
        String key2, 
        String key3, 
        TriConsumer<String, String, String> whileExisted) {
        
        param(key1).unlessNull_(v1 ->
                param(key2).unlessNull_(v2 ->
                    param(key3).unlessNull_(v3 ->
                        whileExisted.accept(v1, v2, v3))));
    }

    public <T>
    T
    unlessNull(String key, Function<String, T> whileExisted, T defaultValue) {
        return param(key).unlessNull(whileExisted, defaultValue);
    }

    public <T>
    T 
    apply(String key, Function<String, T> whileExisted, Supplier<T> whileNotExisted) {
        return param(key).apply(whileExisted, whileNotExisted);
    }

    public <T>
    T 
    apply(
        String key1, 
        String key2, 
        BiFunction<String, String, T> whileExisted, 
        Supplier<T> whileNotExisted) {
        
        return 
            param(key1).
                apply(v1 ->
                    param(key2).
                        apply(
                            v2 -> whileExisted.apply(v1, v2),
                            whileNotExisted),
                    whileNotExisted);
    }
}
