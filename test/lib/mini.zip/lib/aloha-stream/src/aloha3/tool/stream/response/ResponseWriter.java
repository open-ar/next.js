package aloha3.tool.stream.response;

import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.response.buildstep.ResponseMessageBody;

import java.io.IOException;

public final class ResponseWriter extends java.io.Writer {

    private final ResponseMessageBody body;

    public ResponseWriter(ResponseMessageBody body) {
        this.body = body;
    }

    @Override
    public void write(char[] cbuf, int off, int len) {

        if (len == 0) {
            return;
        }
        body.add(cbuf, off, len);
    }

    @Override
    public void write(String s) {
        body.add(s);
    }

    @Override
    public void flush() throws IOException {
        // Logger.DEBUG.log("Writer#flush()");
    }

    @Override
    public void close() throws IOException {
        Logger.DEBUG.log("[DEBUG] Writer#close()");
    }
} // Writer

