package aloha3.tool.stream.response.html;

import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.tool.stream.response.buildstep.ResponseMessageBody;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class ElementBuilder<F extends AbstractField, B extends ResponseMessageBody> {
    private final B body;
    private final AbstractView<F> view;
    private final StringBuilder sb;

    public ElementBuilder(AbstractView<F> view, B body) {
        this.body = body;
        this.view = view;
        this.sb = new StringBuilder();
    }

    public <T extends Comparable<? super T>>
    ElementBuilder<F, B>
    tdMandatory(Function<F, AbstractField.Member.Mandatory<T>> member) {
        return td(this.view.mandatoryValue(member).toString());
    }

    public <T extends Comparable<? super T>>
    ElementBuilder<F, B>
    tdOptional(
        Function<F, AbstractField.Member.Optional<T>> member,
        String inCaseOfNull) {

        return tdOptional(
            member,
            (builder, t) -> builder.td(t.toString()),
            builder -> builder.td(inCaseOfNull));
    }

    public <T extends Comparable<? super T>>
    ElementBuilder<F, B>
    tdOptional(
        Function<F, AbstractField.Member.Optional<T>> member,
        BiConsumer<ElementBuilder<F, B>, T> ifGiven,
        Consumer<ElementBuilder<F, B>> unlessGiven) {

        this.view.
            optionalValue(member).
            apply_(
                t -> ifGiven.accept(this, t),
                () -> unlessGiven.accept(this));
        return this;
    }

    public ElementBuilder<F, B>
    td(String data) {
        sb.append(TAG.TD.asText());
        sb.append(data);
        sb.append(TAG.TD_CLOSE.asText());
        return this;
    }

    public ElementBuilder<F, B>
    elm(String text, ELEMENT... elements) {

        for (ELEMENT element : elements) {
            sb.append(element.from());
        }
        sb.append(text);
        for (int i = elements.length - 1; i >= 0; i--) {
            sb.append(elements[i].to());
        }
        return this;
    }

    public ResponseMessageBody done(String slotName) {
        return this.body.addSlot(slotName, this.sb.toString());
    }
} // SpanBuilder
