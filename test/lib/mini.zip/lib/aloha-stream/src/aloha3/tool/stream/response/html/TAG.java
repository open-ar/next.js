package aloha3.tool.stream.response.html;

import aloha3.tool.stream.response.buildstep.ResponseMessageBuildStep;

public enum TAG implements ResponseMessageBuildStep.Tag {
    SPAN_SLOT("<span slot=\""),
    CLOSE_SLOT("\">"),
    CLOSE_SPAN("</span>"),
    TD("<td>"), // 「Table Data」
    TD_CLOSE("</td>");

    private final String text;

    TAG(String text) {
        this.text = text;
    }

    @Override
    public String asText() {
        return this.text;
    }
}
