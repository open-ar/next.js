package aloha3.tool.stream.exception;

import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;

public final class NoneExceptionHandler implements IExceptionHandler {

    @Override
    public void handle(Request request, Response response, Exception exception) throws Exception {
        if (response.getCurrentBuildStep() == null) {
            response.start().end();
        } else {
            response.getCurrentBuildStep().end();
        }
    }
}