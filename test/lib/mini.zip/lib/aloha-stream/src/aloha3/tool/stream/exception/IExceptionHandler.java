package aloha3.tool.stream.exception;

import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;

public interface IExceptionHandler {
    default void catchException(Request request, Response response, RunWithThrowable mayThrow) throws Exception {
        try {
            mayThrow.run();
        } catch (Exception exception) {
            handle(request, response, exception);
        }
    }

    void handle(Request request, Response response, Exception exception) throws Exception;
}