package aloha3.tool.stream.response.buildstep;

import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.ResponseWriter;
import aloha3.tool.stream.response.html.ElementBuilder;
import aloha3.tool.stream.response.html.TAG;

import static aloha3.tool.stream.response.Response.CRLF_STR;

/**
 * The Build Step when transfer-coding is not chunked.
 * If transfer-coding is chunked, please refer to {@link aloha3.tool.stream.response.buildstep.ResponseMessageBody ResponseMessageBody}
 */
public class ResponseMessageBody extends ResponseMessageBuildStep {
    public ResponseMessageBody(Response response) {
        super(response);
    }

    public ResponseWriter asWriter() {
        return new ResponseWriter(this);
    }

    public ResponseMessageBody add(String StringData) {
        add(StringData.getBytes());
        return this;
    }

    public ResponseMessageBody add(byte[] chunkByte) {
        try {
            response.out.write(chunkByte);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    public void add(char[] chunk, int off, int len) {
        add(new String(chunk, off, len));
    }

    public <F extends AbstractField>
    ElementBuilder<F, ResponseMessageBody>
    addElement(AbstractView<F> view) {
        return new ElementBuilder<>(view, this);
    }

    public ResponseMessageBody addSlot(String slotName, String content) {
        String slot =
            TAG.SPAN_SLOT.asText() +
                slotName +
                TAG.CLOSE_SLOT.asText() +
                content +
                TAG.CLOSE_SPAN.asText() +
                CRLF_STR;
        // Logger.DEBUG.log("slot=" + slot);
        add(slot);
        return this;
    }
}
