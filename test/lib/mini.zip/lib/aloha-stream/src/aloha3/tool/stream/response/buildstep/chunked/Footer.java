package aloha3.tool.stream.response.buildstep.chunked;

import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.ResponseMessageBuildStep;

import java.io.IOException;

import static aloha3.tool.stream.response.Response.CRLF;
import static aloha3.tool.stream.response.Response.CRLF_STR;

/**
 * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-14.40">Trailer</a>
 * Should only use ChunkedResponseMessageBody.footer to generate Footer Object, it is used to add headers specified by Trailer.
 */
public class Footer extends ResponseMessageBuildStep {
    Footer(Response response) {
        super(response);
    }

    public Footer append(String footer) {
        try {
            response.out.write(String.format("%s%s", footer, CRLF_STR).getBytes());
            return this;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void end() {
        try {
            response.out.write(CRLF);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        super.end();
    }
}
