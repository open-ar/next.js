package aloha3.tool.stream.request;

import aloha3.tool.stream.log.Logger;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class RequestParser {
    public static void
    parseKeyValues(
        String urlParams,
        Request req
    ) {
        if (urlParams == null) return;
        String[] parameters = urlParams.split("&");
        for(String parameter : parameters) {
            String[] kv = parameter.split("=", 2);
            if (kv.length == 2) {
                // kv[1] need to decode uri encoding
                String decoded = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                req.keyValues().put(kv[0], decoded);
            }
        }
    }

    private static final Pattern requestLinePattern =
        Pattern.compile("^(?<method>\\S+) (?<target>\\S+) (?<version>\\S+)$");
    private static final Pattern headerPattern =
        Pattern.compile("^(?<name>\\S+):[ \\t]?(?<value>.+)[ \\t]?$");
    private static final String EMPTY = "";

    public static Map<String, String>
    getParamFromQuery(String query) {
        return Arrays.stream(query.split("&"))
            .map(s -> s.split("=", 2)) // 値に "=" が含まれる場合を避けるため、分割回数を制限。key=value=extraでも１回のみ分割するように
            .filter(arr -> arr.length == 2) // 無効なキーと値のペアを除く
            .collect(Collectors.toMap(
                arr -> arr[0],
                arr -> arr[1],
                (_a, b) -> b,
                LinkedHashMap::new)); // 直接マージ
    }

    public static Request readRequest(InputStream in) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String requestLine = br.readLine();
        if (requestLine == null || requestLine.isEmpty()) {
            Logger.DEBUG.log("Nothing to read" +  " " + Thread.currentThread());
            return Request.INVALID;
        }
        Matcher matcher = requestLinePattern.matcher(requestLine);
        if (!matcher.matches() ) {
            Logger.DEBUG.log("Match failed" +  " " + Thread.currentThread());
            return Request.INVALID;
        }

        Request request = new Request(
            matcher.group("method"),
            matcher.group("target"),
            matcher.group("version"),
            br,
            new LinkedHashMap<>(),
            new LinkedHashMap<>());

        Logger.DEBUG.log(request + " " + Thread.currentThread());
        return request;
    }

    public static void parseHeaderLines(Request request) throws IOException {
        while ( true ) {
            String headerField = request.br().readLine();
            if ( EMPTY.equals(headerField.trim()) ) break; // header と body の区切りまで読み込む

            Matcher matcher = headerPattern.matcher(headerField);

            if (matcher.matches()) {
                request.headers().put(matcher.group("name").toLowerCase(), matcher.group("value"));
            } else {
                throw new RuntimeException(headerField);
            }
        }
    }
    public static byte[] parseBody(Request request) throws IOException {
        if (request.headers().containsKey("transfer-encoding")) {
            return parseChunkedBody(request);
        } else if (request.headers().containsKey("content-length")) {
            return parseSimpleBody(request);
        } else {
            Logger.DEBUG.log("Nothing to read from body");
            return null;
        }
    }
    private static byte[] parseChunkedBody(Request request) throws IOException {
        String transferEncoding = request.headers().get("transfer-encoding");
        if (transferEncoding.equals("chunked")) { // only accept "chunked"
            int length = 0;
            ByteArrayOutputStream body = new ByteArrayOutputStream();
            String chunkSizeHex = request.br().readLine().replaceFirst(" .*$", ""); // ignore chunk-ext
            int chunkSize = Integer.parseInt(chunkSizeHex, 16);
            while (chunkSize > 0) {
                char[] chunk = new char[chunkSize];
                request.br().read(chunk, 0, chunkSize);
                request.br().skip(2); // CRLF
                body.write((new String(chunk)).getBytes());
                length += chunkSize;

                chunkSizeHex = request.br().readLine().replaceFirst(" .*$", "");
                chunkSize = Integer.parseInt(chunkSizeHex, 16);
            }
            request.headers().put("content-length", Integer.toString(length));
            request.headers().remove("transfer-encoding");
            return body.toByteArray();
        }
        return null;
    }

    private static byte[] parseSimpleBody(Request request)
        throws IOException {
        int contentLength = Integer.parseInt(request.headers().get("content-length"));

        char[] body = new char[contentLength];
        request.br().read(body, 0, contentLength);

        return (new String(body)).getBytes();
    }
}
