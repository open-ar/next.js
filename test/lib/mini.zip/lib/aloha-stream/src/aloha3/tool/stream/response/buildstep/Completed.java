package aloha3.tool.stream.response.buildstep;

import aloha3.tool.stream.response.Response;

/**
 * The End of Build Step, Don't write anything to Response.out after Response.currentBuildStep is Completed
 */
public class Completed extends ResponseMessageBuildStep {

    public Completed(Response response) {
        super(response);
    }

    @Override
    public void end() {
        // do nothing
    }
}
