package aloha3.tool.stream.response;

public final class Json {
    private final Response response;

    public Json(Response response) {
        this.response = response;
    }

    public void put(String jsonString) {
        this.response.
            start().
            ok().
            appendContentType("application/vnd.api+json").
            body().
            add(jsonString).
            end();
    }
}
