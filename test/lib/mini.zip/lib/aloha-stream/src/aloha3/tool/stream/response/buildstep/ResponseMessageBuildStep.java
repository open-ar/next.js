package aloha3.tool.stream.response.buildstep;

import aloha3.tool.stream.response.Response;

public abstract class ResponseMessageBuildStep {
    protected final Response response;

    protected ResponseMessageBuildStep(Response response) {
        this.response = response;
        // Remember the current build step
        this.response.currentBuildStep(this);
    }

    /**
     * <pre>
     * Change response.currentBuildStep to "Completed".
     * Note: If you override this method, please ensure you call super.end() at the end.
     * </pre>
     */
    public void end() {
        new Completed(response);
    }

    public interface Tag {
        String asText();
    }
}
