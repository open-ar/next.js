package aloha3.tool.stream.response.buildstep;

import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;

import java.io.IOException;

/**
 * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-14">Header Field Definitions</a>
 * The Build Step of Response Headers.
 */
public class Headers extends ResponseMessageBuildStep {
    public Headers(Response response) {
        super(response);
    }

    public Headers appendHeader(String key, String value) {
        try {
            response.out.write(String.format("%s: %s", key, value).getBytes());
            response.out.write(Response.CRLF);
            return this;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Headers appendChunked() {
        try {
            response.out.write("Transfer-Encoding: chunked".getBytes());
            response.out.write(Response.CRLF);
            return this;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Headers appendLocation(String location) {
        try {
            response.out.write(String.format("Location: %s", location).getBytes());
            response.out.write(Response.CRLF);
            return this;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Headers appendContentType(String location) {
        try {
            response.out.write(String.format("Content-Type: %s", location).getBytes());
            response.out.write(Response.CRLF);
            return this;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ChunkedResponseMessageBody chunkBody() {
        try {
            response.out.write(Response.CRLF);
            return new ChunkedResponseMessageBody(response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ResponseMessageBody body() {
        try {
            response.out.write(Response.CRLF);
            return new ResponseMessageBody(response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
