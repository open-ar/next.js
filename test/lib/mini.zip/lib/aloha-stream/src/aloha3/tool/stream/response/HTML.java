package aloha3.tool.stream.response;

public final class HTML {
    private final Response response;

    public HTML(Response response) {
        this.response = response;
    }

    public void put(String htmlString) {
        response.start().
            ok().
            appendContentType("text/html").
            body().
            add(htmlString).
            end();
    }
}
