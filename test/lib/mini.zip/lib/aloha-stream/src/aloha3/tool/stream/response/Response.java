package aloha3.tool.stream.response;

import aloha3.tool.stream.Server;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.buildstep.ResponseMessageBuildStep;
import aloha3.tool.stream.response.buildstep.StatusLine;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;

import java.io.OutputStream;

/**
 * <pre>
 * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-6">6 Response</a>
 *
 * Response Message Build Step:
 * 1. StatusLine
 * 2. Headers
 * 3. Body(ResponseMessageBody or ChunkedResponseMessageBody)
 * 4. Footer(ChunkedResponseMessageBody only)
 * 5. Completed
 *
 * How To Use:
 *
 * 1. normal response:
 * new Response(out).start().
 *     ok().
 *     appendContentType("key","value").
 *     body().
 *     append("body").
 *     end();
 *
 * 2. chunked response:
 * new Response(out).start().
 *     ok().
 *     appendContentType("key","value").
 *     chunkedBody().
 *     append("body").
 *     footer().
 *     append("key","value").
 *     end();
 *
 * 3. create 302 response:
 * new Response(out).redirectTo("URL");
 * or
 * new Response(out).start().found("URL");
 *
 * 4. easy way to create a response:
 * - use {@link #chunked()} to create a chunked response
 * - use {@link #json(OutputStream)}} to create a json string response
 * - use {@link #javaScript(Request, OutputStream, Server.Config)} to create a javascript file response
 * - use {@link #cascadingStyleSheet(Request, OutputStream, Server.Config)} to create a css file response
 * - use {@link #html(OutputStream)} to create a html file response
 * </pre>
 */
public final class Response {

    public static final byte[] CRLF = new byte[]{0x0D, 0x0A};
    public static final String CRLF_STR = "\r\n";

    public final OutputStream out;

    /**
     * use this filed to confirm which build step it is.
     */
    private ResponseMessageBuildStep currentBuildStep;

    public Response(OutputStream out) {
        this.out = out;
    }

    public ResponseMessageBuildStep getCurrentBuildStep() {
        return this.currentBuildStep;
    }

    public void currentBuildStep(ResponseMessageBuildStep buildStep) {
        this.currentBuildStep = buildStep;
    }

    /**
     * Start response message build flow
     */
    public StatusLine start() {
        return new StatusLine(this);
    }

    public ChunkedResponseMessageBody chunked() {
        return this.start().ok().appendChunked().chunkBody();
    }

    public void redirectTo(String location) {
        this.start().found(location);
    }

    public static Json json(OutputStream out) {
        return new Json(new Response(out));
    }

    public static HTML html(OutputStream out) {
        return new HTML(new Response(out));
    }

    public static AbstractFile.JavaScript javaScript(Request request, OutputStream out, Server.Config config) {
        return new AbstractFile.JavaScript(request, new Response(out), config);
    }

    public static AbstractFile.CascadingStyleSheet cascadingStyleSheet(Request request, OutputStream out, Server.Config config) {
        return new AbstractFile.CascadingStyleSheet(request, new Response(out), config);
    }

    public static AbstractFile.Png png(Request request, OutputStream out, Server.Config config) {
        return new AbstractFile.Png(request, new Response(out), config);
    }

    /*
     * https://developer.mozilla.org/en-US/docs/Web/HTML/Element/
     */
    public interface Element {

        String description();

        String from();

        String to();
    }
}