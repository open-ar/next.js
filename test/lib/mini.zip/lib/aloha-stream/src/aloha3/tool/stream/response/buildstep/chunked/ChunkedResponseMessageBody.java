package aloha3.tool.stream.response.buildstep.chunked;

import aloha.AutoCloseableLock;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.ResponseMessageBody;

import java.io.IOException;

import static aloha3.tool.stream.response.Response.CRLF;

/**
 * <pre>
 * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-3.6.1">Chunked Transfer Coding</a>
 * The Build Step when transfer-coding is chunked.
 * If transfer-coding is not chunked, please refer to {@link aloha3.tool.stream.response.buildstep.ResponseMessageBody ResponseMessageBody}
 * </pre>
 */
public class ChunkedResponseMessageBody extends ResponseMessageBody {
    private final AutoCloseableLock lock = new AutoCloseableLock();

    public ChunkedResponseMessageBody(Response response) {
        super(response);
    }

    @Override
    public ChunkedResponseMessageBody add(byte[] chunkByte) {
        String lengthHex = Integer.toHexString(chunkByte.length);
        try (AutoCloseable _ = lock.acquire()) {
            // chunk-size
            response.out.write(lengthHex.getBytes());
            response.out.write(CRLF);
            // chunk-data
            response.out.write(chunkByte);
            response.out.write(CRLF);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    @Override
    public ChunkedResponseMessageBody add(String StringData) {
        super.add(StringData);
        return this;
    }

    public ChunkedResponseMessageBody addSlot(String slotName, String content) {
        super.addSlot(slotName, content);
        return this;
    }

    public Footer footer() {
        try {
            // end of body
            response.out.write("0".getBytes());
            response.out.write(CRLF);
            return new Footer(response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void end() {
        try {
            response.out.write("0".getBytes());
            response.out.write(CRLF);
            response.out.write(CRLF);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        super.end();
    }
}
