package aloha3.tool.stream.response.buildstep;

import aloha3.tool.stream.response.Response;

import java.io.IOException;

/**
 * <pre>
 * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-6.1">6.1 Status-Line</a>
 * </pre>
 */
public class StatusLine extends ResponseMessageBuildStep {
    private boolean called = false;

    public StatusLine(Response response) {
        super(response);
    }

    /**
     * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-10.2.1">200 OK</a>
     * @return next build step
     */
    public Headers ok() {
        try {
            called = true;
            response.out.write("HTTP/1.1 200 OK".getBytes());
            response.out.write(Response.CRLF);
            return new Headers(response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * <a href="https://datatracker.ietf.org/doc/html/rfc2616#section-10.3.3">302 Found</a>
     * @param location location to redirect
     */
    public void found(String location) {
        try {
            called = true;
            response.out.write("HTTP/1.1 302 Found".getBytes());
            response.out.write(Response.CRLF);
            new Headers(response).appendLocation(location).end();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void end() {
        if (called)
            super.end();
        else {
            this.ok().end();
        }
    }
}
