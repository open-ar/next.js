package aloha3.tool.stream.response;

import aloha3.tool.stream.Server;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.buildstep.Headers;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.function.Function;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

public abstract class AbstractFile {

    private AbstractFile(Request request, Response response, Server.Config config, Function<Headers, Headers> more) {
        more.
            apply(response.start().ok()).
            body().
            add(read(config, request.target())).
            end();
    }

    private static
    byte[]
    read(
        Server.Config config,
        String pathToFileName) {
        try {
            if (config.userDir().getFileSystem().toString().endsWith(".jar")) {
                try (JarFile jarFile = new JarFile(config.userDir().getFileSystem().toString())) {
                    // e.g: "/www" + "/assets/css/queryMasterViews.css"
                    final String path = config.userDir() + pathToFileName;
                    String resourcePath = path.startsWith("/") ? path.substring(1) : path;
                    ZipEntry entry = jarFile.getEntry(resourcePath);
                    if (entry != null) {
                        try (InputStream is = jarFile.getInputStream(entry)) {
                            return is.readAllBytes();
                        }
                    } else {
                        throw new IOException("Resource not found in JAR: " + resourcePath);
                    }
                }
            } else {
                String relativePath = pathToFileName.startsWith("/") ? pathToFileName.substring(1) : pathToFileName;
                return Files.readAllBytes(config.userDir().resolve(relativePath).normalize());
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read resource: " + pathToFileName, e);
        }
    }

    //https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Type#examples
    //https://developer.mozilla.org/en-US/docs/Learn/Server-side/Configuring_server_MIME_types
    public static final class JavaScript
        extends AbstractFile {
        public JavaScript(Request request, Response response, Server.Config config) {
            super(
                request,
                response,
                config,
                headers -> headers.appendContentType("application/javascript")); // text/js
        }
    } // JavaScript

    public static final class CascadingStyleSheet
        extends AbstractFile {
        public CascadingStyleSheet(Request request, Response response, Server.Config config) {
            super(
                request,
                response,
                config,
                headers -> headers.appendContentType("text/css"));
        }
    } // CascadingStyleSheet

    public static final class Png
        extends AbstractFile {
        public Png(Request request, Response response, Server.Config config) {
            super(
                request,
                response,
                config,
                headers -> headers.appendContentType("image/png"));
        }
    } // Png
} // AbstractFile
