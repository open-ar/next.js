package aloha3.tool.stream;

import aloha.module.object.DateTime;
import aloha3.tool.stream.exception.IExceptionHandler;
import aloha3.tool.stream.exception.NoneExceptionHandler;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.request.RequestParser;
import aloha3.tool.stream.response.HTML;
import aloha3.tool.stream.response.Response;

import java.awt.Desktop;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class Server {

    public record Config(
        int PORT,
        Path userDir,
        IExceptionHandler exceptionHandler,
        Logger.LEVEL logLevel,
        boolean openBrowser) {

        public Config(int PORT, Path userDir) {
            this(PORT, userDir, new NoneExceptionHandler(), null, true);
        }

        public Config(int PORT, Path userDir, boolean openBrowser) {
            this(PORT, userDir, new NoneExceptionHandler(), null, openBrowser);
        }

        public Config(int PORT, Path userDir, IExceptionHandler exceptionHandler) {
            this(PORT, userDir, exceptionHandler, null, true);
        }

        public Config(int PORT, Path userDir, IExceptionHandler exceptionHandler, boolean openBrowser) {
            this(PORT, userDir, exceptionHandler, null, openBrowser);
        }

        public Config(int PORT, Path userDir, Logger.LEVEL logLevel) {
            this(PORT, userDir, new NoneExceptionHandler(), logLevel, true);
        }

        public Config(int PORT, Path userDir, Logger.LEVEL logLevel, boolean openBrowser) {
            this(PORT, userDir, new NoneExceptionHandler(), logLevel, openBrowser);
        }
    }

    private static final Path userDir = Paths.get(
        System.getProperty("user.dir"),
        "www");

    public static void main(String[] args) {
        DateTime.YMDHMSMSEC start = DateTime.YMDHMSMSEC.current();
        start(new Config(8080, Server.userDir), start,(_,_)->{});
    }

    public static void start(
        Config config,
        DateTime.YMDHMSMSEC start,
        BiConsumer<Request, Response> defaultHandler) {

        Logger.setLevel(config.logLevel);

        try (ServerSocket server = new ServerSocket(config.PORT)) {
            try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {

                Logger.INFO.log("Elapse time to start Server=" +
                    DateTime.YMDHMSMSEC.current().compareTo(start) + " ms");
                if (config.openBrowser()) {
                    openBrowser("http://localhost:" + config.PORT);
                }

                while (true) {
                    Socket socket = server.accept();
                    if (stop(socket)) return;
                    executor.submit(
                        Thread.startVirtualThread(
                            () ->
                                handle(
                                    socket,
                                    config,
                                    _->{},
                                    defaultHandler)));
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    private static boolean stop(@SuppressWarnings("unused") Socket socket) {
        return false;
    }
    private static void handle(
        Socket socket,
        Config config,
        Consumer<HTML> data,
        BiConsumer<Request, Response> defaultHandler) {

        Logger.DEBUG.log("Begin:" + Thread.currentThread() + "@" + DateTime.YMDHMSMSEC.current());
        try (InputStream in = socket.getInputStream(); OutputStream out = socket.getOutputStream()) {

            Request req = RequestParser.readRequest(in);
            if (req == Request.INVALID) {
                Logger.DEBUG.log("End:  " + Thread.currentThread() + "@" + DateTime.YMDHMSMSEC.current() +
                     " target= " + (req == Request.INVALID ? "none" : req.target()));
                return;
            }

            if (req.target().endsWith("favicon.ico"))
                Response.png(req, out, config);
            else if (req.target().endsWith(".js"))
                Response.javaScript(req, out, config);
            else if (req.target().endsWith(".css"))
                Response.cascadingStyleSheet(req, out, config);
            else if (req.target().endsWith(".png"))
                Response.png(req,out,config);
            else {
                final var response = new Response(out);
                config.exceptionHandler.catchException(
                    req,
                    response,
                    () -> {
                        if ((req.method().equalsIgnoreCase("post") || req.method().equalsIgnoreCase("put"))) {
                            RequestParser.parseHeaderLines(req);
                            String body = new String(Objects.requireNonNull(RequestParser.parseBody(req)));
                            Logger.DEBUG.log("body=" + body);
                            RequestParser.parseKeyValues(body, req);
                        } else {
                            String urlParams = URI.create(req.target()).getRawQuery();
                            RequestParser.parseKeyValues(urlParams, req);
                        }
                        defaultHandler.accept(req, response);
                    });
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Logger.DEBUG.log("End:  " + Thread.currentThread() + "@" + DateTime.YMDHMSMSEC.current());
    }

    private static void openBrowser(String uriString) {
        new Thread(() -> {
            try {
                Thread.sleep(1000);
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(new URI(uriString));
                } else {
                    System.out.println("Desktop is not supported.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

}
