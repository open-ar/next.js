package aloha3.tool.stream.exception;

@FunctionalInterface
public interface RunWithThrowable {
    void run() throws Exception;
}
