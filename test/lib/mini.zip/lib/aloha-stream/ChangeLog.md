# 2025/11/16 ver

- Add openBrowser option

# 2025/05/12 ver

大規模なリファクタリングを行う。

- aloha3.tool.stream.Serverクラスのリファクタリング
  - HTTPリクエストのパース処理を分離し、aloha3.tool.stream.requestパッケージに移動
  - HTTPレスポンスの構築処理を分離し、aloha3.tool.stream.responseパッケージに移動
    - 新しいHTTPレスポンス構築ステップの追加（aloha3.tool.stream.response.buildstepパッケージ）
    - ResponseMessageBuildStepクラスの導入で、HTTPレスポンスのChunked電文をHTML標準通りに、正確にステップバイステップで構築できるように
  - HTTPレスポンスのエラー処理をaloha3.tool.stream.exceptionパッケージに移動
  - ロギング処理をaloha3.tool.stream.logパッケージに移動


# 2025/04/12 ver

- aloha3.tool.stream.exception.IExceptionHandler追加
  エラーの場合、共通エラー画面に遷移できるように
- aloha3.tool.stream.Server.Response#chunkedWithoutHeader追加：
  200以外のHTTPステータスコードでも返却可能するように
