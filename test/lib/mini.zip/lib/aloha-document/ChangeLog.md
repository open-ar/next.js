# 2025/11/26 ver

- DocumentLineItem add ArrayIndex support
- Service add `aloha3.document.business.Service.readAllSubmits` method for get all submits(not just latest) of a document
- Use common modal UI (by common-modal.css)

# 2025/11/17 ver

- Aloha document: Tree（NestedElement）でFormの構造を管理する
  - TreeのRootノードは`aloha3.document.business.Service.initRootFormElement()`メソッドで初期化される
