# 2025/11/17 ver

- Aloha document: Tree（NestedElement）でFormの構造を管理する
  - TreeのRootノードは`aloha3.document.business.Service.initRootFormElement()`メソッドで初期化される
