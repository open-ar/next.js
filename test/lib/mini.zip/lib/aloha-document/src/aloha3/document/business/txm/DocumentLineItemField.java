package aloha3.document.business.txm;

import aloha3.document.record.DocumentLineItem;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView;

public final class DocumentLineItemField
    extends TxStarView.FieldOf.AndIntFK<DocumentLineItem> {

    public Mandatory<Long> DocumentLineItemId() { return super.PK();}
    public Mandatory<Integer> NestedElementId() { return super.FK();}
    public final Mandatory<String> Value = attr(DocumentLineItem.Value.class);
    public final Optional<Byte> ArrayIndex = opt(DocumentLineItem.ArrayIndex.class);
}
