package aloha3.document.record;

import aloha.mapping.DBCP;
import aloha.mapping.IDbGroup;
import aloha3.module.object.record.transaction.TxEntityIntFK;

public final class Document extends TxEntityIntFK.On<Form> {
    @Override
    public IDbGroup dbGroup() {
        return DBCP.commonDbGroup();
    }
}
