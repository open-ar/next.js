package aloha3.document.model;

import aloha.module.object.Immutable;
import aloha.module.object.ImmutableArray;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.module.object.model.OneToMany;
import aloha3.module.object.view.StarView;

public record Write(
    StarView.Read<FormField> form,
    ImmutableArray.NonEmpty<
        OneToMany.Values<
            StarView.Read<FormElementField>,
            String>> lineItems)
    implements Immutable {
}
