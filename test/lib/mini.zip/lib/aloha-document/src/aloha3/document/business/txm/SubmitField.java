package aloha3.document.business.txm;

public final class SubmitField extends AbstractSubmitField {
}
