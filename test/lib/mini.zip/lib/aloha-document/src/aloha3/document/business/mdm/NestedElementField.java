package aloha3.document.business.mdm;

import aloha3.document.record.Enum.REQUIRED;
import aloha3.document.record.NestedElement;
import aloha3.module.object.view.StarView;

public final class NestedElementField
    extends StarView.Hierarchy.FieldOf<NestedElement> {

    public Member.Mandatory<Integer> NestedElementId() {
        return unsafeCenterMember();
    }
    public Member.Mandatory<Integer> FromFormElementId() {
        return unsafePivotFKMember();
    }
    public Member.Mandatory<Integer> ToFormElementId() {
        return unsafePivotAFKMember();
    }
    public final Member.Optional<Byte> ArrayMaxSize = opt(NestedElement.ArrayMaxSize.class);
    public final Member.Optional<REQUIRED> Required = optEnum(NestedElement.Required.class);
}
