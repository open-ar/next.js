package aloha3.document.record;

import aloha3.document.record.Enum.REQUIRED;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.HierarchyEntity;

public final class NestedElement
    extends HierarchyEntity.Of.Tree<FormElement> {

    public static final class ArrayMaxSize extends AttributeEntity.Of<NestedElement,Byte> {}
    public static final class Required extends FixedAttributeEntity.EnumOf<NestedElement, REQUIRED> {}
}
