package aloha3.document.record;

import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly;

public final class SubmitLineItem
    extends ChildTxEntityLongAFKOnly.Of<Submit,DocumentLineItem> {
}
