package aloha3.document.model;

import aloha.module.object.Immutable;
import aloha.module.object.ImmutableArray;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.record.SubmitLineItem;
import aloha3.module.object.model.OneToMany;
import aloha3.module.object.record.meta.transaction.ChildTxLongAFKOnly;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

public record Read<F extends AbstractSubmitField>(
    StarView.Read<FormField> form,
    TxStarView.Read<DocumentField> document,
    TxStarView.Read<F> submit,
    ImmutableArray.NonEmpty<
        OneToMany<
            StarView.Read<FormElementField>,
            ChildTxLongAFKOnly.Read<SubmitLineItem>>> lineItems)
    implements Immutable {
}
