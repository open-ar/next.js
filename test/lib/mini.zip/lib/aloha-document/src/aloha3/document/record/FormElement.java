package aloha3.document.record;

import aloha.mapping.DBCP;
import aloha.mapping.IDbGroup;
import aloha.module.object.Type;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;

public final class FormElement extends CoreEntity  {
    @Override
    public IDbGroup dbGroup() {
        return DBCP.commonDbGroup();
    }
    public static final class Name extends AttributeEntity.Of<FormElement,String> {}
    public static final class RefType extends FixedAttributeEntity.EnumOf<FormElement, Type.RefType> {}
}
