package aloha3.document.business.mdm;

import aloha.module.object.Type;
import aloha3.document.record.FormElement;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.StarView;

public final class FormElementField extends StarView.FieldOf<FormElement> {
    public Mandatory<Integer> FormElementId() { return coreMember(); }
    public final Mandatory<String> Name = attr(FormElement.Name.class);
    public final Mandatory<Type.RefType> RefType = asEnum(FormElement.RefType.class);
}
