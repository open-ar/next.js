package aloha3.document.record;

import aloha.mapping.DBCP;
import aloha.mapping.IDbGroup;
import aloha3.module.object.record.transaction.TxAttributeEntity;
import aloha3.module.object.record.transaction.TxEntityIntFK;

public final class DocumentLineItem
    extends TxEntityIntFK.On<NestedElement> {
    @Override
    public IDbGroup dbGroup() {
        return DBCP.commonDbGroup();
    }
    
    public static final class Value extends TxAttributeEntity.Of<DocumentLineItem,String> {
        public Value() {
            super(()->SUFFIX_TO_RESOLVE_CONFLICT_RESERVED_WORD);
        }
    }

    public static final class ArrayIndex extends TxAttributeEntity.Of<DocumentLineItem, Byte> { }
}
