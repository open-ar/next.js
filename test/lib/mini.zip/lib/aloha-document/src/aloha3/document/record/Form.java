package aloha3.document.record;

import aloha.mapping.DBCP;
import aloha.mapping.IDbGroup;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.coc.Graph;

public final class Form extends CoreEntity  {
    @Override
    public IDbGroup dbGroup() {
        return DBCP.commonDbGroup();
    }
    public static final class Name extends AttributeEntity.Of<Form,String> {}
    public static final class GraphId extends FixedAttributeEntityAFK.Unique<Form, Graph> {}
}
