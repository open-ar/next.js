package aloha3.document.business;

import aloha.module.func.Func;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.ImmutableArray;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Type;
import aloha.module.object.Views;
import aloha3.dml.NaturalTransformation;
import aloha3.dml.NaturalTransformationGraph;
import aloha3.dml.hidden.Join;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.document.business.txm.SubmitField;
import aloha3.document.model.Read;
import aloha3.document.model.Write;
import aloha3.document.record.Document;
import aloha3.document.record.DocumentLineItem;
import aloha3.document.record.Form;
import aloha3.document.record.FormElement;
import aloha3.document.record.NestedElement;
import aloha3.document.record.Submit;
import aloha3.document.record.SubmitLineItem;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.master.coc.GraphField;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.function.business.transaction.TxIntFKMgt;
import aloha3.module.function.business.transaction.TxLongFKMgr;
import aloha3.module.object.Records;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.meta.transaction.ChildTxLongAFKOnly;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

public record Service<F extends AbstractSubmitField>(
    ServiceContainer container,
    ServiceContainer.Conceptual conceptualContainer,
    Class<F> submitFieldClass) {

    public static final String ROOT_FORM_ELEMENT = "$ROOT_FORM_ELEMENT";

    public
    TxLongFKMgr.StarView.Family.ChildLongAFKOnly<
        Submit,
        Document,
        F,
        SubmitLineItem>
    submitFamily() {
        return container.getOrAddTxFamily(
            submitFieldClass,
            SubmitLineItem.class,
            TxLongFKMgr.StarView.Family.ChildLongAFKOnly.Generic::create);
    }
    public
    ImmutableArray<
        OneToOne.MayZero<
            OneToOne<
                StarView.Read<FormField>,
                StarView.Read<GraphField>>,
            OneToOne<
                StarView.Hierarchy.Read<NestedElementField>,
                StarView.Read<FormElementField>>>>
    joinFormElements(Views<StarView.Read<FormField>> forms) {

        return Func.apply(
            DateTime.YMDHMS.current(),
            asOf->
                NaturalTransformationGraph.join(
                        NaturalTransformation.fromCore(forms, asOf),
                        Form.GraphId.class,
                        f->f.GraphId,
                        container().getOrAddGraphMgr()).
                    unlessEmpty(
                        f2gs->
                            Join.Int.leftOuter(
                                f2gs,
                                NaturalTransformationGraph.loadFrom(
                                        f2gs,
                                        nestedElementTree(),
                                        asOf).
                                    joinTo(formElementMgr()).
                                    done(),
                                (l,r)->
                                    OneToOne.MayZero.of(l, OneToOne.of(r.left.right, r.right)),
                                OneToOne.MayZero::of,
                                l->l.right.intValue(GraphField::GraphId),
                                r->r.left.left.right.intValue(GraphField::GraphId),
                                aloha3.dml.Join.CARDINALITY.ONE_TO_MANY)));
    }

    public
    ImmutVOs<
        OneToOne<
            OneToOne<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                TxStarView.Read<DocumentField>,
                                StarView.Read<FormField>>,
                            TxStarView.Read<F>>,
                        ChildTxLongAFKOnly.Read<SubmitLineItem>>,
                    TxStarView.Read<DocumentLineItemField>>,
                StarView.Hierarchy.Read<NestedElementField>>,
            StarView.Read<FormElementField>>>
    readAll(Views<TxStarView.Read<DocumentField>> documents) {
        return NaturalTransformation.fromParentTxStarView(documents).
            thenFK(F->
                NaturalTransformation.ParentTx_.join(F, formMgr())).
            liftToParentTxView(t->t.left).
            join(submitFamily()).
            joinChildren(submitFamily()).
            thenAFK(F->
                NaturalTransformation.ChildTx_.join(F, documentLineItemMgr()).
                    thenSelf(
                        NaturalTransformation.ParentTx_::asParentTxIntFK).
                    thenFK(H->
                        NaturalTransformationGraph.
                            join(H, nestedElementTree()).
                            joinTo(formElementMgr()).
                            done()));
    }
    public
    ImmutableArray<
        OneToOne<
            OneToOne<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                TxStarView.Read<F>,
                                ChildTxLongAFKOnly.Read<SubmitLineItem>>,
                            TxStarView.Read<DocumentLineItemField>>,
                        StarView.Hierarchy.Read<NestedElementField>>,
                    StarView.Read<FormElementField>>,
                TxStarView.Read<DocumentField>>,
            StarView.Read<FormField>>>
    readLatestSubmits(Views<TxStarView.Read<DocumentField>> documents) {

        return joinLatestSubmit(documents).
            thenFK(F->
                NaturalTransformation.ParentTx_.
                    joinView(F,documentMgr()).
                    thenSelf(NaturalTransformation.ParentTx_::asParentTxIntFK).
                    thenFK(G->
                        NaturalTransformation.ParentTx_.
                            join(G,formMgr()).
                            done()));
    }

    public
    ImmutableArray<
        OneToOne<
            OneToOne<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                TxStarView.Read<F>,
                                ChildTxLongAFKOnly.Read<SubmitLineItem>>,
                            TxStarView.Read<DocumentLineItemField>>,
                        StarView.Hierarchy.Read<NestedElementField>>,
                    StarView.Read<FormElementField>>,
                TxStarView.Read<DocumentField>>,
            StarView.Read<FormField>>>
    readAllSubmits(TxIntFK.Read<Document> document) {

        return joinAllSubmit(NonEmptyVOs.of(document)).
            thenFK(F->
                NaturalTransformation.ParentTx_.
                    joinView(F,documentMgr()).
                    thenSelf(NaturalTransformation.ParentTx_::asParentTxIntFK).
                    thenFK(G->
                        NaturalTransformation.ParentTx_.
                            join(G,formMgr()).
                            done()));
    }
    private
    NaturalTransformation.ParentTx_<
        OneToOne<
            OneToOne<
                OneToOne<
                    OneToOne<
                        TxStarView.Read<F>,
                        ChildTxLongAFKOnly.Read<SubmitLineItem>>,
                    TxStarView.Read<DocumentLineItemField>>,
                StarView.Hierarchy.Read<NestedElementField>>,
            StarView.Read<FormElementField>>,
        Submit,
        TxLongFK.Read<Submit>>
    joinLatestSubmit(Views<TxStarView.Read<DocumentField>> documents) {

        return NaturalTransformation.fromParentTx(
                submitFamily().selectLatestTxsByFK(
                    Records.T.create(documents.map(TxStarView.Read::txReadOf)))).
            joinAttributes(submitFamily()).
            joinChildren(submitFamily()).
            thenAFK(F->
                NaturalTransformation.ChildTx_.
                    join(F, documentLineItemMgr())).
            thenSelf(NaturalTransformation.ParentTx_::asParentTxIntFK).
            thenFK(F->
                NaturalTransformationGraph.
                    join(F,nestedElementTree()).
                    joinTo(formElementMgr()).
                    liftToParentTxView(t->t.left.left.left.left));
    }
    private
    NaturalTransformation.ParentTx_<
        OneToOne<
            OneToOne<
                OneToOne<
                    OneToOne<
                        TxStarView.Read<F>,
                        ChildTxLongAFKOnly.Read<SubmitLineItem>>,
                    TxStarView.Read<DocumentLineItemField>>,
                StarView.Hierarchy.Read<NestedElementField>>,
            StarView.Read<FormElementField>>,
        Submit,
        TxLongFK.Read<Submit>>
    joinAllSubmit(NonEmptyVOs<TxIntFK.Read<Document>> documents) {

        return NaturalTransformation.fromParentTx(
                submitFamily().selectTxsByFK(documents)).
            joinAttributes(submitFamily()).
            joinChildren(submitFamily()).
            thenAFK(F->
                NaturalTransformation.ChildTx_.
                    join(F, documentLineItemMgr())).
            thenSelf(NaturalTransformation.ParentTx_::asParentTxIntFK).
            thenFK(F->
                NaturalTransformationGraph.
                    join(F,nestedElementTree()).
                    joinTo(formElementMgr()).
                    liftToParentTxView(t->t.left.left.left.left));
    }
    private static final StableValue<Service<?>> service = StableValue.of();

    @SuppressWarnings("unchecked")
    public static
    <F extends AbstractSubmitField>
    Service<F>
    get(
        ServiceContainer container,
        ServiceContainer.Conceptual conceptualContainer,
        Class<F> submitFieldClass) {
        return (Service<F>) service.orElseSet(()->init(container, conceptualContainer, submitFieldClass));
    }
    private static
    <F extends AbstractSubmitField>
    Service<F>
    init(
        ServiceContainer container,
        ServiceContainer.Conceptual conceptualContainer,
        Class<F> submitFieldClass) {
        // Ensure nested element tree is initialized
        conceptualContainer.getOrAddGraphTreeDistinctStarArrow(
            NestedElement.class,
            FormElementField.class,
            NestedElementField.class);
        return new Service<>(container, conceptualContainer, submitFieldClass);
    }
    public void register() {
        formMgr();
        formElementMgr();
        nestedElementTree();
        documentMgr();
        submitFamily();
    }
    public void newDocument(
        Write document) {
        //TODO
    }
    public void updateContents(
        TxStarView.Read<DocumentField> document,
        Write contents) {
        //TODO
    }
    public ImmutableArray.NonEmpty<Read<F>>
    readAll(TxStarView.Read<DocumentField> document) {
        //TODO
        return null;
    }
    public Read<F>
    readOf(TxStarView.Read<SubmitField> submit) {
        //TODO
        return null;
    }
    public
    CoreMgr.StarView<
        Form,
        FormField>
    formMgr() {
        return container.getOrAddCoreMgrOf(FormField.class);
    }
    public
    CoreMgr.StarView<
        FormElement,
        FormElementField>
    formElementMgr() {
        return container.getOrAddCoreMgrOf(FormElementField.class);
    }
    public
    TxIntFKMgt.StarView<
        Document,
        Form,
        DocumentField>
    documentMgr() {
        return container.getOrAddTxIntFKMgrOf(DocumentField.class);
    }
    public TxIntFKMgr.StarView<
        DocumentLineItem,
        NestedElement,
        DocumentLineItemField>
    documentLineItemMgr() {
        return container.getOrAddTxIntFKMgrOf(DocumentLineItemField.class);
    }
    public
    Graph.Tree.Distinct.StarArrow<
        FormElement,
        NestedElement,
        FormElementField,
        NestedElementField>
    nestedElementTree() {
        return conceptualContainer.
            getOrAddGraphTreeDistinctStarArrow(
                NestedElement.class,
                FormElementField.class,
                NestedElementField.class);
    }

    public
    StarView.Read<FormElementField>
    initRootFormElement() {
        return 
            formElementMgr().
            createViewsByAttribute(
                FormElement.Name.class,
                ImmutValues.NonEmptyValues.create(ROOT_FORM_ELEMENT),
                DateTime.YMDHMS.current()).
            apply(
                NonEmptyVOs::first,
                this::createRootFormElement);
    }

    private 
    StarView.Read<FormElementField> 
    createRootFormElement() {
        return formElementMgr().
            saveThen(
                StarView.Write.Prepare.Builder.
                    create(FormElementField.class).
                    setMandatory(
                        f -> f.Name,
                        FormElement.Name.class,
                        ROOT_FORM_ELEMENT).
                    setMandatoryEnum(
                        f -> f.RefType,
                        FormElement.RefType.class,
                        Type.RefType.BYTE).
                    build(),
                DateTime.YMDHMS.current()).
            apply(e ->
                formElementMgr().createView(e, DateTime.YMDHMS.current()));
    }
}
