package aloha3.document.business.txm;

import aloha3.document.record.Submit;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView;

public abstract class AbstractSubmitField
    extends TxStarView.FieldOf.AndLongFK<Submit> {

    public final Mandatory<Long> SubmitId() { return PK(); }
    public final Mandatory<Long> DocumentId() { return FK(); }
}
