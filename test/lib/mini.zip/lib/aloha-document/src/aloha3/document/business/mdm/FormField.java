package aloha3.document.business.mdm;

import aloha3.document.record.Form;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.StarView;

public final class FormField extends StarView.FieldOf<Form> {
    public Mandatory<Integer> FormId() { return coreMember(); }
    public final Mandatory<String> Name = attr(Form.Name.class);
    public final Mandatory<Integer> GraphId = attr(Form.GraphId.class);
}
