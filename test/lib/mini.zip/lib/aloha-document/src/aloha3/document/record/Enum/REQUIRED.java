package aloha3.document.record.Enum;

import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutableArray;

import static aloha.module.object.IdentifiableEnum.find;
import static aloha.module.object.IdentifiableEnum.toArray;

public enum REQUIRED implements IdentifiableEnum<REQUIRED> {
    MANDATORY((byte)1),
    OPTIONAL((byte)2);

    private final byte id;
    REQUIRED(byte id) {
        this.id = id;
    }
    @Override
    public byte id() {
        return this.id;
    }
    @Override
    public REQUIRED of(byte b) {
        return find(id,array);
    }
    final static ImmutableArray<REQUIRED> array = toArray(REQUIRED.class);
}
