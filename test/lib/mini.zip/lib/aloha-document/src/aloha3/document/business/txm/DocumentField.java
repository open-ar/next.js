package aloha3.document.business.txm;

import aloha3.document.record.Document;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView;

public final class DocumentField
    extends TxStarView.FieldOf.AndIntFK<Document> {

    public Mandatory<Long> DocumentId() { return PK(); }
    public Mandatory<Integer> FormId() { return FK(); }
}
