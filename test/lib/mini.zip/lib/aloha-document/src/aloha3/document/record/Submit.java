package aloha3.document.record;

import aloha.mapping.DBCP;
import aloha.mapping.IDbGroup;
import aloha3.module.object.record.transaction.TxEntityLongFK;

public final class Submit extends TxEntityLongFK.On<Document> {
    @Override
    public IDbGroup dbGroup() {
        return DBCP.commonDbGroup();
    }
}
