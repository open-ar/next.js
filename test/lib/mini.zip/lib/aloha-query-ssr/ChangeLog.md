# 2025/12/03 ver

- aloha-document関連機能（CRUD / Document 画面）をaloha-query-ssr-documentとして切り出し


# 2025/11/17 ver

- CRUD / Document 画面をTree構造を対応できるように
- CRUD / Document の実装にvo層（src/aloha3/controller/query/vo）を導入することで画面を簡潔化にする

# 2025/10/08 ver

- CRUD / Document 画面を新規追加し、aloha-documentでドキュメント作成できるように

# 2025/08/29 ver

- CRUD / WorkFlow Transition 画面を新規追加し、FlowableのTxをWorkFlow通り状態遷移できるように
- CRUD / Workflow 画面でWorkflow新規の際に名前を入力できるように

# 2025/07/22 ver

- Query / Transaction 画面のサポートパターンを追加
- Query / Transaction & Master 画面のUI改善
  - 最初スタートしたノードに緑枠付ける
  - データなしの場合のUIを改善

# 2025/07/04 ver
- Query / Transaction 画面
  - TX parentが選択されたら、TX Childが選択できるように
  - `Refer/Refered`にRelationが非表示するように（増幅現象を非サポートするよう）

# 2025/06/20 ver
- バグ対応：AFKの場合Field名にPrefixが付与されていた場合、正しくJoinできないバグを修正
- バグ対応：DerivedTxMgrの場合、正しくJoinできないバグを修正

# 2025/06/05 ver

- バグ対応：ロールバック画面のYMDHMSの時刻は00秒の場合、00がバックエンドに渡さなくても処理できるように

# 2025/05/30 ver

- ロールバック機能追加
  - UI変更点：`ロールバック`メニューを選択し、ロールバック時間を指定して実行する
- Temporal Attributeのサポート
  - UI変更点：`データ管理 / マスタ`メニューから` (CORE Temporal)`付きのCoreを選択し、`時系列属性`列で操作する
- Controllerのリファクタリング：AbstractController追加

# 2025/03/24 ver 初版作成

データブラウザをSSRで実現する（データブラウザーのJQueryからの移行）。

本バージョンは、dx-demo3のサンプルプとして一緒に添付したロジェクトとなりです。

起動方法は、README.mdを参照してください。

**特徴**

HTML-Firstの観点で、Thymeleaf＋WebCで作成されたweb component＋HTMX化を目指しています。

1) [DSD(宣言型の Shadow DOM)](https://web.dev/articles/declarative-shadow-dom?hl=ja)を利用し、ストリーミングで画面を読み込んでいます。
2) JSなしでも、基本的なCRUDが動作します。
3) JS有効な場合、HTMXを利用し、SPAのように動作できるように（TODO）
