# What is in this directory?

HTMX helper for Application should defined here.
The purpose is that the code referenced from the HTML can be very simple: e.g:

```html
<webc:block webc:replace="_/button :: add(${pivot})" />
```

# How about the `_components` directory?

The normal components should put into the `_components` directory.
