package aloha3.controller.tool.query.models;

import java.util.HashMap;

public class EntityValues extends HashMap<String, String> {
    String name;

    private EntityValues() {
    }

    public Integer getInt(String name) {
        return this.containsKey(name) ? Integer.valueOf(this.get(name)) : null;
    }

    public static EntityValues parse(String strValues) {
        EntityValues entityValues = new EntityValues();
        int pos1 = strValues.indexOf("[");
        if (pos1 > 0) {
            entityValues.name = strValues.substring(0, pos1);
            strValues = strValues.substring(pos1 + 1);
        }

        if (strValues.endsWith("]")) {
            strValues = strValues.substring(0, strValues.length() - 1);
        }

        String[] var3 = strValues.split(",");
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            String valueWithName = var3[var5];
            int pos = valueWithName.indexOf("=");
            if (pos != -1) {
                entityValues.put(valueWithName.substring(0, pos).trim(), valueWithName.substring(pos + 1).trim());
            }
        }

        return entityValues;
    }
}
