package aloha3.controller.tool.query;

import aloha3.controller.tool.query.models.AlohaRecord;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.object.record.spec.Schema;

import javax.json.JsonObject;
import java.util.Map;

public class AlohaQueryV1 {

    private static boolean isInitialized;

    public static synchronized void 
    init(
        ServiceContainer container,
        ServiceContainer.Conceptual conceptualContainer
    ) {
        if (isInitialized) {
            return;
        }
        isInitialized = true;

        ReflectiveJoinTool.init(container);
        ReflectiveJoinTool.init(conceptualContainer);

        for(Map.Entry<String, AlohaRecord<Schema<?>,?>> conceptual : ReflectiveJoinTool.conceptuals.entrySet()) {
            ReflectiveJoinTool.records.put(conceptual.getKey(), conceptual.getValue());
        }
        try {
            ViewMgr.init("",false);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static int getId(JsonObject node) {
        String idStr = node.getString("id", null);
        if (idStr != null) {
            try {
                return Integer.parseInt(idStr);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid id format: " + idStr, e);
            }
        } else {
            return node.getInt("id");
        }
    }

}
