package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime.YMDHMS;
import aloha3.module.object.model.read.AbstractTree.SuperTree;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity.Of.Tree;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.List;

public interface GraphTreeWrapper<E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> extends GraphWrapper {
    int registerRoot(JsonArray var1);

    int updateRoot(JsonObject var1);

    int removeRoot(Integer var1);

    default JsonArray queryTree() {
        return queryTree(YMDHMS.current());
    }

    JsonArray queryTree(YMDHMS var1);

    default List<SuperTree> selectAllRoots() {
        return selectAllRoots(YMDHMS.current());
    }

    List<SuperTree> selectAllRoots(YMDHMS var1);
}
