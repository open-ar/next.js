package aloha3.controller.tool.query.crud;

import aloha.module.Array;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.crud.childmodel.DerivedTxLongAFKChildIntAFKOnlyModel;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.DerivedTxLongAFKMgt;
import aloha3.module.function.business.transaction.TxFamilyMgt;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.transaction.DerivedTxLongAFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DerivedTxLongAFKFamilyIntAFKOnlyWrapper<
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends SealedTxParent<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityIntAFKOnly.Of<E,CM>,
    CM extends CoreEntity,
    AF extends AbstractField & TxStarView.Field<A>,
    T extends DerivedTxLongAFKChildIntAFKOnlyModel<E,X,A,F,CH,CM,TxStarView.Read<F>>>
    extends BaseMgrWrapper<T, Long, Long> {

    private final String name;
    private final F field;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final DerivedTxLongAFKMgt.StarView<E,X,A,F> parentMgr;
    private final DerivedTxLongAFKMgt.StarView.Family.ChildIntAFKOnly<E,X,A,F,CH> familyMgr;
    private final String childAfkName;
    private final List<IColumn> attributeColumns;

    public DerivedTxLongAFKFamilyIntAFKOnlyWrapper(
        String name,
        F field,
        Class<CH> childRecord,
        Class<CM> childAfkRecordType,
        DerivedTxLongAFKMgt.StarView<E,X,A,F> parentMgr,
        DerivedTxLongAFKMgt.StarView.Family.ChildIntAFKOnly<E,X,A,F,CH> familyMgr) {

        this.name = name;
        this.field = field;
        this.childRecord = childRecord;
        this.parentMgr = parentMgr;
        this.familyMgr = familyMgr;
        this.childAfkRecordType = childAfkRecordType;

        ImmutableArray<IColumn> immutableArray = familyMgr.childTx().columnArray();
        this.attributeColumns = new ArrayList<>();
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 1));

        this.childAfkName = this.attributeColumns.get(0).getJavaName();
    }

    @Override
    public
    boolean
    isFamily() {
        return true;
    }

    public
    String
    itemName() {

        return childRecord.getSimpleName();
    }

    public
    String
    afkEntityName() {

        return childAfkRecordType.getSimpleName();
    }

    public
    String
    afkAttributeName() {

        return childAfkName;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        String foreignEntity = this.parentMgr.foreignEntity().getClass().getSimpleName();
        long fkId = Long.parseLong(json.getString(this.getCenterMember().javaName()));
        var mayNullVO = GenericSearch.queryTxViewByPK(foreignEntity, fkId);
        String afkName = ((TxStarView.FieldOf.AndLongAFK)this.parentMgr.field()).unsafeAFK().javaName();
        String afkEntity = null;
        if (afkName.endsWith("Id")) {
            afkEntity = afkName.substring(0, afkName.length() - 2);
        }
        MayNullVO mayNullAfk = GenericSearch.queryTxViewByPK(afkEntity, Long.parseLong(json.getString(afkName)));
        TxStarView.Read<AF> txAfk = (TxStarView.Read)mayNullAfk.mustNonNull();

        TxStarView.Write.Prepare.Builder builderParent = TxStarView.Write.Prepare.Builder.
            create(
                getFieldClass());
        setValues(json, field, builderParent);

        JsonArray items = json.getJsonArray("child");
        List<Read<CM>> lineItemsMore = new ArrayList<>();

        for(int i = 0; i < items.size(); i++) {
            JsonObject item = items.getJsonObject(i);
            int afkId = Integer.valueOf(item.getString(afkAttributeName()));
            Core.Read<CM> afk = GenericSearch.queryMasterViewByPK(afkEntityName(), afkId).mustNonNull().coreRead();
            lineItemsMore.add(afk);
        }

        Read<CM> first = lineItemsMore.get(0);
        Read<CM>[] others;
        if (lineItemsMore.size() > 1)
            others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new Read[0]);
        else
            others = new Read[0];

        return familyMgr.
            save(
                builderParent.build(),
                mayNullVO.mustNonNull().txRead(),
                txAfk.txRead(),
                DateTime.YMDHMS.current(),
                (view, childTx)->
                    Array.create(
                        aloha3.module.object.model.write.
                            TxModel.Builder.
                            create(
                                view,
                                childTx,
                                first),
                        others,
                        (builder,lineItem)->
                            builder.setValue(
                                lineItem),
                        builder ->
                            builder.build())).
            get();

    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.unsafeAFK().javaName());
    }

    @Override
    public
    ImmutVOs<T>
    query() {

        List<T> result = new ArrayList<>();
        queryTxs().
            foreach(
                (txRead)->
                    result.add(
                        (T) DerivedTxLongAFKChildIntAFKOnlyModel.of(
                            familyMgr.createModel((DerivedTxLongAFK.Read<E>)txRead))));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    MayNullVO<T>
    queryByPK(Long id) {

        return (MayNullVO<T>) parentMgr.
            selectTx(
                id).
            apply(
                (tx)->
                    MayNullVO.of(
                        DerivedTxLongAFKChildIntAFKOnlyModel.of(
                            familyMgr.createModel(tx))),
                ()->MayNullVO.nullInstance());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Long> pkIDs) {

        List<T> result = new ArrayList<>();
        parentMgr.
            selectTxs(
                DistinctIds.toLongIDs(pkIDs)).
            foreach(
                (txRead)->
                    result.add(
                        (T) DerivedTxLongAFKChildIntAFKOnlyModel.of(
                            familyMgr.createModel(txRead))));
        return ImmutVOs.create(result);
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(DerivedTxLongAFK.Read.createCriteria(this.field.entity()));
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs foreigns,
        Map<String, Object> params) {

        return queryByFKViews(foreigns, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKViews(
        ImmutVOs<TxStarView.Read<F>> foreigns,
        Map<String, Object> params) {

        if (params.containsKey("from") && params.containsKey("to")) {
            return queryByFKAndBetween(
                foreigns,
                (DateTime.YMDHMS) params.get("from"),
                (DateTime.YMDHMS) params.get("to"));
        }

        List<T> result = new ArrayList<>();
        foreigns.unlessEmpty_(
            (foreignCore)->
                parentMgr.
                    createViewsByAFK(
                        (NonEmptyVOs)foreignCore.map(v -> v.txRead())).
                    foreach(
                        (txView) ->
                            result.add(
                                (T) DerivedTxLongAFKChildIntAFKOnlyModel.of(
                                    familyMgr.createModel((DerivedTxLongAFK.Read<E>)txView)))));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKAndBetween(
        ImmutVOs<TxStarView.Read<F>> fkViews,
        // TODO derived Tx no from and to?
        DateTime.YMDHMS from,
        DateTime.YMDHMS to) {

        List<T> result = new ArrayList<>();
        fkViews.
             unlessEmpty_(
                 (fk)->
                     familyMgr.
                         createViews((NonEmptyVOs)fk).
                             // fk.coreRead(),
                             // from,
                             // to).
                         foreach(
                             (txView)->
                                 result.add(
                                     (T) DerivedTxLongAFKChildIntAFKOnlyModel.of(
                                         familyMgr.createModel(
                                             (DerivedTxLongAFK.Read<E>)txView)))));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByIntAFKViews(afkViews,  afkName, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName,
        Map<String, Object> params) {

        if (parentMgr.field().unsafeAFK().javaName().equals(afkName))
            return queryByFKs(afkViews, params);

        return afkViews.
            apply(
                (fks)-> {
                    ImmutVOs<aloha3.module.object.record.transaction.read.ChildTxIntAFKOnly> children = TxFamilyMgt.ChildIntAFKOnly.
                        selectChildren(
                            (NonEmptyVOs) fks.map(v->v.coreRead()),
                            familyMgr);
                    return children.
                        apply(
                            (txChild) ->
                                queryByPKs(
                                    DistinctIds.toLongIDList(
                                        DistinctIds.longIDsFromRecords(
                                            txChild,
                                            child -> child.getTxId()))),
                            () -> ImmutVOs.emptyVOs());
                },
                ()->ImmutVOs.emptyVOs());
    }

    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }

    @Override
    public
    void
    update(
        JsonObject json) {

    }

    @Override
    public
    void
    delete(
        JsonObject json) {

    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory>  members = getMandatoryAttributeMembers(field);
        members.add(0, parentMgr.field().unsafeAFK());
        return members;
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(field);
    }

    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return parentMgr.field().unsafeCenterMember();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }

    public DerivedTxLongAFKMgt.StarView<E, X, A, F> getMgr() {
        return parentMgr;
    }


    @Override
    public ImmutVOs<? extends Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

}
