package aloha3.controller.tool.query.crud;


import aloha.module.object.DateTime;
import aloha.module.object.NonEmptyVOs;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.view.StarView;

import java.util.ArrayList;
import java.util.List;

public class ChainMgr<E extends CoreEntity, F extends StarView.FieldOf<E>, H extends HierarchyEntity.Of.Chain.Straight<E>> {
    private final Graph.Chain.Straight<E,H,F> masterDataMgt;

    public ChainMgr(
        Graph.Chain.Straight<E,H,F> masterDataMgt) {

        this.masterDataMgt = masterDataMgt;
    }

    public
    List<NonEmptyVOs<StarView.Read<F>>>
    selectAllChains() {

        return selectAllChains(
            DateTime.YMDHMS.current());
    }

    public
    List<NonEmptyVOs<StarView.Read<F>>>
    selectAllChains(
        DateTime.YMDHMS at) {

        List<NonEmptyVOs<StarView.Read<F>>> chains = new ArrayList<>();
        GraphMgr.getAllGraphs().foreach(
            (coreGraph)->
                masterDataMgt.
                    selectGraph(
                        coreGraph.rowId(),
                        DateTime.YMDHMS.current()).
                    unlessNull_(
                        (graph)-> {
                            try {
                                masterDataMgt.
                                    createModel(
                                        graph,
                                        at).
                                    unlessNull_(
                                        (model) ->
                                            chains.add(
                                                model.allFromThisNode()));
                            }catch (Exception e) {
                                //do nothing
                            }
                        }));
        return chains;
    }

}
