package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DerivedTxLongAFKChildIntAFKModel<
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>,
    PV extends ValueObject>
    extends TxChildModel {

    private final PV parent;
    private final TxModel.ChildIntAFK<F, CH> model;
    private final ImmutVOs<View<TxModel.ChildIntAFK.FlatField<F, CV>>> flatViews;
    private final List<AbstractField.Member.Mandatory> childMembers;

    private DerivedTxLongAFKChildIntAFKModel(
        PV parent,
        TxModel.ChildIntAFK<F, CH> model) {

        this.parent = parent;
        this.model = model;

        flatViews = model.toFlat(TxModel.ChildIntAFK::toFlat);
        childMembers = new ArrayList<>();
        if (!flatViews.empty()) {
            View<TxModel.ChildIntAFK.FlatField<F, CV>> flatFieldView = flatViews.firstUnlessEmpty();
            childMembers.add(
                flatFieldView.field().PK());
            childMembers.add(
                flatFieldView.field().AFK());
            childMembers.add(
                flatFieldView.field().Attribute());
        }
    }

    public TxModel.ChildIntAFK<F, CH> getModel() {
        return model;
    }

    public ImmutVOs<View<TxModel.ChildIntAFK.FlatField<F, CV>>> getFlatViews() {
        return flatViews;
    }

    public
    List<AbstractField.Member.Mandatory>
    childMembers() {
        return childMembers;
    }

    public
    List<AbstractField.Member.Optional>
    childOptionalMembers() {
        return Collections.EMPTY_LIST;
    }

    public
    PV
    view() {
        return parent;
    }

    public
    ImmutVOs<? extends Read<CH>>
    children() {
        return model.children();
    }

    public static <
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>,
    PV extends TxStarView.Read<F>>
    DerivedTxLongAFKChildIntAFKModel<E,X, A,F,CH,CM,CV, PV>
    of(
        TxModel.ChildIntAFK<F, CH> model) {

        return new DerivedTxLongAFKChildIntAFKModel( model.view(), model ) ;
    }

    public static <
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>,
    PV extends OneToOne<TxStarView.Read<F>, ?>>
    DerivedTxLongAFKChildIntAFKModel<E,X, A,F,CH,CM,CV, PV>
    of(
        OneToOne<TxStarView.Read<F>, ?> parent,
        TxModel.ChildIntAFK<F, CH> model) {

        return new DerivedTxLongAFKChildIntAFKModel( parent, model ) ;
    }

}