package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel.ChildIntAFKOnly;
import aloha3.module.object.model.read.TxModel.ChildIntAFKOnly.FlatField;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK.On;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.List;

public class TxLongFKChildIntAFKOnlyModel<
    E extends On<M>,
    M extends SealedTxParent<?>,
    F extends AndLongFK<E>,
    CH extends ChildTxEntityIntAFKOnly.Of<E, CM>,
    CM extends SealedPivot<?>,
    PV extends ValueObject> extends TxChildModel<F, PV, FlatField<F>> {

    private final PV parent;
    private final ChildIntAFKOnly<F, CH> model;
    private final ImmutVOs<View<FlatField<F>>> flatViews;
    private final List<Mandatory> childMembers;

    private TxLongFKChildIntAFKOnlyModel(PV parent, ChildIntAFKOnly<F, CH> model) {
        this.parent = parent;
        this.model = model;
        this.flatViews = model.toFlat();
        this.childMembers = new ArrayList();
        if (!this.flatViews.empty()) {
            View<FlatField<F>> flatFieldView = this.flatViews.firstUnlessEmpty();
            this.childMembers.add(((FlatField)flatFieldView.field()).PK());
            this.childMembers.add(((FlatField)flatFieldView.field()).AFK());
        }

    }

    private TxLongFKChildIntAFKOnlyModel(PV parent) {
        this.parent = parent;
        this.model = null;
        this.flatViews = ImmutVOs.emptyVOs();
        this.childMembers = new ArrayList();
    }

    public ChildIntAFKOnly<F, CH> getModel() {
        return this.model;
    }

    public ImmutVOs<View<FlatField<F>>> getFlatViews() {
        return this.flatViews;
    }

    public List<Mandatory> childMembers() {
        return this.childMembers;
    }

    public PV view() {
        return this.parent;
    }

    public ImmutVOs<? extends Read<CH>> children() {
        return this.model.children();
    }

    public static <E extends On<M>, M extends SealedTxParent<?>, F extends AndLongFK<E>, CH extends ChildTxEntityIntAFKOnly.Of<E, CM>, CM extends SealedPivot<?>, PV extends aloha3.module.object.view.TxStarView.Read<F>> TxLongFKChildIntAFKOnlyModel<E, M, F, CH, CM, PV> of(ChildIntAFKOnly<F, CH> model) {
        return new TxLongFKChildIntAFKOnlyModel(model.view(), model);
    }

    public static <E extends On<M>, M extends SealedTxParent<?>, F extends AndLongFK<E>, CH extends ChildTxEntityIntAFKOnly.Of<E, CM>, CM extends SealedPivot<?>, PV extends OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?>> TxLongFKChildIntAFKOnlyModel<E, M, F, CH, CM, PV> of(OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?> parent, ChildIntAFKOnly<F, CH> model) {
        return new TxLongFKChildIntAFKOnlyModel(parent, model);
    }

    public static <E extends On<M>, M extends SealedTxParent<?>, F extends AndLongFK<E>> TxLongFKChildIntAFKOnlyModel<E, M, F, ?, ?, ?> of(OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?> parent) {
        return new TxLongFKChildIntAFKOnlyModel(parent);
    }
}
