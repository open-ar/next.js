package aloha3.controller.tool.query.models;

public class FieldMember {
    private final String fieldName;
    private final String memberName;
    private final Class type;

    public FieldMember(
        String fieldName,
        String memberName,
        Class type) {

        this.fieldName = fieldName;
        this.memberName = memberName;
        this.type = type;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getMemberName() {
        return memberName;
    }

    public Class getType() {
        return type;
    }

    @Override
    public
    String
    toString() {
        return fieldName +"."+memberName+"(" + ((type == null) ? "type: null" : type.getSimpleName())+")";
    }

}
