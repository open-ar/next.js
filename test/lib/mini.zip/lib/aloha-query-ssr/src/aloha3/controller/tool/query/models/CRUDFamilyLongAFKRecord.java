package aloha3.controller.tool.query.models;

import aloha3.module.function.business.conceptual.transaction.CRUD.Family.ChildLongAFK;
import aloha3.module.function.business.transaction.TxMgt.StarView;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.coc.generic.Bridge;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;

import java.util.List;

class CRUDFamilyLongAFKRecord<
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & Field<X>,
        M extends StarView<X, F, ?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends AndLongFK<VX>, CH extends ChildTxEntityLongAFK.Of<Bridge<X>, ?, ?>>
        extends AlohaRecord<TxEntity<?>, ChildLongAFK<X, F, M, VX, VF, CH>> {
    public CRUDFamilyLongAFKRecord(RECORD_TYPE type, String name, TxEntity<?> entity, ChildLongAFK<X, F, M, VX, VF, CH> dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
