package aloha3.controller.tool.query.crud;

import aloha.mapping.DBCP;
import aloha.mapping.IDbGroup;
import aloha.mapping.IEntity;
import aloha.mapping.IReadConnection;
import aloha.mapping.IReadPreparedStatement;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.master.HierarchyMgr;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public final class GraphMgr {

    public static <
    E extends CoreEntity,
    H extends HierarchyEntity<E>,
    HM extends HierarchyMgr<E, H, ?>>
    ImmutVOs<Core.Read<Graph>>
    selectAllGraph(
        aloha3.module.function.business.conceptual.master.Graph<E, ?, H, HM> mgr,
        DateTime.YMDHMS asOf) {
        return mgr.selectAllGraphOfThisConcept(asOf);
    }
    public static <
    E extends CoreEntity,
    H extends HierarchyEntity<E>,
    HM extends HierarchyMgr<E, H, ?>>
    ImmutVOs<Core.Read<Graph>>
    selectAllGraph(aloha3.module.function.business.conceptual.master.Graph<E, ?, H, HM> mgr) {
        return mgr.selectAllGraphOfThisConcept(DateTime.YMDHMS.current());
    }

    public static
    ImmutVOs<Core.Read<Graph>>
    getAllGraphs() {

        Graph graph = Instance.of(Graph.class);
        aloha3.module.object.record.meta.master.read.Core.Criteria<Graph, Core.Read<Graph>> criteria
            = Core.Read.createCriteria(graph);
        return  Query.select(criteria);
    }

    public static <
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends HierarchyEntity<E>,
    HM extends HierarchyMgr<E, H, ?>>
    List<Long>
    selectGraphHistories(aloha3.module.function.business.conceptual.master.Graph<E, F, H, HM> mgr) {
        Graph g = Instance.of(Graph.class);
        List<GraphHistory> cancelledGraphs = fetchRegTimes("_graph", Core.Read.createCriteria(g).dbGroup());
        List<GraphHistory> myHistories = fetchRegTimes(((IEntity)mgr.hierarchyEntity()).getTABLE(), ((IEntity)mgr.hierarchyEntity()).dbGroup());
        List<Long> regTimes = new ArrayList<>();
        Iterator var5 = cancelledGraphs.iterator();

        GraphHistory cancelledGraph;
        while(var5.hasNext()) {
            cancelledGraph = (GraphHistory)var5.next();

            for(int i = 0; i < cancelledGraph.graphIds.size(); ++i) {
                int graphId = cancelledGraph.graphIds.get(i);
                boolean exists = false;
                Iterator var10 = myHistories.iterator();

                while(var10.hasNext()) {
                    GraphHistory history = (GraphHistory)var10.next();
                    exists = history.graphIds.contains(graphId);
                    if (exists) {
                        break;
                    }
                }

                if (exists) {
                    regTimes.add(cancelledGraph.txRegTimes.get(i));
                }
            }
        }

        var5 = myHistories.iterator();

        while(var5.hasNext()) {
            cancelledGraph = (GraphHistory)var5.next();
            regTimes.addAll(cancelledGraph.txRegTimes);
        }

        Set regTimesSet = new HashSet();
        regTimesSet.addAll(regTimes);
        regTimes.clear();
        regTimes.addAll(regTimesSet);
        Collections.sort(regTimes);
        Collections.reverse(regTimes);
        return regTimes;
    }
    static class GraphHistory {
        boolean hasGraphId = false;
        List<Long> txRegTimes = new ArrayList();
        List<Integer> graphIds = new ArrayList();
    }
    private static
    List<GraphHistory>
    fetchRegTimes(String name, IDbGroup dbGroup) {
        try {
            IReadConnection readConnection = DBCP.getReadConnection(dbGroup);
            List<GraphHistory> regTimes = new ArrayList();
            regTimes.add(fetchRegTimes("SELECT * FROM " + name + "$cancel", readConnection));
            if (!name.equals("_graph")) {
                regTimes.add(fetchRegTimes("SELECT * FROM " + name + "$graph", readConnection));
            }

            readConnection.close();
            return regTimes;
        } catch (Exception var4) {
            var4.printStackTrace();
            return Collections.EMPTY_LIST;
        }
    }
    private static GraphHistory fetchRegTimes(String sql, IReadConnection readConnection) throws SQLException {
        IReadPreparedStatement pstmt = readConnection.prepareStatementCloseable(sql);

        GraphHistory var3;
        try {
            var3 = fetchRegTimes(pstmt.executeQuery());
        } finally {
            pstmt.close();
        }

        return var3;
    }

    private static GraphHistory fetchRegTimes(ResultSet resultSet) throws SQLException {
        System.out.println(resultSet.getClass().getName());
        GraphHistory graphHistory = new GraphHistory();
        ResultSetMetaData metaData = null;

        while(resultSet.next()) {
            if (metaData == null) {
                if ("aloha.mapping.PreparedStatementWrapper$ResultSetWrapper".equals(resultSet.getClass().getName())) {
                    try {
                        Field field = resultSet.getClass().getDeclaredField("rset");
                        field.setAccessible(true);
                        metaData = ((ResultSet)field.get(resultSet)).getMetaData();
                    } catch (Exception var5) {
                        var5.printStackTrace();
                    }
                } else {
                    metaData = resultSet.getMetaData();
                }
            }

            for(int i = 1; i <= metaData.getColumnCount(); ++i) {
                String name = metaData.getColumnName(i);
                if ("reg_time".equals(name)) {
                    graphHistory.txRegTimes.add(resultSet.getLong(i));
                } else if ("graph_id".equals(name)) {
                    graphHistory.graphIds.add(resultSet.getInt(i));
                    graphHistory.hasGraphId = true;
                }
            }
        }

        return graphHistory;
    }

}