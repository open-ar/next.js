package aloha3.controller.tool.query.models;

public abstract class FieldMemberValue {
    private final FieldMember fieldMember;

    public FieldMemberValue(
        FieldMember fieldMember) {

        this.fieldMember = fieldMember;
    }

    abstract public FieldMemberValue cloneEmpty();
    abstract public boolean isNull();

    public FieldMember getFieldMember() {
        return fieldMember;
    }

    public Integer getInt() {
        throw new RuntimeException("Not Supported " + fieldMember);
    }

    public Long getLong() {
        throw new RuntimeException("Not Supported " + fieldMember);
    }

    public Double getDouble() {
        throw new RuntimeException("Not Supported " + fieldMember);
    }

    public String getString() {
        throw new RuntimeException("Not Supported " + fieldMember);
    }

    abstract public Object getValue();

    public static
    FieldMemberValue
    create(
        FieldMember fieldMember,
        String value) {

        if (fieldMember.getType() == Integer.class)
            return new FieldMemberIntValue(
                fieldMember,
                JsonUtils.toInteger(value));
        else if (fieldMember.getType() == Long.class)
            return new FieldMemberLongValue(
                fieldMember,
                JsonUtils.toLong(value));
        else if (fieldMember.getType() == Double.class)
            return new FieldMemberDoubleValue(
                fieldMember,
                JsonUtils.toDouble(value));
        else
            return new FieldMemberStringValue(
                fieldMember,
                value);
    }

    public static
    FieldMemberValue
    createNullValue(
        FieldMember fieldMember) {

        if (fieldMember.getType() == Integer.class)
            return new FieldMemberIntValue(
                fieldMember,
                null);
        else if (fieldMember.getType() == Long.class)
            return new FieldMemberLongValue(
                fieldMember,
                null);
        else if (fieldMember.getType() == Double.class)
            return new FieldMemberDoubleValue(
                fieldMember,
                null);
        else
            return new FieldMemberStringValue(
                fieldMember,
                null);
    }

    public static
    FieldMemberValue
    create(
        FieldMember fieldMember,
        long value) {

        return new FieldMemberLongValue(fieldMember, value);
    }

    public static
    FieldMemberValue
    create(
        FieldMember fieldMember,
        int value) {

        return new FieldMemberIntValue(fieldMember, value);
    }

    public static
    FieldMemberValue
    create(
        FieldMember fieldMember,
        double value) {

        return new FieldMemberDoubleValue(fieldMember, value);
    }

    @Override
    public
    String
    toString() {
        return fieldMember +":"+getValue();
    }
}

class FieldMemberIntValue extends FieldMemberValue{
    private final Integer value;

    public FieldMemberIntValue(
        FieldMember fieldMember,
        Integer value) {

        super(fieldMember);

        this.value = value;
    }

    @Override
    public Integer getInt() {
        return value;
    }

    @Override
    public Object getValue() {
        return this.value;
    }

    @Override
    public
    boolean
    isNull() {
        return value == null;
    }

    @Override
    public
    FieldMemberValue
    cloneEmpty(){
        return new FieldMemberIntValue(getFieldMember(), null);
    }
}

class FieldMemberLongValue extends FieldMemberValue{
    private final Long value;

    public FieldMemberLongValue(
        FieldMember fieldMember,
        Long value) {

        super(fieldMember);

        this.value = value;
    }

    @Override
    public Long getLong() {
        return value;
    }

    @Override
    public Object getValue() {
        return this.value;
    }

    @Override
    public
    boolean
    isNull() {
        return value == null;
    }

    @Override
    public
    FieldMemberValue
    cloneEmpty(){
        return new FieldMemberLongValue(getFieldMember(), null);
    }
}

class FieldMemberDoubleValue extends FieldMemberValue{
    private final Double value;

    public FieldMemberDoubleValue(
        FieldMember fieldMember,
        Double value) {

        super(fieldMember);

        this.value = value;
    }

    @Override
    public Double getDouble() {
        return value;
    }

    @Override
    public Object getValue() {
        return this.value;
    }

    @Override
    public
    boolean
    isNull() {
        return value == null;
    }

    @Override
    public
    FieldMemberValue
    cloneEmpty(){
        return new FieldMemberDoubleValue(getFieldMember(), null);
    }
}

class FieldMemberStringValue extends FieldMemberValue{
    private final String value;

    public FieldMemberStringValue(
        FieldMember fieldMember,
        String value) {

        super(fieldMember);

        this.value = value;
    }

    @Override
    public String getString() {
        return value;
    }

    @Override
    public Object getValue() {
        return this.value;
    }

    @Override
    public
    boolean
    isNull() {
        return value == null;
    }

    @Override
    public
    FieldMemberValue
    cloneEmpty(){
        return new FieldMemberStringValue(getFieldMember(), null);
    }
}
