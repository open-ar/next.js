package aloha3.controller.query;

import aloha.module.func.Func;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullValue;
import aloha.module.object.NonEmptyArray;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.query.GeneralViewsQuery.ViewConnections;
import aloha3.controller.tool.query.ReflectiveJoinTool;
import aloha3.controller.tool.query.TransactionViewQuery;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaRecord;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.object.record.spec.Schema;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import java.io.StringReader;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.INDEX_CONTENT;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PARAMS;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.query.GeneralViewsQuery.getJoinedViews;

public class QueryTxViewsController extends AbstractController {

    public static final QueryTxViewsController INSTANCE = new QueryTxViewsController();
    public static final String MAIN_TEMPLATE = "queryTxViews.html";
    private static final boolean IS_SKIP_JOIN_RELATION_FROM_TX = true;

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Tx";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot -> renderMainContent(
                    pivot,
                    OperationType.from(request),
                    request.unlessNull(ID, Long::valueOf, 0L)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                INSTANCE.getNavMenuTemplate(),
                Context.Builder.create().
                    add(AlohaMeta.getTxReferrerPivots(container())).
                    build());
        }
    }

    private static void 
    handleContent(
        ChunkedResponseMessageBody body,
        String csv) {

        Func.accept(
            Context.Builder.create().
                add("content", csv).
                build(),
            body.asWriter(),
            (ctx, writer) ->
                Func.accept(
                    engine().processThrottled(INDEX_CONTENT, ctx),
                    throttled ->
                    {
                        while (!throttled.isFinished()) {
                            throttled.process(128, writer);
                        }
                    },
                    _ -> body.end()));
    }

    public static void 
    handleSearch(
        Request request,
        Response response) {
        
        System.out.println("handle search");
        initAlohaQuery();

        request.unlessNull_(
            PARAMS,
            searchParam ->
                searchCsv(searchParam).unlessNull_(
                    csv ->
                        handleContent(response.chunked(), csv)));
    }

    private static void initAlohaQuery() {

        for(Map.Entry<String, AlohaRecord<Schema<?>,?>> conceptual : ReflectiveJoinTool.conceptuals.entrySet()) {
            ReflectiveJoinTool.records.put(conceptual.getKey(), conceptual.getValue());
        }
        try {
            ViewMgr.init("",false);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Same as old aloha-query:
    // aloha.query.controll.GeneralViewsQuery#queryTransactionViews
    private static MayNullValue<String>
    searchCsv(String jsonString) {

        // e.g JSON like: 
        // {"startNode":"Machine-1","nodes":[{"id":"Machine-1","name":"Machine"},{"id":"Censor.machineId-2","name":"Censor.machineId"}],"edges":[{"from":"Censor.machineId-2","to":"Machine-1"}]}
        try (JsonReader jsonReader = Json.createReader(new StringReader(jsonString))) {
            JsonObject jsonParams = jsonReader.readObject();

            String startNodeInJson = jsonParams.getString("startNode");
            String[] selectedMasterIds = jsonParams.getString("selectedMasterIds").split(",");
            String fromYmd = jsonParams.getString("fromYmd");
            String toYmd = jsonParams.getString("toYmd");

            NonEmptyArray.DistinctInts coreIds;
            if (selectedMasterIds.length == 1) {
                coreIds = NonEmptyArray.DistinctInts.
                    createInts(
                        Integer.parseInt(selectedMasterIds[0]));
            } else if (selectedMasterIds.length > 1) {
                int[] coreIdsFromSecond = new int[selectedMasterIds.length - 1];
                for(int i = 1; i < selectedMasterIds.length; i++)
                    coreIdsFromSecond[i - 1] = Integer.parseInt(selectedMasterIds[i]);
                coreIds = NonEmptyArray.DistinctInts.
                    createInts(
                        Integer.parseInt(selectedMasterIds[0]),
                        coreIdsFromSecond);
            }else{
                throw new IllegalArgumentException("selectedMasterIds is empty");
            }

            // String startNode = ViewMgr.toViewModelName(startNodeInJson);
            Map<String, ViewConnections> joinedViews = getJoinedViews(jsonParams);
            return MayNullValue.of(
                JsonUtils.toCsv(
                    TransactionViewQuery.joinViews(
                        coreIds,
                        fromYmd,
                        toYmd,
                        joinedViews.
                            get(
                                startNodeInJson),
                        joinedViews)));
        } catch (Exception e) {
            e.printStackTrace();
            return MayNullValue.nullInstance();
        }
    }

    private static
    String
    renderMainContent(String pivot) {
        return renderMainContent(pivot, null, 0L);
    }

    private static
    String
    renderMainContent(
        String pivot,
        OperationType operation,
        Long id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("referents", skipRelations(AlohaMeta.getReferents(pivot, container()))).
            add("referrers", skipRelations(AlohaMeta.allReferrersWithMasterAndTx(pivot, container()))).
            add("views", AlohaCRUD.starViews(pivot, container())).
            add("views_fk",
                getFkPivot(viewInfo).unlessNull(
                    fkPivot ->
                        AlohaCRUD.starViews(fkPivot, container()),
                    ImmutVOs.emptyVOs())).
            add("views_afk",
                getAfkPivot(viewInfo).unlessNull(
                    afkPivot ->
                        AlohaCRUD.starViews(afkPivot, container()),
                    ImmutVOs.emptyVOs()));

        AlohaCRUD.starView(id, pivot, container()).unlessNull_(
            view ->
                context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static ImmutVOs<View<AlohaMeta.ViewSchemaField>> skipRelations(ImmutVOs<View<AlohaMeta.ViewSchemaField>> referents) {
        if (IS_SKIP_JOIN_RELATION_FROM_TX) {
            return referents.
                filter(
                    view ->
                        !view.mandatoryValue(f -> f.ViewType).equals("RELATION"));
        } else {
            return referents;
        }
    }

    private static
    MayNullValue<String>
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
            view ->
                view.
                    mandatoryValue(f->f.IsFK) == Bool.TRUE).
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static
    MayNullValue<String>
    getAfkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE). // グラフは無視
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }
}

