package aloha3.controller.tool.query.crud;

import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.ValueObject;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.spec.meta.MasterKey;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Isomorphic;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import java.util.Iterator;

public class GenericSearch {

    public static boolean isMaster(String viewName) {
        BaseMgrWrapper dataMgt = getMgrMapper(ViewMgr.toViewModelName(viewName));
        return dataMgt != null && dataMgt.isMaster();
    }

    public static boolean isCRUD(String viewName) {
        BaseMgrWrapper dataMgt = getMgrMapper(ViewMgr.toViewModelName(viewName));
        return dataMgt != null && dataMgt.isCRUD();
    }

    public static boolean isFamily(String viewName) {
        BaseMgrWrapper dataMgt = getMgrMapper(ViewMgr.toViewModelName(viewName));
        return dataMgt != null && dataMgt.isFamily();
    }

    public static boolean isGroup(String viewName) {
        BaseMgrWrapper dataMgt = getMgrMapper(ViewMgr.toViewModelName(viewName));
        return dataMgt != null && dataMgt.isGroup();
    }

    public static
    boolean
    isGeneralTx(
        String viewName ) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        String type = dataMgt.getClass().getSimpleName();
        return (type.startsWith("Tx") && !type.endsWith("CRUDWrapper"));
    }

    @SuppressWarnings({"unchecked"})
    public static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    ImmutVOs<StarView.Read<F>>
    queryMasterViews(
        String viewName) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getMasterDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        return dataMgt.query();
    }

    @SuppressWarnings({"unchecked"})
    public static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    MayNullVO<StarView.Read<F>>
    queryMasterViewByPK(
        String viewName,
        int id) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getMasterDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        return dataMgt.queryByPK(id);
    }

    public static <
    F extends AbstractField & TxStarView.Field<?>>
    ImmutVOs<TxStarView.Read<F>>
    queryTxViews(String viewName) {
        String modelName = ViewMgr.toViewModelName(viewName);
        BaseMgrWrapper dataMgt = getMgrMapper(modelName);
        if (dataMgt == null) {
            return ImmutVOs.emptyVOs();
        } else if (dataMgt.isMaster()) {
            System.out.println("[queryTxViews] viewName=" + viewName);
            System.out.println("[queryTxViews] modelName=" + modelName);
            System.out.println("[queryTxViews] dataMgt=" + dataMgt);
            return ImmutVOs.emptyVOs();
        } else {
            return dataMgt instanceof TxFamilyCRUDWrapper && ((TxFamilyCRUDWrapper)dataMgt).parentName().equals(modelName) ? ((TxFamilyCRUDWrapper)dataMgt).queryParents() : dataMgt.query();
        }
    }
    public static <
        F extends AbstractField & TxStarView.Field<?>>
    ImmutVOs<TxStarView.Read<F>>
    queryTxView(String viewName,Long id) {
        String modelName = ViewMgr.toViewModelName(viewName);
        BaseMgrWrapper dataMgt = getMgrMapper(modelName);
        if (dataMgt == null) {
            return ImmutVOs.emptyVOs();
        } else if (dataMgt.isMaster()) {
            System.out.println("[queryTxView] viewName=" + viewName);
            System.out.println("[queryTxView] modelName=" + modelName);
            System.out.println("[queryTxView] dataMgt=" + dataMgt);
            return ImmutVOs.emptyVOs();
        } else {
            return dataMgt instanceof TxFamilyCRUDWrapper
                    && ((TxFamilyCRUDWrapper)dataMgt).parentName().equals(modelName) ?
                    ((TxFamilyCRUDWrapper)dataMgt).queryParents() :
                    (ImmutVOs<TxStarView.Read<F>>) dataMgt.queryByPK(id).apply(v->ImmutVOs.create((ValueObject) v),()->ImmutVOs.emptyVOs());
        }
    }

    @SuppressWarnings({"unchecked"})
    public static <
    E extends TxEntityIntFK.On<M>,
    M extends CoreEntity,
    F extends TxStarView.FieldOf.AndIntFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>,
    T extends TxIntFKChildIntAFKModel<E,M,F,CH,CM,CV, TxStarView.Read<F>>>
    ImmutVOs<T>
    queryTxModels(
        String viewName) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        return dataMgt.query();
    }
    public static <
        E extends TxEntityIntFK.On<M>,
        M extends CoreEntity,
        F extends TxStarView.FieldOf.AndIntFK<E>,
        CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
        CM extends CoreEntity,
        CV extends Comparable<? super CV>,
        T extends TxIntFKChildIntAFKModel<E,M,F,CH,CM,CV, TxStarView.Read<F>>>
    ImmutVOs<T>
    queryTxModel(
        String viewName,
        Long id) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        return (ImmutVOs<T>) dataMgt.queryByPK(id).apply(v->ImmutVOs.create((ValueObject) v),()->ImmutVOs.emptyVOs());
    }

    public static <
    X extends SealedTxParent<?> & MakeCancellable<X>,
    F extends AbstractField & TxStarView.Field<X>,
    M extends TxMgt.StarView<X, F, ?>,
    VX extends TxEntityLongFK.On<X>,
    VF extends TxStarView.FieldOf.AndLongFK<VX>>
    ImmutVOs<OneToOne<TxStarView.Read<F>, TxStarView.Read<VF>>>
    queryTxCRUDViews(String viewName, String params) {
        BaseMgrWrapper dataMgt = getMgrMapper(ViewMgr.toViewModelName(viewName));
        return dataMgt == null ? ImmutVOs.emptyVOs() : dataMgt.query();
    }
    public static <
            X extends SealedTxParent<?> & MakeCancellable<X>,
            F extends AbstractField & TxStarView.Field<X>,
            M extends TxMgt.StarView<X, F, ?>,
            VX extends TxEntityLongFK.On<X>,
            VF extends TxStarView.FieldOf.AndLongFK<VX>>
    ImmutVOs<OneToOne<TxStarView.Read<F>, TxStarView.Read<VF>>>
    queryTxCRUDViews(String viewName, Long id) {
        BaseMgrWrapper dataMgt = getMgrMapper(ViewMgr.toViewModelName(viewName));
        return dataMgt == null ? ImmutVOs.emptyVOs() :
                (ImmutVOs<OneToOne<TxStarView.Read<F>, TxStarView.Read<VF>>>) dataMgt.queryByPK(id).apply(
                        v->ImmutVOs.create((ValueObject) v),
                        ()->ImmutVOs.emptyVOs());
    }
    @SuppressWarnings({"unchecked"})
    public static
    <F extends AbstractField & TxStarView.Field<?>>
    MayNullVO<TxStarView.Read<F>>
    queryTxViewByPK(
        String viewName,
        long id) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        MayNullVO<?> mayNull = dataMgt.queryByPK(id);
        return (MayNullVO<TxStarView.Read<F>>)mayNull.apply(
                nonNull->
                    nonNull instanceof OneToOne o2o ?
                        MayNullVO.of((ValueObject)o2o.left) : mayNull,
                ()->mayNull);
    }

    public static ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs(String viewName, String params) {
        String modelName = ViewMgr.toViewModelName(viewName);
        BaseMgrWrapper dataMgt = getMgrMapper(modelName);
        if (dataMgt == null) {
            return ImmutVOs.emptyVOs();
        } else if (dataMgt.isMaster()) {
            System.out.println("[queryTxViews] viewName=" + viewName);
            System.out.println("[queryTxViews] modelName=" + modelName);
            System.out.println("[queryTxViews] dataMgt=" + dataMgt);
            return ImmutVOs.emptyVOs();
        } else {
            return dataMgt.queryTxs();
        }
    }

    public static <
    E extends MasterKey<?>,
    T extends aloha3.module.object.record.master.read.meta.Read<E>>
    MayNullVO<T> queryPivotReadByPK(String viewName, int id) {
        BaseMgrWrapper dataMgt = BusinessMgrContainer.getMasterDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null) {
            return MayNullVO.nullInstance();
        } else {
            MayNullVO pivotView = dataMgt.queryByPK(id);
            return (MayNullVO<T>) pivotView.
                apply(
                    v->
                        MayNullVO.of(((Isomorphic.StarView.Read)v).pivotRead()),
                    ()->MayNullVO.nullInstance());
        }
    }
    public static <T extends aloha3.module.object.record.master.read.meta.Read<?>> ImmutVOs<T>
    queryPivotReads(
        String viewName, String params) {
        BaseMgrWrapper dataMgt = BusinessMgrContainer.getMasterDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null) {
            return ImmutVOs.emptyVOs();
        } else {
            return dataMgt.isMaster() ? dataMgt.queryCores() : ImmutVOs.emptyVOs();
        }
    }

    public static BaseMgrWrapper getMgrMapper(String viewName) {
        String modelName = viewName; //ViewMgr.toViewModelName(viewName);
        BaseMgrWrapper dataMgt = BusinessMgrContainer.dataMgts.get(modelName);
        if (dataMgt != null) {
            return dataMgt;
        } else {
            Iterator var3 = BusinessMgrContainer.dataMgts.values().iterator();

            BaseMgrWrapper mapper;
            do {
                if (!var3.hasNext()) {
                    throw new RuntimeException(viewName);
                }

                mapper = (BaseMgrWrapper)var3.next();
            } while(!mapper.isFamily() || !(mapper instanceof TxFamilyWrapper) || !((TxFamilyWrapper)mapper).parentName().equals(modelName));

            return mapper;
        }
    }
}
