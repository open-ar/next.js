package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.query.vo.RegisterDocumentAddView;
import aloha3.controller.query.vo.RegisterDocumentPageView;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.document.business.Service;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.document.record.DocumentLineItem;
import aloha3.document.record.NestedElement;
import aloha3.document.record.Submit;
import aloha3.document.record.SubmitLineItem;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.view.AbstractField.Member;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.List;

import static aloha3.controller.Server.alohaDocumentService;
import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_NAV_MENU_HTML;
import static aloha3.controller.tool.meta.MappingConst.FORM_ID;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.meta.MetaManager.decapitalize;

/**
 * Experimental controller that renders registerDocument page with typed view models.
 * Currently only supports the ADD flow so that we can iterate safely beside the legacy implementation.
 */
public class RegisterDocumentController extends AbstractController {
    public static final RegisterDocumentController INSTANCE = new RegisterDocumentController();
    public static final String MAIN_TEMPLATE = "registerDocument.html";
    public static final String DOCUMENT = "document";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Tx";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void handlePost(Request request, Response response) {
        System.out.println("handle POST");
        request.unlessNull_(
            PIVOT,
            pivot -> {
                if (DOCUMENT.equalsIgnoreCase(pivot)) {
                    saveDocumentWithWorkflow(request);
                } else {
                    throw new RuntimeException("Unsupported pivot for POST: " + pivot);
                }
            });
        response.redirectTo(request.target());
    }

    public static void handlePut(Request request, Response response) {
        System.out.println("handle PUT");
        request.unlessNull_(
            PIVOT,
            pivot -> {
                if (DOCUMENT.equalsIgnoreCase(pivot)) {
                    updateDocumentWithWorkflow(request);
                } else {
                    throw new RuntimeException("Unsupported pivot for PUT: " + pivot);
                }
            });
        response.redirectTo(request.target());
    }

    private static String renderMainContent(
        String pivot,
        OperationType operation,
        Request request) {

        var submitFieldService = alohaDocumentService();
        var pageView = RegisterDocumentPageView.create(pivot, operation, request, submitFieldService);
        return pageView.render(MAIN_TEMPLATE);
    }

    private static void 
    saveDocumentWithWorkflow(Request request) {
        var submitFieldService = alohaDocumentService();

        Integer formId = request.unlessNull(FORM_ID, Integer::valueOf, 0);
        var now = DateTime.YMDHMS.current();
        var formRead = submitFieldService.formMgr().createView(formId, now).mustNonNull();

        var documentWrite = submitFieldService.documentMgr().create(formRead.coreRead(), now);

        saveSubmitModel(request, submitFieldService, now, documentWrite.getTxId());
        submitFieldService.documentMgr().save(
            TxStarView.Write.New.Builder.
                create(
                    DocumentField.class,
                    documentWrite).build());
    }

    private static void 
    updateDocumentWithWorkflow(Request request) {
        var submitFieldService = alohaDocumentService();

        Long documentId = request.unlessNull(IndexController.ID, Long::valueOf, 0L);
        var documentRead = submitFieldService.documentMgr().selectTx(documentId);
        documentRead.ifNull_(() -> {
            throw new RuntimeException("No input values found in the request");
        });

        saveSubmitModel(request, submitFieldService, DateTime.YMDHMS.current(), documentId);
    }

    @SuppressWarnings("unchecked")
    private static void 
    saveSubmitModel(
        Request request,
        Service<AbstractSubmitField> submitFieldService,
        DateTime.YMDHMS now,
        Long documentId) {

        var formId = request.unlessNull(FORM_ID, Integer::valueOf, 0);
        var formRead = submitFieldService.formMgr().createView(formId, now).mustNonNull();
        var graphId = formRead.mandatoryValue(f -> f.GraphId);
        var graphRead = submitFieldService.nestedElementTree().selectGraph(graphId, now).mustNonNull();
        Tree.StarArrow<FormElementField, NestedElementField> treeRead =
            submitFieldService.nestedElementTree().createModel(graphRead, now).mustNonNull();

        List<TxModel.ChildValue<NestedElement, String>> childValues =
            RegisterDocumentAddView.collectChildValues(
                request.keyValues(),
                submitFieldService,
                now,
                treeRead,
                formId);
        if (childValues.isEmpty()) {
            throw new RuntimeException("No input values found in the request");
        }

        submitFieldService.submitFamily().save(
            newSubmitSubmitLineItemModel(
                request,
                documentId,
                childValues.getFirst(),
                childValues.subList(1, childValues.size()).toArray(new TxModel.ChildValue[0])));
    }

    @SafeVarargs
    private static 
    <SF extends AbstractSubmitField>
    TxModel<SF, SubmitLineItem> 
    newSubmitSubmitLineItemModel(
        Request request,
        Long documentId,
        TxModel.ChildValue<NestedElement, String> v,
        TxModel.ChildValue<NestedElement, String>... vs) {

        Service<SF> submitFieldService = alohaDocumentService();

        TxLongFK.Write<Submit> submitWrite =
            TxLongFK.Write.create(
                submitFieldService.submitFamily().entity(),
                documentId,
                DateTime.YMDHMS.current());
        TxStarView.Write.New.Builder<Submit, SF> submitSFBuilder = TxStarView.Write.New.Builder.
            create(
                submitFieldService.submitFieldClass(),
                submitWrite);

        submitFieldService.submitFamily().field().attributeMembers().foreach(member -> {
            var attrName = decapitalize(member.javaName());
            request.param(attrName).unlessNull_(value -> {
                if (member instanceof Member.Optional optionalMember) {
                    if (value.isBlank()) {
                        return;
                    }
                    submitSFBuilder.setOptionalValue(f -> optionalMember, value);
                }
                if (member instanceof Member.Mandatory mandatoryMember) {
                    submitSFBuilder.setMandatoryValue(f -> mandatoryMember, value);
                }
            });
        });
        TxStarView.Write.New<SF> newSubmitView = submitSFBuilder.build();

        return saveSubmitLineItemTxModel(submitFieldService, newSubmitView, v, vs);
    }

    public static <
        SF extends AbstractSubmitField>
    TxModel<SF, SubmitLineItem>
    saveSubmitLineItemTxModel(
        Service<SF> submitFieldService,
        TxStarView.Write.New<SF> newSubmitView,
        TxModel.ChildValue<NestedElement, String> v,
        TxModel.ChildValue<NestedElement, String>[] vs) {

        NonEmptyVOs<TxIntFK.Read<DocumentLineItem>> vsNonEmpty = NonEmptyVOs.of(v, vs).map(vo -> {
            final var value = vo.value().trim();
            var viewMatchedAttrs = findMatchedValueAndNestedElementId(submitFieldService, vo, value);
            return viewMatchedAttrs.apply(
                matched -> (TxIntFK.Read) matched.first().txRead(),
                () ->
                    submitFieldService.documentLineItemMgr().saveThen(
                            TxStarView.Write.Prepare.Builder.
                                create(DocumentLineItemField.class).
                                setMandatory(f -> f.Value, DocumentLineItem.Value.class, value).
                                build(),
                            (Read<NestedElement>) vo.afeRecord(),
                            DateTime.YMDHMS.current()).
                        get());
        });
        return TxModel.create(
            newSubmitView,
            SubmitLineItem.class,
            vsNonEmpty);
    }

    private static <
        SF extends AbstractSubmitField>
    ImmutVOs<TxStarView.Read<DocumentLineItemField>>
    findMatchedValueAndNestedElementId(
        Service<SF> submitFieldService,
        TxModel.ChildValue<NestedElement, String> childValue,
        String value) {

        final var nestedElementId = ((Record.SinglePK.Master) childValue.afeRecord()).getRowId();
        return submitFieldService.documentLineItemMgr().
            selectAttributes(DocumentLineItem.Value.class, value).
            unlessEmpty(attrReads ->
                submitFieldService.documentLineItemMgr().createViewsByAttribute(attrReads)).
            filter(txView ->
                txView.mandatoryValue(DocumentLineItemField::NestedElementId).equals(nestedElementId));
    }

    private static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request),
                INSTANCE::getWelcomeContent
            );
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                COMPONENTS_NAV_MENU_HTML,
                Context.Builder.create().
                    add("title", "Document List").
                    add(AlohaMeta.
                        getTxPivots(container()).
                        filter(t ->
                            t.mandatoryValue(f -> f.Pivot).equalsIgnoreCase(DOCUMENT))).
                    build());
        }
    }
}
