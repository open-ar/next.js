package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.Tuple;
import aloha3.module.function.business.master.coc.StateField;
import aloha3.module.function.business.master.coc.WorkFlowField;
import aloha3.module.object.model.read.Chain;
import aloha3.module.object.view.StarView;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WorkFlow {

    public static
    boolean
    hasWorkFlows() {

        try {
            return aloha3.module.function.business.conceptual.WorkFlow.
                allWorkFlows(
                    DateTime.YMDHMS.current()).
                size() > 0;
        }catch(Throwable e) {
            return false;
        }
    }

    public static
    JsonArray
    queryAllWorkFlows() {

        JsonArrayBuilder workFlows = Json.createArrayBuilder();
        for(Tuple.Pair<StarView.Read<WorkFlowField>, Chain.Star<StateField>> workFlow :  getAllWorkFlows() ) {
            workFlows.add(
                toJson(
                    workFlow.getT1(),
                    workFlow.getT2()));
        }

        return workFlows.build();
    }

    public static
    JsonObject
    toJson(
        StarView.Read<WorkFlowField> workFlow,
        Chain.Star<StateField> start) {

        Map<Integer, StarView.Read<StateField>> states =
            lookupStates(start);

        Map<StarView.Read<StateField>, List<StarView.Read<StateField>>> transitions =
            lookupTransitions(
                start,
                states);

        JsonObjectBuilder jsonWorkflow = Json.createObjectBuilder();
        jsonWorkflow.add(
            "workflow",
            workFlow.asView().stringValue(f->f.Name));

        JsonArrayBuilder jsonStates = Json.createArrayBuilder();
        Integer[] stateIds = states.keySet().toArray(new Integer[0]);
        for(Integer stateId : stateIds) {
            StarView.Read<StateField> state = states.get(stateId);
            JsonObjectBuilder jsonSate = Json.createObjectBuilder();
            jsonSate.add(
                "name",
                state.asView().stringValue(f->f.Name));
            jsonSate.add(
                "id",
                state.coreRead().getRowId());
            jsonStates.add(jsonSate);
        }
        jsonWorkflow.add(
            "states",
            jsonStates);

        jsonWorkflow.add(
            "startState",
            start.node().coreRead().rowId());

        JsonArrayBuilder jsonTransitions = Json.createArrayBuilder();
        StarView.Read<StateField>[] fromNodes = transitions.keySet().toArray(new StarView.Read[0]);
        Arrays.sort(fromNodes, Comparator.comparingInt(from -> from.coreRead().rowId()));
        for(StarView.Read<StateField> fromNode : fromNodes) {
            List<StarView.Read<StateField>> toNodes = transitions.get(fromNode);
            Collections.sort(toNodes, Comparator.comparingInt(toNode->toNode.coreRead().rowId()));
            JsonObjectBuilder jsonSateFrom = Json.createObjectBuilder();
            jsonSateFrom.add(
                "id",
                fromNode.coreRead().getRowId());
            JsonArrayBuilder jsonSateTos = Json.createArrayBuilder();
            for(StarView.Read<StateField> to : toNodes) {
                jsonSateTos.add(to.coreRead().getRowId());
            }
            jsonSateFrom.add(
                "to",
                jsonSateTos);
            jsonTransitions.add(jsonSateFrom);
        }
        jsonWorkflow.add(
            "transitions",
            jsonTransitions);

        return jsonWorkflow.build();
    }

    private static
    Map<Integer, StarView.Read<StateField>>
    lookupStates(
        Chain.Star<StateField> start) {

        Map<Integer, StarView.Read<StateField>> states = new HashMap<>();
        lookupStates(
            start,
            states);

        return states;
    }

    private static
    Map<Integer, StarView.Read<StateField>>
    lookupStates(
        Chain.Star<StateField> root,
        Map<Integer, StarView.Read<StateField>> states) {

        Integer stateId = root.node().coreRead().getRowId();
        if (!states.containsKey(stateId)) {
            states.put(stateId, root.node());
        }

        root.
            posts().
            foreach(
                (child)->
                    lookupStates(
                        child,
                        states));
        return states;
    }

    private static
    Map<StarView.Read<StateField>, List<StarView.Read<StateField>>>
    lookupTransitions(
        Chain.Star<StateField> start,
        Map<Integer, StarView.Read<StateField>> states) {

        Map<StarView.Read<StateField>, List<StarView.Read<StateField>>> transitions = new HashMap<>();
        lookupTransitions(
            start,
            states,
            transitions);

        return transitions;
    }

    private static
    Map<StarView.Read<StateField>, List<StarView.Read<StateField>>>
    lookupTransitions(
        Chain.Star<StateField> root,
        Map<Integer, StarView.Read<StateField>> states,
        Map<StarView.Read<StateField>, List<StarView.Read<StateField>>> transitions) {

        StarView.Read<StateField> state = states.get(root.node().coreRead().getRowId());
        if (!transitions.containsKey(state)) {
            transitions.put(state, new ArrayList<>());
        }
        root.
            posts().
            foreach(
                (child)-> {
                    transitions.
                        get(
                            state).
                        add(
                            child.node());

                    lookupTransitions(
                        child,
                        states,
                        transitions);
                });
        return transitions;
    }

    public static
    List<Tuple.Pair<StarView.Read<WorkFlowField>, Chain.Star<StateField>>>
    getAllWorkFlows() {

        List<Tuple.Pair<StarView.Read<WorkFlowField>, Chain.Star<StateField>>> workFlows = new ArrayList<>();
        getWorkFlows().
            foreach(
                (workFlow)->
                    workFlows.add(
                        Tuple.Pair.of(
                            workFlow,
                            aloha3.module.function.business.conceptual.WorkFlow.
                                modelOf(
                                    workFlow))));

        return workFlows;
    }

    private static
    ImmutVOs<StarView.Read<WorkFlowField>>
    getWorkFlows() {

        return aloha3.module.function.business.conceptual.WorkFlow.
            allWorkFlows(
                DateTime.YMDHMS.current());
    }
}
