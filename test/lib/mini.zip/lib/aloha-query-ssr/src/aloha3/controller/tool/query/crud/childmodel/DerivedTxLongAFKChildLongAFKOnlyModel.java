package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DerivedTxLongAFKChildLongAFKOnlyModel<
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityLongAFKOnly.Of<E,CM>,
    CM extends TxKey.Category<?>,
    PV extends ValueObject>
    extends TxChildModel {

    private final PV parent;
    private final TxModel.ChildLongAFKOnly<F, CH> model;
    private final ImmutVOs<View<TxModel.ChildLongAFKOnly.FlatField<F>>> flatViews;
    private final List<AbstractField.Member.Mandatory> childMembers;

    private DerivedTxLongAFKChildLongAFKOnlyModel(
        PV parent,
        TxModel.ChildLongAFKOnly<F, CH> model) {

        this.parent = parent;
        this.model = model;

        flatViews = model.toFlat();
        childMembers = new ArrayList<>();
        if (!flatViews.empty()) {
            View<TxModel.ChildLongAFKOnly.FlatField<F>> flatFieldView = flatViews.firstUnlessEmpty();
            childMembers.add(
                flatFieldView.field().PK());
            childMembers.add(
                flatFieldView.field().AFK());
        }
    }

    public TxModel.ChildLongAFKOnly<F, CH> getModel() {
        return model;
    }

    public ImmutVOs<View<TxModel.ChildLongAFKOnly.FlatField<F>>> getFlatViews() {
        return flatViews;
    }

    public
    List<AbstractField.Member.Mandatory>
    childMembers() {
        return childMembers;
    }

    public
    List<AbstractField.Member.Optional>
    childOptionalMembers() {
        return Collections.EMPTY_LIST;
    }

    public
    PV
    view() {
        return parent;
    }

    public
    ImmutVOs<? extends Read<CH>>
    children() {
        return model.children();
    }

    public static <
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityLongAFKOnly.Of<E,CM>,
    CM extends TxKey.Category<?>,
    PV extends TxStarView.Read<F>>
    DerivedTxLongAFKChildLongAFKOnlyModel<E,X, A,F,CH,CM, PV>
    of(
        TxModel.ChildLongAFKOnly<F, CH> model) {

        return new DerivedTxLongAFKChildLongAFKOnlyModel( model.view(), model ) ;
    }

    public static <
    E extends DerivedTxEntityLongAFK<?, X, A>,
    X extends SealedTxParent<?>,
    A extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongAFK<E>,
    CH extends ChildTxEntityLongAFKOnly.Of<E,CM>,
    CM extends TxKey.Category<?>,
    PV extends OneToOne<TxStarView.Read<F>, ?>>
    DerivedTxLongAFKChildLongAFKOnlyModel<E,X, A,F,CH,CM, PV>
    of(
        OneToOne<TxStarView.Read<F>, ?> parent,
        TxModel.ChildLongAFKOnly<F, CH> model) {

        return new DerivedTxLongAFKChildLongAFKOnlyModel( parent, model ) ;
    }

}