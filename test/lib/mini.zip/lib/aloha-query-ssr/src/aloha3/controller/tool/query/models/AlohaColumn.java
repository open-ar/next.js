package aloha3.controller.tool.query.models;

import aloha.module.object.IdentifiableEnum;
import aloha.module.object.Type;

import java.util.List;

public class AlohaColumn implements Comparable <AlohaColumn> {
    private final AlohaRecord.COLUMN_TYPE type;
    private final String name;
    private final Type.RefType dataType;
    private final Class declaredClass;
    private final String foreignRecord;
    private final String foreignColumn;
    private String reprName;
    private final List<? extends Enum> enums;
    private boolean immutable = false;
    private boolean optional = false;

    AlohaColumn(AlohaRecord.COLUMN_TYPE type, Class declaredClass, String name, Type.RefType dataType, String foreignRecord, String foreignColumn, List<? extends Enum> enums) {
        this.declaredClass = declaredClass;
        this.name = name;
        this.dataType = dataType;
        this.foreignRecord = foreignRecord;
        this.foreignColumn = (foreignRecord == null) ? null : foreignColumn;
        this.reprName = name;
        this.enums = enums;
        if (enums != null && !enums.isEmpty())
            this.type = AlohaRecord.COLUMN_TYPE.Enum;
        else
            this.type = type;
    }

    AlohaColumn(AlohaRecord.COLUMN_TYPE type, Class declaredClass, String name, Type.RefType dataType, String foreignRecord) {
        this(type, declaredClass, name, dataType, foreignRecord, (foreignRecord == null) ? null : name, null);
    }

    AlohaColumn(AlohaRecord.COLUMN_TYPE type, Class declaredClass, String name, Type.RefType dataType, String foreignRecord, List<? extends Enum> enums) {
        this(type, declaredClass, name, dataType, foreignRecord, (foreignRecord == null) ? null : name, enums);
    }

    AlohaColumn(Class declaredClass, String name, Type.RefType dataType, String foreignRecord, List<? extends Enum> enums) {
        this(
            (foreignRecord != null) ? AlohaRecord.COLUMN_TYPE.AFK : AlohaRecord.COLUMN_TYPE.Normal,
            declaredClass,
            name,
            dataType,
            foreignRecord,
            (foreignRecord == null) ? null : name,
            enums);
    }

    AlohaColumn(Class declaredClass, String name, Type.RefType dataType, String foreignRecord, String foreignColumn, List<? extends Enum> enums) {
        this(
            (foreignRecord != null) ? AlohaRecord.COLUMN_TYPE.AFK : AlohaRecord.COLUMN_TYPE.Normal,
            declaredClass,
            name,
            dataType,
            foreignRecord,
            foreignColumn,
            enums);
    }

    public boolean isImmutable() {
        return immutable;
    }

    public boolean isMulti() {
        return AlohaRecord.COLUMN_TYPE.MultiValue == this.type;
    }

    public AlohaColumn setImmutable(boolean immutable) {
        this.immutable = immutable;
        return this;
    }

    public boolean isOptional() {
        return optional;
    }

    public AlohaColumn setOptional(boolean optional) {
        this.optional = optional;
        return this;
    }

    public List<? extends Enum> getEnums() {
        return enums;
    }

    public IdentifiableEnum
    getEnumValue(
        String name) {

        IdentifiableEnum ret = null;
        for(Enum e : enums) {
            if (e.name().equals(name))
                return (IdentifiableEnum)e;
        }
        return null;
    }

    public String getReprName() {
        return reprName;
    }

    public void setReprName(String reprName) {
        this.reprName = reprName;
    }

    public AlohaRecord.COLUMN_TYPE getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public Type.RefType getDataType() {
        return dataType;
    }

    public
    boolean
    isNumeric() {
        if (dataType ==  Type.RefType.INTEGER)
            return true;
        if (dataType ==  Type.RefType.LONG)
            return true;
        if (dataType ==  Type.RefType.DECIMALSCALE1)
            return true;
        if (dataType ==  Type.RefType.DECIMALSCALE2)
            return true;
        if (dataType ==  Type.RefType.DECIMALSCALE3)
            return true;
        if (dataType ==  Type.RefType.DECIMALSCALE4)
            return true;
        if (dataType ==  Type.RefType.DECIMALSCALE5)
            return true;
        if (dataType ==  Type.RefType.PRECISION18SCALE2)
            return true;
        if (dataType ==  Type.RefType.PRECISION18SCALE5)
            return true;
        if (dataType ==  Type.RefType.YMD)
            return true;
        return dataType == Type.RefType.YMDHMS;
    }

    public
    boolean
    isText() {
        if (dataType ==  Type.RefType.STRING)
            return true;
        return dataType == Type.RefType.TEXT;
    }

    public
    boolean
    isEnum() {
        if (dataType ==  Type.RefType.BYTE)
            return true;
        return dataType == Type.RefType.ENUM;
    }

    public Class getDeclaredClass() {
        return declaredClass;
    }

    public String getForeignRecord() {
        return foreignRecord;
    }

    public String getForeignColumn() {
        return foreignColumn;
    }

    public
    boolean
    isForeign() {
        return foreignRecord != null;
        }

    @Override
    public int compareTo(AlohaColumn o) {
        return this.getName().compareTo(o.getName());
    }

    @Override
    public
    boolean
    equals(
        Object o) {

        if (o instanceof AlohaColumn)
            return compareTo((AlohaColumn) o) == 0;
        else
            return false;
    }

    @Override
    public
    String
    toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(name);
        sb.append("[");
        sb.append(reprName);
        sb.append("]");
        sb.append("(");
        sb.append(type);
        sb.append(")");
        sb.append(" [");
        sb.append(declaredClass);
        sb.append("]");
        if (isForeign()) {
        sb.append(" (");
        sb.append(foreignRecord);
        sb.append(",");
        sb.append(foreignColumn);
        sb.append(")");
        }
        sb.append(" : ");
        sb.append(dataType);

        return sb.toString();
    }
}
