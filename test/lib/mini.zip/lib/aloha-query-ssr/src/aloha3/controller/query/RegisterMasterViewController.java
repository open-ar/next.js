package aloha3.controller.query;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.HashSet;
import java.util.Set;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;

public class RegisterMasterViewController extends AbstractController {

    public static final RegisterMasterViewController INSTANCE = new RegisterMasterViewController();
    public static final String MAIN_TEMPLATE = "registerMasterView.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Master";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void 
    handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST");
        request.unlessNull_(
            PIVOT,
            pivot ->
                AlohaCRUD.saveStarView(
                    pivot,
                    request.keyValues(),
                    container()));
        response.redirectTo(request.target());
    }

    public static void 
    handlePut(
        Request request,
        Response response) {
        
        System.out.println("handle Put");
        request.unlessNull_(
            PIVOT, 
            ID,
            (pivot, id) ->
                AlohaCRUD.updateStarView(
                    Integer.parseInt(id),
                    request.keyValues(),
                    pivot,
                    container()));
        response.redirectTo(request.target());
    }

    public static void 
    handleDelete(
        Request request,
        Response response) {
        
        System.out.println("handle Delete");
        request.unlessNull_(
            PIVOT, ID,
            (pivot, id) ->
                AlohaCRUD.deleteStarView(
                    Integer.parseInt(id),
                    pivot,
                    container()));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Long::valueOf, 0L)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder.add(AlohaMeta.getPivots(container()));
        }
    }

    private static
    String
    renderMainContent(
        String pivot,
        OperationType operation,
        Long id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("views", AlohaCRUD.starViews(pivot, container())).
            add("views_fk",
                getFkPivot(viewInfo).unlessNull(
                    fkPivot ->
                        AlohaCRUD.starViews(fkPivot, container()),
                    ImmutVOs.emptyVOs())).
            add("views_afk",
                getAfkPivot(viewInfo).unlessNull(
                    afkPivot ->
                        AlohaCRUD.starViews(afkPivot, container()),
                    ImmutVOs.emptyVOs()));

        getAfkPivots(viewInfo).foreach(
            afkPivot -> {
                var views = AlohaCRUD.starViews(afkPivot, container());
                // e.g. views_afk_productId
                context.add("views_afk_" + StringUtil.decapitalize(afkPivot) + "Id", views);
                // TODO renameされた場合一時対応
                context.add("views_afk_destination" + afkPivot + "Id", views);
                context.add("views_afk_origin" + afkPivot + "Id", views);
            });
        
        AlohaCRUD.starView(id, pivot, container()).unlessNull_(
            view ->
                context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static
    MayNullValue<String>
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
            view ->
                view.
                    mandatoryValue(f->f.IsFK) == Bool.TRUE).
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static
    MayNullValue<String>
    getAfkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE). // グラフは無視
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static ImmutValues<String>
    getAfkPivots(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            filter(
                view ->
                    // Graph もフォーム入力で選択候補が必要なため除外しない
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE).
            toValues(view->
                view.optionalValue(f->f.Foreign).assertNonNull());
    }
}

