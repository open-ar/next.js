package aloha3.controller.spi;

import java.util.Map;

/**
 * SPI for providing default values for Tree/Graph attributes.
 * <p>
 * This interface allows modules to define default values for specific attributes of Tree nodes (Pivots).
 * These default values are used in two ways:
 * <ol>
 *     <li><b>Skip Saving:</b> When saving a tree node, if an attribute's value matches the default value provided here,
 *         it will NOT be saved to the database. This helps keep the database clean and reduces storage size.</li>
 *     <li><b>Restore Reading:</b> When reading a tree node, if an attribute is missing (because it was skipped),
 *         this default value will be returned instead of null or empty string.</li>
 * </ol>
 * </p>
 */
public interface TreeDefaultValueProvider {

    /**
     * Provides the map of default values.
     *
     * @return A nested map structure:
     *         <ul>
     *             <li><b>Key (Outer Map):</b> The Pivot Name (e.g., "WorkFlow", "State"). This corresponds to the Simple Class Name of the Entity.</li>
     *             <li><b>Value (Outer Map):</b> A map of Attribute Names to Default Values.
     *                 <ul>
     *                     <li><b>Key (Inner Map):</b> The Attribute Name (e.g., "Color", "Label"). This corresponds to the Java field name.</li>
     *                     <li><b>Value (Inner Map):</b> The Default Value as a String.</li>
     *                 </ul>
     *             </li>
     *         </ul>
     */
    Map<String, Map<String, String>> provideDefaultValues();
}
