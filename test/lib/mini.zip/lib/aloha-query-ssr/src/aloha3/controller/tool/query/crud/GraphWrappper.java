package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.master.HierarchyMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.JsonObject;
import java.util.List;
import java.util.Map;

public class GraphWrappper<
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends HierarchyEntity.Of<E>,
    HM extends HierarchyMgr<E,H,?>,
    T extends StarView.Read<F>>
    extends BaseMgrWrapper <T, Integer, Integer> {

    private final String name;
    private final F field;
    private final Graph<E,F,H,HM> mgr;

    public GraphWrappper(
        String name,
        F field,
        Graph<E,F,H,HM> mgr ) {

        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    @Override
    public
    boolean
    isMaster() {
        return true;
    }

    @Override
    @SuppressWarnings({"rawtypes"})
    public
    AbstractField.Member.Mandatory
    getCenterMember() {

        return ((StarView.FieldOf)mgr.coreReadMgt().field()).unsafeCenterMember();
    }

    @Override
    public Object getMgr() {
        return this.mgr.coreMgr();
    }

    @Override
    public
    Object
    register(JsonObject json) {

        Persist.Value<Integer> id = mgr.
            save(
                generateView(
                    json),
                DateTime.YMDHMS.current());
        return id.get();
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    query() {

        return  (ImmutVOs<T>) mgr.coreReadMgt().
            selectAllCores(
                DateTime.YMDHMS.current()).
            unlessEmpty(
                (cores) ->
                    mgr.coreReadMgt().
                        createViews(
                            cores,
                            DateTime.YMDHMS.current()),
                ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public MayNullVO<T>
    queryByPK(Integer id) {

        return (MayNullVO<T>)mgr.coreReadMgt().createView(id, DateTime.YMDHMS.current());
    }
    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Integer> pkIDs ) {

        return (ImmutVOs<T>)mgr.coreReadMgt().
            createViews(
                DistinctIds.toIntIDs(pkIDs),
                DateTime.YMDHMS.current());
    }

    @Override
    public ImmutVOs<? extends Read> queryTxs() {
        return null;
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return null;
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs afkViews,
        Map<String, Object> params ) {

        throw new IllegalCallerException();
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByIntAFKViews(afkViews, afkName);
    }

    @SuppressWarnings(value="unchecked")
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName) {

        return (ImmutVOs<T>)afkViews.apply(
            (afks)->{
                ImmutVOs<Core.Read<E>> mayEmptyCores;
                AlohaColumn referenceColumn = ViewMgr.getJoinColumn(name, afkName);
                if (FixedAttributeEntityAFK.Of.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                    mayEmptyCores = mgr.coreReadMgt().selectCoresOfFixedAttribute(
                        (NonEmptyVOs)afks.map(v->v.coreRead()),
                        referenceColumn.getDeclaredClass(),
                        DateTime.YMDHMS.current());
                } else {
                    mayEmptyCores = mgr.coreReadMgt().selectCoresOf(
                        (NonEmptyVOs)afks.map(v->v.coreRead()),
                        referenceColumn.getDeclaredClass(),
                        DateTime.YMDHMS.current());
                }

                return mayEmptyCores.
                    unlessEmpty(
                        (cores) ->
                            mgr.coreReadMgt().createViews(
                                DistinctIds.intIDsFromRecords(
                                    cores,
                                    Core.Read::coreId),
                                DateTime.YMDHMS.current()),
                        ImmutVOs.emptyVOs());
            },
            ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }

    @Override
    public void update(JsonObject json) {

        String primaryKeyName = getCenterMember().javaName();
        Integer targetId = JsonUtils.getIntValue(
            json,
            primaryKeyName);
        if (targetId == null)
            return;
        JsonUtils.removeKey(json, primaryKeyName);

        mgr.coreReadMgt().
            createView(
                targetId,
                DateTime.YMDHMS.current()).
            unlessNull_(
                (exists)->
                    mgr.
                        save(
                            generateView(
                                exists,
                                json)));
    }

    @Override
    public
    void
    delete(
        JsonObject json) {

        Integer targetId = JsonUtils.getIntValue(json,  getCenterMember().javaName());
        if (targetId == null)
            return;
        mgr.coreReadMgt().
            createView(
                targetId,
                DateTime.YMDHMS.current()).
            unlessNull_(
                (view)->
                    mgr.
                        delete(
                            view,
                            DateTime.YMDHMS.current()));
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(field);
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(field);
    }

    private
    StarView.Write.Prepare<E,F>
    generateView(
        JsonObject json ) {

        StarView.Write.Prepare.Builder<E, F> builder = StarView.Write.Prepare.Builder.
            create(
                getFieldClass());
        setValues(json, field, builder);
        return builder.build();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }

    private
    StarView.Write.Update<F>
    generateView(
        StarView.Read<F> exists,
        JsonObject json ) {

        StarView.Write.Update.Builder<E, F> builder = StarView.Write.Update.Builder.
            create(
                exists,
                DateTime.YMDHMS.current());
        setValues(json, field, builder);
        return builder.build();
    }

}
