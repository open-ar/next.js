package aloha3.controller.tool.query.models;

import aloha3.module.object.view.AbstractView;

import java.util.ArrayList;
import java.util.List;

public class FlatView {
    private final String name;
    private final List<FieldMemberValue> values = new ArrayList<>();
    @SuppressWarnings({"rawtypes"})
    private final AbstractView view;

    @SuppressWarnings({"rawtypes"})
    public FlatView(String name, AbstractView view) {
        this.name = name;
        this.view = view;
    }

    @SuppressWarnings({"rawtypes"})
    public AbstractView getView() {
        return view;
    }

    public
    FlatView
    cloneEmpty() {
        FlatView cloned = new FlatView(name, view);
        values.forEach(
            (value)->
                cloned.values.
                    add(
                        value.cloneEmpty()));
        return cloned;
    }

    public
    List<String>
    keys() {

        List<String> names = new ArrayList<>();
        for(FieldMemberValue value : getValues()) {
            names.add(
                value.getFieldMember().getMemberName());
        }
        return names;
    }

    public
    void
    add(FieldMemberValue value) {
        values.add(value);
    }

    public
    FieldMemberValue
    getMemberValue(
        String memberName) {

        for(FieldMemberValue value : getValues()) {
            if (value.getFieldMember().getMemberName().equals(memberName))
                return value;
        }
        throw new IllegalArgumentException();
    }

    public String getName() {
        return name;
    }

    public
    List<FieldMemberValue>
    getValues() {
        return values;
    }

    public
    Object
    getValue(
        String memberName ) {

        for(FieldMemberValue value : getValues()) {
            if (value.getFieldMember().getMemberName().equals(memberName))
                return value.getValue();
        }
        throw new IllegalArgumentException(memberName +" from " + keys());
    }

    public
    Object
    getFirstValue( ) {

        return values.isEmpty() ? null : values.get(0).getValue();
    }

    @Override
    public
    String
    toString() {
        return name +": " +values;
    }
}
