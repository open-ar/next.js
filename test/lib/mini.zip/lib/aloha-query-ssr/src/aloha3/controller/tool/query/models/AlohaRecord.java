package aloha3.controller.tool.query.models;

import aloha.module.object.Type.RefType;
import aloha.module.object.record.IColumn;
import aloha3.module.function.business.master.CoreMgr.StarView.OneToMany;
import aloha3.module.function.business.transaction.TxIntFKValueMgr;
import aloha3.module.object.record.master.spec.RelationEntity;
import aloha3.module.object.record.spec.Schema;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.spec.TxEntityIntFK;
import aloha3.module.object.record.transaction.spec.TxEntityLongFK;
import aloha3.module.object.record.transaction.spec.meta.DerivedTx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public abstract class AlohaRecord<E extends Schema<?>, M>
    implements Comparable<AlohaRecord> {

    private final RECORD_TYPE type;
    private final String name;
    private String reprName;
    private final E entity;
    private M dataMgt;
    private final List<AlohaColumn> columns;
    private final Map<String, OneToMany> oneToManyMgrs = new HashMap();
    private List<AlohaColumn> columnsOfChildOrDependant = new ArrayList();
    private String nameOfChildOrDependant;
    private boolean readOnly = false;

    public AlohaRecord(RECORD_TYPE type, String name, E entity, M dataMgt, List<AlohaColumn> columns) {
        this.type = type;
        this.name = name;
        this.entity = entity;
        this.dataMgt = dataMgt;
        this.columns = columns;
        this.reprName = name;
        if (entity != null) {
            this.addPrimaryKey();
            this.addForeignKeys();
        }

    }

    public boolean isReadOnly() {
        return this.readOnly;
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    public AlohaColumn getPrimaryKey() {
        return this.columns.get(0);
    }

    public String getNameOfChildOrDependant() {
        return this.nameOfChildOrDependant;
    }

    public AlohaRecord<E, M> setNameOfChildOrDependant(String nameOfChildOrDependant) {
        this.nameOfChildOrDependant = nameOfChildOrDependant;
        return this;
    }

    public List<AlohaColumn> getColumnsOfChildOrDependant() {
        return this.columnsOfChildOrDependant;
    }

    public AlohaRecord<E, M> setColumnsOfChildOrDependant(List<AlohaColumn> columnsOfChildOrDependant) {
        this.columnsOfChildOrDependant = columnsOfChildOrDependant;
        return this;
    }

    public AlohaRecord<E, M> setChildOrDependant(AlohaRecord childOrDependant) {
        this.columnsOfChildOrDependant = childOrDependant.columns;
        this.nameOfChildOrDependant = childOrDependant.name;
        return this;
    }

    public boolean containsChild() {
        return this.columnsOfChildOrDependant != null && !this.columnsOfChildOrDependant.isEmpty();
    }

    public String getReprName() {
        return this.reprName;
    }

    public void setReprName(String reprName) {
        this.reprName = reprName;
    }

    public RECORD_TYPE getType() {
        return this.type;
    }

    public String getName() {
        return this.name;
    }

    public E getEntity() {
        return this.entity;
    }

    public M getDataMgt() {
        return this.dataMgt;
    }

    public void setDataMgt(M dataMgt) {
        this.dataMgt = dataMgt;
    }

    public List<AlohaColumn> getColumns() {
        return this.columns;
    }

    public boolean isOneToMany() {
        return !this.oneToManyMgrs.isEmpty();
    }

    public Map<String, OneToMany> getOneToManyMgrs() {
        return this.oneToManyMgrs;
    }

    public OneToMany getOneToManyMgr(AlohaColumn column) {
        return this.oneToManyMgrs.get(column.getName());
    }

    public AlohaColumn columnOf(String name) {
        Iterator var2 = this.columns.iterator();

        AlohaColumn column;
        do {
            if (!var2.hasNext()) {
                return null;
            }

            column = (AlohaColumn)var2.next();
        } while(!column.getName().equals(name));

        return column;
    }

    public AlohaColumn columnOfChild(String name) {
        Iterator var2 = this.columnsOfChildOrDependant.iterator();

        AlohaColumn column;
        do {
            if (!var2.hasNext()) {
                return null;
            }

            column = (AlohaColumn)var2.next();
        } while(!column.getName().equals(name));

        return column;
    }

    public boolean isMaster() {
        return this.type.isMaster();
    }

    public boolean nonMaster() {
        return !this.type.isMaster();
    }

    public boolean isCore() {
        return this.type == RECORD_TYPE.Core;
    }

    public boolean isRelation() {
        return this.type == RECORD_TYPE.Relation;
    }

    public boolean isChain() {
        return this.type == RECORD_TYPE.Chain;
    }

    public boolean isTree() {
        return this.type == RECORD_TYPE.Tree;
    }

    public boolean isArrowTree() {
        return this.type == RECORD_TYPE.ArrowTree;
    }

    public boolean isArrowChain() {
        return this.type == RECORD_TYPE.ArrowChain;
    }

    public boolean isDistinctTree() {
        return this.type == RECORD_TYPE.DistinctTree;
    }

    public boolean isTx() {
        return this.type == RECORD_TYPE.TxLongFK || this.type == RECORD_TYPE.TxIntFK || this.type == RECORD_TYPE.TxIntValue;
    }

    public boolean isTxGroup() {
        return this.type == RECORD_TYPE.TxIntValueGroup;
    }

    public boolean isTxSum() {
        return this.type == RECORD_TYPE.TxSum;
    }

    public boolean isCrud() {
        return this.type == RECORD_TYPE.CrudIntFK || this.type == RECORD_TYPE.CrudLongFK;
    }

    public boolean isCrudFamily() {
        return this.type == RECORD_TYPE.CrudIntFKChild || this.type == RECORD_TYPE.CrudLongFKChild;
    }

    public boolean isDerivedTx() {
        return this.type == RECORD_TYPE.DerivedTx || this.type == RECORD_TYPE.DerivedTxIntAFK || this.type == RECORD_TYPE.DerivedTxLongAFK;
    }

    public boolean isTxChild() {
        return this.type == RECORD_TYPE.TxChild;
    }

    public boolean isFlowableTx() {
        return this.type == RECORD_TYPE.FlowableTxIntFK;
    }

    public int compareTo(AlohaRecord o) {
        return this.getName().compareTo(o.getName());
    }

    public boolean equals(Object o) {
        if (o instanceof AlohaRecord) {
            return this.compareTo((AlohaRecord)o) == 0;
        } else {
            return false;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.name);
        sb.append("[");
        sb.append(this.reprName);
        sb.append("]");
        sb.append("(");
        sb.append(this.type);
        sb.append(")");
        sb.append(" Entity;");
        sb.append(this.entity.getClass().getName());
        sb.append(" DataMgt;");
        sb.append(this.dataMgt.getClass().getName());
        sb.append(" Columns;");
        Iterator var2 = this.columns.iterator();

        while(var2.hasNext()) {
            AlohaColumn column = (AlohaColumn)var2.next();
            sb.append("\n");
            sb.append("\t");
            sb.append(column);
        }

        var2 = this.oneToManyMgrs.entrySet().iterator();

        while(var2.hasNext()) {
            Entry<String, OneToMany> column = (Entry)var2.next();
            sb.append("\n");
            sb.append("\t");
            sb.append("[OneToMany] ");
            sb.append(column.getKey());
            sb.append(" : ");
            sb.append(column.getValue().getClass().getSimpleName());
        }

        return sb.toString();
    }

    private void addPrimaryKey() {
        if (!this.isDerivedTx()) {
            if (!this.isTxChild()) {
                List var10000 = this.columns;
                COLUMN_TYPE var10004 = COLUMN_TYPE.PK;
                String var10006 = AlohaRecordFactory.getTypeNameOf(this.entity);
                var10000.add(0, (new AlohaColumn(var10004, null, var10006 + "Id", this.isMaster() ? RefType.INTEGER : RefType.LONG, null)).setImmutable(true));
            }
        }
    }

    private void addForeignKeys() {
        if (this.isRelation()) {
            RelationEntity relation = (RelationEntity)this.entity;
            this.columns.add(1, (new AlohaColumn(COLUMN_TYPE.AFK, null, relation.getPrimaryForeignKeyColumn().getJavaName(), relation.getPrimaryForeignKeyColumn().getRefType(), relation.getPrimaryCoreEntity().getSimpleName())).setImmutable(true));
            this.columns.add(2, (new AlohaColumn(COLUMN_TYPE.AFK, null, relation.getSecondaryForeignKeyColumn().getJavaName(), relation.getSecondaryForeignKeyColumn().getRefType(), relation.getSecondaryCoreEntity().getSimpleName())).setImmutable(true));
        } else if (this.type != RECORD_TYPE.TxIntFK && this.type != RECORD_TYPE.CrudIntFK && this.type != RECORD_TYPE.CrudIntFKChild && this.type != RECORD_TYPE.FlowableTxIntFK) {
            if (this.type != RECORD_TYPE.TxLongFK && this.type != RECORD_TYPE.CrudLongFK && this.type != RECORD_TYPE.CrudLongFKChild) {
                if (this.type == RECORD_TYPE.TxIntValue) {
                    IColumn fkColumn = (IColumn)((TxIntFKValueMgr)this.dataMgt).foreignEntity().columnArray().eltAt(0);
                    this.columns.add(1, (new AlohaColumn(COLUMN_TYPE.FK, null, fkColumn.getJavaName(), fkColumn.getRefType(), ((TxIntFKValueMgr)this.dataMgt).foreignEntity().getClass().getSimpleName())).setImmutable(true));
                } else if (this.isDerivedTx()) {
                    this.columns.add(0, (new AlohaColumn(
                        COLUMN_TYPE.FK, null,
                        ((DerivedTx)this.entity).getForeignKeyColumn().getJavaName(),
                        RefType.LONG,
                        ((DerivedTx)this.entity).getForeignEntity().getSimpleName())).setImmutable(true));
                    if (this.type == RECORD_TYPE.DerivedTxIntAFK) {
                        this.columns.add(1, (new AlohaColumn(COLUMN_TYPE.AFK, null, ((DerivedTxEntityIntAFK)this.entity).getAdditionalForeignKeyColumn().getJavaName(), RefType.INTEGER, ((DerivedTxEntityIntAFK)this.entity).getAdditionalReferenceEntity().getSimpleName())).setImmutable(true));
                    } else if (this.type == RECORD_TYPE.DerivedTxLongAFK) {
                        this.columns.add(1, (new AlohaColumn(COLUMN_TYPE.AFK, null, ((DerivedTxEntityLongAFK)this.entity).getAdditionalForeignKeyColumn().getJavaName(), RefType.LONG, ((DerivedTxEntityLongAFK)this.entity).getAdditionalReferenceEntity().getSimpleName())).setImmutable(true));
                    }
                }
            } else {
                this.columns.add(1, (new AlohaColumn(
                    COLUMN_TYPE.FK, null,
                    ((TxEntityLongFK)this.entity).getForeignKeyColumn().getJavaName(),
                    // Bug: derivedTxのPKはSimpleName+Idではない： ((TxEntityLongFK)this.entity).getForeignEntity().getSimpleName() + "Id",
                    RefType.LONG,
                    ((TxEntityLongFK)this.entity).getForeignEntity().getSimpleName()))
                    .setImmutable(true));
            }
        } else {
            this.columns.add(1, (new AlohaColumn(
                COLUMN_TYPE.FK, null,
                ((TxEntityIntFK)this.entity).getForeignKeyColumn().getJavaName(),
                RefType.INTEGER,
                ((TxEntityIntFK)this.entity).getForeignEntity().getSimpleName())).setImmutable(true));
        }

    }

    public enum RECORD_TYPE {
        Core(true),
        Tree(true),
        ArrowTree(true),
        DistinctTree(true),
        Chain(true),
        ArrowChain(true),
        StraightChain(true),
        Relation(true),
        TemporalAttribute(true),
        TxLongFK(false),
        TxIntFK(false),
        CrudLongFK(false),
        CrudIntFK(false),
        CrudIntFKChild(false),
        CrudLongFKChild(false),
        TxIntValue(false),
        TxIntValueGroup(false),
        TxChildGroup(false),
        TxSum(false),
        DerivedTx(false),
        DerivedTxIntAFK(false),
        DerivedTxLongAFK(false),
        TxChild(false),
        FlowableTx(false),
        FlowableTxIntFK(false),
        FlowableTxLongFK(false),
        Unkownn(false);

        private final boolean master;

        RECORD_TYPE(boolean core) {
            this.master = core;
        }

        public boolean isMaster() {
            return this.master;
        }
    }

    public enum COLUMN_TYPE {
        PK,
        FK,
        AFK,
        MultiValue,
        Normal,
        Enum;

        COLUMN_TYPE() {
        }
    }
}
