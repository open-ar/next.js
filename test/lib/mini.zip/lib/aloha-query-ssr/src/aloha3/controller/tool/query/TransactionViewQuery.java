package aloha3.controller.tool.query;

import aloha.module.func.Func;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.NonEmptyArray;
import aloha3.controller.tool.query.crud.BusinessMgrContainer;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.FlatView;
import aloha3.controller.tool.query.models.JoinedView;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.dml.NaturalTransformation;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.transaction.coc.FlowableReadMgt;
import aloha3.module.object.model.read.AbstractTxModel;
import aloha3.module.object.model.read.NonEmptyModels;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public class TransactionViewQuery {

    public static
    List<JoinedView>
    joinViews(
        NonEmptyArray.DistinctInts coreIds,
        String fromYmd,
        String toYmd,
        GeneralViewsQuery.ViewConnections coreView,
        Map<String, GeneralViewsQuery.ViewConnections> txViews) throws Exception {

        return joinViews(
            BusinessMgrContainer.
                getDataMgt(
                    coreView.name).
                queryByPKs(
                    DistinctIds.toIntIDList(coreIds)),
            coreView,
            fromYmd,
            toYmd,
            txViews);
    }

    private static
    List<JoinedView>
    joinViews(
        ImmutVOs<StarView.Super.Read> coreViews,
        GeneralViewsQuery.ViewConnections mainView,
        String fromYmd,
        String toYmd,
        Map<String, GeneralViewsQuery.ViewConnections> txViews) {

        return
            joinViews(
                coreViews,
                JsonUtils.
                    toJsons(
                        coreViews),
                mainView,
                fromYmd,
                toYmd,
                txViews,
                new ArrayList<>());
    }

    private static
    List<JoinedView>
    joinViews(
        ImmutVOs<StarView.Super.Read> pivotViews,
        List<JoinedView> joinedCoreViews,
        GeneralViewsQuery.ViewConnections rootViewConnections,
        String fromYmd,
        String toYmd,
        Map<String, GeneralViewsQuery.ViewConnections> txViews,
        List<JoinedView> result)  {

        result.addAll(joinedCoreViews);

        Map<String, Object> params = new HashMap<>();
        if (JsonUtils.nonEmpty(fromYmd)) {
            params.put("from", DateTime.YMDHMS.beginningOf(JsonUtils.toYMD(fromYmd)));
            if (JsonUtils.isEmpty(toYmd))
                params.put("to", DateTime.YMDHMS.current());
            else
                params.put("to", DateTime.YMDHMS.endOf(JsonUtils.toYMD(toYmd)));
        } else if (JsonUtils.nonEmpty(toYmd)) {
            params.put("from", DateTime.YMDHMS.beginningOf(DateTime.YMD.create(19700101)));
            params.put("to", DateTime.YMDHMS.endOf(JsonUtils.toYMD(toYmd)));
        }
        if (true)
            return pivotViews.apply(
                nonEmpty->
                    nonEmpty.first().field() instanceof StarView.Field coreField ?
                        ViewJoin.joinView(
                            NaturalTransformation.fromCore(
                                (ImmutVOs)nonEmpty,
                                DateTime.YMDHMS.current()),
                            rootViewConnections,
                            (StarView.Field)nonEmpty.first().field()) :
                        Func.apply(
                            (aloha3.module.object.record.master.spec.RelationEntity.Column)
                                StarView.Relation.Read.relationReadOf(
                                    (StarView.Relation.Read)nonEmpty.first()).entity().column(),
                            column->
                                ViewJoin.joinView(
                                    NaturalTransformation.fromRelation(
                                        (ImmutVOs)nonEmpty,
                                        DateTime.YMDHMS.current()),
                                    rootViewConnections,
                                    column.FK(),
                                    column.AFK())),
                ()-> new ArrayList<>());

        List<JoinedView> list = ViewJoin.
            joinView(
                pivotViews,
                joinedCoreViews,
                rootViewConnections,
                result,
                params);

        return list;
    }

    @SuppressWarnings("unchecked")
    private static
    <F extends AbstractField & TxStarView.Field<?>>
    List<JoinedView>
    queryWorkFlows(
        ImmutVOs<StarView.Read> coreViews,
        List<JoinedView> joinedCoreViews,
        GeneralViewsQuery.ViewConnections joinTxView,
        List<JoinedView> result) throws Exception {

        FlowableReadMgt transactionMgt = (FlowableReadMgt) ViewMgr.getTransactionDataMgt(joinTxView.name);
        Method selectTxView =
            transactionMgt.
                getClass().
                getMethod(
                    "select",
                     aloha3.module.object.record.master.read.meta.Read.class);
        selectTxView.setAccessible(true);

        result.clear();
        String joinKey = ViewMgr.getPrimaryKey(joinedCoreViews.get(0).get(0).getName());
        for(StarView.Read core : coreViews.get()) {
            ImmutVOs<TxIntFK.Read> txs = (ImmutVOs<TxIntFK.Read>)selectTxView.invoke(transactionMgt, core.coreRead());
            txs.foreach(
                (tx)->{
                    JoinedView jsonCore = JsonUtils.toJson(core);
                    JoinedView views = new JoinedView();
                    views.copyFrom(jsonCore);
                    WorkFlow.
                        historyOf(
                            tx,
                            transactionMgt).
                        foreach(
                            (history)->{
                                JoinedView jsonHistory = JsonUtils.toJson(history);
                                JoinedView jsonState = new JoinedView();
                                jsonState.add(new FlatView("State", (View)history));
                                jsonState.get(0).
                                    add(
                                        jsonHistory.
                                            getMemberValue(
                                                "Name"));
                                jsonState.get(0).
                                    add(
                                        jsonHistory.
                                            getMemberValue(
                                                "TxTime"));
                                views.copyFrom(
                                    jsonState);
                            });
                    result.add(views);
                }
            );
        }

        return result;
    }

    @SuppressWarnings(value="unchecked")
    private static
    ImmutVOs
    toFlat(
        NonEmptyModels<AbstractTxModel> txModels ) {

        return txModels.toFlat(
            (m) -> {
                if (TxModel.ChildLongAFKOnly.class.isInstance(m))
                    return TxModel.ChildLongAFKOnly.class.cast(m).toFlat();
                if (TxModel.ChildLongAFK.class.isInstance(m))
                    // return TxModel.ChildLongAFK.class.cast(m).toFlat();
                    return TxModel.ChildLongAFK.toFlat((TxModel.ChildLongAFK)m);
                if (TxModel.ChildIntAFKOnly.class.isInstance(m))
                    return TxModel.ChildIntAFKOnly.class.cast(m).toFlat();
                if (TxModel.ChildIntAFK.class.isInstance(m))
                    return toFlat(TxModel.ChildIntAFK.class.cast(m));
                if (TxModel.DoubleChildIntAFK.class.isInstance(m))
                    return toFlat(TxModel.DoubleChildIntAFK.class.cast(m));

                throw new IllegalArgumentException("Unknown type; " + m.getClass().getName());
            });
    }

    private static
    <F extends AbstractField & TxStarView.Field<?>,
     T extends Comparable<? super T>,
     CHT extends ChildTxEntityIntAFK.Of<?,?,T>>
    ImmutVOs<View<TxModel.ChildIntAFK.FlatField<F,T>>>
    toFlat(
        TxModel.ChildIntAFK<F,CHT> model) {

        return model.toFlat((TxModel.ChildIntAFK<F,CHT> m)->TxModel.ChildIntAFK.toFlat(m));
    }

    private static
    <F extends AbstractField & TxStarView.Field<?>,
     T extends Comparable<? super T>,
     CH extends ChildTxEntityIntAFK.Of<?,?,T>,
     T2 extends Comparable<? super T2>,
     CH2 extends ChildTxEntityIntAFK.Of<?,?,T2>>
    ImmutVOs<View<TxModel.DoubleChildIntAFK.FlatField<F,CH,CH2>>>
    toFlat(
        TxModel.DoubleChildIntAFK<F,CH,CH2> model) {

        return model.toFlat(TxModel.DoubleChildIntAFK::toFlat);
    }
}
