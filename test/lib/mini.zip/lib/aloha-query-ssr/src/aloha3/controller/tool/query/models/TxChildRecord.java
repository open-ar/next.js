package aloha3.controller.tool.query.models;

import aloha.module.func.business.ITransactionMgt;
import aloha3.module.object.record.transaction.spec.meta.ChildTx;

import java.util.List;

class TxChildRecord<E, M> extends AlohaRecord<ChildTx<?, ?>, ITransactionMgt> {
    public TxChildRecord(RECORD_TYPE type, String name, ChildTx<?, ?> entity, ITransactionMgt dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
