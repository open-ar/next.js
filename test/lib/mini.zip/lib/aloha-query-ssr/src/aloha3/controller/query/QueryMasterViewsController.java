package aloha3.controller.query;

import aloha.module.func.Func;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.query.AlohaQueryV1;
import aloha3.controller.tool.query.GeneralViewsQuery;
import aloha3.controller.tool.query.MasterViewQuery;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import java.io.StringReader;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static aloha3.controller.Server.conceptual;
import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.INDEX_CONTENT;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PARAMS;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.query.GeneralViewsQuery.getJoinedViews;

public class QueryMasterViewsController extends AbstractController {

    public static final QueryMasterViewsController INSTANCE = new QueryMasterViewsController();
    public static final String MAIN_TEMPLATE = "queryMasterViews.html";

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Master";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot -> 
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Long::valueOf, 0L)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                INSTANCE.getNavMenuTemplate(),
                Context.Builder.create().
                    add(AlohaMeta.getPivots(container())).
                    build());
        }
    }

    private static void 
    handleContent(
        ChunkedResponseMessageBody body,
        String csv) {

        Func.accept(
            Context.Builder.create().
                add("content", csv).
                build(),
            body.asWriter(),
            (ctx, writer) ->
                Func.accept(
                    engine().processThrottled(INDEX_CONTENT, ctx),
                    throttled ->
                    {
                        while (!throttled.isFinished()) {
                            throttled.process(128, writer);
                        }
                    },
                    _ -> body.end()));
    }

    public static void 
    handleSearch(
        Request request,
        Response response) {
        
        System.out.println("handle search");
        AlohaQueryV1.init(container(), conceptual());

        request.unlessNull_(PARAMS,
            searchParam ->
                searchCsv(searchParam).unlessNull_(
                    csv ->
                        handleContent(response.chunked(), csv)));
    }

    // Same as old aloha-query: 
    // aloha.query.controll.GeneralViewsQuery#queryMasterViews(aloha.http.controller.server.v2.AplResponse, javax.json.JsonObject)
    private static MayNullValue<String>
    searchCsv(String jsonString) {

        // e.g JSON like: 
        // {"startNode":"Machine-1","nodes":[{"id":"Machine-1","name":"Machine"},{"id":"Censor.machineId-2","name":"Censor.machineId"}],"edges":[{"from":"Censor.machineId-2","to":"Machine-1"}]}
        try (JsonReader jsonReader = Json.createReader(new StringReader(jsonString))) {
            JsonObject jsonParams = jsonReader.readObject();

            String startNodeInJson = jsonParams.getString("startNode");
            // String startNode = ViewMgr.toViewModelName(startNodeInJson);
            Map<String, GeneralViewsQuery.ViewConnections> joinedViews = getJoinedViews(jsonParams);
            return MayNullValue.of(
                JsonUtils.toCsv(
                    MasterViewQuery.queryAllViews(
                        joinedViews.
                            get(
                                startNodeInJson))));
        } catch (Exception e) {
            e.printStackTrace();
            return MayNullValue.nullInstance();
        }
    }

    private static
    String
    renderMainContent(
        String pivot,
        OperationType operation,
        Long id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("referents", AlohaMeta.getReferents(pivot, container())).
            add("referrers", AlohaMeta.getReferrers(pivot, container())).
            add("views", AlohaCRUD.starViews(pivot, container())).
            add("views_fk",
                getFkPivot(viewInfo).unlessNull(
                    fkPivot ->
                        AlohaCRUD.starViews(fkPivot, container()),
                    ImmutVOs.emptyVOs())).
            add("views_afk",
                getAfkPivot(viewInfo).unlessNull(
                    afkPivot ->
                        AlohaCRUD.starViews(afkPivot, container()),
                    ImmutVOs.emptyVOs()));

        AlohaCRUD.starView(id, pivot, container()).unlessNull_(
            view ->
                context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static
    MayNullValue<String>
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
            view ->
                view.
                    mandatoryValue(f->f.IsFK) == Bool.TRUE).
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static
    MayNullValue<String>
    getAfkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE). // グラフは無視
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }
}

