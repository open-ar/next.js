package aloha3.controller.tool.query.crud;

import aloha.module.Array;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxFamilyMgt;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TxIntFKFamilyIntAFKWrapper <
    E extends TxEntityIntFK.On<M>,
    M extends CoreEntity,
    F extends TxStarView.FieldOf.AndIntFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>,
    MF extends StarView.FieldOf<M>,
    T extends TxIntFKChildIntAFKModel<E,M,F,CH,CM,CV,TxStarView.Read<F>>>
    extends BaseMgrWrapper<T, Long, Integer> {

    private final String name;
    private final F field;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final Class<CV> childValueType;
    private final TxIntFKMgr.StarView<E,M,F> parentMgr;
    private final TxIntFKMgr.StarView.Family.ChildIntAFK<E,M,F,CH> familyMgr;
    private final String childAfkName;
    private final String childValueName;
    private final List<IColumn> attributeColumns;

    public TxIntFKFamilyIntAFKWrapper(
        String name,
        F field,
        Class<CH> childRecord,
        Class<CM> childAfkRecordType,
        Class<CV> childValueType,
        TxIntFKMgr.StarView<E,M,F> parentMgr,
        TxIntFKMgr.StarView.Family.ChildIntAFK<E,M,F,CH> familyMgr) {

        this.name = name;
        this.field = field;
        this.childRecord = childRecord;
        this.parentMgr = parentMgr;
        this.familyMgr = familyMgr;
        this.childValueType = childValueType;
        this.childAfkRecordType = childAfkRecordType;

        ImmutableArray<IColumn> immutableArray = familyMgr.childTx().columnArray();
        this.attributeColumns = new ArrayList<>();
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 2));
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 1));

        this.childAfkName = this.attributeColumns.get(0).getJavaName();
        this.childValueName = this.attributeColumns.get(1).getJavaName();
    }

    @Override
    public
    boolean
    isFamily() {
        return true;
    }

    public
    String
    itemName() {

        return childRecord.getSimpleName();
    }

    public
    String
    afkEntityName() {

        return childAfkRecordType.getSimpleName();
    }

    public
    String
    afkAttributeName() {

        return childAfkName;
    }

    public
    String
    valueAttributeName() {

        return childValueName;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        String foreignEntity = parentMgr.foreignEntity().getClass().getSimpleName();
        int fkId = Integer.valueOf(json.getString(foreignEntity + "Id"));
        MayNullVO<StarView.Read<MF>> core = GenericSearch.queryMasterViewByPK(foreignEntity, fkId);

        TxStarView.Write.Prepare.Builder builderParent = TxStarView.Write.Prepare.Builder.
            create(
                getFieldClass());
        setValues(json, field, builderParent);

        JsonArray items = json.getJsonArray("child");
        List<Tuple.Pair
            <Read<CM>,
                CV>> lineItemsMore = new ArrayList<>();

        for(int i = 0; i < items.size(); i++) {
            JsonObject item = items.getJsonObject(i);
            int afkId = Integer.valueOf(item.getString(afkAttributeName()));
            CV value = null;
            if (childValueType == Integer.class) {
                value = (CV)Integer.valueOf(item.getString(valueAttributeName()));
            } else if (childValueType == String.class) {
                value = (CV)item.getString(valueAttributeName());
            }
            Core.Read<CM> afk = GenericSearch.queryMasterViewByPK(afkEntityName(), afkId).mustNonNull().coreRead();
            lineItemsMore.add(Tuple.Pair.of(afk, value));
        }

        Tuple.Pair
            <Read<CM>,
                CV> first = lineItemsMore.get(0);
        Tuple.Pair
            <Read<CM>,
                CV>[] others;
        if (lineItemsMore.size() > 1)
            others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new Tuple.Pair[0]);
        else
            others = new Tuple.Pair[0];

        return familyMgr.
            save(
                builderParent.build(),
                core.mustNonNull().coreRead(),
                DateTime.YMDHMS.current(),
                (view, childTx)->
                    Array.create(
                        aloha3.module.object.model.write.
                            TxModel.Builder.
                            create(
                                view,
                                childTx,
                                first.getT1(),
                                first.getT2()),
                        others,
                        (builder,lineItem)->
                            builder.setValue(
                                lineItem.getT1(),
                                lineItem.getT2()),
                        builder ->
                            builder.build())).
            get();

    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.unsafeFK().javaName());
    }

    @Override
    public
    ImmutVOs<T>
    query() {

        List<T> result = new ArrayList<>();
        queryTxs().
            foreach(
                (txRead)->
                    result.add(
                        (T) TxIntFKChildIntAFKModel.of(
                            familyMgr.createModel((TxIntFK.Read<E>)txRead))));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    MayNullVO<T>
    queryByPK(Long id) {

        return (MayNullVO<T>) parentMgr.
            selectTx(
                id).
            apply(
                (tx)->
                    MayNullVO.of(
                        TxIntFKChildIntAFKModel.of(
                            familyMgr.createModel(tx))),
                ()->MayNullVO.nullInstance());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Long> pkIDs) {

        List<T> result = new ArrayList<>();
        parentMgr.
            selectTxs(
                DistinctIds.toLongIDs(pkIDs)).
            foreach(
                (txRead)->
                    result.add(
                        (T) TxIntFKChildIntAFKModel.of(
                            familyMgr.createModel(txRead))));
        return ImmutVOs.create(result);
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxIntFK.Read.createCriteria(this.field.entity()));
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs foreigns,
        Map<String, Object> params) {

        return queryByFKViews(foreigns, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKViews(
        ImmutVOs<StarView.Read<MF>> foreigns,
        Map<String, Object> params) {

        if (params.containsKey("from") && params.containsKey("to")) {
            return queryByFKAndBetween(
                foreigns,
                (DateTime.YMDHMS) params.get("from"),
                (DateTime.YMDHMS) params.get("to"));
        }

        List<T> result = new ArrayList<>();
        foreigns.foreach(
            (foreignCore)->
                parentMgr.
                    selectTxsByFK(
                        foreignCore.coreRead()).
                    foreach(
                        (tx)->
                            result.add(
                                (T) TxIntFKChildIntAFKModel.of(
                                    familyMgr.createModel(tx)))));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKAndBetween(
        ImmutVOs<StarView.Read<MF>> fkViews,
        DateTime.YMDHMS from,
        DateTime.YMDHMS to) {

        List<T> result = new ArrayList<>();
        fkViews.
            foreach(
                (fk)->
                    parentMgr.
                        createViews(
                            fk.coreRead(),
                            from,
                            to).
                        foreach(
                            (txView)->
                                result.add(
                                    (T) TxIntFKChildIntAFKModel.of(
                                        familyMgr.createModel((TxIntFK.Read)txView.txRead())))));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByIntAFKViews(afkViews,  afkName, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName,
        Map<String, Object> params) {

        if (parentMgr.field().unsafeFK().javaName().equals(afkName))
            return queryByFKs(afkViews, params);

        return afkViews.
            apply(
                (fks)-> {
                    ImmutVOs<aloha3.module.object.record.transaction.read.ChildTxIntAFK> children = TxFamilyMgt.ChildIntAFK.
                        selectChildren(
                            (NonEmptyVOs) fks.map(v->v.coreRead()),
                            familyMgr);
                    return children.
                        apply(
                            (txChild) ->
                                queryByPKs(
                                    DistinctIds.toLongIDList(
                                        DistinctIds.longIDsFromRecords(
                                            txChild,
                                            child -> child.getTxId()))),
                            () -> ImmutVOs.emptyVOs());
                },
                ()->ImmutVOs.emptyVOs());
    }

    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }

    @Override
    public
    void
    update(
        JsonObject json) {

    }

    @Override
    public
    void
    delete(
        JsonObject json) {

    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory>  members = getMandatoryAttributeMembers(field);
        members.add(0, parentMgr.field().unsafeFK());
        return members;
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(field);
    }

    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return parentMgr.field().unsafeCenterMember();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }

    public TxIntFKMgr.StarView<E, M, F> getMgr() {
        return parentMgr;
    }


    @Override
    public ImmutVOs<? extends Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

}
