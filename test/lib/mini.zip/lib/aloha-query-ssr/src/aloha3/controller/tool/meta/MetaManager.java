package aloha3.controller.tool.meta;

import aloha.module.func.Func;
import aloha.module.func.business.IConceptualMgt;
import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutableArray;
import aloha.module.object.record.EntityType;
import aloha.module.object.record.IAdditionalForeignKey;
import aloha.module.object.record.IAdditionalReferenceEntity;
import aloha.module.object.record.IColumn;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.conceptual.transaction.CRD;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.conceptual.transaction.SuperCRD;
import aloha3.module.function.business.conceptual.transaction.SuperCRUD;
import aloha3.module.function.business.master.PivotReadMgt.StarView;
import aloha3.module.function.business.master.coc.GraphMgr;
import aloha3.module.function.business.transaction.TxStarViewMgt;
import aloha3.module.object.SealedMember;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.spec.AttributeRow;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.spec.DerivedTxEntity;
import aloha3.module.object.record.transaction.spec.meta.ChildTx;
import aloha3.module.object.view.AbstractCompositeField;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.TxStarView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MetaManager {
    // If enable cache for performance
    static final boolean enableCache = true;

    public static void append(
        ServiceContainer container,
        ServiceContainer.Conceptual conceptual) {

        unsafeResetIsInit();
        StarViewMeta.init(container);

        ConceptualView.isInitConceptual.set(false);
        ConceptualView.init(conceptual);
        unsafeResetIsInit();
    }
    public static void unsafeResetIsInit() {

        StarViewMeta.isInit.set(false);
    }

    static class StarViewMeta {
        // Type map
        private static final Map<String, LinkedHashSet<SealedMember._Field>> mgrTypeMap = new TreeMap<>();

        private static final Map<String, Class<?>> mgrUniqueStringMap = new TreeMap<>();
        private static final Map<SealedMember, Field.Member.ofStarView.Attribute<?>> foreignMgrUniqueStringMap = new HashMap<>();

        private static final Map<String, LinkedHashSet<IColumn>> txChildMap = new TreeMap<>();

        private static final Map<String, StarView<?,?,?,?>> mdmMap = new TreeMap<>();
        private static final Map<String, TxStarViewMgt<?,?,?>> txmMap = new TreeMap<>();

        private static final AtomicBoolean isInit = new AtomicBoolean(false);
        static ServiceContainer container;

        synchronized static
        void
        init(ServiceContainer container) {
            if (MetaManager.enableCache && isInit.getAndSet(true)) {
                return;
            }

            StarViewMeta.container = container;
            reload(container);
        }

        static
        void
        reload() {
            if (container == null) {
                System.out.println("Nothing to reload");
                return;
            }
            reload(container);
        }

        private static
        void
        reload(ServiceContainer container) {

            // Master
            container.allMDM().forEach(mdm -> {

                if (mdm instanceof StarView<?, ?, ?, ?> mdmGeneric) {
                    final var mgrName = getMgrName(mdmGeneric.entity());
                    mdmMap.put(mgrName, mdmGeneric);
                    viewMetaMaster(
                        mgrName,
                        mdmGeneric,
                        container);
                } else if (mdm instanceof GraphMgr) {
                    // System.out.println("Ignore coc init, " + mdm.getClass().getName());
                } else {
                    System.err.println("Not support mdm, " + mdm.getClass().getName());
                }
            });

            // Tx
            container.allTxM().forEach(txm -> {
                if (txm instanceof TxStarViewMgt<?, ?, ?> txmGeneric) {
                    final var mgrName = getMgrName(txmGeneric.entity());
                    txmMap.put(mgrName, txmGeneric);
                    viewMetaTx(mgrName, txmGeneric, container);
                    // Add child tx fields
                    if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmChild) {
                        columnMetaTxChild(mgrName, txmChild.childTx(), container);
                    }
                } else {
                    System.err.println("Not support txm, " + txm.getClass().getName());
                }
            });
        }

        static
        void
        columnMetaTxChild(
            String mgrName,
            ChildTx<?, ?> entity,
            ServiceContainer container) {

            final var colMap = getOrAddTxChildMap(mgrName);
            // PK
            Func.accept(
                entity.column().PK(),
                pk -> {
                    colMap.add(pk);
                    MemberMeta.txChildPkColSet.add(pk);
                });

            // FK
            Func.accept(
                entity.getForeignKeyColumn(),
                fk -> {
                    colMap.add(fk);
                    MemberMeta.txChildFkColSet.add(fk);
                });

            // AFK
            if (entity instanceof IAdditionalForeignKey foreignKey &&
                entity instanceof IAdditionalReferenceEntity<?> referenceEntity) {
                Func.accept(
                    foreignKey.getAdditionalForeignKeyColumn(),
                    fk -> {
                        colMap.add(fk);
                        MemberMeta.txChildAFkColSet.add(fk);
                        mapForeignAndUniqueStringColIfPossible(
                            (SealedMember._Column) fk,
                            referenceEntity.getAdditionalReferenceEntity(),
                            container);
                    }
                );
            }

            // Attr
            if (entity instanceof ChildTxEntityIntAFK.Of<?, ?, ?> entityIntAFK) {
                colMap.add(entityIntAFK.attr());
            } else if (entity instanceof ChildTxEntityLongAFK.Of<?, ?, ?> entityLongAFK) {
                colMap.add(entityLongAFK.attr());
            }
        }

        private static
        void
        viewMetaTx(
            String mgrName,
            TxStarViewMgt<?, ?, ?> txmGeneric,
            ServiceContainer container) {

            final LinkedHashSet<SealedMember._Field> fieldMap = getOrAddViewFieldMap(mgrName);
            TxStarView.Field<?> field = txmGeneric.field();
            SealedTxParent<?> entity = txmGeneric.entity();

            // PK
            Func.accept(
                field.unsafeCenterMember(),
                pk -> {
                    fieldMap.add(pk);
                    MemberMeta.pkFieldSet.add(pk);
                    if (field instanceof TxStarView.FieldOf.AndLongFK<?> fieldLongAFK &&
                        entity instanceof DerivedTxEntity<?,?>) {
                        // FK == PK
                        mapForeignAndUniqueStringColIfPossible(
                            fieldLongAFK.unsafeFK(),
                            fieldLongAFK.entity().getForeignEntity(),
                            container);
                    }
                }
            );


            // FK
            if (field instanceof TxStarView.FieldOf.AndIntFK<?> fieldIntFK) {
                Func.accept(
                    fieldIntFK.unsafeFK(),
                    fk -> {
                        fieldMap.add(fk);
                        MemberMeta.fkFieldSet.add(fk);

                        mapForeignAndUniqueStringColIfPossible(
                            fk,
                            fieldIntFK.entity().getForeignEntity(),
                            container);
                    }
                );
            } else if (field instanceof TxStarView.FieldOf.AndLongFK<?> fieldLongFK) {
                Func.accept(
                    fieldLongFK.unsafeFK(),
                    fk -> {
                        fieldMap.add(fk);
                        MemberMeta.fkFieldSet.add(fk);

                        mapForeignAndUniqueStringColIfPossible(
                            fk,
                            fieldLongFK.entity().getForeignEntity(),
                            container);
                    }
                );
            }

            // Attrs
            collectAttrInfo(mgrName, container, fieldMap, field.attributeMembers());
        }

        private static
        void
        viewMetaMaster(
            String mgrName,
            StarView<?,?,?,?> mdmGeneric,
            ServiceContainer container) {


            final Field.ofStarView.Around.Pivot<?> field = mdmGeneric.field();

            final var typeKeys = getOrAddViewFieldMap(mgrName);
            // PK
            Func.accept(
                field.unsafeCenterMember(),
                pk -> {
                    typeKeys.add(pk);
                    MemberMeta.pkFieldSet.add(pk);
                });
            // Attributes
            collectAttrInfo(mgrName, container, typeKeys, field.attributeMembers());
        }

        private static
        void
        collectAttrInfo(
            String mgrName,
            ServiceContainer container,
            LinkedHashSet<SealedMember._Field> typeKeys,
            ImmutableArray<Field.Member.ofStarView.Attribute<?>> attributeImmutableArray) {

            attributeImmutableArray.foreach(attr -> {
                typeKeys.add((SealedMember._Field) attr);

                collectAttrMeta(mgrName, attr);

                if (Instance.of(attr.attributeEntity()) instanceof IAdditionalReferenceEntity<?> attrAfk) {
                    mapForeignAndUniqueStringColIfPossible(
                        (SealedMember._Field) attr,
                        attrAfk.getAdditionalReferenceEntity(),
                        container);
                }
            });
        }

        private static void collectAttrMeta(
            String mgrName,
            Field.Member.ofStarView.Attribute<?> attr) {

            if (isUnique(attr)) {
                MemberMeta.uniqueAttrSet.add(attr);
                mgrUniqueStringMap.put(
                    mgrName,
                    attr.attributeEntity());
            }
            if (isImmutable(attr)) {
                MemberMeta.immutableAttrSet.add(attr);
            }
            if (isOptional(attr)) {
                MemberMeta.optionalAttrSet.add(attr);
            }
            if (isEnum(attr)) {
                MemberMeta.enumAttrMap.put(
                    attr,
                    getEnumArrays(attr));
            }
        }

        private static
        void
        tryMapForeignAndUniqueStringCol(
            SealedMember key,
            ImmutableArray<Field.Member.ofStarView.Attribute<?>> attributeMembers) {

            for (final var attr : attributeMembers.asList()) {
                if (isUnique(attr)) {
                    foreignMgrUniqueStringMap.put(
                        key,
                        attr);
                }
            }
        }

        private static
        void
        _mapForeignAndUniqueStringColIfPossible(
            SealedMember key,
            String foreignEntityName,
            ServiceContainer container) {

            boolean isMatched = false;

            for (final var mdm : container.allMDM()) {
                if (
                    mdm instanceof StarView<?, ?, ?, ?> mdmGeneric &&
                        isThisMgr(mdmGeneric.entity(), foreignEntityName)) {
                    tryMapForeignAndUniqueStringCol(key, mdmGeneric.field().attributeMembers());
                    isMatched = true;
                } else if (mdm instanceof GraphMgr) {
                    // System.out.println("Ignore coc, " + mdm.getClass().getName());
                }
            }

            // Tx
            for (final var txm : container.allTxM()) {
                if (txm instanceof TxStarViewMgt<?, ?, ?> txmGeneric &&
                    isThisMgr(txmGeneric.entity(), foreignEntityName)) {
                    tryMapForeignAndUniqueStringCol(key, txmGeneric.field().attributeMembers());
                    isMatched = true;
                }
            }

            if (!isMatched) {
                System.out.println("- Not matching FK type, " + foreignEntityName + " sealedMember:" + key.Name());
            }
        }

        private static
        void
        mapForeignAndUniqueStringColIfPossible(
            SealedMember key,
            Class<? extends EntityType> afkEntity,
            ServiceContainer container) {

            if (aloha3.module.object.record.master.coc.Graph.class.isAssignableFrom(afkEntity)) {
                MemberMeta.afkToCocSet.add(key);
                System.out.println("Ignore afk to coc Graph, " + key.getClass().toString() + ":" + key.Name() + "->" + afkEntity.getName());
                return;
            }
            if (ChildTx.class.isAssignableFrom(afkEntity)) {
                MemberMeta.afkAttrSet.add(key);
                System.out.println("Ignore afk to txChild, " + key.getClass().toString() + ":" + key.Name() + "->" + afkEntity.getName());
                return;
            }
            _mapForeignAndUniqueStringColIfPossible(
                key,
                afkEntity.getSimpleName(),
                container);
        }

        static
        Optional<LinkedHashSet<SealedMember._Field>>
        getViewField(String mgrName) {
            return Optional.ofNullable(mgrTypeMap.get(mgrName));
        }
        static
        LinkedHashSet<IColumn>
        getTxChildCol(String mgrName) {
            return txChildMap.get(mgrName);
        }
        @SuppressWarnings({"unchecked","rawtypes"})
        static
        Optional<Class<? extends FixedAttributeEntity.UniqueString<?>>>
        getUniqueStringClassFromForeign(
            SealedMember foreignMember) {

            return
                Optional.
                    ofNullable(
                        foreignMgrUniqueStringMap.get(foreignMember)).
                    map(v->
                        (Class)v.attributeEntity());
        }

        static
        Optional<SealedMember>
        getUniqueStringMemberFromForeign(
            SealedMember foreignMember) {

            return
                Optional.
                    ofNullable(
                        (SealedMember._Field)foreignMgrUniqueStringMap.get(foreignMember));
        }

        static Optional<Class<?>>
        getUniqueStringClassFromSelf(String mgrName) {
            return Optional.ofNullable(mgrUniqueStringMap.get(mgrName));
        }
        static boolean isMdm(String mgrName) {
            return mdmMap.containsKey(mgrName);
        }
        static boolean isTxm(String mgrName) {
            return txmMap.containsKey(mgrName);
        }
        static TxStarViewMgt<?, ?, ?> txm(String mgrName) {
            return txmMap.get(mgrName);
        }
        private static void eachTxm(BiConsumer<String, TxStarViewMgt<?,?,?>> action) {
            txmMap.forEach((name, mgt) -> {
                if (!ConceptualView.conceptualCRDs.containsKey(name) &&
                    !ConceptualView.conceptualCRUDs.containsKey(name) &&
                    !ConceptualView.conceptualCRUDFamilies.containsKey(name) &&
                    !ConceptualView.conceptualCRDFamilies.containsKey(name)) {
                    action.accept(name, mgt);
                }
            });
        }
        static
        <T> List<T>
        mapTxm(
            ServiceContainer container,
            ServiceContainer.Conceptual conceptual,
            BiFunction<String, TxStarViewMgt<?,?,?>, T> action) {

            init(container);
            ConceptualView.init(conceptual);

            final List<T> ret = new ArrayList<>();
            eachTxm((t, u) ->
                ret.add(action.apply(t, u)));
            return ret;
        }
        static StarView<?,?,?,?> mdm(String mgrName) {
            return mdmMap.get(mgrName);
        }
        static void eachMdm(BiConsumer<String, StarView<?,?,?,?>> action) {
            mdmMap.forEach(action);
        }
        static
        <T> List<T>
        mapMdm(
            ServiceContainer container,
            BiFunction<String, StarView<?,?,?,?>, T> action) {

            init(container);

            final List<T> ret = new ArrayList<>();
            eachMdm((t, u) ->
                ret.add(action.apply(t, u)));
            return ret;
        }

        static
        <T> List<T>
        findMdm(
            String mdmName,
            ServiceContainer container,
            BiFunction<String, StarView<?,?,?,?>, T> action) {

            init(container);

            final List<T> ret = new ArrayList<>();
            eachMdm((t, u) -> {
                if (t.startsWith(mdmName)) {
                    ret.add(action.apply(t, u));
                }
            });
            return ret;
        }

        static boolean isTxChild(String mgrName) {
            return txChildMap.containsKey(mgrName);
        }

        private static String getMgrName(Object entity) {
            return entity.getClass().getSimpleName();
        }

        private static
        LinkedHashSet<SealedMember._Field>
        getOrAddViewFieldMap(String name) {
            if (!mgrTypeMap.containsKey(name)) {
                mgrTypeMap.put(name, new LinkedHashSet<>());
            }
            return mgrTypeMap.get(name);
        }

        static
        boolean
        isMdmOrTxMgr(String mgrName) {
            return mgrTypeMap.containsKey(mgrName);
        }

        private static
        LinkedHashSet<IColumn>
        getOrAddTxChildMap(String name) {
            if (!txChildMap.containsKey(name)) {
                txChildMap.put(name, new LinkedHashSet<>());
            }
            return txChildMap.get(name);
        }

        private static
        boolean
        isUnique(
            Field.Member.ofStarView.Attribute<?> attr) {

            return FixedAttributeEntity.UniqueString.class.isAssignableFrom(attr.attributeEntity());
        }

        private static
        boolean
        isImmutable(
            Field.Member.ofStarView.Attribute<?> attr) {

            return FixedAttributeEntity.class.isAssignableFrom(attr.attributeEntity());
        }

        private static
        boolean
        isOptional(
            Field.Member.ofStarView.Attribute<?> attr) {

            return attr instanceof AbstractField.Member.Optional<?>;
        }

        private static
        boolean
        isEnum(
            Field.Member.ofStarView.Attribute<?> attr) {

            return AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(attr.attributeEntity());
        }

        private static
        boolean
        isThisMgr(
            final Object mdm,
            final String mgrName) {

            return mdm.getClass().getSimpleName().equals(mgrName);
        }

        @SuppressWarnings("unchecked")
        private static
        <E extends Enum<E> & IdentifiableEnum<E>>
        ImmutableArray<E>
        getEnumArrays(Field.Member.ofStarView.Attribute<?> attr) {
            return IdentifiableEnum.
                toArray(
                    ((AttributeRow.ForIdentifiableEnum<E>) Instance.of(attr.attributeEntity())).
                        enumClass());
        }
    }

    static class ConceptualView{
        // Conceptuals
        private static final Map<String, IConceptualMgt> conceptualMap = new TreeMap<>();
        // Sub concptuals
        private static final Map<String, SuperCRUD<?,?,?,?,?>> conceptualCRUDs = new TreeMap<>();
        private static final Map<String, CRUD.SuperFamily<?, ?, ?, ?, ?, ?, ?, ?, ?>> conceptualCRUDFamilies = new TreeMap<>();
        private static final Map<String, SuperCRD<?, ?, ?>> conceptualCRDs = new TreeMap<>();
        private static final Map<String, CRD.SuperFamily<?, ?, ?, ?, ?>> conceptualCRDFamilies = new TreeMap<>();
        private static final Map<String, Graph<?, ?, ?, ?>> conceptualGraphs = new TreeMap<>();
        // Sub graphs
        private static final Map<String, Graph.Tree.Distinct<?,?,?>> conceptualTrees = new TreeMap<>();

        private static final AtomicBoolean isInitConceptual = new AtomicBoolean(false);

        static void init(ServiceContainer.Conceptual conceptual) {
            if (MetaManager.enableCache && isInitConceptual.getAndSet(true)) {
                return;
            }

            // Conceptuals
            conceptual.all().forEach(conceptualMgt -> {
                if (conceptualMgt instanceof Graph.Tree.Distinct<?,?,?> treeMgr) {
                    final var mgrName = treeMgr.hierarchyEntity().getClass().getSimpleName();
                    conceptualMap.put(mgrName, treeMgr);
                    conceptualGraphs.put(mgrName, treeMgr);
                    conceptualTrees.put(mgrName, treeMgr);
                    // TODO other graphs
                } else if (conceptualMgt instanceof CRUD.SuperFamily<?, ?, ?, ?, ?, ?, ?, ?, ?> crudMgr) {
                    final var mgrName = crudMgr.txMgr().entity().getClass().getSimpleName();
                    conceptualMap.put(mgrName, crudMgr);
                    conceptualCRUDFamilies.put(mgrName, crudMgr);
                    // Init variable which no Manager Attributes
                    crudMgr.parentMgr().variableField().attributeMembers().foreach(attribute -> {
                        StarViewMeta.collectAttrMeta(mgrName, attribute);
                    });
                    // Add child tx fields
                    StarViewMeta.columnMetaTxChild(
                        mgrName,
                        crudMgr.childrenMgr().childTx(),
                        StarViewMeta.container);
                } else if (conceptualMgt instanceof CRD.SuperFamily<?, ?, ?, ?, ?> crdMgr) {
                    final var mgrName = crdMgr.txMgr().entity().getClass().getSimpleName();
                    conceptualMap.put(mgrName, crdMgr);
                    conceptualCRDFamilies.put(mgrName, crdMgr);
                    // Add child tx fields
                    StarViewMeta.columnMetaTxChild(
                        mgrName,
                        crdMgr.txMgr().childTx(), // CRDはchildrenMgrがない
                        StarViewMeta.container);
                } else if (conceptualMgt instanceof SuperCRUD<?,?,?,?,?> crudMgr) {
                    // Normal CRUD
                    final var mgrName = crudMgr.txMgr().entity().getClass().getSimpleName();
                    conceptualMap.put(mgrName, crudMgr);
                    conceptualCRUDs.put(mgrName, crudMgr);
                    // Init variable which no Manager Attributes
                    crudMgr.variableField().attributeMembers().foreach(attribute -> {
                        StarViewMeta.collectAttrMeta(mgrName, attribute);
                    });
                } else if (conceptualMgt instanceof SuperCRD<?, ?, ?> crdMgr) {
                    // Normal CRD
                    final var mgrName = crdMgr.txMgr().entity().getClass().getSimpleName();
                    conceptualMap.put(mgrName, crdMgr);
                    conceptualCRDs.put(mgrName, crdMgr);
                } else {
                    System.err.println("Not support conceptual, " + conceptualMgt.getClass().getName());
                }
            });
        }

        static
        <T> List<T>
        mapConceptualTrees(
            ServiceContainer.Conceptual conceptual,
            BiFunction<String, Graph.Tree.Distinct<?,?,?>, T> action) {

            init(conceptual);

            final List<T> ret = new ArrayList<>();
            conceptualTrees.forEach(((t, u) ->
                ret.add(action.apply(t, u))));
            return ret;
        }

        static
        <T> List<T>
        mapConceptualCRUDs(
            ServiceContainer.Conceptual conceptual,
            BiFunction<String, SuperCRUD<?,?,?,?,?>, T> action) {

            init(conceptual);

            final List<T> ret = new ArrayList<>();
            conceptualCRUDs.forEach((t, u) ->
                ret.add(action.apply(t, u)));
            return ret;
        }

        static
        <T> List<T>
        mapConceptualCRUDFamilies(
            ServiceContainer.Conceptual conceptual,
            BiFunction<String, CRUD.SuperFamily<?, ?, ?, ?, ?, ?, ?, ?, ?>, T> action) {

            init(conceptual);

            final List<T> ret = new ArrayList<>();
            conceptualCRUDFamilies.forEach((t, u) ->
                ret.add(action.apply(t, u)));
            return ret;
        }

        static
        <T> List<T>
        mapConceptualCRDFamilies(
            ServiceContainer.Conceptual conceptual,
            BiFunction<String, CRD.SuperFamily<?, ?, ?, ?, ?>, T> action) {

            init(conceptual);

            final List<T> ret = new ArrayList<>();
            conceptualCRDFamilies.forEach((t, u) ->
                ret.add(action.apply(t, u)));
            return ret;
        }

        static
        <T> List<T>
        mapConceptualCRDs(
            ServiceContainer.Conceptual conceptual,
            BiFunction<String, SuperCRD<?, ?, ?>, T> action) {

            init(conceptual);

            final List<T> ret = new ArrayList<>();
            conceptualCRDs.forEach((t, u) ->
                ret.add(action.apply(t, u)));
            return ret;
        }
    }

    static class MemberMeta {
        private static final LinkedHashSet<SealedMember> pkFieldSet = new LinkedHashSet<>();
        private static final LinkedHashSet<SealedMember> fkFieldSet = new LinkedHashSet<>();
        private static final LinkedHashSet<SealedMember> afkToCocSet = new LinkedHashSet<>();
        private static final LinkedHashSet<SealedMember> afkAttrSet = new LinkedHashSet<>();

        private static final LinkedHashSet<Field.Member.ofStarView.Attribute<?>> uniqueAttrSet = new LinkedHashSet<>();
        private static final LinkedHashSet<Field.Member.ofStarView.Attribute<?>> immutableAttrSet = new LinkedHashSet<>();
        private static final LinkedHashSet<Field.Member.ofStarView.Attribute<?>> optionalAttrSet = new LinkedHashSet<>();
        private static final Map<Field.Member.ofStarView.Attribute<?>, ImmutableArray<?>> enumAttrMap = new LinkedHashMap<>();

        private static final LinkedHashSet<IColumn> txChildPkColSet = new LinkedHashSet<>();
        private static final LinkedHashSet<IColumn> txChildFkColSet = new LinkedHashSet<>();
        private static final LinkedHashSet<IColumn> txChildAFkColSet = new LinkedHashSet<>();

        static boolean isPK(SealedMember field) {
            return pkFieldSet.contains(field);
        }
        static boolean isFK(SealedMember field) {
            return fkFieldSet.contains(field);
        }
        static boolean isAFKToCoc(SealedMember field) {
            return afkToCocSet.contains(field);
        }
        static boolean isAFKAttr(SealedMember field) {
            return afkAttrSet.contains(field);
        }
        static boolean isAttrUnique(Field.Member.ofStarView.Attribute<?> field) {
            return uniqueAttrSet.contains(field);
        }
        static boolean isAttrImmutable(Field.Member.ofStarView.Attribute<?> field) {
            return immutableAttrSet.contains(field);
        }

        static boolean
        isOptional(Field.Member.ofStarView.Attribute<?> attr) {
            return optionalAttrSet.contains(attr);
        }

        static boolean
        isEnum(
            Field.Member.ofStarView.Attribute<?> attr) {

            return enumAttrMap.containsKey(attr);
        }

        static
        List<String>
        enumValues(
            Field.Member.ofStarView.Attribute<?> attr) {

            return enumAttrMap.get(attr).
                asList().
                stream().
                map(Object::toString).
                toList();
        }

        public static
        <E extends Enum<E> & IdentifiableEnum<E>>
        boolean
        enumAttrMapGenerated(
            Class<E> enumClass) {

            final var attrJavaName = underscoresToBigCamelCase(enumClass.getSimpleName());
            return enumAttrMap.keySet().stream().anyMatch(it -> attrJavaName.equals(it.javaName()));
        }

        private static
        String
        underscoresToBigCamelCase(String underLine) {

            return
                Arrays.
                    stream(underLine.toLowerCase().split("_")).
                    map(MetaManager::capitalize).
                    collect(Collectors.joining(""));
        }

        static boolean isTxChildPK(IColumn col) {
            return txChildPkColSet.contains(col);
        }
        @SuppressWarnings({"SuspiciousMethodCalls"})
        static boolean isTxChildPK(SealedMember col) {
            return txChildPkColSet.contains(col);
        }

        static boolean isTxChildFK(IColumn col) {
            return txChildFkColSet.contains(col);
        }
        static boolean isTxChildAFK(IColumn col) {
            return txChildAFkColSet.contains(col);
        }
        @SuppressWarnings({"SuspiciousMethodCalls"})
        static boolean isTxChildFK(SealedMember col) {
            return txChildFkColSet.contains(col);
        }

        static boolean withoutPK_FK_AfkToCoc(SealedMember field) {
            return !(
                MemberMeta.isPK(field) ||
                MemberMeta.isAFKToCoc(field) ||
                MemberMeta.isTxChildPK(field) ||
                MemberMeta.isTxChildFK(field));
        }
        static boolean withPK_withoutFK_AfkToCoc(SealedMember field) {
            return !(
                MemberMeta.isAFKToCoc(field) ||
                MemberMeta.isTxChildPK(field) ||
                MemberMeta.isTxChildFK(field));
        }

        static boolean withoutAfkToCoc(SealedMember field) {
            return !MemberMeta.isAFKToCoc(field);
        }
    }

    static
    List<Class<AbstractCompositeField<?,?>>>
    allGalaxies(Package packageOfGalaxy) {
        Class[] allClasses;
        try {
            allClasses = ClassFinder.getClasses(
                packageOfGalaxy.getName(),
                Thread.currentThread().getContextClassLoader());
                // RsGenerator.class.getClassLoader());
        } catch (Exception e) {
            System.err.println("Error while getClasses: " + packageOfGalaxy.getName());
            return Collections.emptyList();
        }
        return
            Stream.of(allClasses).
                filter(AbstractCompositeField.class::isAssignableFrom).
                map(it -> (Class<AbstractCompositeField<?,?>>)it).
                toList();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    static
    List<Class<AbstractCompositeField<?,?>>>
    allComposedViews(Package packageOfController) {

        Class[] allClasses;
        Class superControllerClass;
        try {
            allClasses = ClassFinder.getClasses(
                packageOfController.getName(),
                Thread.currentThread().getContextClassLoader());
            superControllerClass = Class.forName("aloha3.api.server.mapping.Controller");
        } catch (Exception e) {
            System.err.println("Error while getClasses: " + packageOfController.getName());
            return Collections.emptyList();
        }
        return
            Stream.of(allClasses).
                filter(superControllerClass::isAssignableFrom).
                flatMap(it -> {
                    try {
                        // e.g Call controller.Orders.compositeFields() method by reflection
                        final var methodOfCompositeFields = it.getMethod("compositeFields");
                        final var controller = it.getConstructor().newInstance();
                        return ((List<Class<AbstractCompositeField<?, ?>>>) methodOfCompositeFields.invoke(controller)).stream();
                    } catch (Exception e) {
                        return Stream.of();
                    }
                }).
                toList();
    }

    public static
    String
    decapitalize(String string) {
        return firstCharConvertor(string, Character::toLowerCase);
    }

    public static
    String
    decapitalize(Class<?> clz) {
        return decapitalize(clz.getSimpleName());
    }

    public static
    String
    capitalize(String string) {
        return firstCharConvertor(string, Character::toUpperCase);
    }

    private static
    String
    firstCharConvertor(String string, Function<Character, Character> fn) {
        if (string == null || string.isEmpty()) {
            return string;
        }

        char[] c = string.toCharArray();
        c[0] = fn.apply(c[0]);

        return new String(c);
    }
}
