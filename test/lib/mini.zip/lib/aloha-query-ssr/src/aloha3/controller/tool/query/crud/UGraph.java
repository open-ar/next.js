package aloha3.controller.tool.query.crud;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple.ImmutPair;
import aloha3.controller.tool.query.MasterViewQuery;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.JoinedView;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.object.model.read.Tree.Star;
import aloha3.module.object.model.read.Tree.StarArrow;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK.Of;
import aloha3.module.object.record.master.HierarchyEntity.Of.Chain;
import aloha3.module.object.record.master.HierarchyEntity.Of.Tree;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.meta.master.Core.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field.Member.ofStarView.Attribute;
import aloha3.module.object.view.StarView;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class UGraph {
    public UGraph() {
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonObjectBuilder toTreeNode(Read<Graph> graph, Star<F> node) {
        JsonObjectBuilder nodeBuilder = toTreeNode(JsonUtils.toJson(node.node()), ((StarView.Read)node.node()).coreRead().getRegTimeAsLong());
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ImmutVOs<StarView.Read<F>> leaves = node.leaves();
        Iterator var5 = leaves.asList().iterator();

        while(var5.hasNext()) {
            StarView.Read<F> leaf = (StarView.Read)var5.next();
            arrayBuilder.add(toTreeNode(JsonUtils.toJson(leaf), leaf.coreRead().getRegTimeAsLong()).add("graphId", graph.coreId()));
        }

        ImmutableArray<Star<F>> branches = node.branches();
        Iterator var9 = branches.asList().iterator();

        while(var9.hasNext()) {
            Star<F> branch = (Star)var9.next();
            arrayBuilder.add(toTreeNode(branch));
        }

        nodeBuilder.add("child", arrayBuilder).add("graphId", graph.coreId());
        JsonObjectBuilder root = Json.createObjectBuilder();
        root.add("graphId", graph.coreId());
        root.add("title", "GraphId:" + graph.coreId());
        root.add("id", -1);
        root.add("child", Json.createArrayBuilder().add(nodeBuilder));
        return root;
    }

    private static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonObjectBuilder toTreeNode(Star<F> node) {
        JsonObjectBuilder firstNodeBuilder = toTreeNode(JsonUtils.toJson(node.node()), ((StarView.Read)node.node()).coreRead().getRegTimeAsLong());
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ImmutVOs<StarView.Read<F>> leaves = node.leaves();
        Iterator var4 = leaves.asList().iterator();

        while(var4.hasNext()) {
            StarView.Read<F> leaf = (StarView.Read)var4.next();
            arrayBuilder.add(toTreeNode(JsonUtils.toJson(leaf), leaf.coreRead().getRegTimeAsLong()));
        }

        ImmutableArray<Star<F>> branches = node.branches();
        Iterator var7 = branches.asList().iterator();

        while(var7.hasNext()) {
            Star<F> branch = (Star)var7.next();
            arrayBuilder.add(toTreeNode(branch));
        }

        firstNodeBuilder.add("child", arrayBuilder);
        return firstNodeBuilder;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>, HF extends StarView.Hierarchy.FieldOf<H>> JsonObjectBuilder toTreeNode(Read<Graph> graph, StarArrow<F, HF> node) {
        JsonObjectBuilder objectBuilder = toTreeNode(JsonUtils.toJson(node.from()), node.from().coreRead().getRegTimeAsLong());
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ImmutableArray<ImmutPair<StarView.Hierarchy.Read<HF>, StarView.Read<F>>> leaves = node.arrowToLeaves();
        Iterator var5 = leaves.asList().iterator();

        while(var5.hasNext()) {
            ImmutPair<StarView.Hierarchy.Read<HF>, StarView.Read<F>> leaf = (ImmutPair)var5.next();
            arrayBuilder.add(toTreeNode(JsonUtils.toJson(leaf.getRight()), ((StarView.Read)leaf.getRight()).coreRead().getRegTimeAsLong()).add("attributes", toTreeNodeAttributes(JsonUtils.toJson(leaf.getLeft()), ((StarView.Hierarchy.FieldOf)((StarView.Hierarchy.Read)leaf.getLeft()).field()).attributeMembers(), ((StarView.Read)leaf.getRight()).coreRead().getRegTimeAsLong())));
        }

        ImmutableArray<ImmutPair<StarView.Hierarchy.Read<HF>, StarArrow<F, HF>>> branches = node.arrowToBranches();
        Iterator var9 = branches.asList().iterator();

        while(var9.hasNext()) {
            ImmutPair<StarView.Hierarchy.Read<HF>, StarArrow<F, HF>> branch = (ImmutPair)var9.next();
            arrayBuilder.add(toTreeNode((StarArrow)branch.getRight()).add("attributes", toTreeNodeAttributes(JsonUtils.toJson(branch.getLeft()), ((StarView.Hierarchy.FieldOf)((StarView.Hierarchy.Read)branch.getLeft()).field()).attributeMembers(), 0L)));
        }

        objectBuilder.add("child", arrayBuilder).add("graphId", graph.coreId());
        JsonObjectBuilder root = Json.createObjectBuilder();
        root.add("graphId", graph.coreId());
        root.add("title", "GraphId:" + graph.coreId());
        root.add("id", -1);
        root.add("child", Json.createArrayBuilder().add(objectBuilder));
        return root;
    }

    private static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>, HF extends StarView.Hierarchy.FieldOf<H>> JsonObjectBuilder toTreeNode(StarArrow<F, HF> node) {
        JsonObjectBuilder objectBuilder = toTreeNode(JsonUtils.toJson(node.from()), node.from().coreRead().getRegTimeAsLong());
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ImmutableArray<ImmutPair<StarView.Hierarchy.Read<HF>, StarView.Read<F>>> leaves = node.arrowToLeaves();
        Iterator var4 = leaves.asList().iterator();

        while(var4.hasNext()) {
            ImmutPair<StarView.Hierarchy.Read<HF>, StarView.Read<F>> leaf = (ImmutPair)var4.next();
            arrayBuilder.add(toTreeNode(JsonUtils.toJson(leaf.getRight()), ((StarView.Read)leaf.getRight()).coreRead().getRegTimeAsLong()).add("attributes", toTreeNodeAttributes(JsonUtils.toJson(leaf.getLeft()), ((StarView.Hierarchy.FieldOf)((StarView.Hierarchy.Read)leaf.getLeft()).field()).attributeMembers(), ((StarView.Read)leaf.getRight()).coreRead().getRegTimeAsLong())));
        }

        ImmutableArray<ImmutPair<StarView.Hierarchy.Read<HF>, StarArrow<F, HF>>> branches = node.arrowToBranches();
        Iterator var7 = branches.asList().iterator();

        while(var7.hasNext()) {
            ImmutPair<StarView.Hierarchy.Read<HF>, StarArrow<F, HF>> branch = (ImmutPair)var7.next();
            arrayBuilder.add(toTreeNode((StarArrow)branch.getRight()).add("attributes", toTreeNodeAttributes(JsonUtils.toJson(branch.getLeft()), ((StarView.Hierarchy.FieldOf)((StarView.Hierarchy.Read)branch.getLeft()).field()).attributeMembers(), 0L)));
        }

        objectBuilder.add("child", arrayBuilder);
        return objectBuilder;
    }

    private static JsonObjectBuilder toTreeNodeAttributes(JoinedView nodeJson, ImmutableArray<Attribute<?>> attributes, long regTime) {
        List<String> attributeNames = new ArrayList();
        Map<String, Boolean> foreignAttributes = new HashMap();
        List<String> fieldNames = new ArrayList();
        attributes.foreach((attribute) -> {
            attributeNames.add(attribute.javaName());
            if (attribute.attributeEntity().getSuperclass() == Of.class) {
                foreignAttributes.put(attribute.javaName(), Boolean.TRUE);
            } else {
                foreignAttributes.put(attribute.javaName(), Boolean.FALSE);
            }

            String field = attribute.field().getClass().getSimpleName();
            if (field.endsWith("Field")) {
                field = field.substring(0, field.length() - "Field".length());
            }

            fieldNames.add(field);
        });
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        nodeJson.forEach((view) -> {
            Iterator var5 = view.keys().iterator();

            while(var5.hasNext()) {
                String name = (String)var5.next();
                if (attributeNames.contains(name)) {
                    Object value = view.getValue(name);
                    if (value != null) {
                        if (foreignAttributes.get(name) && name.endsWith("Id")) {
                            String foreign = name.substring(0, name.length() - 2);
                            name = ViewMgr.toViewName(foreign) + "ID";
                        }

                        if (!fieldNames.isEmpty()) {
                            name = ViewMgr.toColumnName(fieldNames.get(0), name);
                        }

                        MasterViewQuery.setValue(objectBuilder, name, value);
                    }
                }
            }

        });
        return objectBuilder;
    }

    private static JsonObjectBuilder toTreeNode(JoinedView nodeJson, long regTime) {
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        nodeJson.forEach((view) -> {
            String titleName = null;
            Object titleValue = null;
            Iterator var4 = view.keys().iterator();

            while(var4.hasNext()) {
                String name = (String)var4.next();
                Object value = view.getValue(name);
                if (value != null) {
                    MasterViewQuery.setValue(objectBuilder, name, value);
                    String label = name;
                    if (name.equals(ViewMgr.getPrimaryKey(view.getName()))) {
                        label = "id";
                    }

                    if (name.endsWith("Name")) {
                        label = "title";
                        titleName = name;
                        titleValue = value;
                    }

                    if (!label.equals(name)) {
                        MasterViewQuery.setValue(objectBuilder, label, value);
                    }
                }
            }

            if (titleName != null) {
                MasterViewQuery.setValue(objectBuilder, "name", titleValue);
            }

            if (titleName == null && view.keys().size() >= 2) {
                titleName = view.keys().get(1);
                titleValue = view.getValue(titleName);
                MasterViewQuery.setValue(objectBuilder, "name", titleValue);
            }

        });
        return objectBuilder;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Chain<E>, HF extends StarView.Hierarchy.FieldOf<H>> JsonObjectBuilder toChainNodes(Read<Graph> graph, aloha3.module.object.model.read.Chain.StarArrow<F, HF> chain) {
        JsonObjectBuilder root = Json.createObjectBuilder();
        root.add("graphId", graph.coreId());
        root.add("title", "GraphId:" + graph.coreId());
        root.add("id", -1);
        root.add("child", Json.createArrayBuilder().add(toJson(graph, -1, chain.from).add("child", toJsonsOfChainStarArrow(graph, chain.from.coreRead().coreId(), chain.arrowToPosts.asList()))));
        return root;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonObjectBuilder toChainNodes(Read<Graph> graph, aloha3.module.object.model.read.Chain.Straight.Star<F> chain) {
        NonEmptyVOs<StarView.Read<F>> nodes = chain.allFromThisNode();
        JsonObjectBuilder root = Json.createObjectBuilder();
        root.add("graphId", graph.coreId());
        root.add("title", "GraphId:" + graph.coreId());
        root.add("id", -1);
        root.add("child", Json.createArrayBuilder().add(toJson(graph, -1, (StarView.Read)nodes.first()).add("child", toChainNodes(graph, ((StarView.Read)nodes.first()).coreRead().coreId(), nodes.asList(), 1))));
        return root;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonArrayBuilder toChainNodes(Read<Graph> graph, int parentId, List<StarView.Read<F>> nodes, int fromIndex) {
        JsonArrayBuilder child = Json.createArrayBuilder();
        if (fromIndex >= nodes.size()) {
            return child;
        } else {
            StarView.Read<F> node = nodes.get(fromIndex);
            JsonObjectBuilder json = toJson(graph, parentId, node);
            json.add("child", toChainNodes(graph, node.coreRead().coreId(), nodes, fromIndex + 1));
            child.add(json);
            return child;
        }
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonObjectBuilder toChainNodes(Read<Graph> graph, aloha3.module.object.model.read.Chain.Star<F> chain) {
        JsonObjectBuilder root = Json.createObjectBuilder();
        root.add("graphId", graph.coreId());
        root.add("title", "GraphId:" + graph.coreId());
        root.add("id", -1);
        root.add("child", Json.createArrayBuilder().add(toJson(graph, -1, (StarView.Read)chain.node()).add("child", toJsons(graph, ((StarView.Read)chain.node()).coreRead().coreId(), chain.posts().asList()))));
        return root;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> List<StarView.Read<F>> flatChainNodes(aloha3.module.object.model.read.Chain.Star<F> chain) {
        List<StarView.Read<F>> nodes = new ArrayList();
        nodes.add(chain.node());
        Iterator var2 = chain.posts().asList().iterator();

        while(var2.hasNext()) {
            aloha3.module.object.model.read.Chain.Star<F> node = (aloha3.module.object.model.read.Chain.Star)var2.next();
            nodes.addAll(flatChainNodes(node));
        }

        return nodes;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonArrayBuilder toChainNodes(Read<Graph> graph, List<StarView.Read<F>> chain) {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        JsonObjectBuilder rootBuilder = Json.createObjectBuilder();
        rootBuilder.add("graphId", graph.coreId());
        rootBuilder.add("title", "GraphId:" + graph.coreId());
        rootBuilder.add("id", -1);
        arrayBuilder.add(rootBuilder);
        JoinedView prev = null;
        Iterator var5 = chain.iterator();

        while(var5.hasNext()) {
            StarView.Read<F> node = (StarView.Read)var5.next();
            JoinedView flatViews = JsonUtils.toJson(node);
            JsonObjectBuilder jsonObjectBuilder = toChainNode(flatViews);
            jsonObjectBuilder.add("graphId", graph.coreId());
            jsonObjectBuilder.add("attributes", Json.createArrayBuilder());
            jsonObjectBuilder.add("child", Json.createArrayBuilder());
            if (prev != null) {
                jsonObjectBuilder.add("parent", prev.getInt(node.asView().field().unsafeCenterMember().javaName()));
            } else {
                jsonObjectBuilder.add("parent", -1);
            }

            prev = flatViews;
            arrayBuilder.add(jsonObjectBuilder);
        }

        return arrayBuilder;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonObjectBuilder toJson(Read<Graph> graph, int parentId, StarView.Read<F> node) {
        JoinedView flatViews = JsonUtils.toJson(node);
        JsonObjectBuilder jsonObjectBuilder = toChainNode(flatViews);
        jsonObjectBuilder.add("graphId", graph.coreId());
        jsonObjectBuilder.add("attributes", Json.createArrayBuilder());
        jsonObjectBuilder.add("child", Json.createArrayBuilder());
        if (parentId != -1) {
            jsonObjectBuilder.add("parent", parentId);
        }

        return jsonObjectBuilder;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Tree<E>> JsonArrayBuilder toJsons(Read<Graph> graph, int parentId, List<aloha3.module.object.model.read.Chain.Star<F>> nodes) {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        Iterator var4 = nodes.iterator();

        while(var4.hasNext()) {
            aloha3.module.object.model.read.Chain.Star<F> node = (aloha3.module.object.model.read.Chain.Star)var4.next();
            JsonObjectBuilder json = toJson(graph, parentId, (StarView.Read)node.node());
            json.add("child", toJsons(graph, ((StarView.Read)node.node()).coreRead().coreId(), node.posts().asList()));
            arrayBuilder.add(json);
        }

        return arrayBuilder;
    }

    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>, H extends Chain<E>, HF extends StarView.Hierarchy.FieldOf<H>> JsonArrayBuilder toJsonsOfChainStarArrow(Read<Graph> graph, int parentId, List<ImmutPair<StarView.Hierarchy.Read<HF>, aloha3.module.object.model.read.Chain.StarArrow<F, HF>>> nodes) {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        Iterator var4 = nodes.iterator();

        while(var4.hasNext()) {
            ImmutPair<StarView.Hierarchy.Read<HF>, aloha3.module.object.model.read.Chain.StarArrow<F, HF>> node = (ImmutPair)var4.next();
            JsonObjectBuilder json = toJson(graph, parentId, node.getRight().from);
            json.add("child", toJsonsOfChainStarArrow(graph, node.getRight().from.coreRead().coreId(), node.getRight().arrowToPosts.asList()));
            json.add("attributes", toTreeNodeAttributes(JsonUtils.toJson(node.getLeft()), ((StarView.Hierarchy.FieldOf)((StarView.Hierarchy.Read)node.getLeft()).field()).attributeMembers(), 0L));
            arrayBuilder.add(json);
        }

        return arrayBuilder;
    }

    private static JsonObjectBuilder toChainNode(JoinedView nodeJson) {
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        String[] nodeTitle = new String[]{""};
        nodeJson.forEach((view) -> {
            String title = null;
            String id = null;
            Iterator var5 = view.keys().iterator();

            while(var5.hasNext()) {
                String name = (String)var5.next();
                Object value = view.getValue(name);
                if (value != null) {
                    MasterViewQuery.setValue(objectBuilder, name, value);
                    String label = name;
                    if (name.equals(ViewMgr.getPrimaryKey(view.getName()))) {
                        label = "id";
                        id = String.valueOf(value);
                    }

                    if (name.endsWith("Name")) {
                        label = "title";
                        title = String.valueOf(value);
                        nodeTitle[0] = title;
                    }

                    MasterViewQuery.setValue(objectBuilder, label, value);
                }
            }

            if (title == null) {
                MasterViewQuery.setValue(objectBuilder, "title", "No." + id);
            }

        });
        return objectBuilder;
    }
}
