package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecordFactory;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.master.CoreMgr.StarView.OneToMany;
import aloha3.module.object.model.MayNull;
import aloha3.module.object.model.read.AbstractChain;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.model.write.Chain.Straight.Star;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK.Of;
import aloha3.module.object.record.master.HierarchyEntity.Of.Chain.Straight;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.StarView.Read;
import aloha3.module.object.view.StarView.Write.Prepare;
import aloha3.module.object.view.StarView.Write.Prepare.Builder;
import aloha3.module.object.view.StarView.Write.Update;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonValue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

public class StraightChainWrapper<
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends Straight<E>,
    HM extends aloha3.module.function.business.conceptual.master.Graph.Chain.Straight<E, H, F>, T extends Read<F>>
    extends BaseMgrWrapper<T, Integer, Integer>
    implements GraphChainWrapper {

    private final String name;
    private final F field;
    private final HM mgr;
    private final Map<String, Class> afks;
    private final Class<H> treeType;
    private final Map<String, OneToMany> oneToManyMgrs = new HashMap();
    private CoreMgrStarViewWrapper<E, F, T> coreMgr;

    public StraightChainWrapper(String name, F field, HM mgr, List<Class> types) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
        this.treeType = (Class<H>) mgr.hierarchyEntity().getClass();
        this.afks = new HashMap();
        Class nodeLinkType = this.treeType;
        Class[] var6 = nodeLinkType.getDeclaredClasses();
        int var7 = var6.length;

        for(int var8 = 0; var8 < var7; ++var8) {
            Class c = var6[var8];
            String fieldName = c.getSimpleName();
            if (Of.class == c.getSuperclass()) {
                Class afk = AlohaRecordFactory.getTypeArguments(c).get(1);
                this.afks.put(fieldName + "Id", afk);
            }
        }

    }

    public CoreMgrStarViewWrapper<E, F, T> getCoreMgr() {
        return this.coreMgr;
    }

    public void setCoreMgr(CoreMgrStarViewWrapper<E, F, T> coreMgr) {
        this.coreMgr = coreMgr;
    }

    public Map<String, OneToMany> getOneToManyMgrs() {
        return this.oneToManyMgrs;
    }

    public boolean isOneToMany() {
        return !this.oneToManyMgrs.isEmpty();
    }

    public Class<H> getHierarchyEntity() {
        return this.treeType;
    }

    public String getName() {
        return this.name;
    }

    public boolean isMaster() {
        return true;
    }

    public Mandatory getCenterMember() {
        return ((StarView.Field)this.mgr.coreReadMgt().field()).unsafeCenterMember();
    }

    public Class<H> getTreeType() {
        return this.treeType;
    }

    public int registerRoot(JsonArray json) {
        int resultGraphId = -1;
        Iterator var3 = json.iterator();

        while(var3.hasNext()) {
            JsonValue node = (JsonValue)var3.next();
            int graphId = node.asJsonObject().getInt("graphId");
            if (graphId <= 0) {
                JsonArray nodes = node.asJsonObject().getJsonArray("nodes");
                if (nodes.size() >= 1) {
                    int rootId = nodes.get(0).asJsonObject().getInt("id");
                    Read<F> root = this.mgr.coreReadMgt().createView(rootId, YMDHMS.current()).apply((v) -> {
                        return v;
                    }, () -> {
                        return null;
                    });
                    if (root != null) {
                        Star<H, F> tree = (Star<H, F>)Star.create(
                                (Read)root,
                                (Class)this.mgr.hierarchyEntity().getClass(),
                                (chainBuilder) -> {
                            this.buildChain((Star) chainBuilder, nodes.get(0).asJsonObject().getJsonArray("nodes"));
                        });
                        resultGraphId = this.mgr.save(tree).get().coreId();
                    }
                }
            }
        }

        return resultGraphId;
    }

    public int updateRoot(JsonObject json) {
        Integer graphId = JsonUtils.getIntValue(json, "graphId");
        if (graphId != 0 && graphId > 0) {
            JsonArray nodes = json.getJsonArray("nodes");
            if (nodes.size() < 1) {
                return -1;
            } else {
                int rootId = nodes.get(0).asJsonObject().getInt("id");
                Read<F> root = this.mgr.coreReadMgt().createView(rootId, YMDHMS.current()).apply((v) -> {
                    return v;
                }, () -> {
                    return null;
                });
                if (root == null) {
                    return -1;
                } else {
                    Star<H, F> chain = Star.create(
                        root,
                        (Class<H>)this.mgr.hierarchyEntity().getClass(),
                        new Consumer<Star<H,F>>() {
                            public void accept(Star<H,F> model){
                                buildChain(model, nodes.get(0).asJsonObject().getJsonArray("nodes"));
                            }
                        });
                    this.mgr.selectGraph(graphId, YMDHMS.current()).unlessNull_((graph) -> {
                        this.mgr.update(graph, chain);
                    });
                    return graphId;
                }
            }
        } else {
            return -1;
        }
    }

    public int removeRoot(Integer graphId) {
        this.mgr.selectGraph(graphId, YMDHMS.current()).unlessNull_((graph) -> {
            this.mgr.deleteGraph(graph, YMDHMS.current());
        });
        return graphId;
    }

    private void buildChain(Star<H, F> tree, JsonArray nodes) {
        Iterator var3 = nodes.iterator();

        while(var3.hasNext()) {
            JsonValue node = (JsonValue)var3.next();
            this.buildChainNext(tree, node.asJsonObject());
        }

    }

    private void buildChainNext(Star<H, F> tree, JsonObject json) {
        int leafId = json.getInt("id");
        Read<F> leaf = this.mgr.coreReadMgt().createView(leafId, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        if (leaf != null) {
            JsonObject attrs = json.getJsonObject("attributes");
            Star<H, F> subtree = tree.next(leaf);
            this.buildChain(subtree, json.getJsonArray("nodes"));
        }
    }

    public Class getAfk(String name) {
        return this.afks.get(name);
    }

    public void addNode(JsonObject json) {
        int fromId = json.getInt("FromId");
        int toId = json.getInt("ToId");
        int graphId = json.getInt("GraphId");
        Read<F> parent = this.mgr.coreReadMgt().createView(fromId, YMDHMS.current()).mustNonNull();
        Read<F> newLeaf = this.mgr.coreReadMgt().createView(toId, YMDHMS.current()).mustNonNull();
        aloha3.module.object.record.meta.master.Core.Read<Graph> graphRead = this.mgr.selectGraph(graphId, YMDHMS.current()).mustNonNull();
        JsonObject attrs = json.getJsonObject("Attributes");
    }

    public void modifyNode() {
    }

    public void removeNode(JsonObject json) {
        int id = json.getInt("Id");
        int graphId = json.getInt("GraphId");
        Read<F> leafToBeDeleted = this.mgr.coreReadMgt().createView(id, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        aloha3.module.object.record.meta.master.Core.Read<Graph> graphRead = this.mgr.selectGraph(graphId, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        if (leafToBeDeleted == null || graphRead == null) {
        }
    }

    public List<Long> getHistoryRegTimes() {
        return GraphMgr.selectGraphHistories(this.mgr);
    }

    public JsonArray queryChain(YMDHMS asOf) {
        JsonArrayBuilder trees = Json.createArrayBuilder();
        GraphMgr.selectAllGraph(this.mgr, asOf).foreach((graph) -> {
            try {
                this.mgr.createModel(graph, asOf).unlessNull_((tree) -> {
                    trees.add(UGraph.toChainNodes(graph, tree));
                });
            } catch (Exception var5) {
                var5.printStackTrace();
            }

        });
        return trees.build();
    }

    public ImmutVOs<aloha3.module.object.record.meta.master.Core.Read<Graph>> queryAllGraphs() {
        return GraphMgr.selectAllGraph(this.mgr);
    }

    public List<List<Read>> selectAllChains(YMDHMS at) {
        List<List<Read>> chains = new ArrayList();
        GraphMgr.selectAllGraph(this.mgr, at).foreach((graph) -> {
            try {
                this.mgr.createModel(graph, YMDHMS.current()).unlessNull_((tree) -> {
                    List<Read> nodes = new ArrayList();
                    nodes.add(tree.node());
                    nodes.addAll(tree.posts().mapTo(AbstractChain::node).asList());
                    chains.add(nodes);
                });
            } catch (Exception var4) {
                var4.printStackTrace();
            }

        });
        return chains;
    }

    @Override
    public Object getMgr() {
        return this.coreMgr.getMgr();
    }

    public Object register(JsonObject json) {
        if (this.coreMgr != null) {
            return this.coreMgr.register(json);
        } else {
            Value<Integer> id = this.mgr.save(this.generateView(json), YMDHMS.current());
            return id.get();
        }
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return this.mgr.coreReadMgt().selectAllCores(YMDHMS.current());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return this.coreMgr != null ? this.coreMgr.query() : (ImmutVOs)this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).unlessEmpty((cores) -> {
            return this.mgr.coreReadMgt().createViews(cores, YMDHMS.current());
        }, ImmutVOs.emptyVOs());
    }

    public MayNullVO<T> queryByPK(Integer id) {
        return (MayNullVO<T>) this.mgr.coreReadMgt().createView(id, YMDHMS.current());
    }

    public ImmutVOs<T> queryByPKs(List<Integer> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : (ImmutVOs<T>) this.mgr.coreReadMgt().createViews(DistinctIds.toIntIDs(pkIDs), YMDHMS.current());
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs afkViews, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<Read> afkViews, String afkName) {
        return (ImmutVOs)afkViews.apply((afks) -> {
            AlohaColumn referenceColumn = ViewMgr.getJoinColumn(this.name, afkName);
            ImmutVOs mayEmptyCores;
            if (Of.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOfFixedAttribute(
                        (NonEmptyVOs)afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            } else {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOf(
                        (NonEmptyVOs)afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            }

            return (ImmutVOs)mayEmptyCores.unlessEmpty((cores) -> {
                return this.mgr.coreReadMgt().createViews(DistinctIds.intIDsFromRecords(
                        (NonEmptyVOs)cores,
                        r->((aloha3.module.object.record.meta.master.Core.Read)r).coreId()), YMDHMS.current());
            }, ImmutVOs.emptyVOs());
        }, ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public void update(JsonObject json) {
        if (this.coreMgr != null) {
            this.coreMgr.update(json);
        } else {
            String primaryKeyName = this.getCenterMember().javaName();
            Integer targetId = JsonUtils.getIntValue(json, primaryKeyName);
            if (targetId == null) {
                return;
            }

            JsonUtils.removeKey(json, primaryKeyName);
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((exists) -> {
                this.mgr.save(this.generateView(exists, json));
            });
        }

    }

    public void delete(JsonObject json) {
        Integer targetId = JsonUtils.getIntValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((view) -> {
                this.mgr.delete(view, YMDHMS.current());
            });
        }
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(this.field);
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    private Prepare<E, F> generateView(JsonObject json) {
        Builder<E, F> builder = Builder.create(this.getFieldClass());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    private Update<F> generateView(Read<F> exists, JsonObject json) {
        Update.Builder<E, F> builder = Update.Builder.create(exists, YMDHMS.current());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public List<CDC> fetchHistories() {
        List<CDC> histories = new ArrayList();
        this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).foreach((core) -> {
            MayNull var10000 = this.mgr.coreReadMgt().cdcOfView(core.coreId());
            Objects.requireNonNull(histories);
            var10000.unlessNull_(r->histories.add((CDC) r));
        });
        return histories;
    }
}
