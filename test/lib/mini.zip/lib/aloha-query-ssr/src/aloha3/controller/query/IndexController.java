package aloha3.controller.query;

import aloha.concurrent.pattern.ParallelFor;
import aloha.module.func.Func;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.ArrayList;

import static aloha3.controller.Server.engine;

public class IndexController {

    public static final String COMPONENTS_SHARED_MENU_HTML = "_components/shared-menu.html";
    public static final String COMPONENTS_NAV_MENU_HTML = "_components/nav-menu.html";
    public static final String OPERATION = "operation";
    public static final String ID = "id";

    public static final String INDEX_STREAM = "index_stream.html";
    public static final String INDEX_CONTENT = "index_content.html";

    public enum OperationType {
        list, add, edit, delete_confirm, preview;

        public static 
        OperationType 
        from(String op) {
            try {
                return OperationType.valueOf(op);
            } catch (Exception e) {
                return list;
            }
        }

        public static
        OperationType
        from(Request request) {
            return
                request.
                    unlessNull(
                        OPERATION,
                        OperationType::from,
                        OperationType.list);
        }
    }

    public static void 
    handle(
        Request request,
        Response response) {
        
        Func.accept(
            response.chunked(),
            (body) -> Func.accept(
                Context.Builder.create().
                    add("mainViewContent", "mainViewContent-welcome").
                    add("title", "TOP").
                    add("withoutLeftMenu", true).
                    addStream(
                        new Stream(
                            body,
                            () -> {})).
                    build(),
                body.asWriter(),
                (ctx, writer) ->
                    Func.accept(
                        engine().processThrottled(INDEX_STREAM, ctx),
                        throttled ->
                        {
                            while (!throttled.isFinished()) {
                                throttled.process(128, writer);
                            }
                        },
                        _ -> body.end())));
    }

    public record Stream(
        ChunkedResponseMessageBody body,
        Runnable afterQuery) implements Runnable {
        @Override
        public void run() {
            // Load Menu Items via SPI
            var crudMenuItems = new ArrayList<aloha3.controller.spi.AlohaQuerySsrPlugin.MenuItem>();
            var queryMenuItems = new ArrayList<aloha3.controller.spi.AlohaQuerySsrPlugin.MenuItem>();
            
            java.util.ServiceLoader.load(aloha3.controller.spi.AlohaQuerySsrPlugin.class).forEach(plugin -> {
                plugin.getMenuItems().foreach(item -> {
                    if ("CRUD".equalsIgnoreCase(item.category())) {
                        crudMenuItems.add(item);
                    } else if ("Query".equalsIgnoreCase(item.category())) {
                        queryMenuItems.add(item);
                    }
                });
            });

            ParallelFor.exec(
                () ->
                    body.addSlot(
                        "shared-menu",
                        engine().process(
                            COMPONENTS_SHARED_MENU_HTML,
                            Context.Builder.create()
                                .add("crudMenuItems", crudMenuItems)
                                .add("queryMenuItems", queryMenuItems)
                                .build())),
                // () ->
                //    body.addSpan(
                //        "nav-menu",
                //        engine().process(
                //            COMPONENTS_NAV_MENU_HTML,
                //            Context.Builder.create().
                //                add(AlohaMeta.getPivots()).
                //                build())),
                () ->
                    body.addSlot(
                        "mainViewContent-welcome",
                        "<h1>Welcome to BOS Data Browser</h1>"));
            afterQuery.run();
        }
    } // Stream

}

