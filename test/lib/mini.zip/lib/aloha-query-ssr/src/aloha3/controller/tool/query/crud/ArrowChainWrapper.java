package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple.Pair;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecordFactory;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.conceptual.master.Graph.Chain.StarArrow;
import aloha3.module.function.business.master.CoreMgr.StarView.OneToMany;
import aloha3.module.object.model.MayNull;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.record.master.FixedAttributeEntityAFK.Of;
import aloha3.module.object.record.master.HierarchyEntity.Of.Chain;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.StarView.FieldOf;
import aloha3.module.object.view.StarView.Read;
import aloha3.module.object.view.StarView.Write.Prepare;
import aloha3.module.object.view.StarView.Write.Prepare.Builder;
import aloha3.module.object.view.StarView.Write.Update;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonValue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ArrowChainWrapper
    extends BaseMgrWrapper
    implements GraphChainWrapper {

    private final String name;
    private final StarView.Field<?> field;
    private final Object linkField;
    private final StarArrow mgr;
    private final Map<String, Class> afks;
    private final Class treeType;
    private final Map<String, OneToMany> oneToManyMgrs = new HashMap();
    private CoreMgrStarViewWrapper coreMgr;

    public ArrowChainWrapper(String name, StarView.Field<?> field, StarArrow mgr, List<Class> types) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
        this.linkField = mgr.arrowField();
        this.treeType =  ((Chain)mgr.hierarchyEntity()).getClass();
        this.afks = new HashMap();
        Class nodeLinkType = this.treeType;
        Class[] var6 = nodeLinkType.getDeclaredClasses();
        int var7 = var6.length;

        for(int var8 = 0; var8 < var7; ++var8) {
            Class c = var6[var8];
            String fieldName = c.getSimpleName();
            if (Of.class == c.getSuperclass()) {
                Class afk = AlohaRecordFactory.getTypeArguments(c).get(1);
                this.afks.put(fieldName + "Id", afk);
            }
        }

    }

    public CoreMgrStarViewWrapper getCoreMgr() {
        return this.coreMgr;
    }

    public void setCoreMgr(CoreMgrStarViewWrapper coreMgr) {
        this.coreMgr = coreMgr;
    }

    public Map<String, OneToMany> getOneToManyMgrs() {
        return this.oneToManyMgrs;
    }

    public boolean isOneToMany() {
        return !this.oneToManyMgrs.isEmpty();
    }

    public Class getHierarchyEntity() {
        return this.treeType;
    }

    public String getName() {
        return this.name;
    }

    public boolean isMaster() {
        return true;
    }

    public Mandatory getCenterMember() {
        return ((FieldOf)this.mgr.coreReadMgt().field()).unsafeCenterMember();
    }

    public Class getTreeType() {
        return this.treeType;
    }

    public StarView.Hierarchy.FieldOf getLinkField() {
        return (StarView.Hierarchy.FieldOf)this.linkField;
    }

    public String getLinkName() {
        String name = this.linkField.getClass().getSimpleName();
        if (name.endsWith("Field")) {
            name = name.substring(0, name.length() - "Field".length());
        }

        return name;
    }

    public int registerRoot(JsonArray json) {
        int resultGraphId = -1;
        Iterator var3 = json.iterator();

        while(var3.hasNext()) {
            JsonValue node = (JsonValue)var3.next();
            int graphId = node.asJsonObject().getInt("graphId");
            if (graphId <= 0) {
                JsonArray nodes = node.asJsonObject().getJsonArray("nodes");
                if (nodes.size() >= 1) {
                    JsonObject firstNode = nodes.get(0).asJsonObject();
                    int rootId = firstNode.getInt("id");
                    Read<?> root = (Read)this.mgr.coreReadMgt().createView(rootId, YMDHMS.current()).apply((v) -> {
                        return v;
                    }, () -> {
                        return null;
                    });
                    if (root != null) {
                        aloha3.module.object.model.write.Chain.StarArrow chain =
                            aloha3.module.object.model.write.Chain.StarArrow.
                                create(
                                    (Read)root,
                                    (Class)this.linkField.getClass(),
                                    YMDHMS.current(),
                                    (chainBuilder) -> {
                                        this.buildChain(chainBuilder, firstNode.getJsonArray("nodes"));
                                });
                            resultGraphId = ((Core.Read)
                                    this.mgr.save(chain).get()).coreId();
                    }
                }
            }
        }

        return resultGraphId;
    }

    public int updateRoot(JsonObject json) {
        Integer graphId = JsonUtils.getIntValue(json, "graphId");
        if (graphId != 0 && graphId > 0) {
            JsonArray nodes = json.getJsonArray("nodes");
            if (nodes.size() < 1) {
                return -1;
            } else {
                int rootId = nodes.get(0).asJsonObject().getInt("id");
                Read<?> root = (Read)this.mgr.coreReadMgt().createView(rootId, YMDHMS.current()).apply((v) -> {
                    return v;
                }, () -> {
                    return null;
                });
                if (root == null) {
                    return -1;
                } else {
                    aloha3.module.object.model.write.Chain.StarArrow chain =
                        aloha3.module.object.model.write.Chain.StarArrow.create(
                                (Read)root,
                                (Class)this.linkField.getClass(), YMDHMS.current(), (chainBuilder) -> {
                        this.buildChain(chainBuilder, nodes.get(0).asJsonObject().getJsonArray("nodes"));
                    });
                    this.mgr.selectGraph(graphId, YMDHMS.current()).unlessNull_((graph) -> {
                        this.mgr.update((Core.Read)graph, chain);
                    });
                    return graphId;
                }
            }
        } else {
            return -1;
        }
    }

    public int removeRoot(Integer graphId) {
        this.mgr.selectGraph(graphId, YMDHMS.current()).unlessNull_((graph) -> {
            this.mgr.deleteGraph((aloha3.module.object.record.master.read.meta.Read<Graph>)graph, YMDHMS.current());
        });
        return graphId;
    }

    private void buildChain(
        aloha3.module.object.model.write.Chain.StarArrow tree,
        JsonArray nodes) {

        Iterator var3 = nodes.iterator();

        while(var3.hasNext()) {
            JsonValue node = (JsonValue)var3.next();
            this.buildChain(tree, node.asJsonObject());
        }

    }

    private void buildChain(
            aloha3.module.object.model.write.Chain.StarArrow
            tree, JsonObject json) {
        int leafId = json.getInt("id");
        Read<?> leaf = (Read)this.mgr.coreReadMgt().createView(leafId, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        if (leaf != null) {
            JsonObject attrs = json.getJsonObject("attributes");
            aloha3.module.object.model.write.Chain.StarArrow subtree = tree.next(leaf, (builder) -> {
                this.getLinkAttributes().forEach((member) -> {
                    this.setMandatoryValue(attrs, member, (AbstractView.Builder)builder);
                });
            });
            this.buildChain(subtree, json.getJsonArray("nodes"));
        }
    }

    public List<Mandatory> getLinkAttributes() {
        List<Mandatory> members = new ArrayList();
        ((StarView.Hierarchy.FieldOf)this.linkField).attributeMembers().foreach((f) -> {
            if (f instanceof Mandatory) {
                members.add((Mandatory)f);
            }

        });
        return members;
    }

    public Class getAfk(String name) {
        return this.afks.get(name);
    }

    public void addNode(JsonObject json) {
        int fromId = json.getInt("FromId");
        int toId = json.getInt("ToId");
        int graphId = json.getInt("GraphId");
        Read parent = (Read)this.mgr.coreReadMgt().createView(fromId, YMDHMS.current()).mustNonNull();
        Read newLeaf = (Read)this.mgr.coreReadMgt().createView(toId, YMDHMS.current()).mustNonNull();
        Core.Read<Graph> graphRead = (Core.Read)this.mgr.selectGraph(graphId, YMDHMS.current()).mustNonNull();
        JsonObject attrs = json.getJsonObject("Attributes");
    }

    public void modifyNode() {
    }

    public void removeNode(JsonObject json) {
        int id = json.getInt("Id");
        int graphId = json.getInt("GraphId");
        Read leafToBeDeleted = (Read)this.mgr.coreReadMgt().createView(id, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        Core.Read<Graph> graphRead = (Core.Read)this.mgr.selectGraph(graphId, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        if (leafToBeDeleted == null || graphRead == null) {
        }
    }

    public List<Long> getHistoryRegTimes() {
        return GraphMgr.selectGraphHistories(this.mgr);
    }

    public JsonArray queryChain(YMDHMS asOf) {
        List<Pair<Core.Read<Graph>, aloha3.module.object.model.read.Chain.StarArrow>> trees = new ArrayList();
        GraphMgr.selectAllGraph(this.mgr, asOf).foreach((graph) -> {
            try {
                this.mgr.createModel((Core.Read)graph, asOf).unlessNull_((model) -> {
                    trees.add(Pair.of((Core.Read<Graph>)graph, (aloha3.module.object.model.read.Chain.StarArrow)model));
                });
            } catch (Exception var5) {
            }

        });
        Collections.sort(trees, Comparator.comparingInt((graph) -> {
            return graph.getT1().coreId();
        }));
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        trees.forEach((tree) -> {
            arrayBuilder.add(UGraph.toChainNodes(tree.getT1(), tree.getT2()));
        });
        return arrayBuilder.build();
    }

    public ImmutVOs<Core.Read<Graph>> queryAllGraphs() {
        return GraphMgr.selectAllGraph(this.mgr);
    }

    public List<List<Read>> selectAllChains(YMDHMS at) {
        List<List<Read>> chains = new ArrayList();
        GraphMgr.selectAllGraph(this.mgr, at).foreach((graph) -> {
            try {
                this.mgr.createModel((Core.Read)graph, at).unlessNull_((model) -> {
                    List<Read> chain = new ArrayList();
                    chain.add(((aloha3.module.object.model.read.Chain.StarArrow)model).from);
                    Iterator var3 = ((aloha3.module.object.model.read.Chain.StarArrow)model).posts().asList().iterator();

                    while(var3.hasNext()) {
                        aloha3.module.object.model.read.Chain.StarArrow<?, ?> node = (aloha3.module.object.model.read.Chain.StarArrow)var3.next();
                        chain.add(node.from);
                    }

                    chains.add(chain);
                });
            } catch (Exception var5) {
                var5.printStackTrace();
            }

        });
        return chains;
    }

    @Override
    public Object getMgr() {
        return this.coreMgr.getMgr();
    }

    public Object register(JsonObject json) {
        if (this.coreMgr != null) {
            return this.coreMgr.register(json);
        } else {
            Value<Integer> id = this.mgr.save(this.generateView(json), YMDHMS.current());
            return id.get();
        }
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return this.mgr.coreReadMgt().selectAllCores(YMDHMS.current());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs query() {
        return this.coreMgr != null ? this.coreMgr.query() : (ImmutVOs)this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).unlessEmpty((cores) -> {
            return this.mgr.coreReadMgt().createViews((NonEmptyVOs)cores, YMDHMS.current());
        }, ImmutVOs.emptyVOs());
    }

    public MayNullVO queryByPK(Object id) {
        return this.mgr.coreReadMgt().createView((Integer)id, YMDHMS.current());
    }

    public ImmutVOs queryByPKs(List pkIDs) {
        return this.mgr.coreReadMgt().createViews(DistinctIds.toIntIDs(pkIDs), YMDHMS.current());
    }

    public ImmutVOs queryByFKs(ImmutVOs afkViews, Map params) {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs queryByIntAFKs(ImmutVOs afkViews, String afkName, Map params) {
        return this.queryByIntAFKViews(afkViews, afkName);
    }

    private ImmutVOs queryByIntAFKViews(ImmutVOs<Read> afkViews, String afkName) {
        return afkViews.apply((afks) -> {
            AlohaColumn referenceColumn = ViewMgr.getJoinColumn(this.name, afkName);
            ImmutVOs mayEmptyCores;
            if (Of.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOfFixedAttribute(afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            } else {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOf(afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            }

            return (ImmutVOs)mayEmptyCores.unlessEmpty((cores) -> {
                return this.mgr.coreReadMgt().createViews(
                        DistinctIds.intIDsFromRecords(
                                (NonEmptyVOs)cores,
                                r->((Core.Read)r).coreId()),
                        YMDHMS.current());
            }, ImmutVOs.emptyVOs());
        }, ImmutVOs::emptyVOs);
    }

    public ImmutVOs queryByLongAFKs(ImmutVOs afkViews, String afkName, Map params) {
        return ImmutVOs.emptyVOs();
    }

    public void update(JsonObject json) {
        if (this.coreMgr != null) {
            this.coreMgr.update(json);
        } else {
            String primaryKeyName = this.getCenterMember().javaName();
            Integer targetId = JsonUtils.getIntValue(json, primaryKeyName);
            if (targetId == null) {
                return;
            }

            JsonUtils.removeKey(json, primaryKeyName);
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((exists) -> {
                this.mgr.save(this.generateView((Read)exists, json));
            });
        }

    }

    public void delete(JsonObject json) {
        Integer targetId = JsonUtils.getIntValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((view) -> {
                this.mgr.delete((Read)view, YMDHMS.current());
            });
        }
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(this.field);
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    private Prepare generateView(JsonObject json) {
        Builder builder = Builder.create((Class)this.getFieldClass());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public Class<?> getFieldClass() {
        return this.field.getClass();
    }

    private Update generateView(Read exists, JsonObject json) {
        Update.Builder builder =
                Update.Builder.create(
                        (Read)exists, YMDHMS.current());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public List<CDC> fetchHistories() {
        List<CDC> histories = new ArrayList();
        this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).foreach((core) -> {
            MayNull var10000 = this.mgr.coreReadMgt().cdcOfView(((Core.Read)core).coreId());
            Objects.requireNonNull(histories);
            var10000.unlessNull_(r->histories.add((CDC) r));
        });
        return histories;
    }
}
