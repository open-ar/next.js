package aloha3.controller.tool.query;

import aloha.mapping.IEntity;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Type;
import aloha3.controller.tool.query.crud.ArrowTreeMgr;
import aloha3.controller.tool.query.crud.BusinessMgrContainer;
import aloha3.controller.tool.query.crud.ChainMgr;
import aloha3.controller.tool.query.crud.DistinctTreeMgr;
import aloha3.controller.tool.query.crud.TreeMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.FieldMember;
import aloha3.controller.tool.query.models.FieldMemberValue;
import aloha3.controller.tool.query.models.JoinedView;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.model.read.ViewManyRecords;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.master.spec.CoreEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public class MasterViewQuery {
    private static final boolean DEBUG = true;

    static
    List<JoinedView>
    queryAllViews(
        String viewName) {

        if (ViewMgr.isTreeEntity(viewName))
            return queryTreeViews(viewName);
        if (ViewMgr.isArrowTreeEntity(viewName))
            return queryArrowTreeViews(viewName);
        if (ViewMgr.isDistinctTreeEntity(viewName))
            return queryDistinctTreeViews(viewName);
        if (ViewMgr.isChainEntity(viewName))
            return queryChainViews(viewName);

        return JsonUtils.
            toJsonsFromStarViews(
                BusinessMgrContainer.
                    getMasterDataMgt(
                        viewName).
                    query());
    }

    @SuppressWarnings("unchecked")
    public static
    List<JoinedView>
    queryAllViews(
        GeneralViewsQuery.ViewConnections centerView) {

        /*
        if (ViewMgr.isTreeEntity(centerView.name))
            return queryTreeViews(centerView.name);
        if (ViewMgr.isChainEntity(centerView.name))
            return queryChainViews(centerView.name);
        if (ViewMgr.isArrowTreeEntity(centerView.name))
            return queryArrowTreeViews(centerView.name);
        if (ViewMgr.isDistinctTreeEntity(centerView.name))
            return queryDistinctTreeViews(centerView.name);
        */

        return ViewJoin.
            joinView(
                centerView,
                Collections.EMPTY_MAP);
    }

    @SuppressWarnings("unchecked")
    static
    JsonArray
    queryTrees(
        GeneralViewsQuery.ViewConnections view,
        DateTime.YMDHMS asOf) {

        String viewName = view.name;
        if (ViewMgr.isArrowTreeEntity(viewName))
            return queryArrowTreesAsOrg(
                view,
                asOf);
        else if (ViewMgr.isDistinctTreeEntity(viewName))
            return queryDistinctTreesAsOrg(
                view,
                asOf);
        return queryTrees(
            viewName,
            ViewMgr.getGraphTreeMgt(viewName),
            asOf);
    }

    @SuppressWarnings("unchecked")
    static
    JsonArray
    queryArrowTreesAsWorkflow(
        GeneralViewsQuery.ViewConnections view,
        DateTime.YMDHMS asOf) {

        String viewName = view.name;
        if (ViewMgr.isTreeEntity(viewName) == false)
            return null;

        return queryArrowTreesAsWorkflow(
            viewName,
            ViewMgr.getGraphTreeStarArrowMgt(viewName),
            asOf);
    }

    @SuppressWarnings("unchecked")
    static
    JsonArray
    queryArrowTreesAsOrg(
        GeneralViewsQuery.ViewConnections view,
        DateTime.YMDHMS asOf) {

        String viewName = view.name;
        if (ViewMgr.isArrowTreeEntity(viewName) == false)
            return null;

        return queryTreesAsOrg(
            viewName,
            ViewMgr.getGraphTreeStarArrowMgt(viewName),
            asOf);
    }

    @SuppressWarnings("unchecked")
    static
    JsonArray
    queryDistinctTreesAsOrg(
        GeneralViewsQuery.ViewConnections view,
        DateTime.YMDHMS asOf) {

        String viewName = view.name;
        if (ViewMgr.isDistinctTreeEntity(viewName) == false)
            return null;

        return queryTreesAsOrg(
            viewName,
            ViewMgr.getGraphTreeDistinctMgt(viewName),
            asOf);
    }

    @SuppressWarnings("unchecked")
    static
    JsonArray
    queryChains(
        GeneralViewsQuery.ViewConnections view) {

        String viewName = view.name;
        if (ViewMgr.isChainEntity(viewName) == false)
            return null;

        return queryChains(
            viewName,
            ViewMgr.getGraphChainMgt(viewName),
            DateTime.YMDHMS.current());
    }

    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>>
    JsonArray
    queryTrees(
        String viewName,
        Graph.Tree<E,H,F> masterDataMgt,
        DateTime.YMDHMS asOf) {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        TreeMgr<E,F,H> tree = new TreeMgr(masterDataMgt);
        for(Tree.Star<F> root : tree.selectAllRoots()) {
            arrayBuilder.add(
                toTreeNode(
                    root));
        }
        return arrayBuilder.build();
    }

    private static <
    E extends aloha3.module.object.record.master.CoreEntity,
    F extends StarView.FieldOf<E>,
    H extends HierarchyEntity.Of.Tree<E>,
    HF extends StarView.Hierarchy.FieldOf<H>>
    JsonArray
    queryTreesAsOrg(
        String viewName,
        Graph.Tree.Distinct.StarArrow<E,H,F,HF> masterDataMgt,
        DateTime.YMDHMS asOf) {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ArrowTreeMgr<E,F,H,HF> tree = new ArrowTreeMgr(masterDataMgt);
        for(Tree.StarArrow<F, HF> root : tree.selectAllRoots(asOf)) {
            arrayBuilder.add(
                toTreeNode(
                    root));
        }

        return arrayBuilder.build();
    }

    private static
    <E extends aloha3.module.object.record.master.CoreEntity,
        F extends StarView.FieldOf<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    JsonArray
    queryTreesAsOrg(
        String viewName,
        Graph.Tree.Distinct<E,H,F> masterDataMgt,
        DateTime.YMDHMS asOf) {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        DistinctTreeMgr<E,F,H> tree = new DistinctTreeMgr(masterDataMgt);
        for(Tree.Star<F> root : tree.selectAllRoots(asOf)) {
            arrayBuilder.add(
                toTreeNode(
                    root));
        }

        return arrayBuilder.build();
    }

    private static
    <E extends aloha3.module.object.record.master.CoreEntity,
        F extends StarView.FieldOf<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    JsonArray
    queryArrowTreesAsWorkflow(
        String viewName,
        Graph.Tree.Distinct.StarArrow<E,H,F,HF> masterDataMgt,
        DateTime.YMDHMS asOf) {

        ArrowTreeMgr<E,F,H,HF> tree = new ArrowTreeMgr(masterDataMgt);
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for(Tree.StarArrow<F, HF> root : tree.selectAllRoots()) {
            arrayBuilder.add(
                toTreeNode(
                    root));
        }

        return arrayBuilder.build();
    }

    private static
    <E extends aloha3.module.object.record.master.CoreEntity,
        F extends StarView.FieldOf<E>,
        H extends HierarchyEntity.Of.Chain.Straight<E>>
    JsonArray
    queryChains(
        String viewName,
        Graph.Chain.Straight<E,H,F> masterDataMgt,
        DateTime.YMDHMS asOf) {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ChainMgr<E,F,H> chain = new ChainMgr(masterDataMgt);
        for(NonEmptyVOs<StarView.Read<F>> head : chain.selectAllChains(asOf)) {
            arrayBuilder.add(
                toChainNodes(
                    head));
        }

        return arrayBuilder.build();
    }

    private static
    <E extends aloha3.module.object.record.master.CoreEntity,
        F extends StarView.FieldOf<E>,
        H extends HierarchyEntity.Of.Tree<E>>
    JsonArrayBuilder
    toChainNodes(
        NonEmptyVOs<StarView.Read<F>> chain) {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        JoinedView prev = null;
        for(StarView.Read<F> node : chain.get()) {
            JoinedView flatViews = JsonUtils.toJson(node);
            JsonObjectBuilder jsonObjectBuilder = toChainNode(flatViews);

            if (prev != null)
                jsonObjectBuilder.
                    add(
                        "parent",
                        prev.getInt(
                            node.asView().field().unsafeCenterMember().javaName()));
            prev = flatViews;

            arrayBuilder.add(
                jsonObjectBuilder);
        }
        return arrayBuilder;
    }

    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>>
    JsonObjectBuilder
    toTreeNode(
        Tree.Star<F> node) {

        JsonObjectBuilder objectBuilder = toTreeNode(
            JsonUtils.
                toJson(
                    node.node()),
            node.node().coreRead().getRegTimeAsLong());

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ImmutVOs<StarView.Read<F>> leaves = node.leaves();
        if (leaves.size() > 0) {
            for(StarView.Read<F> leaf : leaves.get()) {
                arrayBuilder.add(
                    toTreeNode(
                        JsonUtils.
                            toJson(
                                leaf),
                        leaf.coreRead().getRegTimeAsLong()));
            }
        }

        ImmutableArray<Tree.Star<F>> branches = node.branches();
        if (branches.size() > 0) {
            for(Tree.Star<F> branch : branches.get()) {
                arrayBuilder.add(
                    toTreeNode(
                        branch));
            }
        }
        JsonArray array = arrayBuilder.build();
        if (array.isEmpty() == false)
            objectBuilder.add("children", array);

        return objectBuilder;
    }

    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    JsonObjectBuilder
    toTreeNode(
        Tree.StarArrow<F,HF> node) {

        JsonObjectBuilder objectBuilder = toTreeNode(
            JsonUtils.
                toJson(
                    node.from()),
            node.from().coreRead().getRegTimeAsLong());

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        ImmutableArray<StarView.Read<F>> leaves = node.leaves();
        if (leaves.size() > 0) {
            for(StarView.Read<F> leaf : leaves.get()) {
                arrayBuilder.add(
                    toTreeNode(
                        JsonUtils.
                            toJson(
                                leaf),
                        leaf.coreRead().getRegTimeAsLong()));
            }
        }

        ImmutableArray<Tree.StarArrow<F, HF>> branches = node.branches();
        if (branches.size() > 0) {
            for(Tree.StarArrow<F, HF> branch : branches.get()) {
                arrayBuilder.add(
                    toTreeNode(
                        branch));
            }
        }
        JsonArray array = arrayBuilder.build();
        if (array.isEmpty() == false)
            objectBuilder.add("children", array);

        return objectBuilder;
    }

    private static
    JsonObjectBuilder
    toTreeNode(
        JoinedView nodeJson,
        long regTime) {

        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        nodeJson.forEach(
            (view)-> {
                for (String name : view.keys()) {
                    Object value = view.getValue(name);
                    if (value == null)
                        continue;
                    setValue(
                        objectBuilder,
                        name,
                        value);

                    String label = name;
                    if (name.equals(ViewMgr.getPrimaryKey(view.getName())))
                        label = "id";
                    if (name.endsWith("Name"))
                        label = "name";
                    setValue(
                        objectBuilder,
                        label,
                        value);
                }
            }
        );

        return objectBuilder;
    }

    private static
    JsonObjectBuilder
    toChainNode(
        JoinedView nodeJson) {

        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        nodeJson.forEach(
            (view)-> {
                String title = null;
                String id = null;
                for (String name : view.keys()) {
                    Object value = view.getValue(name);
                    if (value == null)
                        continue;
                    setValue(
                        objectBuilder,
                        name,
                        value);

                    String label = name;
                    if (name.equals(ViewMgr.getPrimaryKey(view.getName()))) {
                        label = "id";
                        id = String.valueOf(value);
                    }
                    if (name.endsWith("Name")) {
                        label = "title";
                        title = String.valueOf(value);
                    }
                    setValue(
                        objectBuilder,
                        label,
                        value);
                }
                if (title == null) {
                    setValue(
                        objectBuilder,
                        "title",
                        "No."+id);
                }
            }
        );

        return objectBuilder;
    }

    public static JsonObjectBuilder setValue(JsonObjectBuilder objectBuilder, String name, Object value) {
        if (value == null) {
            return objectBuilder;
        } else {
            if (Integer.class.isInstance(value)) {
                objectBuilder.add(name, Integer.valueOf(String.valueOf(value)));
            } else if (Long.class.isInstance(value)) {
                objectBuilder.add(name, Long.valueOf(String.valueOf(value)));
            } else if (Double.class.isInstance(value)) {
                objectBuilder.add(name, Double.valueOf(String.valueOf(value)));
            } else {
                objectBuilder.add(name, String.valueOf(value));
            }

            return objectBuilder;
        }
    }

    @SuppressWarnings("unchecked")
    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>>
    List<JoinedView>
    queryTreeViews(
        String viewName)  {

        List<JoinedView> result = new ArrayList<>();
        Graph.Tree<E,H,F> masterDataMgt = ViewMgr.getGraphTreeMgt(viewName);
        TreeMgr tree = new TreeMgr(masterDataMgt);
        List<Tree.Star<F>> roots = tree.selectAllRoots();
        for(Tree.Star<F> root : roots) {
            result.addAll(
                JsonUtils.toJsons(
                    root,
                    1));
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    List<JoinedView>
    queryArrowTreeViews(
        String viewName)  {

        Graph.Tree.Distinct.StarArrow<E,H,F,HF> masterDataMgt = ViewMgr.getGraphTreeStarArrowMgt(viewName);
        ArrowTreeMgr tree = new ArrowTreeMgr(masterDataMgt);
        List<Tree.StarArrow<F,HF>> roots = tree.selectAllRoots();
        List<JoinedView> result = new ArrayList<>();
        for(Tree.StarArrow<F,HF> root : roots) {
            result.addAll(
                JsonUtils.toJsons(
                    root,
                    1));

            JsonObjectBuilder json = JsonUtils.toJsonTree(root, "Tree-" + result.size());
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    List<JoinedView>
    queryDistinctTreeViews(
        String viewName)  {

        Graph.Tree.Distinct<E,H,F> masterDataMgt = ViewMgr.getGraphTreeDistinctMgt(viewName);
        DistinctTreeMgr tree = new DistinctTreeMgr(masterDataMgt);
        List<Tree.Star<F>> roots = tree.selectAllRoots();
        List<JoinedView> result = new ArrayList<>();
        for(Tree.Star<F> root : roots) {
            result.addAll(
                JsonUtils.toJsons(
                    root,
                    1));

            JsonObjectBuilder json = JsonUtils.toJsonTree(root, "Tree-" + result.size());
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    private static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Chain.Straight<E>>
    List<JoinedView>
    queryChainViews(
        String viewName)  {

        List<JoinedView> result = new ArrayList<>();
        Graph.Chain.Straight<E,H,F> masterDataMgt = ViewMgr.getGraphChainMgt(viewName);
        ChainMgr chain = new ChainMgr(masterDataMgt);
        List<NonEmptyVOs<StarView.Read<F>>> heads = chain.selectAllChains();
        int chainNo = 1;
        for(NonEmptyVOs<StarView.Read<F>> head : heads) {
            result.addAll(
                JsonUtils.toJsonsFromChain(
                    head,
                    chainNo++));
        }

        return result;
    }


    @SuppressWarnings("unchecked")
    private static
    <E extends CoreEntity & IEntity>
    List<JoinedView>
    appendOneToManyAttributess(
        String viewName,
        ImmutVOs<StarView.Read>  views)  {

        List<JoinedView> cores = new ArrayList<>();
        if (views.size() == 0)
            return cores;
        else if (!StarView.Read.class.isInstance(views.eltAt(0)))
            return JsonUtils.toJsons(views);
        else if (!ViewMgr.hasOneTpManyAttributes(viewName))
            return JsonUtils.toJsons(views);

        for(StarView.Read view : views.get()) {

            JoinedView core = JsonUtils.toJson(view);
            for (Map.Entry<String, CoreMgr.StarView.OneToMany> column : ViewMgr.getRecord(viewName).getOneToManyMgrs().entrySet()) {

                CoreMgr.StarView.OneToMany mgr = column.getValue();
                AlohaColumn columnInfo = ViewMgr.getRecord(viewName).columnOf(column.getKey());

                List<JoinedView> joinedViews = new ArrayList<>();
                FieldMember member;
                if (columnInfo != null) {
                    if (columnInfo.isForeign()) {
                        member = new FieldMember(viewName, column.getKey(), Integer.class);
                        ((ViewManyRecords.AttributeAFK) mgr.
                            createViewManyRecords(
                                view.coreRead(),
                                DateTime.YMDHMS.current())).
                            manyValues().
                            foreach(
                                (value) -> {
                                    JoinedView joinedView = new JoinedView();
                                    joinedView.copyFrom(core);
                                    joinedView.get(0).
                                        add(
                                            FieldMemberValue.create(
                                                member,
                                                (int) value));
                                    joinedViews.add(joinedView);
                                });
                    } else if (columnInfo.getDataType() == Type.RefType.STRING) {
                        member = new FieldMember(viewName, column.getKey(), String.class);
                        ((ViewManyRecords.Attribute) mgr.
                            createViewManyRecords(
                                view.coreRead(),
                                DateTime.YMDHMS.current())).
                            manyValues(
                                (value) ->
                                    ViewManyRecords.Attribute.
                                        valueOf(
                                            (aloha3.module.object.record.master.read.meta.Read) value)).
                            foreach(
                                (value)->{
                                    JoinedView joinedView = new JoinedView();
                                    joinedView.copyFrom(core);
                                    joinedView.get(0).
                                        add(
                                            FieldMemberValue.create(
                                                member,
                                                (String) value));
                                    joinedViews.add(joinedView);
                                });
                    } else if (columnInfo.getDataType() == Type.RefType.INTEGER) {
                        member = new FieldMember(viewName, column.getKey(), Integer.class);
                        ((ViewManyRecords.Attribute) mgr.
                            createViewManyRecords(
                                view.coreRead(),
                                DateTime.YMDHMS.current())).
                            manyValues(
                                (value) ->
                                    ViewManyRecords.Attribute.
                                        valueOf(
                                            (aloha3.module.object.record.master.read.meta.Read) value)).
                            foreach(
                                (value)->{
                                    JoinedView joinedView = new JoinedView();
                                    joinedView.copyFrom(core);
                                    joinedView.get(0).
                                        add(
                                            FieldMemberValue.create(
                                                member,
                                                (Integer) value));
                                    joinedViews.add(joinedView);
                                });
                    }  else {
                        member = null;
                        /*
                         * TODO:
                         */
                        //System.out.println(columnInfo + " " + mgr);
                        continue;
                    }
                }else
                    member = null;

                if (joinedViews.isEmpty()) {
                    JoinedView joinedView = new JoinedView();
                    joinedView.copyFrom(core);
                    if (member != null)
                        joinedView.get(0).
                            add(
                              FieldMemberValue.
                                  createNullValue(
                                    member));
                    joinedViews.add(joinedView);
                }

                cores.addAll(joinedViews);
            }
        }
        return cores;
    }

    private static
    void
    println(
        Object msg) {

        if (DEBUG)
            System.out.println(msg);
    }

    private static
    void
    print(
        Object msg) {

        if (DEBUG)
            System.out.print(msg);
    }

}
