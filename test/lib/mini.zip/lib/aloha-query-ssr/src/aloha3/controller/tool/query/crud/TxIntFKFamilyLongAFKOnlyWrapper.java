package aloha3.controller.tool.query.crud;

import aloha.module.Array;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildLongAFKOnlyModel;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxIntFKMgr.StarView;
import aloha3.module.function.business.transaction.TxIntFKMgr.StarView.Family.ChildLongAFKOnly;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly.Of;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityIntFK.On;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.TxStarView.FieldOf.AndIntFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class TxIntFKFamilyLongAFKOnlyWrapper<
    E extends On<M>,
    M extends SealedPivot<?>,
    F extends AndIntFK<E>,
    CH extends Of<E, CM>,
    CM extends TxKey.Category<?>,
    T extends TxIntFKChildLongAFKOnlyModel<E, M, F, CH, CM, Read<F>>>
    extends BaseMgrWrapper<T, Long, Integer>
    implements TxFamilyWrapper {

    private final String name;
    private final F parentField;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final StarView<E, M, F> parentMgr;
    private final ChildLongAFKOnly<E, M, F, CH> familyMgr;
    private final String childAfkName;
    private final List<IColumn> attributeColumns;

    public TxIntFKFamilyLongAFKOnlyWrapper(String name, F parentField, Class<CH> childRecord, Class<CM> childAfkRecordType, StarView<E, M, F> parentMgr, ChildLongAFKOnly<E, M, F, CH> familyMgr) {
        this.name = name;
        this.parentField = parentField;
        this.childRecord = childRecord;
        this.parentMgr = parentMgr;
        this.familyMgr = familyMgr;
        this.childAfkRecordType = childAfkRecordType;
        ImmutableArray<IColumn> immutableArray = ((Of)familyMgr.childTx()).columnArray();
        this.attributeColumns = new ArrayList();
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 1));
        this.childAfkName = this.attributeColumns.get(0).getJavaName();
    }

    public String getName() {
        return this.name;
    }

    public boolean isFamily() {
        return true;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((Pivot)this.familyMgr.foreignEntity()).getClass().getSimpleName();
        int fkId = Integer.parseInt(json.getString(foreignEntity + "Id"));
        MayNullVO<aloha3.module.object.record.master.read.meta.Read<M>> foreign = GenericSearch.queryPivotReadByPK(foreignEntity, fkId);
        if (foreign.apply((v) -> {
            return false;
        }, () -> {
            return true;
        })) {
            return -1L;
        } else {
            Builder builderParent = Builder.create(this.getFieldClass());
            this.setValues(json, this.parentField, builderParent);
            JsonArray items = json.getJsonArray("child");
            List<aloha3.module.object.record.transaction.read.meta.Read<CM>> lineItemsMore = new ArrayList();

            for(int i = 0; i < items.size(); ++i) {
                JsonObject item = items.getJsonObject(i);
                long afkId = Long.parseLong(item.getString(this.afkAttributeName()));
                lineItemsMore.add((aloha3.module.object.record.transaction.read.meta.Read)((Read)GenericSearch.queryTxViewByPK(this.afkEntityName(), afkId).mustNonNull()).unsafeTx());
            }

            aloha3.module.object.record.transaction.read.meta.Read<CM> first = lineItemsMore.get(0);
            aloha3.module.object.record.transaction.read.meta.Read[] others;
            if (lineItemsMore.size() > 1) {
                others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new aloha3.module.object.record.transaction.read.meta.Read[0]);
            } else {
                others = new aloha3.module.object.record.transaction.read.meta.Read[0];
            }

            return this.familyMgr.save(builderParent.build(), foreign.mustNonNull(), YMDHMS.current(), (view, childTx) -> {
                return Array.create(
                        TxModel.Builder.create(view, childTx, first),
                        others,
                        (builder,afeRead)->builder.setValue(afeRead),
                        TxModel.Builder::build);
            }).get();
        }
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.parentField.unsafeCenterMember().javaName());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxIntFK.Read.createCriteria(this.parentField.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->queryModels((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        return this.familyMgr.selectTx(id).apply((tx) -> {
            return MayNullVO.of(this.queryModel(tx));
        }, MayNullVO::nullInstance);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : this.queryModels(this.familyMgr.selectTxs(DistinctIds.toLongIDs(pkIDs)));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs foreigns, Map<String, Object> params) {
        if (foreigns.empty()) {
            return ImmutVOs.emptyVOs();
        } else {
            return foreigns.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByFKViews(toCores(foreigns), params);
        }
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<M>> foreigns, Map<String, Object> params) {
        return params.containsKey("from") && params.containsKey("to") ? this.queryByFKAndBetween(foreigns, (YMDHMS)params.get("from"), (YMDHMS)params.get("to")) : (ImmutVOs)foreigns.apply((foreignCores) -> {
            return this.queryModels(this.familyMgr.selectTxsByFK(foreignCores));
        }, ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryByFKAndBetween(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<M>> fkViews, YMDHMS from, YMDHMS to) {
        List<T> result = new ArrayList();
        fkViews.foreach((fk) -> {
            result.addAll(this.queryModels(this.familyMgr.createViews(fk, from, to).map(Read::txIntFKReadOf)).asList());
        });
        return ImmutVOs.create(result);
    }

    private ImmutVOs<T> queryModels(ImmutVOs<TxIntFK.Read<E>> txList) {
        List<T> result = new ArrayList();
        txList.unlessEmpty_((txs) -> {
            this.familyMgr.createModels(txs).toFlat((model) -> {
                result.add((T)TxIntFKChildLongAFKOnlyModel.of(model));
                return ImmutVOs.emptyVOs();
            });
        });
        return ImmutVOs.create(result);
    }

    private T queryModel(TxIntFK.Read<E> tx) {
        return (T)TxIntFKChildLongAFKOnlyModel.of(this.familyMgr.createModel(tx));
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return afkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByIntAFKViews(toCores(afkViews), afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read> afkViews, String afkName, Map<String, Object> params) {
        return ((AndIntFK)this.familyMgr.field()).unsafeFK().javaName().equals(afkName) ? this.queryByFKs(afkViews, params) : TxFamilyQuery.queryByIntAFKs(toCores(afkViews), ViewMgr.getColumn(this.name, afkName), this.familyMgr, this);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByLongAFKViews(afkViews, afkName, params);
    }

    private <
    AX extends SealedTxParent<?>,
    F extends AbstractField & Field<AX>>
    ImmutVOs<T> queryByLongAFKViews(ImmutVOs<Read<F>> afkViews, String afkName, Map<String, Object> params) {
        return afkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByLongAFKs(toTxs(afkViews), afkName);
    }

    private ImmutVOs<T> queryByLongAFKs(ImmutVOs<aloha3.module.object.record.transaction.read.meta.Read> afkViews, String afkName) {
        Iterator var3 = this.getMandatoryAttributeMembers().iterator();

        // TODO
        /*
        Mandatory member;
        do {
            if (!var3.hasNext()) {
                AlohaColumn afkColumnOfChild = ViewMgr.getColumnOfChild(this.name, afkName);
                if (afkColumnOfChild != null) {
                    return TxFamilyQuery.filterByLongAFKViewsOfChild(this.query(), afkViews, afkName);
                }

                return ImmutVOs.emptyVOs();
            }

            member = (Mandatory)var3.next();
        } while(!member.javaName().equals(afkName));

        return TxFamilyQuery.queryByLongAFKs(afkViews, ViewMgr.getColumn(this.name, afkName), this.familyMgr, this);
         */
        return null;
    }

    public void update(JsonObject json) {
    }

    public void delete(JsonObject json) {
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.parentField);
        members.add(0, ((AndIntFK)this.familyMgr.field()).unsafeFK());
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.parentField);
    }

    public Mandatory getCenterMember() {
        return ((AndIntFK)this.familyMgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>)this.parentField.getClass();
    }

    public String parentName() {
        return this.parentField.entity().getClass().getSimpleName();
    }

    public String afkAttributeName() {
        return this.childAfkName;
    }

    public String afkEntityName() {
        return this.childAfkRecordType.getSimpleName();
    }

    public StarView<E, M, F> getMgr() {
        return this.familyMgr;
    }
}
