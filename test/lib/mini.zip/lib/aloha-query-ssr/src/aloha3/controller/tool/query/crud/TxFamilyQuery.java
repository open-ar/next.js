package aloha3.controller.tool.query.crud;

import aloha.module.object.Compare;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.controller.tool.query.crud.childmodel.TxChildModel;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.module.function.business.transaction.TxStarViewMgt;
import aloha3.module.object.model.read.TxModel.AbstractFlatField;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxAttributeEntityLongAFK;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TxFamilyQuery {

    public static <
    E extends SealedTxParent<?>,
    A extends TxAttributeEntityLongAFK<? super A,E, AT>,
    AT extends TxKey<?>,
    T extends ValueObject>
    ImmutVOs<T>
    queryByIntAFKs(ImmutVOs<Read> afkViews, AlohaColumn afkColumn, TxStarViewMgt mgr, BaseMgrWrapper wrapper) {
        if (afkColumn == null) {
            return ImmutVOs.emptyVOs();
        } else {
            return afkViews.size() == 0 ? ImmutVOs.emptyVOs() : (ImmutVOs)afkViews.apply((vos) -> {
                ImmutVOs<aloha3.module.object.record.meta.transaction.TxAttributeIntAFK.Read> attrs = mgr.selectAttributeIntAFKs(afkColumn.getDeclaredClass(), vos);
                List<Long> txIds = new ArrayList();
                attrs.foreach((attr) -> {
                    txIds.add(attr.getTxId());
                });
                return wrapper.queryByPKs(txIds);
            }, ImmutVOs::emptyVOs);
        }
    }

    public static <
            F extends AbstractField & Field<?>,
            T extends ValueObject,
            FF extends AbstractFlatField<F, Integer>,
            V extends TxChildModel<F, T, FF>>
    ImmutVOs<V>
    filterByIntAFKViewsOfChild(ImmutVOs<V> vos, ImmutVOs<Read> afkViews, String afkName) {
        return vos.size() == 0 ? ImmutVOs.emptyVOs() : vos.filter((model) -> {
            if (model.getFlatViews().size() == 0) {
                return false;
            } else {
                Mandatory<Integer> afk = ((AbstractFlatField)((View)model.getFlatViews().eltAt(0)).field()).AFK();
                return afk.javaName().equals(afkName) && afkViews.find((afkView) -> {
                    ImmutVOs<View<FF>> flatViews = model.getFlatViews();
                    Iterator var3 = flatViews.asList().iterator();

                    int afkId;
                    do {
                        if (!var3.hasNext()) {
                            return false;
                        }

                        View<AbstractFlatField<F, Integer>> flatView = (View) var3.next();
                        afkId = flatView.intValue((f) -> {
                            return f.AFK();
                        });
                    } while (!Compare.eq(afkId, afkView.rowId()));

                    return true;
                }).apply((notEmpty) -> {
                    return true;
                }, () -> {
                    return false;
                });
            }
        });
    }

    public static <
    E extends SealedTxParent<?>,
    A extends TxAttributeEntityLongAFK<? super A,E, AT>,
    AT extends TxKey<?>,
    T extends ValueObject>
    ImmutVOs<T>
    queryByLongAFKs(ImmutVOs<aloha3.module.object.record.transaction.read.meta.Read> afkViews, AlohaColumn afkColumn, TxStarViewMgt mgr, BaseMgrWrapper wrapper) {
        if (afkColumn == null) {
            return ImmutVOs.emptyVOs();
        } else {
            return afkViews.size() == 0 ? ImmutVOs.emptyVOs() : (ImmutVOs)afkViews.apply((vos) -> {
                ImmutVOs<aloha3.module.object.record.meta.transaction.TxAttributeLongAFK.Read> attrs = mgr.selectAttributeLongAFKs(afkColumn.getDeclaredClass(), vos);
                List<Long> txIds = new ArrayList();
                attrs.foreach((attr) -> {
                    txIds.add(attr.getTxId());
                });
                return wrapper.queryByPKs(txIds);
            }, ImmutVOs::emptyVOs);
        }
    }
    public static <F extends AbstractField & Field<?>, T extends ValueObject, FF extends AbstractFlatField<F, Long>, V extends TxChildModel<F, T, FF>> ImmutVOs<V> filterByLongAFKViewsOfChild(ImmutVOs<V> vos, ImmutVOs<aloha3.module.object.record.transaction.read.meta.Read> afkViews, String afkName) {
        return vos.size() == 0 ? ImmutVOs.emptyVOs() : vos.filter((model) -> {
            if (model.getFlatViews().size() == 0) {
                return false;
            } else {
                Mandatory<Long> afk = ((AbstractFlatField)((View)model.getFlatViews().eltAt(0)).field()).AFK();
                return afk.javaName().equals(afkName) && afkViews.find((afkView) -> {
                    ImmutVOs<View<FF>> flatViews = model.getFlatViews();
                    Iterator var3 = flatViews.asList().iterator();

                    long afkId;
                    do {
                        if (!var3.hasNext()) {
                            return false;
                        }

                        View<AbstractFlatField<F, Long>> flatView = (View) var3.next();
                        afkId = flatView.longValue((f) -> {
                            return f.AFK();
                        });
                    } while (!Compare.eq(afkId, afkView.rowId()));

                    return true;
                }).apply((notEmpty) -> {
                    return true;
                }, () -> {
                    return false;
                });
            }
        });
    }

}
