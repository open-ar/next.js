package aloha3.controller.tool.meta;

import aloha.module.func.Func;
import aloha.module.func.business.AbstractServiceContainer;
import aloha.module.func.business.IMasterDataMgt;
import aloha.module.object.IdentifiableEnum;
import aloha.module.object.MayNullValue;
import aloha.module.object.Type;
import aloha.module.object.record.master.IMasterKey;
import aloha3.module.function.business.master.CoreReadMgt;
import aloha3.module.function.business.master.PivotReadMgt;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.master.coc.State;
import aloha3.module.object.record.master.coc.WorkFlow;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.spec.AttributeRow;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static aloha3.controller.tool.meta.StringUtil.getJsonValueString;

class _ViewMapping {

    static
    <F extends AbstractField>
    String
    stringOf(
        Map<String, String> values,
        Class<F> fieldClass,
        Function<F, AbstractField.Member.Mandatory<String>> member) {

        return
            values.get(
                StringUtil.decapitalize(
                    member.
                        apply(Field.instanceOf(fieldClass)).
                        javaName()));
    }

    static
    <F extends AbstractField>
    int
    intOf(
        Map<String, String> values,
        Class<F> fieldClass,
        Function<F, AbstractField.Member.Mandatory<Integer>> member) {

        return Integer.parseInt(
            values.get(
                StringUtil.decapitalize(
                    member.
                        apply(Field.instanceOf(fieldClass)).
                        javaName())));
    }

    static
    <F extends AbstractField>
    long
    longOf(
        Map<String, String> values,
        Class<F> fieldClass,
        Function<F, AbstractField.Member.Mandatory<Long>> member) {

        return
            Long.parseLong(
                values.get(
                    StringUtil.decapitalize(
                        member.
                            apply(Field.instanceOf(fieldClass)).
                            javaName())));
    }

    static <
        E extends SealedPivot<?>>
    aloha3.module.object.record.master.read.meta.Read<E>
    selectPivot(
        Map<String, String> values,
        Class<E> pivotClass,
        AbstractServiceContainer<?> Mgrs) {

        return
            findPivotMgr(
                pivotClass,
                Mgrs).
                selectPivotByPK(
                    Integer.parseInt(
                        values.get(
                            StringUtil.decapitalize(
                                Instance.of(pivotClass).PK().getJavaName())))).
                mustNonNull();
    }

    @SuppressWarnings("unchecked")
    static <
        E extends SealedPivot<?>>
    PivotReadMgt<E,?>
    findPivotMgr(
        Class<E> pivotClass,
        AbstractServiceContainer<?> Mgrs) {

        for(IMasterDataMgt mdm : Mgrs.allMDM()) {
            if ( mdm instanceof PivotReadMgt<?,?> mgr
                && mgr.entity().getClass() == pivotClass ) {
                return (PivotReadMgt<E,?>)mgr;
            }
        }
        throw new RuntimeException("Register PivotMgr for: " + pivotClass.getName());
    }

    @SafeVarargs
    static <
        F extends AbstractField & Field.ofStarView<?>,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>>
    V
    fromJsonObject(
        Map<String, String> values,
        B builder,
        AbstractServiceContainer<?> businessServices,
        TypeConverter.FromJsonObject<F>... typeConverters) {

        return Func.
            apply(
                builder,
                b->
                    setAttributes(
                        b,
                        toCaseInsensitiveKeyMap(values),
                        businessServices,
                        typeConverters),
                AbstractView.Builder::build);
    }

    @SafeVarargs
    private static <
        F extends AbstractField & Field.ofStarView<?>,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>>
    void
    setAttributes(
        B builder,
        Map<CaseInsensitiveKey, String> jsonValueMap,
        AbstractServiceContainer<?> businessServices,
        TypeConverter.FromJsonObject<F>... typeConverters) {

        builder.field.attributeMembers().
            foreach(
                attribute->
                    builder.
                        unlessValueGiven(
                            f-> (AbstractField.TypedMember<?>)attribute,
                            ()->
                                setValue(
                                    builder,
                                    attribute,
                                    jsonValueMap.get(
                                        CaseInsensitiveKey.of(
                                            attribute.javaName())),
                                    businessServices,
                                    typeConverters)));
    }

    private static
    Map<CaseInsensitiveKey,String>
    toCaseInsensitiveKeyMap(Map<String, String> values) {

        return Func.
            apply(
                new HashMap<CaseInsensitiveKey,String>(),
                values.entrySet(),
                (map,declaredFields)-> {
                    for(Map.Entry<String, String> declaredField : declaredFields) {
                        map.put(
                            CaseInsensitiveKey.of(declaredField.getKey()),
                            declaredField.getValue());
                    }
                    return map;
                });
    }

    @SuppressWarnings({"rawtypes","unchecked"})
    private static <
        F extends AbstractField & Field.ofStarView<?>,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>,
        T extends Comparable<? super T>>
    void
    setValue(
        B builder,
        Field.Member.ofStarView.Attribute<?> attribute,
        Object value,
        AbstractServiceContainer<?> businessServices,
        TypeConverter.FromJsonObject<F>... typeConverters) {

        if ( value == null ||
            (value instanceof Comparable<?> && MayNullValue.of((Comparable)value).unsafeIsNull())) {
            
            if (builder instanceof StarView.Write.Update.Builder b &&
                attribute instanceof AbstractField.Member.Optional o &&
                (Instance.of(attribute.attributeEntity()) instanceof AttributeEntity.Cancellable<?,?>)) {
                b.setOrDeleteOptional((_) -> o, attribute.attributeEntity(), MayNullValue.nullInstance());
            }
            return;
        }

        AbstractField.Member fieldMember = setTypeMemberByAttribute(attribute);

        Comparable<?> cValue = null;
        for(TypeConverter.FromJsonObject<F> typeConverter : typeConverters) {
            if ( typeConverter.member.apply(builder.field) == attribute ) {
                cValue = typeConverter.converter.apply(value);
            }
        }
        if (cValue == null) {

            final String stringValue = getJsonValueString(value);
            final Type.RefType refType = fieldMember.getRefType();
            cValue =
                toComparable(
                    refType,
                    value,
                    Optional.of(Instance.of(attribute.attributeEntity())));
            if (cValue != null && !cValue.toString().isBlank()) {
                cValue =
                    switch (refType) {

                        case INTEGER -> Func.apply(
                            Integer.parseInt(stringValue),
                            intValue ->
                                (Instance.of(attribute.attributeEntity())
                                    instanceof aloha.module.object.record.master.IAdditionalForeignEntity entity) ?
                                    validateInteger(
                                        intValue,
                                        entity,
                                        businessServices,
                                        attribute instanceof Field.Member.ofStarView.Attribute.TypedMandatory) :
                                    intValue);
                        case STRING -> (
                            !(builder instanceof StarView.Write.Update.Builder) &&
                                (Instance.of(attribute.attributeEntity())
                                    instanceof FixedAttributeEntity.UniqueString<?> entity)
                        ) ?
                            validateString(
                                stringValue,
                                entity,
                                businessServices) :
                            stringValue;
                        default -> cValue;
                    };
            }
        }
        if ( attribute instanceof AbstractField.Member.Optional) {
            builder.setOptionalValue(f->(AbstractField.Member.Optional)attribute,(T)cValue);
        } else if (attribute instanceof AbstractField.Member.Mandatory) {
            builder.setMandatoryValue(f->(AbstractField.Member.Mandatory)attribute,(T)cValue);
        } else {
            throw new RuntimeException("Unknown Attribute Member type:" + attribute.getClass().getName());
        }
    }
    static
    Comparable<?>
    toComparable(
        Type.RefType refType,
        Object value,
        Optional<AttributeRow<?>> attributeEntity) {

        return Func.apply(
            getJsonValueString(value),
            stringValue-> {
                if (refType == Type.RefType.BYTE) {
                    if (attributeEntity.isPresent()) {
                        if (attributeEntity.get() instanceof AttributeRow.ForIdentifiableEnum entity)
                            return IdentifiableEnum.
                                    findBy(
                                        stringValue,
                                        entity.enumClass());
                        return (Comparable<?>) Type.toComparable(
                            stringValue,
                            refType);
                    } else {
                        return Type.toComparable(
                                stringValue,
                                refType);
                    }
                } 
                // validate format
                if (refType == Type.RefType.YMD ||
                    refType == Type.RefType.HMS ||
                    refType == Type.RefType.YMDHMS ||
                    refType == Type.RefType.YEAR ||
                    refType == Type.RefType.YearMonth ||
                    refType == Type.RefType.YMDHMSMSEC) {
                    
                    // While chrome / edge, it not send :00 seconds, so need to change 2025-05-20T00:01 to 2025-05-20T00:01:00
                    if (refType == Type.RefType.YMDHMS) {
                        if (stringValue.contains("T") && stringValue.split(":").length == 2) {
                            stringValue = stringValue + ":00";
                        }
                    }
                    
                    // e.g Date: 2021-01-01 -> 20210101
                    // e.g Time: 12:00:00 -> 120000
                    // e.g DateTime: 2021-01-01 12:00:00 -> 20210101120000
                    String asNumber = stringValue.replaceAll("[^0-9]", "");
                    if (refType == Type.RefType.YMD && asNumber.length() < 8 ||
                        refType == Type.RefType.HMS && asNumber.length() < 6 ||
                        refType == Type.RefType.YMDHMS && asNumber.length() < 14 ||
                        refType == Type.RefType.YEAR && asNumber.length() < 4 ||
                        refType == Type.RefType.YearMonth && asNumber.length() < 6 ||
                        refType == Type.RefType.YMDHMSMSEC && asNumber.length() < 17) {
                        return null;
                    }
                    return Type.toComparable(
                        asNumber,
                        refType);
                }
                
                // optional field 
                if (refType != Type.RefType.STRING && stringValue.isBlank()) {
                    return null;
                }
                return Type.toComparable(
                    stringValue,
                    refType);
            });
    }

    private static
    AbstractField.Member
    setTypeMemberByAttribute(
        Field.Member.ofStarView.Attribute<?> attribute) {

        return (AbstractField.Member) attribute;
    }

    private static
    <AFE extends Pivot<?>>
    Integer
    validateInteger(
        int afkId,
        aloha.module.object.record.master.IAdditionalForeignEntity<AFE> entity,
        AbstractServiceContainer<?> businessServices,
        boolean isMandatory) {

        AFE afe = Instance.of(entity.getAdditionalForeignEntity());
        return
            validateInteger(
                afkId,
                afe,
                businessServices,
                isMandatory);
    }

    private static
    <P extends Pivot<?>>
    Integer
    validateInteger(
        int afkId,
        P entity,
        AbstractServiceContainer<?> businessServices,
        boolean isMandatory) {

        if (entity instanceof Graph) {
            // TODO support chain selection (add graph validate after it can register by graph)
            return afkId;
        } else if (entity instanceof WorkFlow) {
            return aloha3.module.function.business.conceptual.WorkFlow.selectWorkFlowByPK(afkId).apply(
                IMasterKey::getRowId,
                ()-> {
                    if (isMandatory) {
                        throw new RuntimeException(
                            "Invalid ID(PK) given " + afkId +
                                " for WorkFlow");
                    } else {
                        return null;
                    }
                });
        } else if (entity instanceof State) {
            // TODO select state by id?
            return aloha3.module.function.business.conceptual.WorkFlow.allStates().apply(
                states->
                    states.
                        find(it -> it.coreRead().rowId() == afkId).
                        apply(
                            state -> state.coreRead().rowId(),
                            () -> {
                                if (isMandatory) {
                                    throw new RuntimeException(
                                        "Invalid ID(PK) given " + afkId +
                                            " for State");
                                } else {
                                    return null;
                                }
                            }),
                ()-> {
                    throw new RuntimeException(
                        "Invalid ID(PK) given " + afkId +
                            " for State");
                });
        }
        for(IMasterDataMgt mdm : businessServices.allMDM()) {

            if ( mdm instanceof PivotReadMgt<?,?> mgr && mgr.entity() == entity) {
                return mgr.
                    selectPivotByPK(afkId).
                    apply(
                        IMasterKey::getRowId,
                        ()-> {
                            if (isMandatory) {
                                throw new RuntimeException(
                                    "Invalid ID(PK) given " + afkId +
                                        " for " + mgr.entity().getClass().getName());
                            } else {
                                return null;
                            }
                        });
            }
        }
        if (isMandatory) {
            throw new RuntimeException("MDM NOT FOUND of " + entity.toString());
        } else {
            return null;
        }
    }

    @SuppressWarnings({"unchecked"})
    private static
    String
    validateString(
        String uniqueString,
        FixedAttributeEntity.UniqueString<?> attributeEntity,
        AbstractServiceContainer<?> businessServices) {

        for (IMasterDataMgt mdm : businessServices.allMDM()) {
            if (mdm instanceof CoreReadMgt mgr
                && mgr.entity().getClass() == attributeEntity.getForeignEntity()) {
                return (String)mgr.
                    assertUniqueKey(
                        attributeEntity.getClass(),
                        uniqueString,
                        ()-> uniqueString,
                        exist->
                        {
                            throw new RuntimeException(
                                "Already exists @ " + attributeEntity.getTABLE() +
                                    " : " + exist.toString());
                        });
            }
        }
        throw new RuntimeException("MDM NOT FOUND for " + attributeEntity.getTABLE());
    }

    private static final class CaseInsensitiveKey {

        final String memberName;
        final int hashCodeAsLowerCase;

        CaseInsensitiveKey(String memberName) {
            this.memberName = memberName;
            this.hashCodeAsLowerCase = memberName.toLowerCase().hashCode();
        }

        static
        CaseInsensitiveKey
        of(String memberName) {
            return new CaseInsensitiveKey(memberName);
        }

        @Override
        public int hashCode() {
            return this.hashCodeAsLowerCase;
        }

        @Override
        public boolean equals(Object other) {
            if (other instanceof CaseInsensitiveKey key) {
                return key.memberName.equalsIgnoreCase(this.memberName);
            }
            return false;
        }
    } // CaseInsensitiveKey

    static abstract class TypeConverter <
        F extends AbstractField,
        T,
        U> {

        final Function<F, AbstractField.TypedMember<?>> member;
        final Function<T,U> converter;

        TypeConverter(
            Function<F, AbstractField.TypedMember<?>> member,
            Function<T,U> converter) {

            this.member = member;
            this.converter = converter;
        }

        static class FromJsonObject
            <F extends AbstractField>
            extends TypeConverter<F, Object,Comparable<?>> {

            private
            FromJsonObject(
                Function<F, AbstractField.TypedMember<?>> member,
                Function<Object,Comparable<?>> converter) {
                super(member,converter);
            }
            @SuppressWarnings({"unchecked","rawtypes"})
            public static <
                F extends AbstractField,
                T extends Comparable<? super T>>
            FromJsonObject<F>
            of(
                Function<F, AbstractField.TypedMember<T>> member,
                Function<Comparable<?>, T> converter) {

                return new FromJsonObject<>((Function)member, (Function)converter);
            }
        } // FromJsonObject
    } // TypeConverter
}
