package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.IdentifiableEnum;
import aloha.module.object.Immutable;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullValue;
import aloha.module.object.Tuple;
import aloha.module.object.Type;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.spec.AttributeRow;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static aloha3.controller.Server.conceptual;
import static aloha3.controller.Server.engine;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;

public class RegisterHierarchyViewController extends AbstractController {

    public static final RegisterHierarchyViewController INSTANCE = new RegisterHierarchyViewController();
    public static final String MAIN_TEMPLATE = "registerHierarchyView.html";
    private static final String GRAPH_ID = "graphId";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Hierarchy";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void handlePut(Request request, Response response) {
        request.unlessNull_(
            PIVOT,
            ID,
            (pivot, idString) -> updateHierarchy(pivot, Integer.parseInt(idString), request.keyValues()));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Integer::valueOf, 0),
                        request),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder
                .add("title", "Nested Elements")
                .add(AlohaMeta.getTreePivots());
        }
    }

    private static String renderMainContent(
        String pivot,
        OperationType operation,
        Integer requestedId,
        Request request
    ) {
        Integer requestedGraphId = request.unlessNull(GRAPH_ID, Integer::valueOf, 0);
        HierarchyPageData pageData = buildPageData(pivot, requestedId, requestedGraphId);

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            Context.Builder.create()
                .add(PIVOT, pivot)
                .add(ID, pageData.selectedId())
                .add("hierarchies", pageData.listRows())
                .add("detail", pageData.detail())
                .build());
    }

    private static HierarchyPageData buildPageData(String pivot, Integer requestedId, Integer requestedGraphId) {
        var entries = collectHierarchyEntries(pivot, DateTime.YMDHMS.current());

        List<HierarchyListRow> rows = entries.values().stream().
            map(RegisterHierarchyViewController::toListRow).
            sorted(Comparator.comparingInt(HierarchyListRow::hierarchyId)).
            collect(Collectors.toList());

        Integer selectedId = determineSelectedId(requestedId, requestedGraphId, rows);
        HierarchyDetailView detail = selectedId == null ? null : entries.containsKey(selectedId)
            ? toDetailView(entries.get(selectedId))
            : null;

        return new HierarchyPageData(rows, detail, selectedId);
    }

    private static Integer determineSelectedId(
        Integer requestedId,
        Integer requestedGraphId,
        List<HierarchyListRow> rows
    ) {
        if (rows.isEmpty()) {
            return null;
        }
        if (requestedId != null && requestedId != 0) {
            return requestedId;
        }
        if (requestedGraphId != null && requestedGraphId != 0) {
            return rows.stream()
                .filter(row -> row.graphId() == requestedGraphId)
                .map(HierarchyListRow::hierarchyId)
                .findFirst()
                .orElse(rows.getFirst().hierarchyId());
        }
        return rows.getFirst().hierarchyId();
    }

    private static Map<Integer, HierarchyEntry> collectHierarchyEntries(String pivot, DateTime.YMDHMS asOf) {
        Map<Integer, HierarchyEntry> collector = new HashMap<>();
        AlohaCRUD.starViewsOfGraph(pivot, asOf).forEach(pair -> {
            Immutable model = pair.right();
            if (model instanceof Tree.StarArrow<?, ?> starArrow) {
                int graphId = pair.left().coreId();
                collectStarArrowEntries(starArrow, graphId, collector);
            }
        });
        return collector;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void collectStarArrowEntries(
        Tree.StarArrow starArrow,
        int graphId,
        Map<Integer, HierarchyEntry> collector
    ) {
        starArrow.arrowToLeaves().asList().forEach(leaf -> {
            var pair = (Tuple.ImmutPair<StarView.Hierarchy.Read<?>, StarView.Read<?>>) leaf;
            var hierarchy = pair.left();
            var childNode = pair.right();
            registerEntry(collector, graphId, hierarchy, starArrow.from(), childNode);
        });
        starArrow.arrowToBranches().asList().forEach(branch -> {
            var pair = (Tuple.ImmutPair<StarView.Hierarchy.Read<?>, Tree.StarArrow<?, ?>>) branch;
            var hierarchy = pair.left();
            var next = pair.right();
            registerEntry(collector, graphId, hierarchy, starArrow.from(), next.from());
            collectStarArrowEntries(next, graphId, collector);
        });
    }

    private static void registerEntry(
        Map<Integer, HierarchyEntry> collector,
        int graphId,
        StarView.Hierarchy.Read<?> hierarchy,
        StarView.Read<?> from,
        StarView.Read<?> to
    ) {
        int hierarchyId = hierarchy.pivotRead().rowId();
        collector.put(
            hierarchyId,
            new HierarchyEntry(
                hierarchyId,
                graphId,
                hierarchy,
                NodeSummary.from(from),
                NodeSummary.from(to)));
    }

    private static HierarchyListRow toListRow(HierarchyEntry entry) {
        String label = entry.from().label() + " → " + entry.to().label();
        return new HierarchyListRow(entry.hierarchyId(), entry.graphId(), entry.from(), entry.to(), label);
    }

    private static HierarchyDetailView toDetailView(HierarchyEntry entry) {
        List<HierarchyAttributeField> attributes = buildAttributeFields(entry.hierarchy());
        return new HierarchyDetailView(entry.hierarchyId(), entry.from(), entry.to(), attributes);
    }

    private static void updateHierarchy(String pivot, int hierarchyId, Map<String, String> formValues) {
        var asOf = DateTime.YMDHMS.current();
        var entries = collectHierarchyEntries(pivot, asOf);
        HierarchyEntry target = entries.get(hierarchyId);
        if (target == null) {
            return;
        }
        var graphModel = AlohaCRUD.starViewOfGraph(target.graphId(), pivot, asOf)
            .orElseThrow(() -> new IllegalArgumentException("Graph not found for pivot " + pivot));
        Immutable immutable = graphModel.right();
        if (!(immutable instanceof Tree.StarArrow<?, ?> starArrow)) {
            return;
        }
        Map<Integer, Map<String, String>> overrides = new HashMap<>();
        overrides.put(hierarchyId, mergeAttributeValues(target.hierarchy(), formValues));
        Tuple.Triplet[] triplets = buildTripletsForGraph(pivot, starArrow, overrides);
        AlohaCRUD.updateOfGraph(pivot, graphModel.left(), triplets);
    }

    private static Tuple.Triplet[] buildTripletsForGraph(
        String pivot,
        Tree.StarArrow<?, ?> root,
        Map<Integer, Map<String, String>> overrides
    ) {
        List<Tuple.Triplet> collector = new ArrayList<>();
        collectTriplets(pivot, root, overrides, collector);
        return collector.toArray(Tuple.Triplet[]::new);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void collectTriplets(
        String pivot,
        Tree.StarArrow node,
        Map<Integer, Map<String, String>> overrides,
        List<Tuple.Triplet> collector
    ) {
        node.arrowToLeaves().asList().forEach(leaf -> {
            var pair = (Tuple.ImmutPair<StarView.Hierarchy.Read<?>, StarView.Read<?>>) leaf;
            var hierarchy = pair.left();
            var child = pair.right();
            var attrs = overrides.getOrDefault(hierarchyId(hierarchy), extractAttributesFromHierarchy(hierarchy));
            var write = buildHierarchyWriter(pivot, node.from(), child, hierarchy, attrs);
            collector.add(Tuple.Triplet.of(node.from(), write, child));
        });
        node.arrowToBranches().asList().forEach(branch -> {
            var pair = (Tuple.ImmutPair<StarView.Hierarchy.Read<?>, Tree.StarArrow<?, ?>>) branch;
            var hierarchy = pair.left();
            var childNode = pair.right();
            var attrs = overrides.getOrDefault(hierarchyId(hierarchy), extractAttributesFromHierarchy(hierarchy));
            var write = buildHierarchyWriter(pivot, node.from(), childNode.from(), hierarchy, attrs);
            collector.add(Tuple.Triplet.of(node.from(), write, childNode.from()));
            collectTriplets(pivot, childNode, overrides, collector);
        });
    }

    private static Map<String, String> mergeAttributeValues(
        StarView.Hierarchy.Read<?> hierarchy,
        Map<String, String> formValues
    ) {
        Map<String, String> values = extractAttributesFromHierarchy(hierarchy);
        hierarchy.field().attributeMembers().asList().forEach(attribute -> {
            String submitted = formValues.get(attribute.javaName());
            if (submitted == null) {
                return;
            }
            String trimmed = submitted.trim();
            if (trimmed.isEmpty() && attribute instanceof AbstractField.Member.Mandatory) {
                return;
            }
            values.put(attribute.javaName(), trimmed);
        });
        return values;
    }

    private static Map<String, String> extractAttributesFromHierarchy(StarView.Hierarchy.Read<?> hierarchy) {
        Map<String, String> values = new HashMap<>();
        hierarchy.field().attributeMembers().asList().forEach(attribute -> {
            String value = readAttributeValue(hierarchy, attribute);
            if (value != null && !value.isBlank()) {
                values.put(attribute.javaName(), value);
            }
        });
        return values;
    }

    private static int hierarchyId(StarView.Hierarchy.Read<?> hierarchy) {
        return hierarchy.pivotRead().rowId();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static StarView.Hierarchy.Write.New<?> buildHierarchyWriter(
        String pivot,
        StarView.Read<?> from,
        StarView.Read<?> to,
        StarView.Hierarchy.Read<?> originalHierarchy,
        Map<String, String> attributes
    ) {
        for (final var c : conceptual().all()) {
            if (c instanceof aloha3.module.function.business.conceptual.master.Graph.Tree.Distinct.StarArrow.Generic hm &&
                hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                var builder = hm.createArrowBuilder(from, to, DateTime.YMDHMS.current());
                @SuppressWarnings("unchecked")
                List<Field.Member.ofStarView.Attribute<?>> arrowMembers =
                    (List<Field.Member.ofStarView.Attribute<?>>)(List<?>) hm.arrowField().attributeMembers().asList();
                for (Field.Member.ofStarView.Attribute<?> attribute : arrowMembers) {
                    String key = attribute.javaName();
                    String raw = attributes.containsKey(key)
                        ? attributes.get(key)
                        : readAttributeValue(originalHierarchy, attribute);
                    if ((raw == null || raw.isBlank()) && attribute instanceof AbstractField.Member.Optional optional) {
                        builder.setOptionalValue(f -> optional, null);
                        continue;
                    }
                    var value = convertAttributeValue(attribute, raw);
                    if (value == null) {
                        continue;
                    }
                    if (attribute instanceof AbstractField.Member.Mandatory mandatory) {
                        builder.setMandatoryValue(f -> mandatory, value);
                    } else if (attribute instanceof AbstractField.Member.Optional optional) {
                        builder.setOptionalValue(f -> optional, value);
                    }
                }
                return builder.build();
            }
        }
        throw new IllegalStateException("Unsupported pivot " + pivot);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Comparable<?> convertAttributeValue(
        Field.Member.ofStarView.Attribute<?> member,
        String raw
    ) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(member.attributeEntity())) {
            AttributeRow.ForIdentifiableEnum enumAttr =
                (AttributeRow.ForIdentifiableEnum) Instance.of(member.attributeEntity());
            return IdentifiableEnum.findBy(trimmed, enumAttr.enumClass());
        }
        try {
            return Type.toComparable(trimmed, member.refType());
        } catch (Exception ex) {
            return trimmed;
        }
    }

    private static List<HierarchyAttributeField> buildAttributeFields(StarView.Hierarchy.Read<?> hierarchy) {
        var members = hierarchy.field().attributeMembers().asList();
        List<HierarchyAttributeField> fields = new ArrayList<>(members.size());
        for (Field.Member.ofStarView.Attribute<?> attr : members) {
            fields.add(toAttributeField(hierarchy, attr));
        }
        return fields;
    }

    private static HierarchyAttributeField toAttributeField(
        StarView.Hierarchy.Read<?> hierarchy,
        Field.Member.ofStarView.Attribute<?> member
    ) {
        boolean optional = member instanceof AbstractField.Member.Optional<?>;
        boolean fixedAttribute = FixedAttributeEntity.class.isAssignableFrom(member.attributeEntity());
        boolean enumType = AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(member.attributeEntity());

        List<EnumOption> options = enumType ? buildEnumOptions(member) : Collections.emptyList();
        String value = readAttributeValue(hierarchy, member);
        boolean immutable = fixedAttribute && value != null && !value.isBlank();

        return new HierarchyAttributeField(
            member.javaName(),
            StringUtil.humanize(member.javaName()),
            member.refType().name(),
            optional,
            immutable,
            enumType,
            options,
            value
        );
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static String readAttributeValue(
        StarView.Hierarchy.Read<?> hierarchy,
        Field.Member.ofStarView.Attribute<?> member
    ) {
        if (member instanceof AbstractField.Member.Mandatory<?> mandatory) {
            Object val = hierarchy.mandatoryValue(f -> (AbstractField.Member.Mandatory)mandatory);
            return val == null ? "" : val.toString();
        }
        if (member instanceof AbstractField.Member.Optional<?> optional) {
            MayNullValue<?> val = hierarchy.optionalValue(f -> (AbstractField.Member.Optional)optional);
            return val.apply(obj -> obj == null ? "" : obj.toString(), () -> "");
        }
        return "";
    }

    private static List<EnumOption> buildEnumOptions(Field.Member.ofStarView.Attribute<?> member) {
        if (!AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(member.attributeEntity())) {
            return Collections.emptyList();
        }
        AttributeRow.ForIdentifiableEnum<?> attr =
            (AttributeRow.ForIdentifiableEnum<?>) Instance.of(member.attributeEntity());
        ImmutableArray<? extends IdentifiableEnum<?>> enums = IdentifiableEnum.toArray(attr.enumClass());
        List<EnumOption> options = new ArrayList<>(enums.size());
        enums.foreach(e -> {
            options.add(new EnumOption(e.name(), Byte.toString(e.id())));
        });
        return options;
    }

    private record HierarchyPageData(
        List<HierarchyListRow> listRows,
        HierarchyDetailView detail,
        Integer selectedId
    ) {}

    private record HierarchyEntry(
        int hierarchyId,
        int graphId,
        StarView.Hierarchy.Read<?> hierarchy,
        NodeSummary from,
        NodeSummary to
    ) {}

    public record HierarchyListRow(
        int hierarchyId,
        int graphId,
        NodeSummary from,
        NodeSummary to,
        String label
    ) {}

    public record NodeSummary(
        int id,
        String label
    ) {
        static NodeSummary from(StarView.Read<?> node) {
            int nodeId = node.coreRead().coreId();
            String nodeLabel = RegisterTreeController.getNodeLabel(node);
            return new NodeSummary(nodeId, nodeLabel);
        }
    }

    public record HierarchyDetailView(
        int hierarchyId,
        NodeSummary from,
        NodeSummary to,
        List<HierarchyAttributeField> attributes
    ) {}

    public record HierarchyAttributeField(
        String name,
        String label,
        String dataType,
        boolean optional,
        boolean immutable,
        boolean enumType,
        List<EnumOption> options,
        String value
    ) {}

    public record EnumOption(String label, String value) {}
}

