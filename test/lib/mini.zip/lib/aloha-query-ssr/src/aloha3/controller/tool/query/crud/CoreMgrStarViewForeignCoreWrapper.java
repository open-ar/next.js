package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.master.CoreMgt;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class CoreMgrStarViewForeignCoreWrapper<
    E extends aloha3.module.object.record.master.CoreEntity,
    F extends StarView.FieldOf.ForeignCore<E,FA>,
    FE extends aloha3.module.object.record.master.CoreEntity,
    FA extends FixedAttributeEntityAFK.Of<E,FE>,
    T extends StarView.Read<F>>
    extends BaseMgrWrapper<T, Integer, Integer> {

    private final String name;
    private final F field;
    private final CoreMgr.StarView.ForeignCore<E, F,FE,FA> mgr;

    public CoreMgrStarViewForeignCoreWrapper(
        String name,
        F field,
        CoreMgr.StarView.ForeignCore<E, F,FE,FA> mgr ) {

        this.field = field;
        this.mgr = Objects.requireNonNull(mgr);
        this.name = name;
    }

    @Override
    public
    boolean
    isMaster() {
        return true;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        return mgr.
            save(
                generateView(
                    json),
                DateTime.YMDHMS.current()).get();
    }

    @Override
    public
    List<CDC>
    fetchHistories() {

        List<CDC> histories = new ArrayList<>();
        mgr.
            selectAllCores(
                DateTime.YMDHMS.current()).
            foreach(
                (core)->
                    mgr.
                        cdcOfView(
                            core.coreId()).
                        unlessNull_(
                            (cdc)->
                                histories.add(cdc)));
        return histories;
    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.foreignCore().javaName());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    query() {

        return (ImmutVOs<T>) mgr.
            selectAllCores(
                DateTime.YMDHMS.current()).
            unlessEmpty(
                (cores) ->
                    mgr.
                        createViews(
                            cores,
                            DateTime.YMDHMS.current()),
                ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    MayNullVO<T>
    queryByPK(Integer id) {

        return (MayNullVO<T>)mgr.
            createView(
                id,
                DateTime.YMDHMS.current());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Integer> pkIDs ) {

        return (ImmutVOs<T>)mgr.createViews(
            DistinctIds.toIntIDs(pkIDs),
            DateTime.YMDHMS.current());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs fkViews,
        Map<String, Object> params ) {

        return queryByForeigns(fkViews);
    }

    @SuppressWarnings(value="unchecked")
    ImmutVOs<T>
    queryByForeigns(
        ImmutVOs<StarView.Read> fkViews ) {

        return fkViews.apply(
            (foreigns)->
                mgr.
                    createViewsByFK(
                        foreigns.map(v->v.coreRead()),
                        DateTime.YMDHMS.current()),
            ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByIntAFKViews(afkViews, afkName);
    }

    @SuppressWarnings(value="unchecked")
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName) {

        if (isForeignKey(afkName))
            return queryByForeigns(afkViews);

        return (ImmutVOs<T>)afkViews.apply(
            (afks)->{
                ImmutVOs<Core.Read<E>> mayEmptyCores;
                AlohaColumn referenceColumn = ViewMgr.getJoinColumn(name, afkName);
                if (FixedAttributeEntityAFK.Of.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                    mayEmptyCores = mgr.selectCoresOfFixedAttribute(
                        (NonEmptyVOs)afks.map(v->v.coreRead()),
                        referenceColumn.getDeclaredClass(),
                        DateTime.YMDHMS.current());
                } else {
                    mayEmptyCores = mgr.selectCoresOf(
                        (NonEmptyVOs)afks.map(v->v.coreRead()),
                        referenceColumn.getDeclaredClass(),
                        DateTime.YMDHMS.current());
                }

                return mayEmptyCores.
                    unlessEmpty(
                        (cores) ->
                            mgr.createViews(
                                DistinctIds.intIDsFromRecords(
                                    cores,
                                    Core.Read::coreId),
                                DateTime.YMDHMS.current()),
                        ImmutVOs.emptyVOs());
            },
            ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }

    @Override
    public
    void
    update(
        JsonObject json) {

        String primaryKeyName = getCenterMember().javaName();
        Integer targetId = JsonUtils.getIntValue(
            json,
            primaryKeyName);
        if (targetId == null)
            return;
        JsonUtils.removeKey(json, primaryKeyName);

        mgr.
            createView(
                targetId,
                DateTime.YMDHMS.current()).
            unlessNull_(
                (exists)->
                    mgr.
                        save(
                            generateView(
                                exists,
                                json)));
    }

    @Override
    public
    void
    delete(
        JsonObject json) {

        Integer targetId = JsonUtils.getIntValue(json,  getCenterMember().javaName());
        if (targetId == null)
            return;
        MayNullVO<StarView.Read<F>> view = mgr.
            createView(
                targetId,
                DateTime.YMDHMS.current());

        view.
            unlessNull_(
                (exists) ->
                    mgr.
                        delete(
                            exists,
                            DateTime.YMDHMS.current()));
    }

    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return mgr.field().unsafeCenterMember();
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(field);
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(field);
    }

    @Override
    public CoreMgt.StarView<E, F> getMgr() {
        return this.mgr;
    }

    @SuppressWarnings(value="unchecked")
    private
    StarView.Write.Prepare<E,F>
    generateView(
        JsonObject json ) {

        String foreignKey = field.foreignCore().javaName();
        String foreignEntity = foreignKey.substring(0, foreignKey.length() - 2);
        BaseMgrWrapper foreignMgt = BusinessMgrContainer.getMasterDataMgt(foreignEntity);

        MayNullVO<StarView.Read> foreignView = ((CoreMgt.StarView)foreignMgt.getMgr()).
            createView(
                Integer.valueOf(
                    json.getString(foreignKey)),
                DateTime.YMDHMS.current());

        StarView.Write.Prepare.Builder<E, F> builder = StarView.Write.Prepare.Builder.
            create(
                getFieldClass(),
                foreignView.mustNonNull().coreRead());

        setValues(json, field, builder);
        return builder.build();
    }

    @SuppressWarnings(value="unchecked")
    private
    StarView.Write.Update<F>
    generateView(
        StarView.Read<F> exists,
        JsonObject json ) {

        StarView.Write.Update.Builder<E, F> builder = StarView.Write.Update.Builder.
            create(
                exists,
                DateTime.YMDHMS.current());
        setValues(json, field, builder);
        return builder.build();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }

    @Override
    public ImmutVOs<? extends Read> queryTxs() {
        return null;
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return null;
    }

}
