package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Type;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.master.CoreMgr.StarView.OneToMany;
import aloha3.module.function.business.master.CoreMgt;
import aloha3.module.object.model.MayNull;
import aloha3.module.object.model.OneToMany.Attributes;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.record.master.AttributeEntityAFK;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.FixedAttributeEntityAFK.Of;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView.Read;
import aloha3.module.object.view.StarView.Write.Prepare;
import aloha3.module.object.view.StarView.Write.Update;
import aloha3.module.object.view.StarView.Write.Update.Builder;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

public class CoreMgrStarViewWrapper<
    E extends CoreEntity,
    F extends AbstractField & aloha3.module.object.view.StarView.Field<E>,
    T extends Read<F>>
    extends BaseMgrWrapper<T, Integer, Integer> {

    private final String name;
    private final F field;
    private final CoreMgt.StarView<E, F> mgr;
    private final Map<String, OneToMany> oneToManyMgrs = new HashMap();

    public CoreMgrStarViewWrapper(String name, F field, CoreMgt.StarView<E, F> mgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;

        if (mgr instanceof OneToMany oneToManyMgr) {
            Class oneToManyEntity = oneToManyMgr.manyAttrEntity().getClass();
            String columnName;
            if (AttributeEntityAFK.class.isAssignableFrom(oneToManyEntity)) {
                //columnName = ((AttributeEntityAFK) Instance.of(oneToManyEntity)).getAdditionalForeignKeyColumn().getJavaName();
                columnName = oneToManyEntity.getSimpleName() +"Id";
            } else {
                columnName = oneToManyEntity.getSimpleName();
            }
            this.oneToManyMgrs.put(columnName, oneToManyMgr);
        }
    }
    public String getName() {
        return this.name;
    }

    public F getField() {
        return this.field;
    }

    @Override
    public CoreMgt.StarView<E, F> getMgr() {
        return this.mgr;
    }

    public void test() {
        this.mgr.selectAllCores(YMDHMS.current());
        CDC<E, F> cdc = this.mgr.cdcOfView(1).apply((c) -> {
            return c;
        }, () -> {
            return null;
        });
    }

    public Map<String, OneToMany> getOneToManyMgrs() {
        return this.oneToManyMgrs;
    }

    public OneToMany getOneToManyMgr() {
        return this.oneToManyMgrs.isEmpty() ? null : this.oneToManyMgrs.get(this.oneToManyMgrs.keySet().toArray()[0]);
    }

    public boolean isOneToMany() {
        return !this.oneToManyMgrs.isEmpty();
    }

    public boolean isMaster() {
        return true;
    }

    public Mandatory getCenterMember() {
        return this.mgr.field().unsafeCenterMember();
    }

    public Object register(JsonObject json) {
        if (!this.isOneToMany()) {
            return this.mgr.save(this.generateView(json), YMDHMS.current()).get();
        } else {
            Integer id = null;
            new ArrayList();
            AlohaColumn firstOneToManyColumn = null;
            OneToMany oneToManyMgr = null;
            Iterator var6 = this.getOneToManyMgrs().entrySet().iterator();

            while(var6.hasNext()) {
                Entry<String, OneToMany> entry = (Entry)var6.next();
                AlohaColumn column = ViewMgr.getColumn(this.name, entry.getKey());
                if (column == null || column.isMulti()) {
                    Value<Integer> ret = entry.getValue().
                        save(
                            this.generateView(json),
                            this.createValues(
                                column,
                                json.getString(
                                    column == null ? entry.getKey() : column.getName())),
                            YMDHMS.current());
                    id = ret.get();
                    firstOneToManyColumn = column;
                    oneToManyMgr = entry.getValue();
                    break;
                }
            }

            Read<F> fRead = this.mgr.createView(id, YMDHMS.current()).mustNonNull();
            List<Attributes> oneToManyAttributes = new ArrayList();
            Iterator var14 = ViewMgr.getRecord(this.name).getColumns().iterator();

            while(var14.hasNext()) {
                AlohaColumn column = (AlohaColumn)var14.next();
                if (column.isMulti() && column != firstOneToManyColumn) {
                    if (column.isForeign()) {
                        ImmutVOs<Core.Read> foreignValues = this.createForeignValues(column, json.getString(column.getName()));
                        oneToManyAttributes.add(Attributes.create(column.getDeclaredClass(), (ImmutVOs)foreignValues));
                    } else {
                        ImmutValues values = this.createValues(column, json.getString(column.getName()));
                        oneToManyAttributes.add(Attributes.create(column.getDeclaredClass(), values));
                    }
                }
            }

            if (oneToManyAttributes.size() > 0 && oneToManyMgr != null) {
                oneToManyMgr.update(Builder.create(fRead, YMDHMS.current()).build(), oneToManyAttributes.toArray(new Attributes[0]));
            }

            if (id == null) {
                throw new IllegalStateException();
            } else {
                return id;
            }
        }
    }

    public void update(JsonObject json) {
        String primaryKeyName = this.getCenterMember().javaName();
        Integer targetId = JsonUtils.getIntValue(json, primaryKeyName);
        if (targetId != null) {
            JsonUtils.removeKey(json, primaryKeyName);
            if (this.isOneToMany()) {
                OneToMany oneToManyMgr = null;
                Iterator var5 = this.getOneToManyMgrs().entrySet().iterator();

                while(var5.hasNext()) {
                    Entry<String, OneToMany> entry = (Entry)var5.next();
                    AlohaColumn column = ViewMgr.getColumn(this.name, entry.getKey());
                    if (column == null || column.isMulti()) {
                        oneToManyMgr = entry.getValue();
                    }
                }

                Read<F> fRead = this.mgr.createView(targetId, YMDHMS.current()).mustNonNull();
                List<Attributes> oneToManyAttributes = new ArrayList();
                Iterator var12 = ViewMgr.getRecord(this.name).getColumns().iterator();

                while(var12.hasNext()) {
                    AlohaColumn column = (AlohaColumn)var12.next();
                    if (column.isMulti()) {
                        if (column.isForeign()) {
                            ImmutVOs<Core.Read> foreignValues = this.createForeignValues(column, json.getString(column.getName()));
                            oneToManyAttributes.add(Attributes.create(column.getDeclaredClass(), (ImmutVOs)foreignValues));
                        } else {
                            ImmutValues values = this.createValues(column, json.getString(column.getName()));
                            oneToManyAttributes.add(Attributes.create(column.getDeclaredClass(), values));
                        }
                    }
                }

                oneToManyMgr.update(this.generateView(fRead, json), oneToManyAttributes.toArray(new Attributes[0]));
            } else {
                this.mgr.createView(targetId, YMDHMS.current()).unlessNull_((exists) -> {
                    this.mgr.save(this.generateView(exists, json));
                });
            }

        }
    }

    public void delete(JsonObject json) {
        Integer targetId = JsonUtils.getIntValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.mgr.createView(targetId, YMDHMS.current()).unlessNull_((exists) -> {
                this.mgr.delete(exists, YMDHMS.current());
            });
        }
    }

    public List<CDC> fetchHistories() {
        List<CDC> histories = new ArrayList();
        this.mgr.selectAllCores(YMDHMS.current()).foreach((core) -> {
            MayNull var10000 = this.mgr.cdcOfView(core.coreId());
            Objects.requireNonNull(histories);
            var10000.unlessNull_(v->histories.add((CDC) v));
        });
        return histories;
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return this.mgr.selectAllCores(YMDHMS.current());
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)this.mgr.selectAllCores(YMDHMS.current()).unlessEmpty((cores) -> {
            return this.mgr.createViews(cores, YMDHMS.current());
        }, ImmutVOs.emptyVOs());
    }

    public MayNullVO<T> queryByPK(Integer id) {
        return (MayNullVO<T>) this.mgr.createView(id, YMDHMS.current());
    }

    public ImmutVOs<T> queryByPKs(List<Integer> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : (ImmutVOs<T>) this.mgr.createViews(DistinctIds.toIntIDs(pkIDs), YMDHMS.current());
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViewss, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        if (afkViews.size() == 0) {
            return ImmutVOs.emptyVOs();
        } else {
            return afkViews.eltAt(0) instanceof aloha3.module.object.view.StarView.Relation.Read ? this.queryByIntAFKViews(afkViews.map(r->((aloha3.module.object.view.StarView.Relation.Read)r).relationRead()), afkName) : this.queryByIntAFKViews(afkViews.map(r->((Read)r).coreRead()), afkName);
        }
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read> afkViews, String afkName) {
        return (ImmutVOs)afkViews.apply((afks) -> {
            AlohaColumn referenceColumn = ViewMgr.getJoinColumn(this.name, afkName);
            if (referenceColumn == null) {
                System.out.println("afkName: " + afkName);
                System.out.println("name: " + this.name);
                System.out.println("referenceColumn: " + referenceColumn);
            }

            ImmutVOs mayEmptyCores;
            if (Of.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                mayEmptyCores = this.mgr.selectCoresOfFixedAttribute((NonEmptyVOs)afks, referenceColumn.getDeclaredClass(), YMDHMS.current());
            } else if (FixedAttributeEntityAFK.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                mayEmptyCores = this.mgr.selectCoresOfFixedAttribute((NonEmptyVOs)afks, referenceColumn.getDeclaredClass(), YMDHMS.current());
            } else {
                mayEmptyCores = this.mgr.selectCoresOf((NonEmptyVOs)afks, referenceColumn.getDeclaredClass(), YMDHMS.current());
            }

            return (ImmutVOs)mayEmptyCores.unlessEmpty((cores) -> {
                return this.mgr.createViews(DistinctIds.intIDsFromRecords((NonEmptyVOs)cores, r->((Core.Read)r).rowId()), YMDHMS.current());
            }, ImmutVOs.emptyVOs());
        }, () -> {
            return ImmutVOs.emptyVOs();
        });
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(this.field);
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    private Prepare<E, F> generateView(JsonObject json) {
        Prepare.Builder<E, F> builder = Prepare.Builder.create(this.getFieldClass());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    private Update<F> generateView(Read<F> exists, JsonObject json) {
        Builder<E, F> builder = Builder.create(exists, YMDHMS.current());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    private <T extends Comparable<? super T>> ImmutValues createValues(AlohaColumn column, String str) {
        if (str != null && !str.isEmpty()) {
            String[] strings = str.split(",");
            switch(column.getDataType()) {
                case STRING:
                    return ImmutValues.of(strings);
                case INTEGER:
                    Integer[] values = new Integer[strings.length];

                    for(int i = 0; i < strings.length; ++i) {
                        values[i] = Integer.valueOf(strings[i]);
                    }

                    return ImmutValues.of(values);
                default:
                    return ImmutValues.emptyInstance();
            }
        } else {
            return ImmutValues.emptyInstance();
        }
    }

    private ImmutVOs createForeignValues(AlohaColumn column, String str) {
        if (str != null && !str.isEmpty()) {
            String foreignEntity = column.getForeignRecord();
            String[] strings = str.split(",");
            List<Core.Read> afks = new ArrayList();
            if (column.getDataType() == Type.RefType.INTEGER) {
                String[] var6 = strings;
                int var7 = strings.length;

                for (int var8 = 0; var8 < var7; ++var8) {
                    String strValue = var6[var8];
                    int afkId = Integer.parseInt(strValue);
                    GenericSearch.queryMasterViewByPK(foreignEntity, afkId).unlessNull_((core) -> {
                        afks.add(core.coreRead());
                    });
                }

                return ImmutVOs.create(afks);
            }
            return ImmutVOs.emptyVOs();
        } else {
            return ImmutVOs.emptyVOs();
        }
    }
}

