package aloha3.controller.tool.query.crud;

import aloha.module.Array;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxLongFKChildIntAFKOnlyModel;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxLongFKMgr.StarView;
import aloha3.module.function.business.transaction.TxLongFKMgr.StarView.Family.ChildIntAFKOnly;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK.On;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView.FieldOf;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TxLongFKFamilyIntAFKOnlyWrapper<
    E extends On<M>,
    M extends SealedTxParent<?>,
    F extends AndLongFK<E>,
    CH extends ChildTxEntityIntAFKOnly.Of<E, CM>,
    CM extends SealedPivot<?>,
    MF extends FieldOf<?>,
    T extends TxLongFKChildIntAFKOnlyModel<E, M, F, CH, CM, Read<F>>>
    extends BaseMgrWrapper<T, Long, Integer>
    implements TxFamilyWrapper {

    private final String name;
    private final F field;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final StarView<E, M, F> parentMgr;
    private final ChildIntAFKOnly<E, M, F, CH> familyMgr;
    private final String childAfkName;
    private final List<IColumn> attributeColumns;

    public TxLongFKFamilyIntAFKOnlyWrapper(String name, F field, Class<CH> childRecord, Class<CM> childAfkRecordType, StarView<E, M, F> parentMgr, ChildIntAFKOnly<E, M, F, CH> familyMgr) {
        this.name = name;
        this.field = field;
        this.childRecord = childRecord;
        this.parentMgr = parentMgr;
        this.familyMgr = familyMgr;
        this.childAfkRecordType = childAfkRecordType;
        ImmutableArray<IColumn> immutableArray = ((ChildTxEntityIntAFKOnly)familyMgr.childTx()).columnArray();
        this.attributeColumns = new ArrayList();
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 1));
        this.childAfkName = this.attributeColumns.get(0).getJavaName();
    }

    public String getName() {
        return this.name;
    }

    public boolean isFamily() {
        return true;
    }

    public String itemName() {
        return this.childRecord.getSimpleName();
    }

    public String afkEntityName() {
        return this.childAfkRecordType.getSimpleName();
    }

    public String afkAttributeName() {
        return this.childAfkName;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((TxEntity)this.familyMgr.foreignEntity()).getClass().getSimpleName();
        long fkId = Long.parseLong(json.getString(foreignEntity + "Id"));
        MayNullVO<Read<MF>> foreign = GenericSearch.queryTxViewByPK(foreignEntity, fkId);
        Builder builderParent = Builder.create(this.getFieldClass());
        this.setValues(json, this.field, builderParent);
        JsonArray items = json.getJsonArray("child");
        List<aloha3.module.object.record.master.read.meta.Read<CM>> lineItemsMore = new ArrayList();

        for(int i = 0; i < items.size(); ++i) {
            JsonObject item = items.getJsonObject(i);
            int afkId = Integer.parseInt(item.getString(this.afkAttributeName()));
            MayNullVO<aloha3.module.object.record.master.read.meta.Read<CM>> afk = GenericSearch.queryPivotReadByPK(this.afkEntityName(), afkId);
            lineItemsMore.add(afk.mustNonNull());
        }

        aloha3.module.object.record.master.read.meta.Read<CM> first = lineItemsMore.get(0);
        aloha3.module.object.record.master.read.meta.Read[] others;
        if (lineItemsMore.size() > 1) {
            others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new aloha3.module.object.record.master.read.meta.Read[0]);
        } else {
            others = new aloha3.module.object.record.master.read.meta.Read[0];
        }

        return this.familyMgr.save(builderParent.build(), (aloha3.module.object.record.transaction.read.meta.Read)((Read)foreign.mustNonNull()).unsafeTx(), YMDHMS.current(), (view, childTx) -> {
            return Array.create(TxModel.Builder.create(view, childTx, first), others,
                    (builder,other)->
                            builder.setValue(other), TxModel.Builder::build);
        }).get();
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeFK().javaName());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxLongFK.Read.createCriteria(this.field.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->queryModels((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        return this.familyMgr.selectTx(id).apply((tx) -> {
            return MayNullVO.of(this.queryModel(tx));
        }, MayNullVO::nullInstance);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : this.queryModels(this.familyMgr.selectTxs(DistinctIds.toLongIDs(pkIDs)));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs foreigns, Map<String, Object> params) {
        return this.queryByFKViews(toTxViews(foreigns), params);
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<Read<MF>> fkViews, Map<String, Object> params) {
        return params.containsKey("from") && params.containsKey("to") ? this.queryByFKAndBetween(fkViews, (YMDHMS)params.get("from"), (YMDHMS)params.get("to")) : (ImmutVOs)fkViews.apply((foreigns) -> {
            return this.queryModels(this.familyMgr.selectByFK(foreigns.map(Read::txRead)));
        }, ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryByFKAndBetween(ImmutVOs<Read<MF>> fkViews, YMDHMS from, YMDHMS to) {
        return fkViews.apply((foreigns) -> {
            return this.queryModels(this.familyMgr.selectByFK(foreigns.map(Read::txRead)));
        }, ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryModels(ImmutVOs<TxLongFK.Read<E>> txList) {
        List<T> result = new ArrayList();
        txList.apply((txs) -> {
            return this.familyMgr.createModels(txs).toFlat((model) -> {
                result.add((T)TxLongFKChildIntAFKOnlyModel.of(model));
                return ImmutVOs.emptyVOs();
            });
        }, ImmutVOs::emptyVOs);
        return ImmutVOs.create(result);
    }

    private T queryModel(TxLongFK.Read<E> tx) {
        return (T)TxLongFKChildIntAFKOnlyModel.of(this.familyMgr.createModel(tx));
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(toCores(afkViews), afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read> afkViews, String afkName, Map<String, Object> params) {
        AlohaColumn afkColumn = ViewMgr.getColumn(this.name, afkName);
        if (afkColumn != null) {
            return TxFamilyQuery.queryByIntAFKs(toCores(afkViews), afkColumn, this.familyMgr, this);
        } else {
            AlohaColumn afkColumnOfChild = ViewMgr.getColumnOfChild(this.name, afkName);
            return afkColumnOfChild != null ? TxFamilyQuery.filterByIntAFKViewsOfChild(this.query(), toCores(afkViews), afkName) : ImmutVOs.emptyVOs();
        }
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.isForeignKey(afkName) ? this.queryByFKs(afkViews, params) : TxFamilyQuery.queryByLongAFKs(afkViews, ViewMgr.getColumn(this.name, afkName), this.familyMgr, this);
    }

    public void update(JsonObject json) {
    }

    public void delete(JsonObject json) {
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((AndLongFK)this.familyMgr.field()).unsafeFK());
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    public Mandatory getCenterMember() {
        return ((AndLongFK)this.familyMgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>)this.field.getClass();
    }

    public StarView<E, M, F> getMgr() {
        return this.familyMgr;
    }

    public String parentName() {
        return this.field.entity().getClass().getSimpleName();
    }
}
