package aloha3.controller.tool.query.models;

import aloha3.module.object.view.TxStarView;

import java.util.ArrayList;
import java.util.List;

public class JoinedView extends ArrayList<FlatView> {
    private final List<String> joinKeys = new ArrayList<>();

    public <T>
    T
    getAlohaViews(
        String name) {

        for(FlatView view : this) {
            if (view.getName().equals(name))
                return (T)view.getView();
        }
        throw new IllegalArgumentException(name);
    }

    public
    JoinedView
    cloneEmpty() {

        JoinedView cloned = new  JoinedView();
        forEach(
            (view)->
                cloned.add(
                    view.cloneEmpty()));
        return cloned;
    }

    @Override
    public
    boolean
    add(
        FlatView obj) {

        return super.add(obj);
    }

    public
    JoinedView
    addJoinKey(
        String joinKey) {

        joinKeys.add(joinKey);
        return this;
    }

    public
    JoinedView
    copyFrom (
        JoinedView obj) {

        for(FlatView view : obj) {
            FlatView copy = new FlatView(view.getName(), view.getView());
            copy.getValues().addAll(view.getValues());
            add(copy);
        }
        this.joinKeys.addAll(obj.joinKeys);
        return this;
    }

    public
    List<String>
    keys() {

        List<String> names = new ArrayList<>();
        for(FlatView view : this) {
            names.addAll(
                view.keys());
        }
        return names;
    }

    public
    List<String>
    getJoinKeys() {
        return joinKeys;
    }

    public
    List<Object>
    values() {

        List<Object> values = new ArrayList<>();
        for(FlatView view : this) {
            for(FieldMemberValue value : view.getValues()) {
                values.add(
                    value.getValue());
            }
        }
        return values;
    }

    public
    List<Object>
    values(
        JoinedView titleViews ) {

        List<Object> values = new ArrayList<>();
        int index = 0;
        for(FlatView   titleView : titleViews) {
            FlatView view = get(index);
            if (view.getName().equals(titleView.getName())) {
                for (FieldMemberValue value : view.getValues()) {
                    values.add(
                        value.getValue());
                }
                index++;
                if (index >= size())
                    break;
            }else {
                for (FieldMemberValue value : titleView.getValues()) {
                    values.add(
                        null);
                }
            }
        }
        return values;
    }

    public
    FieldMemberValue
    getMemberValue(
        String memberName) {

        for(FlatView view : this) {
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value;
            }
        }
        throw new IllegalArgumentException(memberName);
    }

    public
    Object
    getValue(
        String fieldName,
        String memberName ) {

        for(FlatView view : this) {
            if (!view.getName().equals(fieldName))
                continue;
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.getValue();
            }
        }
        throw new IllegalArgumentException(fieldName+"."+memberName);
    }

    public
    int
    getInt(
        String memberName ) {

        for(FlatView view : this) {
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.isNull() ? Integer.MIN_VALUE : value.getInt();
            }
        }
        return Integer.MIN_VALUE;
        //throw new IllegalArgumentException(memberName);
    }

    public
    int
    getInt(
        String fieldName,
        String memberName ) {

        for(FlatView view : this) {
            if (!view.getName().equals(fieldName))
                continue;
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.isNull() ? Integer.MIN_VALUE : value.getInt();
            }
        }
        return Integer.MIN_VALUE;
        //throw new IllegalArgumentException(fieldName+"."+memberName);
    }

    public
    long
    getLong(
        String memberName ) {

        for(FlatView view : this) {
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.isNull() ? Long.MIN_VALUE : value.getLong();
            }
        }
        // DerivedTxの場合
        for(FlatView view : this) {
            if (view.getView().field().getClass().getSimpleName().replaceFirst("Field$", "Id").equals(memberName)) {
                return ((TxStarView.Read)view.getView()).txRead().getTxId();
            }
        }
        return Long.MIN_VALUE;
        //throw new IllegalArgumentException(memberName);
    }

    public
    long
    getLong(
        String fieldName,
        String memberName ) {

        for(FlatView view : this) {
            if (!view.getName().equals(fieldName))
                continue;
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.isNull() ? Long.MIN_VALUE : value.getLong();
            }
        }
        return Long.MIN_VALUE;
        //throw new IllegalArgumentException(fieldName+"."+memberName);
    }

    public
    double
    getDouble(
        String memberName ) {

        for(FlatView view : this) {
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.isNull() ? Double.MIN_VALUE : value.getDouble();
            }
        }
        throw new IllegalArgumentException(memberName);
    }

    public
    double
    getDouble(
        String fieldName,
        String memberName ) {

        for(FlatView view : this) {
            if (!view.getName().equals(fieldName))
                continue;
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.isNull() ? Double.MIN_VALUE : value.getDouble();
            }
        }
        throw new IllegalArgumentException(fieldName+"."+memberName);
    }


    public
    String
    getString(
        String memberName ) {

        for(FlatView view : this) {
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.getString();
            }
        }
        throw new IllegalArgumentException(memberName);
    }

    public
    String
    getString(
        String fieldName,
        String memberName ) {

        for(FlatView view : this) {
            if (!view.getName().equals(fieldName))
                continue;
            for(FieldMemberValue value : view.getValues()) {
                if (value.getFieldMember().getMemberName().equals(memberName))
                    return value.getString();
            }
        }
        throw new IllegalArgumentException(fieldName+"."+memberName);
    }

    public
    Object
    getFirstValue( ) {

        return isEmpty() ? null : get(0).getFirstValue();
    }


    public final static JoinedView EMPTY_JOINED_VIEW = new JoinedView();
}
