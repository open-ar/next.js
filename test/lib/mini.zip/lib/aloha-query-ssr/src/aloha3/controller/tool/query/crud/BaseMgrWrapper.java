package aloha3.controller.tool.query.crud;

import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.ValueObject;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxChildModel;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public abstract class BaseMgrWrapper<
    T extends ValueObject,
    K extends Object,
    FK extends Comparable<? super FK>> {

    public abstract Object getMgr();

    abstract public Object register(JsonObject json);
    abstract public void update(JsonObject json);
    abstract public void delete(JsonObject json);

    abstract public MayNullVO<T> queryByPK(K id);
    abstract public ImmutVOs<T> query();
    abstract public ImmutVOs<T> queryByPKs(List<K> pkIDs);
    public abstract ImmutVOs<? extends Read> queryTxs();
    public abstract ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores();

    abstract public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params);
    abstract public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params);
    abstract public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params);

    abstract public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers();
    abstract public List<AbstractField.Member.Optional> getOptionalAttributeMembers();
    abstract public  AbstractField.Member.Mandatory getCenterMember();

    public boolean isGroup() {
        return false;
    }

    public
    List<CDC>
    fetchHistories() {
        return Collections.emptyList();
    }

    public
    boolean
    isPrimaryKey(String name) {
        return name.equals(getCenterMember().javaName());
    }

    public
    boolean
    isForeignKey(String name) {
        return false;
    }

    public
    boolean
    isFamily() {
        return false;
    }

    public
    boolean
    isCRUD() {
        return false;
    }

    public
    boolean
    isMaster() {
        return false;
    }

    @SuppressWarnings({"rawtypes"})
    public
    List<AbstractField.Member.Mandatory>
    getMandatoryMembers() {

        List<AbstractField.Member.Mandatory> members = new ArrayList<>();
        members.
            add(
                getCenterMember());

        members.addAll(
            getMandatoryAttributeMembers());
        return members;
    }

    @SuppressWarnings({"rawtypes"})
    public
    List<AbstractField.Member.Optional>
    getOptionalMembers() {

        return getOptionalAttributeMembers();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public
    List<AbstractField.Member.Mandatory>
    getMandatoryAttributeMembers(
        StarView.Field field) {

        List<AbstractField.Member.Mandatory> members = new ArrayList<>();
        field.attributeMembers().
            foreach(
                (f) -> {
                    if (f instanceof AbstractField.Member.Mandatory)
                        members.add(
                            (AbstractField.Member.Mandatory) f);
                });
        return members;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public
    List<AbstractField.Member.Mandatory>
    getMandatoryAttributeMembers(
        StarView.Relation.FieldOf field) {

        List<AbstractField.Member.Mandatory> members = new ArrayList<>();

        members.add(
            field.unsafePivotFKMember());
        members.add(
            field.unsafePivotAFKMember());

        field.attributeMembers().
            foreach(
                (f) -> {
                    if (f instanceof AbstractField.Member.Mandatory)
                        members.add(
                            (AbstractField.Member.Mandatory) f);
                });

        return members;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public
    List<AbstractField.Member.Optional>
    getOptionalAttributeMembers(
        StarView.Field field) {

        List<AbstractField.Member.Optional> members = new ArrayList<>();
        field.attributeMembers().
            foreach(
                (f) -> {
                    if (f instanceof AbstractField.Member.Optional)
                        members.add(
                            (AbstractField.Member.Optional) f);
                });

        return members;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public
    List<AbstractField.Member.Optional>
    getOptionalAttributeMembers(
        StarView.Relation.FieldOf field) {

        List<AbstractField.Member.Optional> members = new ArrayList<>();
        field.attributeMembers().
            foreach(
                (f) -> {
                    if (f instanceof AbstractField.Member.Optional)
                        members.add(
                            (AbstractField.Member.Optional) f);
                });

        return members;
    }

    @SuppressWarnings("unchecked")
    public <
    F extends AbstractField,
    V extends AbstractView<F>,
    B extends AbstractView.Builder<F,V,B>,
    E extends AbstractView.Builder<F,V,B>>
    E
    setValues(
        JsonObject json,
        StarView.Field field,
        E builder) {

        getMandatoryAttributeMembers(field).
            forEach(
                (member)->
                    setMandatoryValue(
                        json,
                        member,
                        builder));

        getOptionalAttributeMembers(field).
            forEach(
                (member)->
                    setOptionalValue(
                        json,
                        member,
                        builder));

        return builder;
    }


    @SuppressWarnings("unchecked")
    public
    <F extends AbstractField,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>,
        E extends AbstractView.Builder<F,V,B>>
    E
    setValues(
        JsonObject json,
        TxStarView.Field field,
        E builder) {

        getMandatoryAttributeMembers(field).
            forEach(
                (member)->
                    setMandatoryValue(
                        json,
                        member,
                        builder));

        getOptionalAttributeMembers(field).
            forEach(
                (member)->
                    setOptionalValue(
                        json,
                        member,
                        builder));

        return builder;
    }

    @SuppressWarnings("unchecked")
    public
    <F extends AbstractField,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>,
        E extends AbstractView.Builder<F,V,B>>
    E
    setValues(
        JsonObject json,
        StarView.Relation.FieldOf field,
        E builder) {

        getMandatoryAttributeMembers(field).
            forEach(
                (member)->
                    setMandatoryValue(
                        json,
                        member,
                        builder));

        getOptionalAttributeMembers(field).
            forEach(
                (member)->
                    setOptionalValue(
                        json,
                        member,
                        builder));

        return builder;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public boolean
    containsAttributeMember(
        TxStarView.Field field,
        String name) {

        ImmutableArray<aloha3.module.object.view.Field.Member.ofStarView.Attribute>  attrs = field.attributeMembers();
        for (aloha3.module.object.view.Field.Member.ofStarView.Attribute attr : attrs.get()) {
            if (attr.javaName().equals(name))
                return true;
        }
        return false;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public List<AbstractField.Member.Mandatory>
    getMandatoryAttributeMembers(
            TxStarView.Field field) {

        List<AbstractField.Member.Mandatory> members = new ArrayList<>();
        field.attributeMembers().
            foreach(
                (f) -> {
                    if (f instanceof AbstractField.Member.Mandatory)
                        members.add(
                            (AbstractField.Member.Mandatory) f);
                });
        return members;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public
    List<AbstractField.Member.Optional>
    getOptionalAttributeMembers(
        TxStarView.Field field) {

        List<AbstractField.Member.Optional> members = new ArrayList<>();
        field.attributeMembers().
            foreach(
                (f) -> {
                    if (f instanceof AbstractField.Member.Optional)
                        members.add(
                            (AbstractField.Member.Optional) f);
                });

        return members;
    }

    static
    <TA extends Comparable<? super TA>>
    TA
    valueOf(
        IColumn member,
        JsonObject json) {

        final String name = member.getJavaName();

        switch(member.getRefType()) {
            case INTEGER:
                return (TA) JsonUtils.getIntValue(
                                json, name);
            case STRING:
                return (TA)JsonUtils.getStringValue(
                                json, name);
            default:
                throw new RuntimeException("Not Supported yet : " + member.getRefType());
        }
    }

    @SuppressWarnings("unchecked")
    public
    <F extends AbstractField,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>,
        E extends AbstractView.Builder<F,V,B>,
        T extends Comparable<? super T>>
    E
    setMandatoryValue(
        JsonObject json,
        AbstractField.Member.Mandatory<T> member,
        E builder) {

        String name = member.javaName();
        if (!json.containsKey(name))
            return builder;

        switch(member.getRefType()) {
            case INTEGER:
                builder.setMandatoryValue(
                    f -> member,
                    (T) JsonUtils.getIntValue(
                        json, name));
                break;
            case BYTE:
                AlohaColumn column = ViewMgr.getColumn(member);
                String enumName = JsonUtils.getStringValue(json, name);
                IdentifiableEnum enumValue = column.getEnumValue(enumName);
                if (enumValue != null) {
                    builder.setMandatoryValue(
                        f -> member,
                        (T) enumValue);
                }
                break;
            case LONG:
                builder.setMandatoryValue(
                    f -> member,
                    (T) JsonUtils.getLongValue(
                        json, name));
                break;
            case STRING:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getStringValue(
                        json, name));
                break;
            case YMDHMS:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getYMDHMSValue(
                        json, name));
                break;
            case YMD:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getYMDValue(
                        json, name));
                break;
            case YearMonth:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getYearMonthValue(
                        json, name));
                break;
            case DECIMALSCALE1:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getDecimalScale1Value(
                        json, name));
                break;
            case DECIMALSCALE2:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getDecimalScale2Value(
                        json, name));
                break;
            case DECIMALSCALE3:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getDecimalScale3Value(
                        json, name));
                break;
            case DECIMALSCALE4:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getDecimalScale4Value(
                        json, name));
                break;
            case DECIMALSCALE5:
                builder.setMandatoryValue(
                    f -> member,
                    (T)JsonUtils.getDecimalScale5Value(
                        json, name));
                break;
            case PRECISION18SCALE2:
                builder.setMandatoryValue(
                    f -> member,
                    (T) JsonUtils.getPrecision18Scale2Value(
                        json, name));
                break;
            case PRECISION18SCALE5:
                builder.setMandatoryValue(
                    f -> member,
                    (T) JsonUtils.getPrecision18Scale5Value(
                        json, name));
                break;
        }
        return  builder;
    }

    @SuppressWarnings("unchecked")
    public
    <F extends AbstractField,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>,
        E extends AbstractView.Builder<F,V,B>,
        T extends Comparable<? super T>>
    E
    setOptionalValue(
        JsonObject json,
        AbstractField.Member.Optional<T> member,
        E builder) {

        String name = member.javaName();
        if (!json.containsKey(name))
            return builder;

        switch(member.getRefType()) {
            case INTEGER:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getIntValue(
                        json, name));
                break;
            case BYTE:
                AlohaColumn column = ViewMgr.getColumn(member);
                String enumName = JsonUtils.getStringValue(json, name);
                IdentifiableEnum enumValue = column.getEnumValue(enumName);
                if (enumValue != null) {
                    builder.setOptionalValue(
                        f -> member,
                        (T) enumValue);
                }
                break;
            case LONG:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getLongValue(
                        json, name));
                break;
            case STRING:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getStringValue(
                        json, name));
                break;
            case YMDHMS:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getYMDHMSValue(
                        json, name));
                break;
            case YMD:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getYMDValue(
                        json, name));
                break;
            case YearMonth:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getYearMonthValue(
                        json, name));
                break;
            case DECIMALSCALE1:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getDecimalScale1Value(
                        json, name));
                break;
            case DECIMALSCALE2:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getDecimalScale2Value(
                        json, name));
                break;
            case DECIMALSCALE3:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getDecimalScale3Value(
                        json, name));
                break;
            case DECIMALSCALE4:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getDecimalScale4Value(
                        json, name));
                break;
            case DECIMALSCALE5:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getDecimalScale5Value(
                        json, name));
                break;
            case PRECISION18SCALE2:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getPrecision18Scale2Value(
                        json, name));
                break;
            case PRECISION18SCALE5:
                builder.setOptionalValue(
                    f -> member,
                    (T) JsonUtils.getPrecision18Scale5Value(
                        json, name));
                break;
        }
        return  builder;
    }
    public static Read toTx(Object view) {
        if (view instanceof TxStarView.Read) {
            return ((TxStarView.Read)view).txRead();
        } else if (view instanceof OneToOne) {
            return toTx(((OneToOne)view).left);
        } else if (view instanceof TxModel) {
            return toTx(((TxModel)view).view());
        } else {
            throw new IllegalArgumentException(view.getClass().getName());
        }
    }

    public static ImmutVOs toCores(ImmutVOs views) {
        if (views.size() == 0) {
            return views;
        } else {
            if (views.eltAt(0) instanceof StarView.Relation.Read) {
                views = views.map((v) -> {
                    return ((StarView.Relation.Read)v).relationRead();
                });
            } else if (views.eltAt(0) instanceof StarView.Read) {
                views = views.map((v) -> {
                    return ((StarView.Read)v).coreRead();
                });
            } else if (views.eltAt(0) instanceof aloha3.module.object.record.master.read.meta.Read) {
                views = views;
            }

            return views;
        }
    }

    public static ImmutVOs toTxs(ImmutVOs views) {
        if (views.size() == 0) {
            return views;
        } else {
            if (views.eltAt(0) instanceof TxStarView.Read) {
                views = views.map((v) -> {
                    return ((TxStarView.Read)v).txRead();
                });

            } else if (views.eltAt(0) instanceof TxModel) {
                views = toTxs(views.map((v) -> {
                    return ((TxModel)v).view();
                }));

            } else if (views.eltAt(0) instanceof OneToOne) {
                views = toTxs(views.map((v) -> {
                    return ((OneToOne)v).left;
                }));
            } else if (views.eltAt(0) instanceof Read) {
                views = views;
            }

            return views;
        }
    }

    public static ImmutVOs toTxViews(ImmutVOs views) {
        if (views.size() == 0) {
            return views;
        } else if (views.eltAt(0) instanceof TxStarView.Read) {
            return views;
        } else if (views.eltAt(0) instanceof OneToOne) {
            return toTxViews(views.map((v) -> {
                return ((OneToOne)v).left;
            }));
        } else {
            return views.eltAt(0) instanceof TxChildModel ? toTxViews(views.map((v) -> {
                return ((TxChildModel)v).view();
            })) : views;
        }
    }

}
