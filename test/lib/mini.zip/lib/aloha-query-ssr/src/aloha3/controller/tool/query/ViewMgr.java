package aloha3.controller.tool.query;

import aloha.module.func.business.ITransactionMgt;
import aloha.module.object.ImmutValues;
import aloha.module.object.ImmutableArray;
import aloha.module.object.Tuple;
import aloha.module.object.record.transaction.IForeignEntity;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecord;
import aloha3.controller.tool.query.object.Csv;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.master.CoreReadMgt;
import aloha3.module.function.business.master.PivotReadMgt;
import aloha3.module.function.business.master.StarViewReadMgt;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.master.spec.meta.AttributeEntity;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.spec.Schema;
import aloha3.module.object.record.transaction.TxEntityIntFKValue;
import aloha3.module.object.record.transaction.spec.TxEntityIntFK;
import aloha3.module.object.record.transaction.spec.TxEntityLongFK;
import aloha3.module.object.record.transaction.spec.meta.ChildTx;
import aloha3.module.object.record.transaction.spec.meta.DerivedTx;
import aloha3.module.object.record.transaction.spec.meta.TxAttribute;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractCompositeField;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public class ViewMgr {

    public static final boolean BIND_TX_WITH_CHILD = false;
    private static EntityNames entitiesNames;
    //private static Map<String, String> commonNames;
    public static Map<String, String> viewNames;

    public static
    void
    init(String namesFile, boolean isNameFileParameGiven) throws Exception {
        try {
            loadViewNames(namesFile, isNameFileParameGiven);
        }catch ( IOException e) {
            e.printStackTrace();
        }
    }

    public static AlohaRecord.RECORD_TYPE
    getType(
        String entityName) {

        AlohaRecord record = getRecord(entityName);
        return (record != null) ?
            record.getType()
            : AlohaRecord.RECORD_TYPE.Unkownn;
    }

    public static
    boolean
    hasOneTpManyAttributes(
        String entityName) {

        return getRecord(entityName).isOneToMany();
    }

    public static
    boolean
    containsChild(
        String entityName) {

        return getRecord(entityName).containsChild();
    }

    public static
    boolean
    isCoreEntity(
        String entityName) {

        return getType(entityName).isMaster();
    }

    public static
    boolean
    isRelationEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.Relation;
    }

    public static
    boolean
    isTreeEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.Tree;
    }

    public static
    boolean
    isArrowTreeEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.ArrowTree;
    }

    public static
    boolean
    isDistinctTreeEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.DistinctTree;
    }

    public static
    boolean
    isChainEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.Chain;
    }

    public static
    boolean
    isTxEntity(
        String entityName) {

        return isTxLongFKEntity(entityName)
            || isTxIntFKEntity(entityName);
    }

    public static
    boolean
    isTxLongFKEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.TxLongFK;
    }

    public static
    boolean
    isTxIntFKEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.TxIntFK;
    }

    public static
    boolean
    isDerivedTxEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.DerivedTx;
    }

    public static
    boolean
    isFlowableTxEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.FlowableTx;
    }

    public static
    boolean
    isTxChildEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.TxChild;
    }

    public static
    boolean
    isCrudEntity(
        String entityName) {

        return isCrudLongFKEntity(entityName)
            || isCrudIntFKEntity(entityName);
    }

    public static
    boolean
    isCrudLongFKEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.CrudLongFK;
    }

    public static
    boolean
    isCrudIntFKEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.CrudIntFK;
    }

    public static
    boolean
    isCrudChildEntity(
        String entityName) {

        return getType(entityName) == AlohaRecord.RECORD_TYPE.CrudIntFKChild
            || getType(entityName) == AlohaRecord.RECORD_TYPE.CrudLongFKChild;
    }

    public static
    List<String>
    getMasters() {

        List<String> names = new ArrayList<>();
        ReflectiveJoinTool.
            masters().
            foreach(
                it -> {
                    if ("State".equalsIgnoreCase(it) && !ReflectiveJoinTool.workflowEnabled() ||
                        "WorkFlow".equalsIgnoreCase(it)) {
                        // Hide `WorkFlow` table and skip `State` if WorkFlow not enabled
                    } else {
                        names.add(it);
                    }
                });

        Collections.sort(names);
        return names;
    }

    public static
    List<String>
    getCores() {

        List<String> names = new ArrayList<>();
        ReflectiveJoinTool.
            cores().
            foreach(
                names::add);

        Collections.sort(names);
        return names;
    }

    public static
    List<String>
    getRelations() {

        List<String> names = new ArrayList<>();
        names.addAll(
            Arrays.asList(
                ReflectiveJoinTool.
                    relations().
                    get()));
        Collections.sort(names);
        return names;
    }

    public static
    List<String>
    getChains() {

        List<String> names = new ArrayList<>();
        names.addAll(
            Arrays.asList(
                ReflectiveJoinTool.
                    chains().
                    get()));
        Collections.sort(names);
        return names;
    }

    public static
    List<String>
    getArrowTrees() {

        List<String> names = new ArrayList<>();
        names.addAll(
            Arrays.asList(
                ReflectiveJoinTool.
                    arrowTrees().
                    get()));
        Collections.sort(names);
        return names;
    }

    public static
    List<String>
    getDistinctTrees() {

        List<String> names = new ArrayList<>();
        names.addAll(
            Arrays.asList(
                ReflectiveJoinTool.
                    distinctTrees().
                    get()));
        Collections.sort(names);
        return names;
    }

    public static
    List<String>
    getNonCores() {

        List<String> txNames = new ArrayList<>(
            Arrays.asList(
                ReflectiveJoinTool.
                    nonCores().get()));

        Collections.sort(txNames);
        return txNames;
    }

    public static List<String> getTxs() {
        List<String> txNames = new ArrayList(ReflectiveJoinTool.txs().asList());
        txNames.addAll(ReflectiveJoinTool.txChilds().asList());
        txNames.addAll(ReflectiveJoinTool.cruds().asList());
        txNames.addAll(ReflectiveJoinTool.crudFamilies().asList());
        Collections.sort(txNames);
        return txNames;
    }

    public static AlohaColumn
    getJoinColumn(
        String view,
        String joinedView) {

        if (view.contains("."))
            view = view.substring(0,view.indexOf("."));

        if (view.endsWith("Id"))
            view = view.substring(0, view.length()-2);
        if (joinedView.endsWith("Id"))
            joinedView = joinedView.substring(0, joinedView.length()-2);

        for(AlohaColumn column : ReflectiveJoinTool.recordOf(view).getColumns() ) {
            if (!column.isForeign())
                continue;
            if (column.getForeignRecord().equals(joinedView))
                return column;
        }

        if (containsChild(view)) {
            AlohaRecord record = getRecord(view);
            List<AlohaColumn> columns = record.getColumnsOfChildOrDependant();
            for(AlohaColumn column : columns) {
                if (!column.isForeign())
                    continue;
                if (column.getForeignRecord().equals(joinedView))
                    return column;
            }
        }

        return null;
    }

    public static AlohaColumn getColumnOfChild(String viewModelName, String columnName) {
        try {
            AlohaRecord record = ReflectiveJoinTool.recordOf(viewModelName);
            return record != null ? record.columnOfChild(columnName) : null;
        } catch (Exception var3) {
            return null;
        }
    }

    public static AlohaColumn
    getJoinFromColumn(
        String view,
        String joinedView) {

        for(AlohaColumn column : ReflectiveJoinTool.recordOf(joinedView).getColumns() ) {
            if (!column.isForeign())
                continue;
            if (column.getForeignRecord().equals(view))
                return ReflectiveJoinTool.recordOf(view).getPrimaryKey();
        }

        return null;
    }

    public static
    <P extends Pivot<?>>
    ImmutableArray<AttributeEntity.One<P,Integer,?>>
    attributeEntitiesOf(
        P pivotEntity) {

        List<AttributeEntity.One<P,Integer,?>> buf = new ArrayList<>();
        for( AttributeEntity.One<P,?,?> one : ((PivotReadMgt.StarView) ReflectiveJoinTool.mdmOf(pivotEntity)).attributeTypes().attrs()) {
            buf.add((AttributeEntity.One<P,Integer,?>)one);
        }
        return ImmutableArray.of(buf);
    }

    public static
    <P extends TxEntity>
    ImmutableArray<TxAttribute>
    txAttributeEntitiesOf(
        P pivotEntity) {

        List<TxAttribute> buf = new ArrayList<>();
        ITransactionMgt iTransactionMgt = ReflectiveJoinTool.txmOf(pivotEntity);
        if (iTransactionMgt instanceof TxMgt.StarView){
            for( TxAttribute txAttribute : ((TxMgt.StarView) iTransactionMgt).attributeTypes().attrs()) {
                buf.add(txAttribute);
            }
        } else if (iTransactionMgt instanceof TxMgt.Derived.StarView){
            for( TxAttribute txAttribute : ((TxMgt.Derived.StarView) iTransactionMgt).attributeTypes().attrs()) {
                buf.add(txAttribute);
            }
        }
        return ImmutableArray.of(buf);
    }

    public static
    <P extends TxEntity>
    String
    foreignCoreOfTxEntity(
        P pivotEntity) {

        List<TxAttribute> buf = new ArrayList<>();
        if (pivotEntity instanceof TxEntityIntFK) {
            return ((TxEntityIntFK) pivotEntity).getForeignEntity().getSimpleName();
        } else if (pivotEntity instanceof TxEntityIntFKValue) {
            return ((TxEntityIntFKValue) pivotEntity).getForeignEntity().getSimpleName();
        }
        return null;
    }

    public static
    <P extends TxEntity>
    String
    foreignTxOfTxEntity(
        String viewName) {

        String foreignTx =  foreignTxOfTxEntity(
            ReflectiveJoinTool.schemaOf(
                viewName));
        if (foreignTx != null)
            return foreignTx;

        return null;
    }

    public static
    <P extends Schema<?>>
    String
    foreignTxOfTxEntity(
        P pivotEntity) {

        if (pivotEntity instanceof TxEntityLongFK) {
            return ((TxEntityLongFK) pivotEntity).getForeignEntity().getSimpleName();
        } else if (pivotEntity instanceof DerivedTx) {
            return ((DerivedTx) pivotEntity).getForeignEntity().getSimpleName();
        } else if (pivotEntity instanceof ChildTx) {
            return ((ChildTx) pivotEntity).getForeignEntity().getSimpleName();
        }
        return null;
    }

    public static
    List<AlohaColumn>
    getMembersNamesOf(
        String viewName ) {

        return getRecord(viewName).getColumns();
    }

    public static
    List<String>
    getForeignNamesOf(
        String viewName ) {

        List<String> foreigns = new ArrayList<>();
        for(AlohaColumn member : getMembersNamesOf(viewName)) {
            if (member.isForeign())
                foreigns.add(member.getForeignRecord());
        }
        return foreigns;
    }

    public static
    String
    getPrimaryKey(
        String viewModelName) {

        AlohaRecord record = getRecord(viewModelName);
        return (record != null) ?
            record.getPrimaryKey().getName()
            : viewModelName + "Id";
    }

    public static List<Tuple.Pair<String, AlohaColumn>> getReferentsOf(String viewModelName) {
        List<Tuple.Pair<String,AlohaColumn>> names = new ArrayList();
        Iterator var2 = ReflectiveJoinTool.recordOf(viewModelName).getColumns().iterator();

        while(var2.hasNext()) {
            AlohaColumn column = (AlohaColumn)var2.next();
            if (column.isForeign()) {
                names.add(Tuple.Pair.of(column.getForeignRecord(),column));
            }
        }

        return names;
    }

    public static
    List<Tuple.Pair<String,AlohaColumn>>
    getRelationsOf(
        String viewModelName ) {

        List<Tuple.Pair<String,AlohaColumn>> names = new ArrayList<>();
        ReflectiveJoinTool.
            masters().
            foreach(
                (relationName)-> {
                    for(AlohaColumn column : ReflectiveJoinTool.recordOf(relationName).getColumns()) {
                        if (column.isForeign() && column.getForeignRecord().equals(viewModelName))
                            names.add(Tuple.Pair.of(relationName,column));
                    }
                });
        return names;
    }

    public static
    Class
    getMgrType(
        CoreReadMgt.StarView joinedDataMgt) {

        if (joinedDataMgt.getClass().getSuperclass().getName().endsWith("CoreMgr$StarView"))
            return StarViewReadMgt.class;
        else if (joinedDataMgt.getClass().getSuperclass().getName().endsWith("RelationMgr$StarView"))
            return StarViewReadMgt.Relation.class;

        throw new IllegalArgumentException(joinedDataMgt.getClass().getName());
    }

    @Deprecated
    public static
    Class
    getResultType(
        GeneralViewsQuery.ViewConnections[] views) {

        int viewsCount = views.length + 1;

        if (viewsCount == 2)
            return AbstractCompositeField.Field.Two.class;
        else if (viewsCount == 3)
            return AbstractCompositeField.Field.Three.class;
        else if (viewsCount == 4)
            return AbstractCompositeField.Field.Four.class;
        else if (viewsCount == 5)
            return AbstractCompositeField.Field.Five.class;
        else if (viewsCount == 6)
            return AbstractCompositeField.Field.Six.class;
        else if (viewsCount == 7)
            return AbstractCompositeField.Field.Seven.class;
        else if (viewsCount == 8)
            return AbstractCompositeField.Field.Eight.class;

        throw new IllegalArgumentException("Joined Views : " +views.length);
    }

    public static
    Class
    getMemberClass(
        String field,
        String member) {

        if (isCoreEntity(field)) {
            ImmutableArray<AttributeEntity.One> attrs = (ImmutableArray) attributeEntitiesOf(
                ReflectiveJoinTool.
                    pivotOf(
                        field));

            for (int i = 0; i < attrs.size(); i++) {
                AttributeEntity.One attribute = attrs.eltAt(i);
                if (attribute.attributeColumn().getJavaName().equals(member))
                    return attribute.getClass();
            }
        } else {
            ImmutableArray<TxAttribute> attrs = (ImmutableArray) txAttributeEntitiesOf(
                ReflectiveJoinTool.
                    txOf(
                        field));

            for (int i = 0; i < attrs.size(); i++) {
                TxAttribute attribute = attrs.eltAt(i);
                if (attribute.attributeColumn().getJavaName().equals(member))
                    return attribute.getClass();
            }
        }
        throw new IllegalArgumentException(field +"."+member);
    }

    public static <
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>>
    CoreReadMgt.StarView<E,F>
    getMasterDataMgt(
        String field) {

        if (isCoreEntity(field))
            return ReflectiveJoinTool.
                mdmOf(
                    ReflectiveJoinTool.
                        pivotOf(
                            field));
        else {
            throw new RuntimeException();
        }
    }

    public static <
        E extends CoreEntity,
        H extends HierarchyEntity.Of.Tree<E>,
        F extends AbstractField & StarView.Field<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    Graph.Tree.Distinct.StarArrow<E,H,F,HF>
    getGraphTreeStarArrowMgt(
        String field) {

        if (isCoreEntity(field))
            return ReflectiveJoinTool.
                graphTreeStarArrowMgtOf(
                    ReflectiveJoinTool.
                        pivotOf(
                            field));
        else {
            throw new RuntimeException();
        }
    }

    public static <
        E extends CoreEntity,
        H extends HierarchyEntity.Of.Tree<E>,
        F extends AbstractField & StarView.Field<E>>
    Graph.Tree.Distinct<E,H,F>
    getGraphTreeDistinctMgt(
        String field) {

        if (isCoreEntity(field))
            return ReflectiveJoinTool.
                graphTreeDistinctMgtOf(
                    ReflectiveJoinTool.
                        pivotOf(
                            field));
        else {
            throw new RuntimeException("is Not CoreEntity:" + field.getClass().getName());
        }
    }

    public static
    <E extends CoreEntity,
    H extends HierarchyEntity.Of.Tree<E>,
    F extends AbstractField & StarView.Field<E>>
    Graph.Tree<E,H,F>
    getGraphTreeMgt(
        String field) {

        if (isCoreEntity(field))
            return ReflectiveJoinTool.
                graphTreeMgtOf(
                    ReflectiveJoinTool.
                        pivotOf(
                            field));
        else {
            throw new RuntimeException();
        }
    }

    public static <
        E extends CoreEntity,
        H extends HierarchyEntity.Of.Chain.Straight<E>,
        F extends AbstractField & StarView.Field<E>>
    Graph.Chain.Straight<E,H,F>
    getGraphChainMgt(
        String field) {

        if (isCoreEntity(field))
            return ReflectiveJoinTool.
                graphChainMgtOf(
                    ReflectiveJoinTool.
                        pivotOf(
                            field));
        else {
            throw new RuntimeException();
        }
    }

    static
    ITransactionMgt
    getTransactionDataMgt(
        String field) {

        Schema schema = ReflectiveJoinTool.
            schemaOf(
                field);

        if (CRUD.class.isInstance(schema))
            throw new IllegalArgumentException(field);
        else if (TxEntity.class.isInstance(schema))
            return ReflectiveJoinTool.
                txmOf(
                    TxEntity.class.cast(
                        schema));
        else if (ChildTx.class.isInstance(schema))
            return ReflectiveJoinTool.
                txmOf(
                    ChildTx.class.cast(
                        schema));
        else
            throw new IllegalArgumentException(field);
    }

    public static
    CRUD
    getCrudDataMgt(
        String field) {

        return ReflectiveJoinTool.
            crudOf(
                ReflectiveJoinTool.
                    txOf(
                        field));
    }

    public static
    CRUD.Family
    getCrudChildDataMgt(
        String field) {

        return ReflectiveJoinTool.
            crudChildOf(
                ReflectiveJoinTool.
                    txOf(
                        field));
    }

    public static
    ITransactionMgt
    getChildTransactionDataMgt(
        String field) {

        return ReflectiveJoinTool.txmOf(
            (ChildTx)ReflectiveJoinTool.schemaOf(
                field));
    }

    public static String toViewModelName(String name) {
        /*
        AlohaRecord record = getRecordByRepsName(name);
        if (record != null) {
            return record.getName();
        } else {
         */
        name = trimBeforeHyphen(trimBeforeComma(name));

        Iterator<Map.Entry<String,String>> var2 = viewNames.entrySet().iterator();

        while(var2.hasNext()) {

            Map.Entry<String,String> e = var2.next();
            if ( e.getValue().equals(name) )
                return e.getKey();
            if ( e.getKey().equals(name))
                return name;
        }
        // throw new RuntimeException(name);
        return name;
    }
    public static
    String
    trimBeforeComma(String name) {
        if ( name.contains(".") ) {
            name = name.substring(0,name.indexOf("."));
        }
        return name;
    }
    public static
    String
    trimBeforeHyphen(String name) {
        if ( name.contains("-") ) {
            name = name.substring(0,name.indexOf("-"));
        }
        return name;
    }
    public static
    String
    toViewName(
        String modelName) {

        AlohaRecord record =getRecord(modelName);
        return record != null ?
            record.getReprName()
            :
            modelName;
    }

    public static AlohaRecord<?,?>
    getRecord(
        String modelName) {

        try {
            return ReflectiveJoinTool.recordOf(modelName);
        }catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static AlohaRecord
    getRecordByRepsName(
        String repsName) {

        try {
            return ReflectiveJoinTool.recordByRepsName(repsName);
        }catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static
    <T extends Comparable<? super T>>
    AlohaColumn
    getColumn(
        AbstractField.Member.Mandatory<T> member) {

        String viewModelName = member.field().getClass().getSimpleName();
        viewModelName = viewModelName.substring(0, viewModelName.length() - "Field".length());
        String columnName = member.javaName();
        try {
            AlohaRecord record = ReflectiveJoinTool.recordOf(viewModelName);
            if (record != null) {
                return record.columnOf(columnName);
            }
            throw new RuntimeException();
        }catch (Exception e){
            throw new RuntimeException(e);
        }
        //throw new IllegalArgumentException(viewModelName +"."+columnName);
    }

    public static
    <T extends Comparable<? super T>>
    AlohaColumn
    getColumn(
        AbstractField.Member.Optional<T> member) {

        String viewModelName = member.field().getClass().getSimpleName();
        viewModelName = viewModelName.substring(0, viewModelName.length() - "Field".length());
        String columnName = member.javaName();
        try {
            AlohaRecord record = ReflectiveJoinTool.recordOf(viewModelName);
            if (record != null) {
                return record.columnOf(columnName);
            }
            throw new RuntimeException();
        }catch (Exception e){
            throw new RuntimeException(e);
        }
        //throw new IllegalArgumentException(viewModelName +"."+columnName);
    }

    public static AlohaColumn
    getColumn(
        String viewModelName,
        String columnName) {

        try {
            AlohaRecord record = ReflectiveJoinTool.recordOf(viewModelName);
            if (record != null) {
                return record.columnOf(columnName);
            }
            throw new RuntimeException(viewModelName + "." + columnName);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
        //throw new IllegalArgumentException(viewModelName +"."+columnName);
    }

    public static
    String
    toColumnName(
        String viewModelName,
        String columnName) {

        AlohaColumn column = getColumn( viewModelName, columnName);
        return (column != null) ?
            column.getReprName()
            : columnName;
    }

    public static List<String> getAllForeigenCoresOfTxs() {
        List<String> foreignCores = new ArrayList();
        ImmutValues<String> cores = ReflectiveJoinTool.cores();
        cores = cores.append(ReflectiveJoinTool.relations(), new ImmutValues[0]);
        cores = cores.append(ReflectiveJoinTool.chains(), new ImmutValues[0]);
        cores = cores.append(ReflectiveJoinTool.arrowTrees(), new ImmutValues[0]);
        cores = cores.append(ReflectiveJoinTool.distinctTrees(), new ImmutValues[0]);
        cores.foreach((coreName) -> {
            Pivot<?> pivot = ReflectiveJoinTool.pivotOf(coreName);
            ImmutableArray<Schema<?>> referTos = ReflectiveJoinTool.referTo(pivot);
            referTos.foreach((refer) -> {
                Class p;
                if (refer instanceof IForeignEntity) {
                    p = ((IForeignEntity)refer).getForeignEntity();
                    if (coreName.equals(p.getSimpleName()) && !foreignCores.contains(coreName)) {
                        foreignCores.add(coreName);
                    }
                } else if (refer instanceof aloha.module.object.record.master.IForeignEntity) {
                    p = ((aloha.module.object.record.master.IForeignEntity)refer).getForeignEntity();
                    if (coreName.equals(p.getSimpleName()) && !foreignCores.contains(coreName)) {
                        foreignCores.add(coreName);
                    }
                } else {
                    String var10000 = refer.getClass().getSimpleName();
                    System.out.println(" skip " + var10000 + " ==> " + refer.getClass().getSuperclass().getName());
                }

            });
        });
        return foreignCores;
    }

    public static List<String> getAllAdditionalForeigenCoresOfTxs() {
        List<String> foreignCores = new ArrayList();
        Iterator var1 = getTxs().iterator();

        label39:
        while(var1.hasNext()) {
            String tx = (String)var1.next();
            Iterator var3 = getMembersNamesOf(tx).iterator();

            while(true) {
                String name;
                do {
                    AlohaColumn field;
                    do {
                        do {
                            if (!var3.hasNext()) {
                                continue label39;
                            }

                            field = (AlohaColumn)var3.next();
                        } while(!field.isForeign());
                    } while(!ReflectiveJoinTool.existsOf(field.getForeignRecord()));

                    name = field.getForeignRecord();
                } while(!isCoreEntity(name) && !isRelationEntity(name));

                if (!foreignCores.contains(name)) {
                    foreignCores.add(name);
                }
            }
        }

        return foreignCores;
    }

    public static
    List<String>
    getTxsOfCore(
        String coreName) {

        List<String> txs = new ArrayList<>();
        for(String tx : getTxs()) {

            if (BIND_TX_WITH_CHILD) {
                if (isTxChildEntity(tx))
                    continue;
            }
            /*
            String foreignCore = foreignCoreOfTxEntity(ReflectiveJoinTool.txOf(tx));
            if (coreName.equals(foreignCore))
                txs.add(tx);
            */
            for(AlohaColumn field : ViewMgr.getMembersNamesOf(tx)) {
                String name = field.getForeignRecord();
                if (field.isForeign() && name.equals(coreName)) {
                    txs.add(tx);
                }
            }
            if (BIND_TX_WITH_CHILD) {
                if (containsChild(tx)) {
                    AlohaRecord record = ViewMgr.getRecord(tx);
                    List<AlohaColumn> columns = record.getColumnsOfChildOrDependant();
                    for (AlohaColumn field : columns) {
                        String name = field.getForeignRecord();
                        if (field.isForeign() && name.equals(coreName)) {
                            txs.add(tx);
                        }
                    }
                }
            }
        }
        return txs;
    }

    public static
    List<String>
    getTxsOfTx(
        String txName) {

        List<String> txs = new ArrayList<>();
        for(String tx : getNonCores()) {
            if (BIND_TX_WITH_CHILD && isTxChildEntity(tx))
                continue;
            if (tx.equals(txName))
                continue;
            if (getForeignNamesOf(tx).contains(txName))
                txs.add(tx);
        }
        return txs;
    }

    private static void loadViewNames(String namesFile, boolean isNameFileParameGiven) throws Exception {
        //loadCommonNames(namesFile.getParentFile());
        entitiesNames = new EntityNames();
        String entityName = null;
        String tableName = null;
        List<List<String>> names = Csv.parse(readNames(namesFile, entitiesNames.getClass().getClassLoader(), isNameFileParameGiven));
        AlohaRecord table = null;
        viewNames = new HashMap();
        Map<String, Map<String, String>> viewColumnNames = new HashMap();
        Iterator var6 = names.iterator();

        while(true) {
            List nameInfo;
            String modelName;
            String name;
            do {
                do {
                    if (!var6.hasNext()) {
                        var6 = names.iterator();

                        while(true) {
                            while(true) {
                                do {
                                    if (!var6.hasNext()) {
                                        ReflectiveJoinTool.records().forEach((record) -> {
                                            //if (record.getReprName().equals(record.getName()) && commonNames.containsKey(record.getName())) {
                                            //    record.setReprName((String)commonNames.get(record.getName()));
                                            //}

                                            record.getColumns().forEach((column) -> {
                                                if (column.getReprName().equals(column.getName())) {
                                                    //if (commonNames.containsKey(column.getName())) {
                                                    //    column.setReprName((String)commonNames.get(column.getName()));
                                                    //} else
                                                    if (column.getType() == AlohaRecord.COLUMN_TYPE.PK) {
                                                        column.setReprName("ID");
                                                    }
                                                }

                                                if (column.getReprName().equals(column.getName())) {
                                                    NameItem columnByModel = entitiesNames.getColumnByModel(record.getName(), column.getName());
                                                    if (columnByModel != null) {
                                                        column.setReprName(columnByModel.view);
                                                    } else if (column.isForeign()) {
                                                        column.setReprName(toViewName(column.getForeignRecord()) + "ID");
                                                    }
                                                }

                                            });
                                            if (record.isCrudFamily()) {
                                                String parentFieldName = record.getEntity().getClass().getSimpleName();
                                                if (viewColumnNames.containsKey(parentFieldName)) {
                                                    record.getColumns().forEach((column) -> {
                                                        if (column.getReprName().equals(column.getName()) && ((Map)viewColumnNames.get(parentFieldName)).containsKey(column.getName())) {
                                                            column.setReprName((String)((Map)viewColumnNames.get(parentFieldName)).get(column.getName()));
                                                        }

                                                    });
                                                }

                                                if (viewColumnNames.containsKey(record.getName())) {
                                                    record.getColumnsOfChildOrDependant().forEach((column) -> {
                                                        if (column.getReprName().equals(column.getName()) && ((Map)viewColumnNames.get(record.getName())).containsKey(column.getName())) {
                                                            column.setReprName((String)((Map)viewColumnNames.get(record.getName())).get(column.getName()));
                                                        }

                                                    });
                                                }
                                            }

                                        });
                                        List<AlohaRecord<Schema<?>, ?>> records = new ArrayList();
                                        records.addAll(ReflectiveJoinTool.records());
                                        // records.stream().sorted(Comparator.comparing(AlohaRecord::getName)).forEach((record) -> {
                                        //     System.out.println(toPrettyJsonString(record));
                                        // });
                                        // BusinessMgrContainer.dataMgts.keySet().stream().sorted().forEach((namex) -> {
                                        //     System.out.println(namex + ": " + ((BaseMgrWrapper)BusinessMgrContainer.dataMgts.get(namex)).getClass().getSimpleName());
                                        // });
                                        return;
                                    }

                                    nameInfo = (List)var6.next();
                                } while(nameInfo.isEmpty());

                                if (((String)nameInfo.get(0)).isEmpty() && nameInfo.size() >= 3) {
                                    modelName = (String)nameInfo.get(1);
                                    name = (String)nameInfo.get(2);
                                    if (table != null) {
                                        AlohaColumn column = table.columnOf(modelName);
                                        if (column == null) {
                                            if (modelName.endsWith("Id")) {
                                                String foreign = modelName.substring(0, modelName.length() - 2);
                                                if (viewNames.containsKey(foreign)) {
                                                    name = (String)viewNames.get(foreign) + "ID";
                                                }
                                            }

                                            if (name == null || name.isEmpty()) {
                                                name = modelName;
                                            }
                                        } else {
                                            if (name == null || name.isEmpty()) {
                                                if (column.isForeign()) {
                                                    name = toViewName(column.getForeignRecord()) + "ID";
                                                } else {
                                                    name = modelName;
                                                }
                                            }

                                            column.setReprName(name);
                                        }
                                    } else {
                                        if (modelName.endsWith("Id")) {
                                            String foreign = modelName.substring(0, modelName.length() - 2);
                                            if (viewNames.containsKey(foreign)) {
                                                name = (String)viewNames.get(foreign) + "ID";
                                            }
                                        }

                                        if (name == null || name.isEmpty()) {
                                            name = modelName;
                                        }
                                    }

                                    if (viewColumnNames.containsKey(tableName)) {
                                        ((Map)viewColumnNames.get(tableName)).put(modelName, name);
                                    }

                                    entitiesNames.addColumn(entityName, new NameItem(name, modelName));
                                } else if (nameInfo.size() >= 2) {
                                    modelName = (String)nameInfo.get(0);
                                    name = (String)nameInfo.get(1);
                                    entityName = name;
                                    tableName = modelName;

                                    try {
                                        table = ReflectiveJoinTool.recordOf(modelName);
                                    } catch (Exception var12) {
                                        var12.printStackTrace();
                                        table = null;
                                    }
                                }
                            }
                        }
                    }

                    nameInfo = (List)var6.next();
                } while(nameInfo.isEmpty());
            } while(((String)nameInfo.get(0)).isEmpty() && nameInfo.size() >= 3);

            if (nameInfo.size() >= 2) {
                modelName = (String)nameInfo.get(0);
                name = (String)nameInfo.get(1);
                viewNames.put(modelName, name);
                viewColumnNames.put(modelName, new HashMap());
                entityName = name;
                entitiesNames.add(new EntityName(new NameItem(name, modelName)));

                try {
                    table = ReflectiveJoinTool.recordOf(modelName);
                    if (table != null) {
                        table.setReprName(name);
                    }
                } catch (Exception var13) {
                    var13.printStackTrace();
                    table = null;
                }
            }
        }
    }
    /*
    private static void loadCommonNames(File path) throws Exception {
        commonNames = new HashMap();

        try {
            List<List<String>> names = Csv.parse(readNames(new File(path, "names-common.csv")));
            Iterator var2 = names.iterator();

            while(var2.hasNext()) {
                List<String> nameInfo = (List)var2.next();
                if (nameInfo.size() == 2) {
                    commonNames.put((String)nameInfo.get(0), (String)nameInfo.get(1));
                }
            }
        } catch (Exception var4) {
            var4.printStackTrace();
        }

    }
     */
    private static String readNames(String namesFile, ClassLoader classLoader, boolean isNameFileParameGiven) {
        byte[] BOMM_MARGIC = new byte[]{-17, -69, -65};

        try {
            byte[] bs = readAllBytesMayFromJar(namesFile, classLoader, isNameFileParameGiven);
            if (bs.length > BOMM_MARGIC.length) {
                boolean isBOMFile = true;

                for(int i = 0; i < BOMM_MARGIC.length; ++i) {
                    if (bs[i] != BOMM_MARGIC[i]) {
                        isBOMFile = false;
                        break;
                    }
                }

                if (isBOMFile) {
                    byte[] nonBOMData = new byte[bs.length - BOMM_MARGIC.length];
                    System.arraycopy(bs, BOMM_MARGIC.length, nonBOMData, 0, nonBOMData.length);
                    bs = nonBOMData;
                }
            }

            return new String(bs, StandardCharsets.UTF_8);
        } catch (Exception var5) {
            throw new RuntimeException(var5);
        }
    }

    private static
    byte[]
    readAllBytesMayFromJar(String namesFile, ClassLoader classLoader, boolean isNameFileParameGiven) throws IOException {
        try {
            return Files.readAllBytes(Path.of(namesFile));
        } catch (Exception e) {
            // Remove relative path
            final var namesFileInJar = namesFile.replaceFirst("^\\./", "");
            final var fis = classLoader.getResourceAsStream(namesFileInJar);
            if (fis == null) {
                if (isNameFileParameGiven) {
                    // If no option given, do not show error
                    System.err.println("Read resource NOT exist in classpath:" + namesFile);
                }
                return new byte[]{};
            } else {
                // System.out.println("Read resource from class path:" + namesFile);
                return fis.readAllBytes();
            }
        }
    }

    private static
    String
    toPrettyJsonString(
        AlohaRecord<?, ?> record) {

        StringBuilder sb = new StringBuilder();
        sb.append(record.getReprName());
        sb.append(",");
        sb.append(record.getName());
        sb.append(",");
        sb.append(record.getType());
        sb.append(",");
        sb.append(record.getDataMgt().getClass().getSimpleName());
        sb.append(",");
        sb.append("\n");

        for(AlohaColumn column : record.getColumns()) {
            sb.append(
                toPrettyJsonString(
                    column,
                    ""));
            sb.append("\n");
        }
        return sb.toString();
    }

    private static
    String
    toPrettyJsonString(
        AlohaColumn column,
        String prefix) {

        StringBuilder sb = new StringBuilder();
        sb.append(prefix);
        sb.append(",");
        sb.append(column.getReprName());
        sb.append(",");
        sb.append(column.getName());
        sb.append(",");
        sb.append(column.getDataType());
        sb.append(",");
        sb.append(column.getType());
        sb.append(",");
        if (column.getDeclaredClass() != null) {
            sb.append(column.getDeclaredClass().getSimpleName());
        }
        sb.append(",");
        if (column.isForeign()) {
            if (column.getForeignRecord() != null) {
                sb.append(column.getForeignRecord());
                sb.append(".");
            }
            sb.append(column.getForeignColumn());
            sb.append(",");
        }

        return sb.toString();
    }
    public static boolean isReadOnly(String entityName) {
        return getRecord(entityName).isReadOnly();
    }

    static class EntityNames {
        private List<EntityName> entities = new ArrayList();

        EntityNames() {
        }

        public void add(EntityName entity) {
            this.entities.add(entity);
        }

        public void addColumn(String entityViewName, NameItem col) {
            EntityName entity = this.getEntityByView(entityViewName);
            if (entity != null) {
                entity.addColumn(col);
            }

        }

        public EntityName getEntityByModel(String modelName) {
            Iterator var2 = this.entities.iterator();

            EntityName entity;
            do {
                if (!var2.hasNext()) {
                    return null;
                }

                entity = (EntityName)var2.next();
            } while(!entity.entity.model.equals(modelName));

            return entity;
        }

        public EntityName getEntityByView(String viewName) {
            Iterator var2 = this.entities.iterator();

            EntityName entity;
            do {
                if (!var2.hasNext()) {
                    throw new RuntimeException();
                }

                entity = (EntityName)var2.next();
            } while(!entity.entity.view.equals(viewName));

            return entity;
        }

        public NameItem getColumnByModel(String entityModelName, String colModelName) {
            EntityName entity = this.getEntityByModel(entityModelName);
            return entity == null ? null : entity.geColumnByModel(colModelName);
        }

        public NameItem getColumnByView(String entityViewName, String colViewName) {
            EntityName entity = this.getEntityByView(entityViewName);
            return entity == null ? null : entity.geColumnByView(colViewName);
        }

        public NameItem getColumnByModel(String modelName) {
            Iterator var2 = this.entities.iterator();

            NameItem col;
            do {
                if (!var2.hasNext()) {
                    throw new RuntimeException();
                }

                EntityName entity = (EntityName)var2.next();
                col = entity.geColumnByModel(modelName);
            } while(col == null);

            return col;
        }

        public NameItem getColumnByView(String viewName) {
            Iterator var2 = this.entities.iterator();

            NameItem col;
            do {
                if (!var2.hasNext()) {
                    throw new RuntimeException();
                }

                EntityName entity = (EntityName)var2.next();
                col = entity.geColumnByView(viewName);
            } while(col == null);

            return col;
        }
    }

    static class EntityName {
        private final NameItem entity;
        private final List<NameItem> columns = new ArrayList();

        public EntityName(NameItem entity) {
            this.entity = entity;
        }

        public NameItem geColumnByModel(String modelName) {
            Iterator var2 = this.columns.iterator();

            NameItem col;
            do {
                if (!var2.hasNext()) {
                    return null;
                }

                col = (NameItem)var2.next();
            } while(!col.model.equals(modelName));

            return col;
        }

        public NameItem geColumnByView(String viewName) {
            Iterator var2 = this.columns.iterator();

            NameItem col;
            do {
                if (!var2.hasNext()) {
                    throw new RuntimeException();
                }

                col = (NameItem)var2.next();
            } while(!col.view.equals(viewName));

            return col;
        }

        public void addColumn(NameItem col) {
            this.columns.add(col);
        }

        public NameItem getEntity() {
            return this.entity;
        }

        public List<NameItem> getColumns() {
            return this.columns;
        }
    }

    static class NameItem {
        private final String view;
        private final String model;

        public NameItem(String view, String model) {
            this.view = view;
            this.model = model;
        }

        public String getView() {
            return this.view;
        }

        public String getModel() {
            return this.model;
        }

        public String toString() {
            return this.model + "." + this.view;
        }
    }
}
