package aloha3.controller.tool.query.models;

import aloha.module.func.business.IMasterDataMgt;
import aloha3.module.object.record.master.spec.meta.Pivot;

import java.util.List;

class CoreRecord<E, M> extends AlohaRecord<Pivot<?>, IMasterDataMgt> {
    public CoreRecord(RECORD_TYPE type, String name, Pivot<?> entity, IMasterDataMgt dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
