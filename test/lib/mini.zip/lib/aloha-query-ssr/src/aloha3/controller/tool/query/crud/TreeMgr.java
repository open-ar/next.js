package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.object.model.read.Tree.Star;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import java.util.ArrayList;
import java.util.List;

public class TreeMgr<
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends HierarchyEntity.Of.Tree<E>> {
    private final Graph.Tree<E,H,F> masterDataMgt;

    public TreeMgr(
        Graph.Tree<E,H,F> masterDataMgt) {

        this.masterDataMgt = masterDataMgt;
    }

    public
    List<Star<F>>
    selectAllRoots() {

        return selectAllNodes(
            DateTime.YMDHMS.current());
    }

    private
    List<Star<F>>
    selectAllNodes(
        DateTime.YMDHMS at) {

        List<Star<F>> nodes = new ArrayList<>();
        GraphMgr.getAllGraphs().
            foreach(
                (coreGraph)->
                    masterDataMgt.
                        selectGraph(
                            coreGraph.rowId(),
                            DateTime.YMDHMS.current()).
                        unlessNull_(
                            (graph)-> {
                                try {
                                    masterDataMgt.
                                        createModel(
                                            graph,
                                            at).
                                        unlessNull_(
                                            nodes::add);
                                }catch (Exception e) {
                                    //do nothing
                                }
                            })
            );
        return nodes;
    }

}
