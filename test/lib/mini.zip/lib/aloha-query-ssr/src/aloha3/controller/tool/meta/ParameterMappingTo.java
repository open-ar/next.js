package aloha3.controller.tool.meta;

import aloha.module.func.Func;
import aloha.module.func.business.AbstractServiceContainer;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutableArray;
import aloha.module.object.ImmutableArray.PageKey;
import aloha.module.object.Type;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.master.Attribute;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.master.Relation;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TemporalField;
import aloha3.module.object.view.TemporalView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import javax.json.JsonValue;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

public final class ParameterMappingTo {

    public static <
        F extends AbstractField>
    String
    stringOf(
        Map<String, String> values,
        Class<F> fieldClass,
        Function<F, AbstractField.Member.Mandatory<String>> member) {

        return
            _ViewMapping.stringOf(
                values,
                fieldClass,
                member);
    }

    public static <
        F extends AbstractField>
    int
    intOf(
        Map<String, String> values,
        Class<F> fieldClass,
        Function<F, AbstractField.Member.Mandatory<Integer>> member) {

        return
            _ViewMapping.intOf(
                values,
                fieldClass,
                member);
    }

    @Deprecated
    public static <
        F extends AbstractField>
    long
    longOf(
        Map<String, String> values,
        Class<F> fieldClass,
        Function<F, AbstractField.Member.Mandatory<Long>> member) {

        return
            _ViewMapping.longOf(
                values,
                fieldClass,
                member);
    }

    @SafeVarargs
    public static <
        F extends AbstractField & Field.ofStarView<?>,
        V extends AbstractView<F>,
        B extends AbstractView.Builder<F,V,B>>
    V
    view(
        Map<String, String> values,
        B builder,
        AbstractServiceContainer<?> businessServices,
        _ViewMapping.TypeConverter.FromJsonObject<F>... typeConverters) {

        return
            _ViewMapping.fromJsonObject(
                values,
                builder,
                businessServices,
                typeConverters);
    }

    public static <
        E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    StarView.Write.Prepare<E,F>
    starView(
        Map<String, String> values,
        Class<F> fieldClass,
        AbstractServiceContainer<?> MDMs) {

        return
            _StarViewMapping.toStarView(
                values,
                fieldClass,
                MDMs);
    }
    public static <
        P extends CoreEntity,
        S extends CoreEntity,
        E extends aloha3.module.object.record.master.RelationEntity.Of<P,S>,
        F extends StarView.Relation.FieldOf<E>>
    StarView.Relation.Write.Prepare<E,F>
    relationStarView(
        Map<String, String> values,
        Class<F> fieldClass,
        AbstractServiceContainer<?> MDMs) {

        return
            _StarViewMapping.toRelationStarView(
                values,
                fieldClass,
                MDMs);
    }
    public static <
        E extends CoreEntity,
        F extends StarView.FieldOf.ForeignCore<E,A>,
        FE extends CoreEntity,
        A extends FixedAttributeEntityAFK.Of<E,FE>>
    StarView.Write.Prepare<E,F>
    starView(
        Map<String, String> values,
        Class<F> fieldClass,
        Class<A> foreignAttributeClass,
        AbstractServiceContainer<?> MDMs) {

        return
            _StarViewMapping.toStarView(
                values,
                fieldClass,
                foreignAttributeClass,
                MDMs);
    }
    @SuppressWarnings("unchecked")
    public static <
        P extends SealedPivot<?>,
        A extends AttributeEntity.Cancellable.Temporal<P,T>,
        F extends TemporalField.OfAttribute<A,T>,
        T extends Comparable<? super T>>
    TemporalView.Write.New<F>
    temporalAttributeView(
        Map<String, String> values,
        Class<F> fieldClass,
        Read<P> pivotRead,
        YMDHMS regTime) {

        return Func.apply(
            Field.instanceOf(fieldClass),
            (F field)->
                Func.apply(
                    (T)_ViewMapping.toComparable(
                        field.entity().attributeColumn().getRefType(),
                        values.get(StringUtil.decapitalize(field.entity().attributeColumn().getJavaName())),
                        Optional.of(field.entity())),
                    (T t)->
                        Func.apply(
                            Attribute.Write.create(
                                field.entity(),
                                pivotRead.rowId(),
                                t,
                                regTime),
                            attributeWrite->
                                createTemporalNew(
                                    values,
                                    field,
                                    attributeWrite))));
    }
    @SuppressWarnings("unchecked")
    private static <
        P extends SealedPivot<?>,
        A extends AttributeEntity.Cancellable.Temporal<P,T>,
        F extends TemporalField.OfAttribute<A,T>,
        T extends Comparable<? super T>>
    TemporalView.Write.New<F>
    createTemporalNew(
        Map<String, String> values,
        F field,
        Attribute.Write<A> attributeWrite) {

        return Func.
            accept(
                TemporalView.Write.New.Builder.
                    create(
                        (Class<F>)field.getClass(),
                        attributeWrite),
                builder->
                    setTemporalTimes(
                        builder,
                        values,
                        field)).
            build();
    }
    private static <
        F extends TemporalField.OfAttribute<?,?>,
        B extends AbstractView.Builder<F,?,?>>
    void
    setTemporalTimes(
        B temporalViewBuilder,
        Map<String, String> values,
        F field) {

        Func.
            accept(
                temporalViewBuilder,
                builder->
                    setTemporalTime(
                        builder,
                        values,
                        field,
                        f->f.TemporalFromTime),
                builder->
                    setTemporalTime(
                        builder,
                        values,
                        field,
                        f->f.TemporalToTime));
    }
    private static <
        F extends TemporalField.OfAttribute<?,?>>
    void
    setTemporalTime(
        AbstractView.Builder<F,?,?> builder,
        Map<String, String> values,
        F field,
        Function<F,AbstractField.TypedMember.Optional<YMDHMS>> temporalTimeMember) {

        Func.accept(
            temporalTimeMember.apply(field),
            member->
                builder.
                    setOptionalValue(
                        f->member,
                        (YMDHMS)Func.apply(
                            values.get(StringUtil.decapitalize(member.javaName())),
                            value-> value == null ? null :
                                _ViewMapping.toComparable(
                                    Type.RefType.YMDHMS,
                                    value,
                                    Optional.empty()))));
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    StarView.Write.Update<F>
    starView(
        Map<String, String> values,
        Core.Read<E> coreRead,
        Class<F> fieldClass,
        YMDHMS regTime,
        AbstractServiceContainer<?> MDMs) {

        return
            _StarViewMapping.toStarView(
                values,
                coreRead,
                fieldClass,
                regTime,
                MDMs);
    }

    public static <
        P extends SealedPivot<?>,
        A extends AttributeEntity.Cancellable.Temporal<P,T>,
        F extends TemporalField.OfAttribute<A,T>,
        T extends Comparable<? super T>>
    TemporalView.Write.Update<F>
    temporalAttributeView(
        Map<String, String> values,
        TemporalView.Read<F> currentView,
        YMDHMS regTime) {

        return Func.apply(
            currentView.field(),
            field->
                Func.apply(
                    TemporalView.Write.Update.Builder.
                        create(
                            (Class<F>)field.getClass(),
                            currentView,
                            regTime),
                    builder->
                        setTemporalTimes(
                            builder,
                            values,
                            field),
                    TemporalView.Write.Update.Builder::build));
    }
    
    @SuppressWarnings("unchecked")
    public static <
        P extends SealedPivot<?>,
        A extends AttributeEntity.Cancellable.Temporal<P,T>,
        F extends TemporalField.OfAttribute<A,T>,
        T extends Comparable<? super T>>
    void
    temporalAttributeView(
        Map<String, String> values,
        TemporalView.Read<F> currentView,
        YMDHMS regTime,
        Consumer<TemporalView.Write.New<F>> inCaseOfNew,
        Consumer<TemporalView.Write.Update<F>> inCaseOfUpdate) {

        Func.accept(
            currentView.field(),
            (Attribute.Read<A>)TemporalView.Read.temporalRoot(currentView),
            (field,attributeRead)->
                Func.accept(
                    (Class<F>)field.getClass(),
                    Attribute.Read.attributeOf(attributeRead),
                    (Class<F> fieldClass,T currentAttribute)->
                        Func.accept(
                            attributeRead.entity(),
                            toComparable(values, field, attributeRead),
                            (A entity,T toBeAttribute)->
                            {
                                if (toBeAttribute.compareTo(currentAttribute) == 0)
                                    inCaseOfUpdate.accept(
                                        Func.accept(
                                                TemporalView.Write.Update.Builder.
                                                    create(
                                                        fieldClass,
                                                        currentView,
                                                        regTime),
                                                builder->
                                                    setTemporalTimes(
                                                        builder,
                                                        values,
                                                        field)).
                                            build());
                                else
                                    inCaseOfNew.accept(
                                        createTemporalNew(
                                            values,
                                            field,
                                            Attribute.Write.
                                                create(
                                                    entity,
                                                    attributeRead.getPivotId(),
                                                    toBeAttribute,
                                                    regTime)));
                            })));
    }

    @SuppressWarnings("unchecked")
    public static <
        P extends SealedPivot<?>, 
        A extends AttributeEntity.Cancellable.Temporal<P,T>, 
        F extends TemporalField.OfAttribute<A,T>, 
        T extends Comparable<? super T>> 
    T
    toComparable(
        Map<String, String> values, 
        F field, 
        Attribute.Read<A> attributeRead) {
        
        return (T) _ViewMapping.toComparable(
            attributeRead.entity().attributeColumn().getRefType(),
            values.get(StringUtil.decapitalize(attributeRead.entity().attributeColumn().getJavaName())),
            Optional.of(field.entity()));
    }

    @SuppressWarnings("unchecked")
    public static <T extends Comparable<? super T>> T
    toComparable(
        JsonObject values, 
        AbstractField.TypedMember<T> attr) {

        // Get first value TODO a better way
        JsonValue val = values.get(StringUtil.decapitalize(attr.javaName()));
        if (val == null) {
            if (values.entrySet().size() == 1) {
                // In case only one value is passed without field name
                val = values.values().iterator().next();
            } else {
                throw new RuntimeException(attr.javaName() + " is not found in " + values);
            }
        }
        
        return (T) _ViewMapping.toComparable(
            attr.getRefType(),
            val,
            Optional.empty());
    }

    public static <
        E extends aloha3.module.object.record.master.RelationEntity<?,?>,
        F extends StarView.Relation.FieldOf<E>>
    StarView.Relation.Write.Update<F>
    relationStarView(
        Map<String, String> values,
        Relation.Read<E> relationRead,
        Class<F> fieldClass,
        YMDHMS regTime,
        AbstractServiceContainer<?> MDMs) {

        return
            _StarViewMapping.toRelationStarView(
                values,
                relationRead,
                fieldClass,
                regTime,
                MDMs);
    }

    public static <
        E extends SealedTxParent<?>,
        F extends AbstractField & TxStarView.Field<E>>
    TxStarView.Write.Prepare<E,F>
    txStarView(
        Map<String, String> values,
        Class<F> field,
        AbstractServiceContainer<?> Mgrs) {

        return
            _TxStarViewMapping.toTxStarView(
                values,
                field,
                Mgrs);
    }

    public static <
        E extends SealedTxParent<?>,
        F extends AbstractField & TxStarView.Field<E>>
    TxStarView.Write.New<F>
    txStarViewNewWithId(
        Map<String, String> values,
        Class<F> fieldClass,
        AbstractServiceContainer<?> Mgrs) {

        return
            _TxStarViewMapping.newTxStarView(
                values,
                fieldClass,
                Mgrs);
    }

    //public static <
    //    E extends SealedTxParent<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    CH extends
    //        SealedChildTx<E,?> &
    //        IAdditionalReferenceEntity<A>,
    //    A extends Schema<?>>
    //TxModel<F,CH>
    //txModel(
    //    Map<String, String> values,
    //    Class<F> fieldClass,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs) {
    //
    //    return
    //        _TxModelMapping.toTxModel(
    //            values,
    //            fieldClass,
    //            childTxClass,
    //            Mgrs);
    //}
    //
    //public static <
    //    X extends SealedTxParent<?>,
    //    F extends AbstractField & TxStarView.Field<X>,
    //    CH extends
    //        SealedChildTx<X,?> &
    //        IAdditionalReferenceEntity<AFE>,
    //    AFE extends Schema<?>,
    //    T extends Number & Comparable<? super T>>
    //TxModel<F, CH>
    //txModel(
    //    TxStarView.Write.New<F> newTxStarView,
    //    Map<String, String> values,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs) {
    //
    //    return
    //        _TxModelMapping.newTxModel(
    //            newTxStarView,
    //            values,
    //            childTxClass,
    //            Mgrs);
    //}
    //
    //public static <
    //    AFE extends Schema<?>,
    //    T extends Comparable<? super T>,
    //    CH extends ChildTx<?,?> & IAdditionalReferenceEntity<AFE> & AttributeRow<T>>
    //NonEmptyVOs<TxModel.Builder.RecordAndAttribute<AFE,T>>
    //txModelDetails(
    //    Map<String, String> values,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs) {
    //
    //    return
    //        _TxModelMapping.detailsOf(
    //            values,
    //            childTxClass,
    //            Mgrs);
    //}
    //
    //public static <
    //    E extends SealedTxParent<?>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    R>
    //R
    //apply(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<VF> variableField,
    //    Function<
    //        TxStarView.Write.Prepare<VE,VF>,
    //        R> updateCRUDFamily) {
    //
    //    return
    //        _TxStarViewMapping.apply(
    //            values,
    //            Mgrs,
    //            variableField,
    //            updateCRUDFamily);
    //}
    //
    //public static <
    //    E extends SealedTxParent<?>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    AFE extends Schema<?>,
    //    T extends Comparable<? super T>,
    //    CH extends ChildTx<Bridge<E>,?> & IAdditionalReferenceEntity<AFE> & AttributeRow<T>,
    //    R>
    //R
    //apply(
    //    Map<String, String> values,
    //    Class<VF> variableField,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs,
    //    BiFunction<
    //        TxStarView.Write.Prepare<VE,VF>,
    //        NonEmptyVOs<TxModel.Builder.RecordAndAttribute<AFE,T>>,
    //        R> updateCRUDFamily) {
    //
    //    return
    //        _TxModelMapping.apply(
    //            values,
    //            variableField,
    //            childTxClass,
    //            Mgrs,
    //            updateCRUDFamily);
    //}
    //
    //public static <
    //    E extends SealedTxParent<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    AFE extends Schema<?>,
    //    T extends Comparable<? super T>,
    //    CH extends ChildTx<Bridge<E>,?> & IAdditionalReferenceEntity<AFE> & AttributeRow<T>,
    //    R>
    //R
    //apply(
    //    Map<String, String> values,
    //    Class<F> fixedField,
    //    Class<VF> variableField,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs,
    //    TriFunction<
    //        TxStarView.Write.New<F>,
    //        TxStarView.Write.Prepare<VE,VF>,
    //        NonEmptyVOs<TxModel.Builder.RecordAndAttribute<AFE,T>>,
    //        R> createCRUDFamily) {
    //
    //    return
    //        _TxModelMapping.apply(
    //            values,
    //            fixedField,
    //            variableField,
    //            childTxClass,
    //            Mgrs,
    //            createCRUDFamily);
    //}
    //
    //@SuppressWarnings("unchecked")
    //public static <
    //    E extends SealedTxParent<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    AFE extends SealedPivot<?>,
    //    CH extends ChildTxEntityIntAFKOnly.Of<Bridge<E>,AFE>,
    //    R>
    //R
    //applyIntAFKOnly(
    //    Map<String, String> values,
    //    Class<F> fixedField,
    //    Class<VF> variableField,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs,
    //    TriFunction<
    //        TxStarView.Write.New<F>,
    //        TxStarView.Write.Prepare<VE,VF>,
    //        NonEmptyVOs<? extends Read<AFE>>,
    //        R> createCRUDFamily) {
    //
    //    return
    //        createCRUDFamily.apply(
    //            _TxStarViewMapping.newTxStarView(values,fixedField,Mgrs),
    //            _TxStarViewMapping.toVariableTxStarView(values,variableField,Mgrs),
    //            (NonEmptyVOs<? extends Read<AFE>>)
    //                _TxModelMapping.afeOnlyReads(
    //                    values,
    //                    Instance.of(childTxClass),
    //                    Mgrs));
    //}
    //
    //@SuppressWarnings("unchecked")
    //public static <
    //    E extends SealedTxParent<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    AFE extends TxKey<?>,
    //    CH extends ChildTxEntityLongAFKOnly.Of<Bridge<E>,AFE>,
    //    R>
    //R
    //applyLongAFKOnly(
    //    Map<String, String> values,
    //    Class<F> fixedField,
    //    Class<VF> variableField,
    //    Class<CH> childTxClass,
    //    AbstractServiceContainer<?> Mgrs,
    //    TriFunction<
    //        TxStarView.Write.New<F>,
    //        TxStarView.Write.Prepare<VE,VF>,
    //        NonEmptyVOs<? extends aloha3.module.object.record.transaction.read.meta.Read<AFE>>,
    //        R> createCRUDFamily) {
    //
    //    return
    //        createCRUDFamily.apply(
    //            _TxStarViewMapping.newTxStarView(values,fixedField,Mgrs),
    //            _TxStarViewMapping.toVariableTxStarView(values,variableField,Mgrs),
    //            (NonEmptyVOs<? extends aloha3.module.object.record.transaction.read.meta.Read<AFE>>)
    //                _TxModelMapping.afeOnlyReads(
    //                    values,
    //                    Instance.of(childTxClass),
    //                    Mgrs));
    //}
    //
    //public static <
    //    E extends SealedTxParent<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    R>
    //R
    //apply(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<F> fixedField,
    //    Class<VF> variableField,
    //    BiFunction<
    //        TxStarView.Write.Prepare<E, F>,
    //        TxStarView.Write.Prepare<VE,VF>,
    //        R> createCRUD) {
    //
    //    return
    //        _TxStarViewMapping.apply(
    //            values,
    //            Mgrs,
    //            fixedField,
    //            variableField,
    //            createCRUD);
    //}
    //
    //public static <
    //    E extends TxEntityIntFK.On<M>,
    //    M extends SealedPivot<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    R>
    //R
    //applyIntFK(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<F> fixedField,
    //    Class<VF> variableField,
    //    TriFunction<
    //        Read<M>,
    //        TxStarView.Write.Prepare<E, F>,
    //        TxStarView.Write.Prepare<VE,VF>,
    //        R> createCRUD) {
    //
    //    return
    //        _TxStarViewMapping.applyIntFK(
    //            values,
    //            Mgrs,
    //            fixedField,
    //            variableField,
    //            createCRUD);
    //}
    //
    //public static <
    //    E extends TxEntityIntFK.On<M>,
    //    M extends SealedPivot<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    R>
    //R
    //applyIntFK(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<F> fixedField,
    //    BiFunction<
    //        Read<M>,
    //        TxStarView.Write.Prepare<E, F>,
    //        R> doCreate) {
    //
    //    return
    //        _TxStarViewMapping.applyIntFK(
    //            values,
    //            Mgrs,
    //            fixedField,
    //            doCreate);
    //}
    //
    //public static <
    //    E extends
    //        SealedTxParent<?> &
    //        aloha.module.object.record.transaction.IForeignEntity<FE>,
    //    FE extends TxKey<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    VE extends TxEntityLongFK<? super VE,E>,
    //    VF extends AbstractField & TxStarView.Field<VE>,
    //    R>
    //R
    //applyLongFK(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<F> fixedField,
    //    Class<VF> variableField,
    //    TriFunction<
    //        aloha3.module.object.record.transaction.read.meta.Read<FE>,
    //        TxStarView.Write.Prepare<E, F>,
    //        TxStarView.Write.Prepare<VE,VF>,
    //        R> createCRUD) {
    //
    //    return
    //        _TxStarViewMapping.applyLongFK(
    //            values,
    //            Mgrs,
    //            fixedField,
    //            variableField,
    //            createCRUD);
    //}
    //
    //public static <
    //    E extends
    //        SealedTxParent<?> &
    //        aloha.module.object.record.transaction.IForeignEntity<FE>,
    //    FE extends TxKey<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    R>
    //R
    //applyLongFK(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<F> field,
    //    BiFunction<
    //        aloha3.module.object.record.transaction.read.meta.Read<FE>,
    //        TxStarView.Write.Prepare<E, F>,
    //        R> doCreate) {
    //
    //    return
    //        _TxStarViewMapping.applyLongFK(
    //            values,
    //            Mgrs,
    //            field,
    //            doCreate);
    //}
    //
    //public static <
    //    E extends
    //        SealedTxParent<?> &
    //        aloha.module.object.record.transaction.IForeignEntity<FE> &
    //        aloha.module.object.record.master.IAdditionalForeignEntity<AFE>,
    //    FE extends TxKey<?>,
    //    AFE extends SealedPivot<?>,
    //    F extends AbstractField & TxStarView.Field<E>,
    //    R>
    //R
    //applyLongFKIntAFK(
    //    Map<String, String> values,
    //    AbstractServiceContainer<?> Mgrs,
    //    Class<F> fieldClass,
    //    TriFunction<
    //        aloha3.module.object.record.transaction.read.meta.Read<FE>,
    //        Read<AFE>,
    //        TxStarView.Write.Prepare<E, F>,
    //        R> doCreate) {
    //
    //    return Func.apply(
    //        Field.instanceOf(fieldClass),
    //        field->
    //            Func.apply(
    //                _ViewMapping.
    //                    selectPivot(
    //                        values,
    //                        field.entity().getAdditionalForeignEntity(),
    //                        Mgrs),
    //                afeRead->
    //                    _TxStarViewMapping.applyLongFK(
    //                        values,
    //                        Mgrs,
    //                        fieldClass,
    //                        (feRead,prepareView)->
    //                            doCreate.
    //                                apply(
    //                                    feRead,
    //                                    afeRead,
    //                                    prepareView))));
    //}
    //
    //public static
    //<T extends Enum<? super T>>
    //QueryOption<T>
    //queryOption(
    //    Map<String, String> values,
    //    Function<String, T> stateMapper) {
    //
    //    return new QueryOption<>(
    //        searchConditions(values),
    //        pagingOption(values),
    //        stateCondition(
    //            values.get(STATE).asJsonObject(),
    //            stateMapper));
    //}
    //
    //public static
    //<T extends Enum<? super T>>
    //QueryOption<T>
    //queryOption(
    //    Map<String, String> values,
    //    Function<String, T> jsonStateMapper,
    //    StateCondition<T> givenStateCondition) {
    //
    //    return new QueryOption<>(
    //        searchConditions(values),
    //        pagingOption(values),
    //        StateCondition.merge(
    //            stateCondition(
    //                values.get(STATE).asJsonObject(),
    //                jsonStateMapper),
    //            givenStateCondition));
    //}
    //
    //public static
    //<T extends Enum<? super T>>
    //QueryOption<T>
    //queryOption(
    //    Map<String, String> values,
    //    StateCondition<T> givenStateCondition) {
    //
    //    return new QueryOption<>(
    //        searchConditions(values),
    //        pagingOption(values),
    //        givenStateCondition);
    //}
    //
    //private static
    //ImmutValues<QueryOption.SearchCondition>
    //searchConditions(Map<String, String> values) {
    //    List<QueryOption.SearchCondition> conditions = new ArrayList<>();
    //    for (JsonValue conditionValue : values.getJsonArray("conditions")) {
    //        Map<String, String> conditionObject = conditionValue.asJsonObject();
    //        int key = conditionObject.getInt("id");
    //        String value = conditionObject.getString("value");
    //        String operator = conditionObject.getString("operator");
    //        if (value != null && !value.trim().isEmpty()) {
    //            conditions.add(new QueryOption.SearchCondition(key, value, IAttributeCondition.OPERATOR.valueOf(operator)));
    //        }
    //    }
    //    return ImmutValues.of(conditions.toArray(
    //        new QueryOption.SearchCondition[0]));
    //}
    //
    //public static
    //PageKey<ImmutableArray.SIZE>
    //pagingOption(Map<String, String> values) {
    //    Map<String, String> pageOption = values.getJsonObject("paging");
    //    int page = pageOption.getInt("page");
    //    int size = pageOption.getInt("size");
    //    return getSizeOrDefaultTen(page, size);
    //}
    //
    //private static
    //<T extends Enum<? super T>>
    //StateCondition<T>
    //stateCondition(
    //    Map<String, String> values,
    //    Function<String, T> stateMapper) {
    //
    //    return StateCondition.of(
    //        includeStatesOption(values, stateMapper),
    //        excludeStatesOption(values, stateMapper));
    //}
    //
    //private static
    //<T extends Enum<? super T>>
    //ImmutValues<T>
    //includeStatesOption(
    //    Map<String, String> values,
    //    Function<String, T> stateMapper) {
    //
    //    return
    //        convertToImmutValues(
    //            values.getJsonArray("includeStates"),
    //            stateMapper);
    //}
    //
    //private static
    //<T extends Enum<? super T>>
    //ImmutValues<T>
    //excludeStatesOption(
    //    Map<String, String> values,
    //    Function<String, T> stateMapper) {
    //
    //    return
    //        convertToImmutValues(
    //            values.getJsonArray("excludeStates"),
    //            stateMapper);
    //}
    //
    //public static
    //<T extends Comparable<? super T>>
    //ImmutValues<T>
    //convertToImmutValues(
    //    JsonArray jsonArray,
    //    Function<String, T> convertToT) {
    //
    //    final var excludeStates = jsonArray.stream()
    //        .map(jsonValue -> convertToT.apply(JsonBuilder.getJsonValueString(jsonValue)))
    //        .toList();
    //    if (excludeStates.isEmpty()) {
    //        return ImmutValues.emptyInstance();
    //    }
    //    return ImmutValues.of(convertToArray(excludeStates));
    //}


    @SuppressWarnings("unchecked")
    public static <T> T[] convertToArray(List<T> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must be non-empty");
        }
        Class<?> elementType = list.get(0).getClass();
        T[] array = (T[]) java.lang.reflect.Array.newInstance(elementType, list.size());
        list.toArray(array);
        return array;
    }

    private static PageKey<ImmutableArray.SIZE>
    getSizeOrDefaultTen(int page, int size) {
        ImmutableArray.SIZE sizeEnum = ImmutableArray.SIZE.TEN;
        for (var s: ImmutableArray.SIZE.values()) {
            if (s.getAsInt() == size) {
                sizeEnum = s;
                break;
            }
        }
        if (page < 1) {
            page = 1;
        }
        int beginIndex = (page - 1) * sizeEnum.getAsInt();
        return PageKey.of(beginIndex, sizeEnum);
    }

}
