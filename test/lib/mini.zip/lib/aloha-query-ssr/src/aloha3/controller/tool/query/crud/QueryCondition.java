package aloha3.controller.tool.query.crud;

import aloha.mapping.read.IAttributeCondition;
import aloha.module.object.DateTime;
import aloha.module.object.DecimalScale;
import aloha.module.object.ImmutableArray;
import aloha.module.object.Type;
import aloha3.dml.master.Select;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.Json;
import javax.json.JsonObject;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class QueryCondition {

    public static <
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>>
    ImmutableArray<Select.SearchCriteria.ICondition<F>>
    parse(
        F field,
        String params ) {

        if (params == null || params.isEmpty())
            return ImmutableArray.emptyArray();

        return parse(
            field,
            Json.createReader(new StringReader(params)).readObject());
    }

    @SuppressWarnings(value="unchecked")
    public static <
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>>
    ImmutableArray<Select.SearchCriteria.ICondition<F>>
    parse(
        F field,
        JsonObject json ) {

        List<QueryFilter> filters = new ArrayList<>();
        json.forEach(
            (key, value)->
                filters.add(
                    parser(
                        field,
                        key,
                        value.toString().trim())));

        Select.SearchCriteria.ICondition<F>[] conditions = new  Select.SearchCriteria.ICondition[filters.size()];
        int i = 0;
        for(QueryFilter filter : filters) {
            conditions[i++] = filter.toCondition((Class<F>)field.getClass());
        }
        return ImmutableArray.of(conditions);
    }

    private static
    <E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    QueryFilter
    parser(
        F field,
        String name,
        String value) {

        Type.RefType valueType =  BusinessMgrContainer.getMemberType(field,  name);

        if (value.startsWith("\""))
            value = value.substring(1);
        if (value.endsWith("\""))
            value = value.substring(0, value.length() - 1);
        value = value.trim();

        if (value.startsWith(">="))
            return new QueryFilter(
                name,
                toMemberValue(valueType, value.substring(2)),
                IAttributeCondition.OPERATOR.GREATER_THAN_EQUAL);
        else if (value.startsWith("<="))
            return new QueryFilter(
                name,
                toMemberValue(valueType, value.substring(2)),
                IAttributeCondition.OPERATOR.LESS_THAN_EQUAL);
        else if (value.startsWith(">"))
            return new QueryFilter(
                name,
                toMemberValue(valueType, value.substring(1)),
                IAttributeCondition.OPERATOR.GREATER_THAN);
        else if (value.startsWith("<"))
            return new QueryFilter(
                name,
                toMemberValue(valueType, value.substring(1)),
                IAttributeCondition.OPERATOR.LESS_THAN);
        else if (value.startsWith("="))
            return new QueryFilter(
                name,
                toMemberValue(valueType, value.substring(1)),
                IAttributeCondition.OPERATOR.EQUAL);
        else if (value.toLowerCase().startsWith("between ")) {
            List<String> parts = new ArrayList<>();
            for (String part : value.split(" ")) {
                if (part.isEmpty())
                    continue;
                parts.add(part);
            }
            if (parts.size() == 4 && parts.get(2).equalsIgnoreCase("and") )
                return new QueryFilter(
                    name,
                    new Object[]{
                        toMemberValue(valueType, parts.get(1)),
                        toMemberValue(valueType, parts.get(3))
                    },
                    IAttributeCondition.OPERATOR.BETWEEN );
        }

        if (value.startsWith("%") && value.endsWith("%"))
            return new QueryFilter(
                name,
                value.substring(1, value.length() - 1),
                IAttributeCondition.OPERATOR.LIKE);
        else if (value.startsWith("%"))
            return new QueryFilter(
                name,
                value.substring(1),
                IAttributeCondition.OPERATOR.LIKE_END_WITH);
        else if (value.endsWith("%"))
            return new QueryFilter(
                name,
                value.substring(0, value.length() - 1),
                IAttributeCondition.OPERATOR.LIKE_START_WITH);
        else if (valueType == Type.RefType.STRING)
            return new QueryFilter(
                name,
                value,
                IAttributeCondition.OPERATOR.EQUAL_STRING);
        else if (valueType == Type.RefType.INTEGER || valueType == Type.RefType.LONG)
            return new QueryFilter(
                name,
                toMemberValue(valueType, value),
                IAttributeCondition.OPERATOR.EQUAL);
        else if (valueType == Type.RefType.YMD)
            return new QueryFilter(
                name,
                toMemberValue(valueType, value),
                IAttributeCondition.OPERATOR.EQUAL);
        else if (valueType == Type.RefType.ENUM) {
            throw new UnsupportedOperationException(field.getClass().getSimpleName() + "." + name + " : " + valueType);
        }
        throw new RuntimeException("Member Not Found by " + name + "["+valueType+"] at " + field.getClass().getName());
    }

    private static
    Comparable
    toMemberValue(
        Type.RefType valueType,
        String value) {

        switch(valueType) {
            case INTEGER:
                return Integer.valueOf(value);
            case LONG:
                return Long.valueOf(value);
            case STRING:
                return value;
            case YMD:
                return DateTime.YMD.create(Integer.parseInt(value));
            case DECIMALSCALE1:
                return DecimalScale.DecimalScale1.of(Double.parseDouble(value));
            case DECIMALSCALE2:
                return DecimalScale.DecimalScale2.of(Double.parseDouble(value));
            case DECIMALSCALE3:
                return DecimalScale.DecimalScale3.of(Double.parseDouble(value));
            case DECIMALSCALE4:
                return DecimalScale.DecimalScale4.of(Double.parseDouble(value));
            case ENUM:
                throw new IllegalArgumentException(valueType.name());
        }
        throw new IllegalArgumentException(valueType.name());
    }
}
