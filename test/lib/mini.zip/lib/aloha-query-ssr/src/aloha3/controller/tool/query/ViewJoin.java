package aloha3.controller.tool.query;

import aloha.module.object.ImmutVOs;
import aloha.module.object.NonEmptyArray;
import aloha.module.object.Type;
import aloha.module.object.record.IAdditionalReferenceEntity;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.crud.BaseMgrWrapper;
import aloha3.controller.tool.query.crud.BusinessMgrContainer;
import aloha3.controller.tool.query.crud.CoreMgrStarViewWrapper;
import aloha3.controller.tool.query.crud.DerivedTxIntAFKWrapper;
import aloha3.controller.tool.query.crud.DerivedTxLongAFKFamilyLongAFKOnlyWrapper;
import aloha3.controller.tool.query.crud.DerivedTxLongAFKWrapper;
import aloha3.controller.tool.query.crud.DerivedTxWrapper;
import aloha3.controller.tool.query.crud.RelationMgrWrapper;
import aloha3.controller.tool.query.crud.TxIntFKFamilyIntAFKWrapper;
import aloha3.controller.tool.query.crud.TxIntFKWrapper;
import aloha3.controller.tool.query.crud.TxLongFKWrapper;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildLongAFKOnlyModel;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecord;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JoinedView;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.dml.NaturalTransformation;
import aloha3.module.function.business.transaction.TxFamilyMgt;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.function.business.transaction.TxMgtUnsafe;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.master.spec.MasterColumn;
import aloha3.module.object.record.master.spec.meta.AttributeEntity;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxAttributeEntityIntAFK;
import aloha3.module.object.record.transaction.TxAttributeEntityLongAFK;
import aloha3.module.object.record.transaction.read.ChildTxIntAFK;
import aloha3.module.object.record.transaction.read.ChildTxIntAFKOnly;
import aloha3.module.object.record.transaction.read.ChildTxLongAFK;
import aloha3.module.object.record.transaction.read.ChildTxLongAFKOnly;
import aloha3.module.object.record.transaction.read.DerivedTx;
import aloha3.module.object.record.transaction.spec.TxColumn;
import aloha3.module.object.record.transaction.spec.meta.ChildTx;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TemporalView;
import aloha3.module.object.view.TxStarView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

public class ViewJoin {

    public static
    List<JoinedView>
    joinView(
        GeneralViewsQuery.ViewConnections centerView,
        Map<String, Object> params) {

        BaseMgrWrapper dataMgt = BusinessMgrContainer.
            getDataMgt(
                centerView.name);

        ImmutVOs cores = dataMgt.query();
        List<JoinedView> firstViews = toFlatViews(cores);
        List<JoinedView> result = new ArrayList<>();
        result.addAll(firstViews);
        joinView(
            cores,
            firstViews,
            centerView,
            result,
            params);

        return result;
    }

    public static
    List<JoinedView>
    joinView(
        NaturalTransformation.Relation_ functorFromRelation,
        GeneralViewsQuery.ViewConnections viewConnections,
        MasterColumn.Super.IntFK fk1OfRelation,
        MasterColumn.IntAFK.BesidesPKAndFK fk2OfRelation) {

        ImmutVOs<OneToOne> done = ImmutVOs.emptyVOs();
        for (GeneralViewsQuery.ViewConnections referrerView : viewConnections.referrerViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);
            if (nextDataMgt instanceof TxIntFKWrapper<?, ?, ?, ?, ?> wrapper) {
                done = join(
                    functorFromRelation.join(wrapper.getMgr()),
                    referrerView,
                    wrapper.getMgr().entity().column().PK(),
                    wrapper.getMgr().field());
            }
        }
        int count = 0;
        for (GeneralViewsQuery.ViewConnections relationView : viewConnections.referentViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(relationView.name);
            if (nextDataMgt instanceof CoreMgrStarViewWrapper<?,?,?> wrapper) {
                NaturalTransformation.Core_ coreFunctor;
                if ( wrapper.getCenterMember().javaName().equals(fk1OfRelation.getJavaName()))
                    coreFunctor = functorFromRelation.joinFK1(wrapper.getMgr());
                else if ( wrapper.getCenterMember().javaName().equals(fk2OfRelation.getJavaName()))
                    coreFunctor = functorFromRelation.joinFK2(wrapper.getMgr());
                else
                    throw new RuntimeException("may other star view's  (Fixed)AttributeAFK ");
                functorFromRelation = coreFunctor.liftToRelation(
                        ++count == 1 ? o2o-> ((OneToOne)o2o).left
                        : newNextToRight(1));
            }
        }
        List<JoinedView> result = new ArrayList<>();
        done.foreach(o2o->result.add(toJoinedView(o2o)));
        return result;
    }
    public static
    List<JoinedView>
    joinView(
        NaturalTransformation.Core_ functorFromCore,
        GeneralViewsQuery.ViewConnections viewConnections,
        StarView.Field coreField) {

        int count = 0;
        ImmutVOs<OneToOne> done = null;
        for (GeneralViewsQuery.ViewConnections referentView : viewConnections.referentViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referentView.name);
            if (nextDataMgt instanceof CoreMgrStarViewWrapper<?,?,?> wrapper) {
                NaturalTransformation.Core_ F =
                    functorFromCore.joinNto1(
                        attributeAFK(
                                wrapper.getMgr().field().entity(),
                                coreField),
                            wrapper.getMgr());
                functorFromCore = F.liftToCore(
                    ++count == 1 ? o2o-> ((OneToOne)o2o).left
                    : newNextToRight(count));
            }
        } // referent loop
        if (viewConnections.referrerViews.isEmpty())
            done = functorFromCore.done();

        for (GeneralViewsQuery.ViewConnections referrerView : viewConnections.referrerViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);
            if (nextDataMgt instanceof CoreMgrStarViewWrapper<?,?,?> wrapper) {

                return joinView(
                    functorFromCore.join1toN(
                        attributeAFK(
                            coreField.core(),
                            wrapper.getMgr().field()),
                        wrapper.getMgr()),
                    referrerView,
                    wrapper.getField());
            }
            if (nextDataMgt instanceof TxIntFKWrapper<?,?,?,?,?> wrapper) {
                done = join(
                    functorFromCore.join(wrapper.getMgr()),
                    referrerView,
                    wrapper.getMgr().entity().column().PK(),
                    wrapper.getMgr().field());
            }
            if (nextDataMgt instanceof DerivedTxIntAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if( wrapper.getMgr().field().entity().column().AFK().getJavaName().equals(coreField.core().PK().getJavaName()))
                    done = join(
                        functorFromCore.join1toN(wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().FK(), // FK is PK
                        wrapper.getMgr().field());
            }
        } // referrer loop
        if ( viewConnections.referentViews.isEmpty() &&
                viewConnections.referrerViews.isEmpty() )
            done = functorFromCore.done();
        List<JoinedView> result = new ArrayList<>();
        done.foreach(o2o->result.add(toJoinedView(o2o)));
        return result;
    }
    private static
    NaturalTransformation.ParentTx_.View_
    rewind(
        NaturalTransformation.ParentTx_.View_ functor,
        AtomicInteger count,
        int initCount) {

        return functor.liftToParentTxView(newNextToRight(count.get() - (initCount + 1)));
    }
    private static
    NaturalTransformation.ParentTx_.View_
    joinFurtherAsLongAsAmplificationFree(
        NaturalTransformation.ParentTx_.View_ functor,
        GeneralViewsQuery.ViewConnections viewConnections,
        TxColumn.Super.LongPK pk,
        TxStarView.Field field,
        AtomicInteger count) {

        final int initCount = count.get();
        count.incrementAndGet();
        for (GeneralViewsQuery.ViewConnections referentView : sortMasterFirst(viewConnections.referentViews)) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referentView.name);
            if (nextDataMgt instanceof CoreMgrStarViewWrapper<?, ?, ?> wrapper) {
                if (field instanceof TxStarView.FieldOf.AndIntFK<?> intFKField) {
                    if (intFKField.unsafeFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                        NaturalTransformation.Core_ G =
                            (NaturalTransformation.Core_) functor.thenFK(F ->
                                NaturalTransformation.ParentTx_.View_.joinParentFK(
                                    (NaturalTransformation.ParentTx_) F,
                                    wrapper.getMgr()));
                        functor = joinFurtherIfAny(G, referentView, count);
                        functor = rewind(functor,count,initCount);
                    }
                } // FK
                else if (field instanceof TxStarView.FieldOf.AndIntAFK<?> intAFKField) {
                    if (intAFKField.unsafeAFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                        NaturalTransformation.Core_ G =
                            (NaturalTransformation.Core_) functor.thenAFK(F ->
                                NaturalTransformation.ParentTx_.View_.joinParentAFK(
                                    (NaturalTransformation.ParentTx_) F,
                                    wrapper.getMgr()));
                        functor = joinFurtherIfAny(G, referentView, count);
                        functor = rewind(functor,count,initCount);
                    }
                }
            } // Core
            else if( nextDataMgt instanceof TxIntFKWrapper<?,?,?,?,?> wrapper) {
                if (field instanceof TxStarView.FieldOf.AndLongAFK<?> longAFKField
                        && longAFKField.unsafeAFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        (NaturalTransformation.ParentTx_.View_)
                            functor.thenAFK(F ->
                                NaturalTransformation.ParentTx_.joinViewAFK(
                                    (NaturalTransformation.ParentTx_) F,
                                    (TxMgtUnsafe.StarView_) wrapper.getMgr())),
                        referentView,
                        wrapper.getMgr().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                } else if (field.unsafeCenterMember().javaName().equals(wrapper.getCenterMember().javaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        (NaturalTransformation.ParentTx_.View_) functor.then(F->
                            NaturalTransformation.ParentTx_.joinView(
                                (NaturalTransformation.ParentTx_)F,
                                wrapper.getMgr())),
                        referentView,
                        wrapper.getMgr().field().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                }
            } // TxIntFK
            else if (nextDataMgt instanceof DerivedTxLongAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join((TxMgt.Derived.StarView) wrapper.getMgr()),
                        referentView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                }
            }
        } // referent loop
        for (GeneralViewsQuery.ViewConnections referrerView : viewConnections.referrerViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);
            if (nextDataMgt instanceof TxIntFKWrapper<?, ?, ?, ?, ?> wrapper) {
                if (field instanceof TxStarView.FieldOf.AndLongAFK<?> longAFKField
                        && longAFKField.unsafeAFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        (NaturalTransformation.ParentTx_.View_) functor.thenAFK(F ->
                            NaturalTransformation.ParentTx_.joinViewAFK(
                                (NaturalTransformation.ParentTx_) F,
                                (TxMgtUnsafe.StarView_) wrapper.getMgr())),
                        referrerView,
                        wrapper.getMgr().field().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                } else if (field.unsafeCenterMember().javaName().equals(wrapper.getCenterMember().javaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        (NaturalTransformation.ParentTx_.View_) functor.then(F->
                            NaturalTransformation.ParentTx_.join(
                                (NaturalTransformation.ParentTx_)F,
                                (TxMgtUnsafe)wrapper.getMgr())),
                        referrerView,
                        wrapper.getMgr().field().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                }
            } // TxIntFK
            if (nextDataMgt instanceof DerivedTxWrapper<?, ?, ?, ?, ?> wrapper) {
                functor = joinFurtherAsLongAsAmplificationFree(
                    functor.join(wrapper.getMgr()),
                    referrerView,
                    wrapper.getMgr().field().entity().column().FK(),
                    wrapper.getMgr().field(),
                    count);
                functor = rewind(functor,count,initCount);
            } // DerivedTx
            if (nextDataMgt instanceof DerivedTxLongAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join((TxMgt.Derived.StarView) wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                } // by PK
            } // DerivedTxLongAFK
            if (nextDataMgt instanceof DerivedTxIntAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join(wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field(),
                        count);
                    functor = rewind(functor,count,initCount);
                } // by PK
            } // DerivedTxIntAFK
        } // referrer loop
        return functor.liftToParentTxView(newNextToRight(count.get()-initCount));
    }
    private static
    ImmutVOs<OneToOne>
    join(
        NaturalTransformation.ParentTx_.View_ functor,
        GeneralViewsQuery.ViewConnections viewConnections,
        TxColumn.Super.LongPK pk,
        TxStarView.Field field) {

        AtomicInteger count = new AtomicInteger(0);
        for (GeneralViewsQuery.ViewConnections referentView : sortMasterFirst(viewConnections.referentViews)) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referentView.name);
            if (nextDataMgt instanceof CoreMgrStarViewWrapper<?,?,?> wrapper) {
                if (field instanceof TxStarView.FieldOf.AndIntAFK<?> intAFKField) {
                    if(intAFKField.unsafeAFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                        NaturalTransformation.Core_ G =
                            (NaturalTransformation.Core_) functor.thenAFK(F->
                                NaturalTransformation.ParentTx_.View_.joinParentAFK(
                                    (NaturalTransformation.ParentTx_)F,
                                    wrapper.getMgr()));
                        functor = joinFurtherIfAny(G,referentView,count);
                        functor = functor.liftToParentTxView(newNextToRight(count.get()));
                        continue;
                    }
                }
                NaturalTransformation.Core_ f =
                    functor.join(
                        txAttributeIntAFK(
                            wrapper.getMgr().field().entity().PK(),
                            field),
                        wrapper.getMgr());
                functor = f.liftToParentTxView(newNextToRight(count.incrementAndGet()));
            } // Core
            if( nextDataMgt instanceof DerivedTxIntAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (field instanceof TxStarView.FieldOf.AndLongFK<?> longFKField) {
                    if (longFKField.unsafeFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                        functor = joinFurtherAsLongAsAmplificationFree(
                            (NaturalTransformation.ParentTx_.View_)
                                functor.thenFK(F->
                                    NaturalTransformation.ParentTx_.joinView(
                                        (NaturalTransformation.ParentTx_)F,
                                        (TxMgtUnsafe.StarView_)wrapper.getMgr())),
                            referentView,
                            wrapper.getMgr().entity().column().FK(), // is PK
                            wrapper.getMgr().field(),
                            count);
                        functor = functor.liftToParentTxView(newNextToRight(count.get()));
                    }
                } // LongFK
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join(wrapper.getMgr()),
                        referentView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } // by PK/FK
            } // DerivedTxIntAFK
            if (nextDataMgt instanceof DerivedTxLongAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join(wrapper.getMgr()),
                        referentView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } // by PK/FK
            } // DerivedTxLongAFKWrapper
            if( nextDataMgt instanceof TxIntFKWrapper<?,?,?,?,?> wrapper) {
                if (field instanceof TxStarView.FieldOf.AndLongAFK<?> longAFKField
                        && longAFKField.unsafeAFK().javaName().equals(wrapper.getCenterMember().javaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        (NaturalTransformation.ParentTx_.View_)
                            functor.thenAFK(F->
                                NaturalTransformation.ParentTx_.joinViewAFK(
                                    (NaturalTransformation.ParentTx_)F,
                                    (TxMgtUnsafe.StarView_)wrapper.getMgr())),
                        referentView,
                        wrapper.getMgr().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } else if (field instanceof TxStarView.FieldOf.AndLongAFK<?> longAFKField
                        && longAFKField.unsafePK().javaName().equals(wrapper.getCenterMember().javaName())) {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        (NaturalTransformation.ParentTx_.View_)
                            functor.thenFK(F->
                                NaturalTransformation.ParentTx_.joinView(
                                    (NaturalTransformation.ParentTx_)F,
                                    (TxMgtUnsafe.StarView_)wrapper.getMgr())),
                        referentView,
                        wrapper.getMgr().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } else {
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.joinNto1(
                            txAttributeLongAFK(
                                (TxColumn.Super.LongPK<?>) wrapper.getMgr().field().entity().PK(),
                                field),
                            wrapper.getMgr()),
                        referentView,
                        wrapper.getMgr().entity().column().PK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                }
            } // TxIntFK
        } // referent loop

        AtomicInteger toReferrerCount = new AtomicInteger(viewConnections.referrerViews.size());
        for (GeneralViewsQuery.ViewConnections referrerView : sortByNumberOfReferrers(viewConnections.referrerViews)) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);

            if( nextDataMgt instanceof TxIntFKFamilyIntAFKWrapper<?,?,?,?,?,?,?,?> wrapper) {
                functor = joinFurtherIfAny(
                    functor.joinChildren((TxFamilyMgt) wrapper.getMgr()),
                    referrerView,
                    count);
                functor = functor.liftToParentTxView(newNextToRight(count.get()));
            } // TxIntFKFamilyIntAFKWrapper
            if (nextDataMgt instanceof DerivedTxLongAFKFamilyLongAFKOnlyWrapper<?,?,?,?,?,?,?,?> wrapper) {
                functor = joinFurtherIfAny(
                    functor.joinChildren((TxFamilyMgt) wrapper.getMgr()),
                    referrerView,
                    count);
                functor = functor.liftToParentTxView(newNextToRight(count.get()));
            } // DerivedTxLongAFKFamilyLongAFKOnlyWrapper
            if (nextDataMgt instanceof TxLongFKWrapper<?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().unsafeFK().javaName())) {
                    return join(
                        functor.join(wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().PK(),
                        wrapper.getMgr().field());
                }
                return join(
                    functor.join1toN(
                        txAttributeLongAFK(pk,wrapper.getMgr().field()),
                        wrapper.getMgr()),
                    referrerView,
                    wrapper.getMgr().entity().column().PK(),
                    wrapper.getMgr().field());
            }
            if (nextDataMgt instanceof DerivedTxWrapper<?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    if(viewConnections.referrerViews.size() == 1)
                        return join(
                                functor.join(wrapper.getMgr()),
                                referrerView,
                                wrapper.getMgr().entity().column().FK(),
                                wrapper.getMgr().field());
                    functor = joinFurtherAsLongAsAmplificationFree(
                            functor.join(wrapper.getMgr()),
                            referrerView,
                            wrapper.getMgr().entity().column().FK(),
                            wrapper.getMgr().field(),
                            count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } // FK
            } // DerivedTx
            if (nextDataMgt instanceof DerivedTxIntAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName())) {
                    if(viewConnections.referrerViews.size() == 1 || toReferrerCount.get() == 1)
                        return join(
                            functor.join(wrapper.getMgr()),
                            referrerView,
                            wrapper.getMgr().entity().column().FK(),
                            wrapper.getMgr().field());
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join(wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().FK(),
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } // FK
            } // DerivedTxIntAFK
            if (nextDataMgt instanceof DerivedTxLongAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                if (pk.getJavaName().equals(wrapper.getMgr().field().entity().column().AFK().getJavaName())) {
                    return join(
                        functor.join(wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field());
                } // by AFK
                if ( pk.getJavaName().equals(wrapper.getMgr().field().entity().column().FK().getJavaName()) ) {
                    if(viewConnections.referrerViews.size() == 1 || toReferrerCount.get() == 1)
                        return join(
                            functor.join((TxMgt.Derived.StarView)wrapper.getMgr()),
                            referrerView,
                            wrapper.getMgr().entity().column().FK(), // is PK
                            wrapper.getMgr().field());
                    functor = joinFurtherAsLongAsAmplificationFree(
                        functor.join((TxMgt.Derived.StarView)wrapper.getMgr()),
                        referrerView,
                        wrapper.getMgr().entity().column().FK(), // is PK
                        wrapper.getMgr().field(),
                        count);
                    functor = functor.liftToParentTxView(newNextToRight(count.get()));
                } // by PK
                toReferrerCount.decrementAndGet();
            }
        } // referrer loop
        ImmutVOs<OneToOne> done = functor.done();
        return done;
    }
    private static
    GeneralViewsQuery.ViewConnections[]
    sortMasterFirst(List<GeneralViewsQuery.ViewConnections> alphabeticalOrder) {

        GeneralViewsQuery.ViewConnections[] array = alphabeticalOrder.toArray(new GeneralViewsQuery.ViewConnections[0]);

        Arrays.sort(array,(e1,e2)-> {
            if ( BusinessMgrContainer.getDataMgt(e1.name).isMaster()
                    && !BusinessMgrContainer.getDataMgt(e2.name).isMaster())
                return -1;
            if ( !BusinessMgrContainer.getDataMgt(e1.name).isMaster()
                    && BusinessMgrContainer.getDataMgt(e2.name).isMaster())
                    return 1;
            else
                return 0;
        });
        return array;
    }
    private static
    GeneralViewsQuery.ViewConnections[]
    sortByNumberOfReferrers(List<GeneralViewsQuery.ViewConnections> alphabeticalOrder) {

        GeneralViewsQuery.ViewConnections[] array = alphabeticalOrder.toArray(new GeneralViewsQuery.ViewConnections[0]);

        Arrays.sort(array,(e1,e2)-> {
            if ( !BusinessMgrContainer.getDataMgt(e1.name).isMaster()
                    && !BusinessMgrContainer.getDataMgt(e2.name).isMaster()) {

                int diff_referrer = e1.referrerViews.size() - e2.referrerViews.size();
                if (diff_referrer != 0) return diff_referrer;
                return e1.referentViews.size() - e2.referentViews.size();
            }
            if ( !BusinessMgrContainer.getDataMgt(e1.name).isMaster()
                    && BusinessMgrContainer.getDataMgt(e2.name).isMaster())
                return Integer.MAX_VALUE;
            else
                return e1.referrerViews.size() > e2.referrerViews.size() ?
                    -e1.referrerViews.size() : -e2.referrerViews.size();
        });
        return array;
    }
    private static
    NaturalTransformation.ParentTx_.View_
    joinFurtherIfAny(
        NaturalTransformation.Core_ functor,
        GeneralViewsQuery.ViewConnections viewConnections,
        AtomicInteger countOfLiftToParentTx) {

        final int initCount = countOfLiftToParentTx.get();
        countOfLiftToParentTx.incrementAndGet();

        for (GeneralViewsQuery.ViewConnections referrerView : viewConnections.referrerViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);
            if (nextDataMgt instanceof RelationMgrWrapper<?,?,?,?,?> wrapper) {
                System.out.println("Joining " + wrapper.getName() + " lead to amplification ");
            }
        }
        for (GeneralViewsQuery.ViewConnections referentView : viewConnections.referentViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
        }
        return functor.liftToParentTxView(newNextToRight(countOfLiftToParentTx.get() - initCount));
    }
    private static
    NaturalTransformation.ParentTx_.View_
    joinFurtherIfAny(
        NaturalTransformation.ChildTx_ functor,
        GeneralViewsQuery.ViewConnections viewConnections,
        AtomicInteger countOfLiftToParentTx) {

        final int initCount = countOfLiftToParentTx.get();
        countOfLiftToParentTx.incrementAndGet();

        for (GeneralViewsQuery.ViewConnections referrerView : viewConnections.referrerViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);
            if (nextDataMgt instanceof DerivedTxLongAFKFamilyLongAFKOnlyWrapper<?,?,?,?,?,?,?,?> wrapper) {
                NaturalTransformation.ChildTx_ G =
                    functor.joinChildren((TxFamilyMgt.ChildLongAFKOnly)wrapper.getMgr());
                return joinFurtherIfAny(G,referrerView,countOfLiftToParentTx);
            }
        } // referrer loop
        for (GeneralViewsQuery.ViewConnections referentView : sortMasterFirst(viewConnections.referentViews)) {
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referentView.name);
            if (nextDataMgt instanceof CoreMgrStarViewWrapper<?,?,?> wrapper) {
                NaturalTransformation.Core_ G =
                    (NaturalTransformation.Core_)
                        functor.thenAFK(F-> NaturalTransformation.ChildTx_.join(
                            (NaturalTransformation.ChildTx_)F,
                            wrapper.getMgr()));
                countOfLiftToParentTx.incrementAndGet(); // for child
                functor = G.liftToChild(newNextToRight(1));
            }
            if (nextDataMgt instanceof TxIntFKFamilyIntAFKWrapper<?,?,?,?,?,?,?,?> wrapper) {
                NaturalTransformation.ChildTx_ G =
                    (NaturalTransformation.ChildTx_)
                        functor.thenAFK(F-> NaturalTransformation.ChildTx_.joinChildren(
                            (NaturalTransformation.ChildTx_)F,
                            (TxFamilyMgt)wrapper.getMgr()));
                return joinFurtherIfAny(G,referentView,countOfLiftToParentTx);
            }
            if (nextDataMgt instanceof DerivedTxLongAFKWrapper<?,?,?,?,?,?,?> wrapper) {
                NaturalTransformation.ParentTx_ F =
                    functor.joinParent((TxFamilyMgt) wrapper.getMgr());
                NaturalTransformation.ParentTx_.View_ G = NaturalTransformation.ParentTx_.
                    joinAttributes(
                        F,
                        wrapper.getMgr());
                countOfLiftToParentTx.incrementAndGet(); // for attributes
                return joinFurtherAsLongAsAmplificationFree(
                    G,
                    referentView,
                    wrapper.getMgr().field().entity().column().FK(),
                    wrapper.getMgr().field(),
                    countOfLiftToParentTx);
            }
            if (nextDataMgt instanceof TxIntFKWrapper<?,?,?,?,?> wrapper) {
                NaturalTransformation.ParentTx_ F =
                        functor.joinParent((TxFamilyMgt) wrapper.getMgr());
                NaturalTransformation.ParentTx_.View_ G = NaturalTransformation.ParentTx_.
                    joinAttributes(
                        F,
                        wrapper.getMgr());
                countOfLiftToParentTx.incrementAndGet(); // for attributes
                return joinFurtherAsLongAsAmplificationFree(
                    G,
                    referentView,
                    wrapper.getMgr().field().entity().column().PK(),
                    wrapper.getMgr().field(),
                    countOfLiftToParentTx);
            }
        } // referent loop
        return functor.liftToParentTxView(newNextToRight(countOfLiftToParentTx.get()-initCount));
    }
    @SuppressWarnings("rawtypes")
    private static
    Function
    newNextToRight(int moreThanEqualToOne) {

        final AtomicReference<Function<OneToOne,Object>> f = new AtomicReference<>();
        f.set((OneToOne o2o)->o2o.left);
        for(int i = 1 ; i < moreThanEqualToOne ; i++) {
            Function<OneToOne,Object> current = f.get();
            Function<OneToOne,Object> next = t->((OneToOne)current.apply(t)).left;
            f.set(next);
        }
        Function<OneToOne,Object> function = f.get();
        return t->((OneToOne)function.apply((OneToOne)t)).right;
        /*
        return switch(moreThanEqualToOne) {
            case 1-> t-> ((OneToOne)((OneToOne)t).left).right;
            case 2-> t-> ((OneToOne)((OneToOne)((OneToOne)t).left).left).right;
            case 3-> t-> ((OneToOne)((OneToOne)((OneToOne)((OneToOne)t).left).left).left).right;
            default -> throw new IllegalStateException("Unexpected value: " + moreThanEqualToOne);
        };
         */
    }
    @SuppressWarnings("unchecked")
    private static<
        X extends SealedTxParent<?>,
        A extends TxAttributeEntityLongAFK.Of<X,?>>
    Class<A>
    txAttributeLongAFK(
        TxColumn.Super.LongPK<?> pk,
        TxStarView.Field<X> field) {

        return (Class<A>)
            field.attributeMembers().
                findOrException(
                    m->m.javaName().equals(
                        pk.getJavaName())).
                attributeEntity();
    }
    @SuppressWarnings("unchecked")
    private static<
        X extends SealedTxParent<?>,
        A extends TxAttributeEntityIntAFK.Of<X,?>>
    Class<A>
    txAttributeIntAFK(
        IColumn pk,
        TxStarView.Field<?> field) {

        return (Class<A>)
            field.attributeMembers().
                findOrException(
                    m->m.javaName().equals(
                        pk.getJavaName())).
                attributeEntity();
    }
    private static <
        E extends Pivot<?>,
        F2 extends Field.ofStarView.Around.Pivot<E2>,
        E2 extends Pivot<?>,
        A extends
            AttributeEntity.One<E,Integer,?> &
            IAdditionalReferenceEntity<E2>>
    Class<A>
    attributeAFK(E toPivot, F2 ofField) {
        return (Class<A>)
            ofField.attributeMembers().
                findOrException(
                    m->m.javaName().equals(
                        toPivot.PK().getJavaName())).
                attributeEntity();
    }
    private static <
        E extends Pivot<?>,
        F2 extends Field.ofStarView.Around.Pivot<E2>,
        E2 extends Pivot<?>,
        A2 extends
            AttributeEntity.One<E2,Integer,?> &
            IAdditionalReferenceEntity<E>>
    Class<A2>
    attributeAFK(F2 ofField, E toPivot) {
        return (Class<A2>)
            ofField.attributeMembers().
                findOrException(
                    m->m.javaName().equals(
                        toPivot.PK().getJavaName())).
                attributeEntity();
    }
    private static
    JoinedView
    toJoinedView(OneToOne o2o) {

        List<JoinedView> joinedViews = new ArrayList<>();
        collectFlatViewInto(joinedViews,o2o);
        JoinedView result = new JoinedView();
        for(JoinedView v : joinedViews) {
            result.copyFrom(v);
        }
        return result;
    }
    private static
    void
    collectFlatViewInto(List<JoinedView> flatViews, OneToOne<?,?> o2o) {
        if ( o2o.left instanceof OneToOne<?,?> left )
            collectFlatViewInto(flatViews,left);
        if ( o2o.left instanceof AbstractView<?> view )
            flatViews.add(toFlatView(view));
        if ( o2o.right instanceof OneToOne<?,?> right )
            collectFlatViewInto(flatViews,right);
        if ( o2o.right instanceof AbstractView<?> view )
            flatViews.add(toFlatView(view));
        if ( o2o.left instanceof ChildTx<?,?> child )
            flatViews.add(toFlatView(child));
        if ( o2o.right instanceof ChildTx<?,?> child )
            flatViews.add(toFlatView(child));
    }
    private static
    JoinedView
    toFlatView(AbstractView<?> view) {

        if ( view instanceof StarView.Read<?> coreView )
            return JsonUtils.toJson(coreView);
        if ( view instanceof TxStarView.Read<?> txView )
            return JsonUtils.toJson(txView);
        if ( view instanceof StarView.Relation.Read<?> relationView )
            return JsonUtils.toJson(relationView);
        throw new RuntimeException("Unknown Type:" + view.getClass().getName());
    }

    private static
    JoinedView
    toFlatView(ChildTx<?,?> child) {

        if ( child instanceof ChildTxIntAFK txChildIntAFK )
            return JsonUtils.toFlatView(txChildIntAFK);
        if ( child instanceof ChildTxLongAFK txChildLongAFK )
            return JsonUtils.toFlatView(txChildLongAFK);
        if ( child instanceof ChildTxIntAFKOnly txChildIntAFKOnly )
            return JsonUtils.toFlatView(txChildIntAFKOnly);
        if ( child instanceof ChildTxLongAFKOnly txChildLongAFKOnly )
            return JsonUtils.toFlatView(txChildLongAFKOnly);
        throw new RuntimeException("Unknown Type:" + child.getClass().getName());
    }

    public static
    List<JoinedView>
    joinView(
        ImmutVOs views,
        List<JoinedView> nodes,
        GeneralViewsQuery.ViewConnections conntentors,
        List<JoinedView> result,
        Map<String, Object> params) {

        for (GeneralViewsQuery.ViewConnections relationView : conntentors.referentViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {

            AlohaColumn joinColumn =
                relationView.link.isPresent() ?
                relationView.link.get() :
                ViewMgr.getJoinColumn(conntentors.name, relationView.name);
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(relationView.name);
            if (nextDataMgt == null) {
                System.out.println("The Next DataMgt not be found!" );
                System.out.println("[joinView] relationView:" + relationView.name);
                System.out.println("[joinView] name:" + conntentors.name + " referent:" + relationView.name + " joinColumn:" + joinColumn);

                joinView(
                    views,
                    nodes,
                    relationView,
                    result,
                    Collections.EMPTY_MAP);
                continue;
            }
            if (joinColumn.getDataType() == Type.RefType.INTEGER) {

                final var joinKeys = JsonUtils.getIntKeys(nodes, joinColumn.getName());
                ImmutVOs immutVOs = nextDataMgt.queryByPKs(DistinctIds.toIntIDList(joinKeys));
                List<JoinedView> refViewList = toFlatViews(immutVOs);

                JsonUtils.joinByInt(
                    result,
                    joinColumn.getName(),
                    // joinColumn.getForeignColumn(),
                    refViewList,
                    nextDataMgt.getCenterMember().javaName());

                joinView(
                    immutVOs,
                    refViewList,
                    relationView,
                    result,
                    Collections.EMPTY_MAP);

            } else if (joinColumn.getDataType() == Type.RefType.LONG) {

                NonEmptyArray.DistinctLongs joinKeys = JsonUtils.getLongKeys(nodes, joinColumn.getName());
                ImmutVOs immutVOs = nextDataMgt.queryByPKs(DistinctIds.toLongIDList(joinKeys));
                List<JoinedView> refViewList = toFlatViews(immutVOs);

                JsonUtils.joinByLong(
                    result,
                    refViewList,
                    joinColumn.getName());

                joinView(
                    immutVOs,
                    refViewList,
                    relationView,
                    result,
                    Collections.EMPTY_MAP);
            }
        }

        for (GeneralViewsQuery.ViewConnections referrerView : conntentors.referrerViews.toArray(new GeneralViewsQuery.ViewConnections[0])) {


            AlohaColumn joinColumn = ViewMgr.getJoinColumn(
                ViewMgr.toViewModelName(referrerView.name),
                conntentors.name);
            BaseMgrWrapper nextDataMgt = BusinessMgrContainer.getDataMgt(referrerView.name);
            if (nextDataMgt == null) {
                System.out.println("The Next DataMgt not be found" );
                System.out.println("[joinView] relationView:" + referrerView.name);
                System.out.println("[joinView] joinColumn:" + joinColumn.getName()
                    + " getForeignRecord:" + joinColumn.getForeignRecord()
                    + " getForeignColumn:" + joinColumn.getForeignColumn()
                );
                if (ViewMgr.isTxChildEntity(referrerView.name)) {
                    nextDataMgt = BusinessMgrContainer.getDataMgt(conntentors.name);
                    List<JoinedView> refViewList = new ArrayList<>();
                    List vos = new ArrayList();
                    for(int i  = 0; i < views.size(); i++) {
                        TxIntFKChildIntAFKModel model = (TxIntFKChildIntAFKModel)views.eltAt(i);
                        System.out.println("model " + model.children().eltAt(0) );
                        model.children().foreach(
                            v->vos.add(v));
                        refViewList.addAll(toFlatViews(model.children()));
                    }

                    JsonUtils.joinByLong(
                        result,
                        refViewList,
                        nextDataMgt.getCenterMember().javaName());

                    joinView(
                        ImmutVOs.create(vos),
                        refViewList,
                        referrerView,
                        result,
                        Collections.EMPTY_MAP);
                } else {
                    joinView(
                        views,
                        nodes,
                        referrerView,
                        result,
                        Collections.EMPTY_MAP);
                }
                continue;
            }
            if (joinColumn.getDataType() == Type.RefType.INTEGER) {

                ImmutVOs immutVOs = nextDataMgt.
                    queryByIntAFKs(
                        views,
                        joinColumn.getForeignColumn(),
                        params);
                List<JoinedView> refViewList = toFlatViews(immutVOs);

                JsonUtils.joinByInt(
                    result,
                    // joinColumn.getName(),
                    joinColumn.getForeignColumn(),
                    refViewList,
                    joinColumn.getName());

                joinView(
                    immutVOs,
                    refViewList,
                    referrerView,
                    result,
                    params);

            } else if (joinColumn.getDataType() == Type.RefType.LONG) {
                // DerivedLongAFKの場合、LONG型でも、FKとして扱う
                ImmutVOs immutVOs = joinColumn.getType() == AlohaRecord.COLUMN_TYPE.FK ?
                    nextDataMgt.queryByFKs(
                        views,
                        params)
                    :
                    nextDataMgt.queryByLongAFKs(
                        views,
                        joinColumn.getName(),
                        params);
                List<JoinedView> refViewList = toFlatViews(immutVOs);

                JsonUtils.joinByLong(
                    result,
                    refViewList,
                    joinColumn.getName());

                joinView(
                    immutVOs,
                    refViewList,
                    referrerView,
                    result,
                    params);
            }
        }

        return result;
    }

    public static
    List<JoinedView>
    toFlatViews(
        ImmutVOs immutVOs) {

        if (immutVOs.empty())
            return Collections.EMPTY_LIST;

        List<JoinedView> refViewList = null;
        if (immutVOs.eltAt(0) instanceof TemporalView.Read)
            return JsonUtils.toJsonFromTemporalViews(immutVOs);
        else if (immutVOs.eltAt(0) instanceof StarView.Read)
            return JsonUtils.toJsonFromStarViews(immutVOs);
        else if (immutVOs.eltAt(0) instanceof StarView.Relation)
            return JsonUtils.toJsonsFromRelationViews(immutVOs);
        else if (immutVOs.eltAt(0) instanceof TxStarView.Read)
            return JsonUtils.toJsonsFromTxStarViews(immutVOs);
        else if (immutVOs.eltAt(0) instanceof OneToOne)
            return JsonUtils.toJsonFromCrudViews(immutVOs);
        else if (immutVOs.eltAt(0) instanceof TxIntFKChildIntAFKModel)
            return JsonUtils.toJsonFromTxChildModels(immutVOs);
        else if (immutVOs.eltAt(0) instanceof TxIntFKChildLongAFKOnlyModel<?,?,?,?,?,?>)
            return JsonUtils.toJsonFromTxChildLongAFKOnlyModels(immutVOs);
        else if (immutVOs.eltAt(0) instanceof ChildTxIntAFK)
            return JsonUtils.toJsonFromTxChildIntAFKs(immutVOs);
        else if (immutVOs.eltAt(0) instanceof DerivedTx)
            return JsonUtils.toJsonFromDerivedTxs(immutVOs);

        throw new IllegalArgumentException(immutVOs.eltAt(0).getClass().getName());
    }
}
