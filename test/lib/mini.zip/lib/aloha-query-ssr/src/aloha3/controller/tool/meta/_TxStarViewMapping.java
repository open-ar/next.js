package aloha3.controller.tool.meta;

import aloha.module.Assert;
import aloha.module.func.Func;
import aloha.module.func.business.AbstractServiceContainer;
import aloha.module.func.business.ITransactionMgt;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.record.master.IForeignEntity;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.master.PivotReadMgt;
import aloha3.module.function.business.master.coc.WorkFlowField;
import aloha3.module.function.business.transaction.TxIntFKMgt;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.function.business.transaction.coc.FlowableWriteMgt;
import aloha3.module.object.model.read.AbstractGraph;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.transaction.ChildTxIntAFK;
import aloha3.module.object.record.meta.transaction.ChildTxIntAFKOnly;
import aloha3.module.object.record.meta.transaction.ChildTxLongAFK;
import aloha3.module.object.record.meta.transaction.ChildTxLongAFKOnly;
import aloha3.module.object.record.meta.transaction.DerivedTx;
import aloha3.module.object.record.meta.transaction.DerivedTxIntAFK;
import aloha3.module.object.record.meta.transaction.DerivedTxLongAFK;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly;
import aloha3.module.object.record.transaction.DerivedTxEntity;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedChildTx;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeFlowable;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.record.transaction.write.meta.Write;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import java.util.Map;
import java.util.function.BiFunction;

import static aloha3.controller.tool.meta.MappingConst.WORK_FLOW_ID;

class _TxStarViewMapping {

    static <
        E extends SealedTxParent<?>,
        F extends AbstractField & TxStarView.Field<E>>
    TxStarView.Write.Prepare<E,F>
    toTxStarView(
        Map<String, String> jsonObject,
        Class<F> field,
        AbstractServiceContainer<?> Mgrs) {

        return
            Func.apply(
                TxStarView.Write.Prepare.Builder.create(field),
                builder->
                    _ViewMapping.fromJsonObject(
                        jsonObject,
                        builder,
                        Mgrs),
                TxStarView.Write.Prepare.Builder::build);
    }

    static <
        E extends SealedTxParent<?>,
        F extends AbstractField & TxStarView.Field<E>>
    TxStarView.Write.New<F>
    newTxStarView(
        Map<String, String> jsonObject,
        Class<F> fieldClass,
        AbstractServiceContainer<?> Mgrs) {

        return
            Func.apply(
                toTxStarView(jsonObject,fieldClass,Mgrs),
                createTxWrite(jsonObject, Field.instanceOf(fieldClass).entity(),Mgrs),
                TxStarView.Write.Prepare::create);
    }
    
    static <E extends TxEntityIntFK.On<M> & MakeFlowable<E>, M extends Pivot<?>, F extends TxStarView.FieldOf.AndIntFK<E>> 
    TxIntFK.Read<E>
    newTxStarViewWithTransition(
        Map<String, String> jsonObject,
        Class<F> fieldClass,
        AbstractServiceContainer<?> Mgrs) {

        TxIntFK.Write txWrite = (TxIntFK.Write)createTxWrite(jsonObject, Field.instanceOf(fieldClass).entity(), Mgrs);

        final E txEntity = Field.instanceOf(fieldClass).entity() ;

        TxStarView.Write.Prepare view = toTxStarView(jsonObject,fieldClass,Mgrs);

        StarView.Read<WorkFlowField> workFlowRead =
            WorkFlow.workFlowOf(
                WorkFlow.selectWorkFlowByPK(Integer.parseInt(jsonObject.get(WORK_FLOW_ID))).mustNonNull(),
                DateTime.YMDHMS.current()).
            mustNonNull();

        final FlowableWriteMgt.TxIntFK mgr = (FlowableWriteMgt.TxIntFK)findTxMgr(
            txEntity,
            Mgrs);

        return WorkFlow.saveFlowable(
            txWrite,
            view,
            AbstractGraph::node, // First State
            workFlowRead,
            mgr);
    }

    @SuppressWarnings({"unchecked"})
    static <
        E extends SealedTxParent<?>>
    Write<E>
    createTxWrite(
        Map<String, String> jsonObject,
        E txEntity,
        AbstractServiceContainer<?> Mgrs) {

        if ( txEntity instanceof TxEntityIntFK.On e )
            return createTxIntFKWrite(jsonObject,e,Mgrs);
        else if ( txEntity instanceof TxEntityIntFK.Msec e)
            return createTxIntFKMsecWrite(jsonObject,e,Mgrs);
        else if ( txEntity instanceof TxEntityLongFK e)
            return createTxLongTxWrite(jsonObject,e,Mgrs);
        else if ( txEntity instanceof DerivedTxEntity e)
            return createDerivedTxWrite(jsonObject,e,Mgrs);
        else if ( txEntity instanceof DerivedTxEntityIntAFK e)
            return createDerivedTxWrite(jsonObject,e,Mgrs);
        else if ( txEntity instanceof DerivedTxEntityLongAFK e)
            return createDerivedTxWrite(jsonObject,e,Mgrs);
        else
            throw new RuntimeException("Not Supported tx: " + txEntity.getClass().getName());
    }

    private static <
        X extends TxKey<?>,
        E extends TxEntityLongFK<? super E,X>>
    TxLongFK.Write<E>
    createTxLongTxWrite(
        Map<String, String> jsonObject,
        E e,
        AbstractServiceContainer<?> Mgrs) {

        return
            Func.apply(
                findTxMgr(e,Mgrs),
                jsonObject.get(
                    StringUtil.decapitalize(
                        e.getForeignKeyColumn().getJavaName())),
                (txMgr,txId)->
                    Func.apply(
                        selectForeignTx(
                            e,
                            StringUtil.safeLong(txId),
                            Mgrs),
                        foreignRead->
                            TxLongFK.Write.
                                create(
                                    e,
                                    foreignRead,
                                    getTxTimeOrCurrent(jsonObject))));
    }

    private static <
        X extends TxKey<?>,
        E extends DerivedTxEntity<?,X>>
    DerivedTx.Write<E>
    createDerivedTxWrite(
        Map<String, String> jsonObject,
        E e,
        AbstractServiceContainer<?> Mgrs) {

        return
            Func.apply(
                findTxMgr(e,Mgrs),
                jsonObject.get(
                    StringUtil.decapitalize(
                        e.getForeignKeyColumn().getJavaName())),
                (txMgr,txId)->
                    Func.apply(
                        selectForeignTx(
                            e,
                            StringUtil.safeLong(txId),
                            Mgrs),
                        foreignRead->
                            DerivedTx.Write.
                                create(
                                    e,
                                    foreignRead,
                                    getTxTimeOrCurrent(jsonObject))));
    }

    private static <
        X extends TxKey<?>,
        A extends Pivot<?>,
        E extends DerivedTxEntityIntAFK<?,X, A>>
    DerivedTxIntAFK.Write<E>
    createDerivedTxWrite(
        Map<String, String> jsonObject,
        E e,
        AbstractServiceContainer<?> Mgrs) {

        final aloha3.module.object.record.transaction.read.meta.Read<X> fkTx = 
            selectForeignTx(
                e,
                StringUtil.safeLong(
                    jsonObject.get(
                        StringUtil.decapitalize(
                            e.getForeignKeyColumn().getJavaName()))),
                Mgrs);
        final aloha3.module.object.record.master.read.meta.Read<A> afkMaster = 
            selectForeignMaster(
                e,
                StringUtil.safeInt(
                    jsonObject.get(
                        StringUtil.decapitalize(
                            e.getAdditionalForeignKeyColumn().getJavaName()))),
                Mgrs);
        
        return
            aloha3.module.object.record.meta.transaction.DerivedTxIntAFK.Write.
                create(
                    e,
                    fkTx,
                    afkMaster,
                    getTxTimeOrCurrent(jsonObject));
    }
    
    private static <
        X extends TxKey<?>,
        A extends TxKey<?>,
        E extends DerivedTxEntityLongAFK<?,X, A>>
    DerivedTxLongAFK.Write<E>
    createDerivedTxWrite(
        Map<String, String> jsonObject,
        E e,
        AbstractServiceContainer<?> Mgrs) {

        final aloha3.module.object.record.transaction.read.meta.Read<X> fkTx = 
            selectForeignTx(
                e,
                StringUtil.safeLong(
                    jsonObject.get(
                        StringUtil.decapitalize(
                            e.getForeignKeyColumn().getJavaName()))),
                Mgrs);
        final aloha3.module.object.record.transaction.read.meta.Read<A> afkTx = 
            selectAFKTx(
                e,
                StringUtil.safeLong(
                    jsonObject.get(
                        StringUtil.decapitalize(
                            e.getAdditionalForeignKeyColumn().getJavaName()))),
                Mgrs);
        
        return
            aloha3.module.object.record.meta.transaction.DerivedTxLongAFK.Write.
                create(
                    e,
                    fkTx,
                    afkTx,
                    getTxTimeOrCurrent(jsonObject));
    }
    
    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends TxEntityLongFK<? super E,X>>
    Read<X>
    selectForeignTx(
        E e,
        long foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getForeignEntity()),
                x-> {
                    if ( x instanceof SealedChildTx ch )
                        return selectChildOf(ch,foreignTxId);
                    if ( x instanceof SealedTxParent<?> p)
                        return findTxMgr(p,Mgrs).selectTx(foreignTxId).mustNonNull();
                    throw new RuntimeException("Unknown Type" + x.getClass().getName());
                });
    }

    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends DerivedTxEntity<?,X>>
    Read<X>
    selectForeignTx(
        E e,
        long foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getForeignEntity()),
                x-> {
                    if ( x instanceof SealedChildTx ch )
                        return selectChildOf(ch,foreignTxId);
                    if ( x instanceof SealedTxParent<?> p)
                        return findTxMgr(p,Mgrs).selectTx(foreignTxId).mustNonNull();
                    throw new RuntimeException("Unknown Type" + x.getClass().getName());
                });
    }


    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends aloha3.module.object.record.transaction.spec.DerivedTxEntityIntAFK<?,X, ?>>
    Read<X>
    selectForeignTx(
        E e,
        long foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getForeignEntity()),
                x-> {
                    if ( x instanceof SealedChildTx ch )
                        return selectChildOf(ch,foreignTxId);
                    if ( x instanceof SealedTxParent<?> p)
                        return findTxMgr(p,Mgrs).selectTx(foreignTxId).mustNonNull();
                    throw new RuntimeException("Unknown Type" + x.getClass().getName());
                });
    }
    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends aloha3.module.object.record.transaction.spec.DerivedTxEntityLongAFK<?,X, ?>>
    Read<X>
    selectForeignTx(
        E e,
        long foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getForeignEntity()),
                x-> {
                    if ( x instanceof SealedChildTx ch )
                        return selectChildOf(ch,foreignTxId);
                    if ( x instanceof SealedTxParent<?> p)
                        return findTxMgr(p,Mgrs).selectTx(foreignTxId).mustNonNull();
                    throw new RuntimeException("Unknown Type" + x.getClass().getName());
                });
    }

    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends aloha3.module.object.record.transaction.spec.DerivedTxEntityLongAFK<?,?,X>>
    Read<X>
    selectAFKTx(
        E e,
        long foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getAdditionalForeignEntity()),
                x-> {
                    if ( x instanceof SealedChildTx ch )
                        return selectChildOf(ch,foreignTxId);
                    if ( x instanceof SealedTxParent<?> p)
                        return findTxMgr(p,Mgrs).selectTx(foreignTxId).mustNonNull();
                    throw new RuntimeException("Unknown Type" + x.getClass().getName());
                });
    }


    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends DerivedTxEntityIntAFK<?,X,?>>
    Read<X>
    selectAFKMaster(
        E e,
        int foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getAdditionalForeignEntity()),
                x-> {
                    final var mgr = _ViewMapping.findPivotMgr(
                        (Class)x.getClass(),
                        Mgrs);
                    return mgr.selectPivotByPK(foreignTxId).mustNonNull();
                });
    }
    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        E extends DerivedTxEntityLongAFK<?,X,?>>
    Read<X>
    selectAFK(
        E e,
        long foreignTxId,
        AbstractServiceContainer<?> Mgrs) {

        return (Read<X>)
            Func.apply(
                Instance.of(e.getForeignEntity()),
                x-> {
                    if ( x instanceof SealedChildTx ch )
                        return selectChildOf(ch,foreignTxId);
                    if ( x instanceof SealedTxParent<?> p)
                        return findTxMgr(p,Mgrs).selectTx(foreignTxId).mustNonNull();
                    throw new RuntimeException("Unknown Type" + x.getClass().getName());
                });
    }

    @SuppressWarnings("unchecked")
    private static <
        X extends TxKey<?>,
        M extends Pivot<?>,
        E extends DerivedTxEntityIntAFK<?,X,M>>
    aloha3.module.object.record.master.read.meta.Read<M>
    selectForeignMaster(
        E e,
        int foreignMasterId,
        AbstractServiceContainer<?> Mgrs) {

        return (aloha3.module.object.record.master.read.meta.Read)
            Func.apply(
                Instance.of(e.getAdditionalForeignEntity()),
                x-> {
                    return _ViewMapping.findPivotMgr(
                        (Class)e.getAdditionalForeignEntity(),
                        Mgrs).selectPivotByPK(foreignMasterId).mustNonNull();
                });
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private static <
        CH extends SealedChildTx<?,?>>
    Read<CH>
    selectChildOf(CH ch, long pkValue) {

        if ( ch instanceof ChildTxEntityIntAFK.Of e)
            return
                mustUnique(
                    Query.select(
                        (aloha3.module.object.record.meta.transaction.read.ChildTxIntAFK.Criteria)
                            ChildTxIntAFK.Read.createCriteria(e).andPrimaryKey(e,pkValue)));
        if ( ch instanceof ChildTxEntityIntAFKOnly.Of e)
            return
                mustUnique(
                    Query.select(
                        (aloha3.module.object.record.meta.transaction.read.ChildTxIntAFKOnly.Criteria)
                            ChildTxIntAFKOnly.Read.createCriteria(e).andPrimaryKey(e,pkValue)));
        if ( ch instanceof ChildTxEntityLongAFK.Of e)
            return
                mustUnique(
                    Query.select(
                        (aloha3.module.object.record.meta.transaction.read.ChildTxLongAFK.Criteria)
                            ChildTxLongAFK.Read.createCriteria(e).andPrimaryKey(e,pkValue)));
        if ( ch instanceof ChildTxEntityLongAFKOnly.Of e)
            return
                mustUnique(
                    Query.select(
                        (aloha3.module.object.record.meta.transaction.read.ChildTxLongAFKOnly.Criteria)
                            ChildTxLongAFKOnly.Read.createCriteria(e).andPrimaryKey(e,pkValue)));
        else throw new RuntimeException("never");
    }

    private static <
        CH extends SealedChildTx<?,?>>
    Read<CH>
    mustUnique(ImmutVOs<Read<CH>> vos) {

        return Assert.mustUnique(vos).mustNonNull();
    }

    @SuppressWarnings("unchecked")
    private static <
        E extends TxEntityIntFK.On<M>,
        M extends SealedPivot<?>>
    Write<E>
    createTxIntFKWrite(
        Map<String, String> jsonObject,
        E txEntity,
        AbstractServiceContainer<?> Mgrs) {

        return
            createTxIntFKWrite(
                jsonObject,
                txEntity,
                Mgrs,
                (pivotRead,txMgr)->
                    ((TxIntFKMgt<E,M>)txMgr).
                        create(
                            pivotRead,
                            getTxTimeOrCurrent(jsonObject)));
    }

    private static
    DateTime.YMDHMS
    getTxTimeOrCurrent(
        Map<String, String> jsonObject) {

        if (
            jsonObject.containsKey(MappingConst.TX_TIME) &&
                Long.parseLong(jsonObject.get(MappingConst.TX_TIME)) > 0) {
            return
                DateTime.YMDHMS.create(
                    Long.parseLong(jsonObject.get(MappingConst.TX_TIME)));
        } else {
            return DateTime.YMDHMS.current();
        }
    }

    private static
    DateTime.YMDHMSMSEC
    getTxTimeMsecOrCurrent(
        Map<String, String> jsonObject) {

        if (
            jsonObject.containsKey(MappingConst.TX_TIME) &&
                Long.parseLong(jsonObject.get(MappingConst.TX_TIME)) > 0) {
            return
                DateTime.YMDHMSMSEC.create(
                    Long.parseLong(jsonObject.get(MappingConst.TX_TIME)));
        } else {
            return DateTime.YMDHMSMSEC.current();
        }
    }

    @SuppressWarnings("unchecked")
    private static <
        E extends TxEntityIntFK.Msec<M>,
        M extends SealedPivot<?>>
    Write<E>
    createTxIntFKMsecWrite(
        Map<String, String> jsonObject,
        E txEntity,
        AbstractServiceContainer<?> Mgrs) {

        return
            createTxIntFKWrite(
                jsonObject,
                txEntity,
                Mgrs,
                (pivotRead,txMgr)->
                    ((TxIntFKMgt.Msec<M,E>)txMgr).
                        create(
                            pivotRead,
                            getTxTimeMsecOrCurrent(jsonObject)));
    }

    private static <
        E extends SealedTxParent<?> & IForeignEntity<M>,
        M extends SealedPivot<?>>
    Write<E>
    createTxIntFKWrite(
        Map<String, String> jsonObject,
        E txEntity,
        AbstractServiceContainer<?> Mgrs,
        BiFunction<
            aloha3.module.object.record.master.read.meta.Read<M>,
            TxMgt<E,?>,
            Write<E>> createTxWrite) {

        return
            Func.apply(
                findPivotMgr(txEntity,Mgrs),
                jsonObject.get(StringUtil.decapitalize(txEntity.getForeignKeyColumn().getJavaName())),
                (pivotMgr,pivotId)->
                    pivotMgr.
                        selectPivotByPK(Integer.parseInt(pivotId)).
                        apply(
                            pivotRead->
                                Func.apply(
                                    findTxMgr(
                                        txEntity,
                                        Mgrs),
                                    txMgr->
                                        createTxWrite.apply(
                                            pivotRead,
                                            txMgr)),
                            ()->{
                                throw new RuntimeException(
                                    "Not Found by Pivot from " + txEntity.getTABLE()
                                        + " by pk=" + pivotId);}));
    }

    private static <
        X extends SealedTxParent<?> & IForeignEntity<M>,
        M extends SealedPivot<?>>
    PivotReadMgt<M,?>
    findPivotMgr(
        X txEntity,
        AbstractServiceContainer<?> Mgrs) {

        return
            _ViewMapping.findPivotMgr(
                txEntity.getForeignEntity(),
                Mgrs);
    }

    @SuppressWarnings("unchecked")
    static <
        E extends SealedTxParent<?>,
        R extends Read.TxTime<E>>
    TxMgt<E,R>
    findTxMgr(
        E txEntity,
        AbstractServiceContainer<?> Mgrs) {

        for(ITransactionMgt txm : Mgrs.allTxM()) {
            if ( txm instanceof TxMgt.StarView<?,?,?> mgr
                && mgr.field().entity() == txEntity ) {
                return (TxMgt<E,R>)mgr;
            }
        }
        throw new RuntimeException("No TxM found by + " + txEntity.getClass().getName());
    }

    @SuppressWarnings("unchecked")
    static <
        E extends SealedTxParent<?>,
        R extends Read.TxTime<E>>
    TxMgt<E,R>
    findTxMgr(
        Class<E> txClass,
        AbstractServiceContainer<?> Mgrs) {

        for(ITransactionMgt txm : Mgrs.allTxM()) {
            if ( txm instanceof TxMgt.StarView<?,?,?> mgr
                && mgr.entity().getClass() == txClass ) {
                return (TxMgt<E,R>)mgr;
            }
        }
        throw new RuntimeException("No TxM found by + " + txClass.getName());
    }
}
