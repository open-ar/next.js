package aloha3.controller.tool.query.models;

import aloha.module.func.business.ITransactionMgt;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;

import java.util.List;

class TxRecord<E, M> extends AlohaRecord<TxEntity<?>, ITransactionMgt> {
    public TxRecord(RECORD_TYPE type, String name, TxEntity<?> entity, ITransactionMgt dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
