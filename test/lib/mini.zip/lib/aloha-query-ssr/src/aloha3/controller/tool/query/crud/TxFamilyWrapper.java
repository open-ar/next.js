package aloha3.controller.tool.query.crud;

public interface TxFamilyWrapper {
    String parentName();
}
