package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.coc.generic.Bridge;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TxIntFKFamilyIntAFKCRUDWrapper <
    X extends TxEntityIntFK.On<FK> & MakeCancellable<X>,
    F extends TxStarView.FieldOf.AndIntFK<X>,
    M extends TxIntFKMgr.StarView<X,FK,F>,
    FK extends CoreEntity,
    VX extends TxEntityLongFK.On<X>,
    VF extends TxStarView.FieldOf.AndLongFK<VX>,
    CH extends ChildTxEntityIntAFK.Of<Bridge<X>,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>,
    T extends TxIntFKChildIntAFKModel<X,FK,F,?,CM,CV, OneToOne<TxStarView.Read<F>, TxStarView.Read<VF>>>>
    extends BaseMgrWrapper<T, Long, Integer> {

    private final  String name;
    private final  F field;
    private final  VF vField;
    private final  CRUD.Family.ChildIntAFK<X,F,M,VX,VF,CH> mgr;
    private final  M txMainMgr;
    private final String childAfkName;
    private final String childValueName;

    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final Class<CV> childValueType;

    public TxIntFKFamilyIntAFKCRUDWrapper(
        String name,
        F field,
        VF vField,
        Class<CH> childRecord,
        Class<CM> childAfkRecordType,
        Class<CV> childValueType,
        CRUD.Family.ChildIntAFK<X,F,M,VX,VF,CH> mgr,
        M txMainMgr) {

        this.name = name;
        this.field = field;
        this.vField = vField;
        this.mgr = mgr;
        this.childRecord = childRecord;
        this.childAfkRecordType = childAfkRecordType;
        this.childValueType = childValueType;
        this.txMainMgr = txMainMgr;

        this.childAfkName = childAfkRecordType.getSimpleName() + "Id";
        this.childValueName = childRecord.getDeclaredFields()[0].getName();
    }

    @Override
    public Object getMgr() {
        return this.txMainMgr;
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public Object register(JsonObject json) {

        String foreignEntity = txMainMgr.foreignEntity().getClass().getSimpleName();
        int fkId = Integer.valueOf(json.getString(foreignEntity + "Id"));
        MayNullVO<StarView.Read<StarView.FieldOf<FK>>> foreign = GenericSearch.queryMasterViewByPK(foreignEntity, fkId);
        if (foreign.apply((v)->false, ()->true))
            return -1L;

        TxStarView.Write.Prepare<X, F> fixAttribures = setValues(
            json,
            field,
            TxStarView.Write.Prepare.Builder.
                create(
                    field.getClass())).
                build();

        TxStarView.Write.Prepare<VX, VF> variableAttr = setValues(
            json,
            vField,
            TxStarView.Write.Prepare.Builder.
                create(
                    vField.getClass())).
            build();

        JsonArray items = json.getJsonArray("child");
        List<Tuple.Pair
            <Read<CM>,
                CV>> lineItemsMore = new ArrayList<>();

        for(int i = 0; i < items.size(); i++) {
            JsonObject item = items.getJsonObject(i);
            int afkId = Integer.valueOf(item.getString(afkAttributeName()));
            CV value = null;
            if (childValueType == Integer.class) {
                value = (CV)Integer.valueOf(item.getString(valueAttributeName()));
            } else if (childValueType == String.class) {
                value = (CV)item.getString(valueAttributeName());
            }
            Core.Read<CM> afk = GenericSearch.queryMasterViewByPK(afkEntityName(), afkId).mustNonNull().coreRead();
            lineItemsMore.add(Tuple.Pair.of(afk, value));
        }

        Tuple.Pair
            <Read<CM>,
                CV> first = lineItemsMore.get(0);
        Tuple.Pair
            <Read<CM>,
                CV>[] others;
        if (lineItemsMore.size() > 1)
            others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new Tuple.Pair[0]);
        else
            others = new Tuple.Pair[0];

        return register(
            foreign.mustNonNull(),
            fixAttribures,
            variableAttr,
            first,
            others);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public void update(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json,  getCenterMember().javaName());
        if (targetId == null)
            return;

        TxStarView.Write.Prepare<VX, VF> variableAttr = setValues(
            json,
            vField,
            TxStarView.Write.Prepare.Builder.
                create(
                    vField.getClass())).
            build();

        JsonArray items = json.getJsonArray("child");
        List<Tuple.Pair
            <Read<CM>,
                CV>> lineItemsMore = new ArrayList<>();

        for(int i = 0; i < items.size(); i++) {
            JsonObject item = items.getJsonObject(i);
            int afkId = Integer.valueOf(item.getString(afkAttributeName()));
            CV value = null;
            if (childValueType == Integer.class) {
                value = (CV)Integer.valueOf(item.getString(valueAttributeName()));
            } else if (childValueType == String.class) {
                value = (CV)item.getString(valueAttributeName());
            }
            Core.Read<CM> afk = GenericSearch.queryMasterViewByPK(afkEntityName(), afkId).mustNonNull().coreRead();
            lineItemsMore.add(Tuple.Pair.of(afk, value));
        }

        Tuple.Pair
            <Read<CM>,
                CV> first = lineItemsMore.get(0);
        Tuple.Pair
            <Read<CM>,
                CV>[] others;
        if (lineItemsMore.size() > 1)
            others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new Tuple.Pair[0]);
        else
            others = new Tuple.Pair[0];

        update(
            targetId,
            variableAttr,
            first,
            others);

    }

    @Override
    public void delete(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json,  getCenterMember().javaName());
        if (targetId == null)
            return;
        delete(targetId);
    }

    @Override
    public MayNullVO<T> queryByPK(Long id) {
        return null;
    }

    @Override
    public ImmutVOs<T> query() {

        //aloha3.module.object.model.read.TxModel.ChildIntAFK.toFlat(model).
        List<T> result = new ArrayList<>();

        queryTxs().
            foreach(
                (tx)->
                    mgr.
                        readChildren(
                            tx).
                        unlessNull_(
                            (model)-> {
                                TxIntFKChildIntAFKModel of = TxIntFKChildIntAFKModel.of(
                                    mgr.readParent((aloha3.module.object.record.transaction.read.meta.Read.TxTime<X>) tx).mustNonNull(),
                                    (aloha3.module.object.model.read.TxModel.ChildIntAFK) model);
                                result.add((T)of);
                            }));
        return ImmutVOs.create(result);
    }

    @Override
    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        List<T> result = new ArrayList<>();
        ImmutVOs<TxIntFK.Read<X>> txs = txMainMgr.selectTxs(DistinctIds.toLongIDs(pkIDs));
        txs.foreach(
            (tx)->
                mgr.
                    readChildren(
                        tx).
                    unlessNull_(
                        (model)-> {
                            TxIntFKChildIntAFKModel of = TxIntFKChildIntAFKModel.of(
                                mgr.readParent(tx).mustNonNull(),
                                (aloha3.module.object.model.read.TxModel.ChildIntAFK) model);
                            result.add((T)of);
                        }));
        return ImmutVOs.create(result);
    }

    @Override
    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {

        return queryByFKViews(fkViews, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKViews(
        ImmutVOs<StarView.Read<StarView.FieldOf<FK>>> foreigns,
        Map<String, Object> params) {

        if (params.containsKey("from") && params.containsKey("to")) {
            return queryByFKAndBetween(
                foreigns,
                (DateTime.YMDHMS) params.get("from"),
                (DateTime.YMDHMS) params.get("to"));
        }

        List<T> result = new ArrayList<>();
        foreigns.foreach(
            (foreignCore)->
                txMainMgr.
                    selectTxsByFK(
                        foreignCore.coreRead()).
                    foreach(
                        (tx)->
                            mgr.
                            readChildren(
                                tx).
                                unlessNull_(
                                    (model)-> {
                                        TxIntFKChildIntAFKModel of = TxIntFKChildIntAFKModel.of(
                                            mgr.readParent(tx).mustNonNull(),
                                            (aloha3.module.object.model.read.TxModel.ChildIntAFK) model);
                                        result.add((T)of);
                                    })));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKAndBetween(
        ImmutVOs<StarView.Read<StarView.FieldOf<FK>>> fkViews,
        DateTime.YMDHMS from,
        DateTime.YMDHMS to) {

        List<T> result = new ArrayList<>();
        fkViews.
            foreach(
                (fk)->
                    txMainMgr.
                        createViews(
                            fk.coreRead(),
                            from,
                            to).
                        foreach(
                            (txView)->
                                mgr.
                                    readChildren(
                                        txView.txRead()).
                                    unlessNull_(
                                        (model)-> {
                                            TxIntFKChildIntAFKModel of = TxIntFKChildIntAFKModel.of(
                                                mgr.readParent(txView.txRead()).mustNonNull(),
                                                (aloha3.module.object.model.read.TxModel.ChildIntAFK) model);
                                            result.add((T)of);
                                        })));
        return ImmutVOs.create(result);
    }

    @Override
    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {

        return null;
    }

    @Override
    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return null;
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory>  members = getMandatoryAttributeMembers(field);
        members.add(0, txMainMgr.field().unsafeFK());
        members.addAll(getMandatoryAttributeMembers(vField));
        return members;
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        List<AbstractField.Member.Optional>  members = getOptionalAttributeMembers(field);
        members.addAll(getOptionalAttributeMembers(vField));
        return members;
    }

    @SuppressWarnings(value="rawtype")
    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return txMainMgr.field().unsafeCenterMember();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {
        return (Class<F>)field.getClass();
    }

    @Override
    public
    boolean
    isCRUD() {
        return true;
    }

    @Override
    public
    boolean
    isFamily() {
        return true;
    }

    public
    String
    itemName() {

        return childRecord.getSimpleName();
    }

    public
    String
    afkEntityName() {

        return childAfkRecordType.getSimpleName();
    }

    public
    String
    afkAttributeName() {

        return childAfkName;
    }

    public
    String
    valueAttributeName() {

        return childValueName;
    }

    @SuppressWarnings("unchecked")
    private
    long
    register(
        StarView.Read<StarView.FieldOf<FK>> foreign,
        TxStarView.Write.Prepare<X, F> fixAttribures,
        TxStarView.Write.Prepare<VX, VF> variableAttr,
        Tuple.Pair<Read<CM>, CV> atLeastOneLineItem,
        Tuple.Pair<Read<CM>, CV>... lineItemsMore) {

        List<TxModel.Builder.RecordAndAttribute<CM,CV>> mores = new ArrayList<>();
        for(Tuple.Pair<Read<CM>, CV> lineItemMore : lineItemsMore )
            mores.add(
                TxModel.Builder.RecordAndAttribute.of(
                    lineItemMore.getT1(),
                    lineItemMore.getT2()));

        Persist.Value<? extends aloha3.module.object.record.transaction.read.meta.Read<X>> value =
            CRUD.Family.ChildIntAFK.create(
                mgr,
                fixAttribures,
                (txMgr, txTime) -> txMainMgr.
                    create(
                        foreign.coreRead(),
                        txTime),
                variableAttr,
                (NonEmptyVOs<TxModel.Builder.RecordAndAttribute<CM,CV>>)
                    NonEmptyVOs.of(
                        TxModel.Builder.RecordAndAttribute.of(
                            atLeastOneLineItem.getT1(),
                            atLeastOneLineItem.getT2())).
                    append(
                        NonEmptyVOs.of(mores)));

        return value.get().getTxId();
    }

    private
    long
    update(
        Long id,
        TxStarView.Write.Prepare<VX, VF> variableAttr,
        Tuple.Pair<Read<CM>, CV> atLeastOneLineItem,
        Tuple.Pair<Read<CM>, CV>... lineItemsMore) {

        return txMainMgr.
            createView(
                id).
            apply(
                view->
                    modify(
                        TxStarView.Read.txIntFKReadOf(view),
                        variableAttr,
                        atLeastOneLineItem,
                        lineItemsMore),
                ()->-1L);
    }

    private
    long
    modify(
        TxIntFK.Read<X> cart,
        TxStarView.Write.Prepare<VX, VF> variableAttr,
        Tuple.Pair<Read<CM>, CV> atLeastOneLineItem,
        Tuple.Pair<Read<CM>, CV>... lineItemsMore) {

        List<TxModel.Builder.RecordAndAttribute<CM,CV>> mores = new ArrayList<>();
        for(Tuple.Pair<Read<CM>, CV> lineItemMore : lineItemsMore )
            mores.add(
                TxModel.Builder.RecordAndAttribute.of(
                    lineItemMore.getT1(),
                    lineItemMore.getT2()));

        return CRUD.Family.ChildIntAFK.
            update(
                mgr,
                cart,
                variableAttr,
                (NonEmptyVOs<TxModel.Builder.RecordAndAttribute<CM,CV>>)
                    NonEmptyVOs.of(
                        TxModel.Builder.RecordAndAttribute.of(
                            atLeastOneLineItem.getT1(),
                            atLeastOneLineItem.getT2())).
                    append(
                        NonEmptyVOs.of(mores)),
                DateTime.YMDHMS.current()).
            get();
    }

    private
    void
    delete(
        Long id) {

        txMainMgr.
            selectTx(
                id).
            unlessNull_(
                (tx)->mgr.delete(tx));
    }

    private MayNullVO<StarView.Read<StarView.FieldOf<FK>>>
    getForeign(
        int foreignId) {

        return  GenericSearch.queryMasterViewByPK(txMainMgr.foreignEntity().getClass().getSimpleName(), foreignId);
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
            return Query.select(TxIntFK.Read.createCriteria(this.field.entity()));
    }

    @Override
    public ImmutVOs<? extends Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

}
