package aloha3.controller.query;

import aloha.concurrent.pattern.ParallelFor;
import aloha.module.func.Func;
import aloha3.controller.Server;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.tool.rollback.PointInTimeRecovery;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.Set;

import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_SHARED_MENU_HTML;
import static aloha3.controller.query.IndexController.INDEX_STREAM;

public class RollbackController {

    public static final String MAIN_TEMPLATE = "rollback.html";

    public static void 
    handle(
        Request request,
        Response response) {
        
        Func.accept(
            response.chunked(),
            (body) -> Func.accept(
                Context.Builder.create().
                    add("mainViewContent", "rollback").
                    add("title", "ロールバック").
                    add("withoutLeftMenu", true).
                    addStream(
                        new Stream(
                            body,
                            request,
                            () -> {})).
                    build(),
                body.asWriter(),
                (ctx, writer) ->
                    Func.accept(
                        engine().processThrottled(INDEX_STREAM, ctx),
                        throttled ->
                        {
                            while (!throttled.isFinished()) {
                                throttled.process(128, writer);
                            }
                        },
                        _ -> body.end())));
    }

    public record Stream(
        ChunkedResponseMessageBody body,
        Request request,
        Runnable afterQuery) implements Runnable {
        @Override
        public void run() {

            ParallelFor.exec(
                () ->
                    body.addSlot(
                        "shared-menu",
                        engine().process(
                            COMPONENTS_SHARED_MENU_HTML,
                            Context.Builder.create().build())),
                () ->
                    body.addSlot(
                        "rollback",
                        engine().process(
                            MAIN_TEMPLATE,
                            Set.of("style", "rollback-container"),
                            Context.Builder.create().
                                add("successMessage", request.unlessNull("successMessage", "")).
                                add("errorMessage", request.unlessNull("errorMessage", "")).
                                build())));

            afterQuery.run();
        }
    }

    public static void 
    handlePost(
        Request request,
        Response response) {
        
        request.param("rollbackDate").unlessNull_(
            (rollbackDateString) ->
                StringUtil.toYMDHMS(rollbackDateString).
                    unlessNull_(
                        rollbackTo -> Server.
                            resources().
                            forEach(resource ->
                                PointInTimeRecovery.
                                    rollback(resource, rollbackTo))));
        response.redirectTo(request.target());
    }
}
