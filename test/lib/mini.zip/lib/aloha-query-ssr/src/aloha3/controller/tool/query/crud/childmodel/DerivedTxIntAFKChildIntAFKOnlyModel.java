package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DerivedTxIntAFKChildIntAFKOnlyModel<
    E extends DerivedTxEntityIntAFK<?, X, M>,
    X extends SealedTxParent<?>,
    M extends aloha3.module.object.record.master.spec.CoreEntity,
    F extends TxStarView.FieldOf.AndIntAFK<E>,
    CH extends ChildTxEntityIntAFKOnly.Of<E,CM>,
    CM extends CoreEntity,
    PV extends ValueObject>
    extends TxChildModel {

    private final PV parent;
    private final TxModel.ChildIntAFKOnly<F, CH> model;
    private final ImmutVOs<View<TxModel.ChildIntAFKOnly.FlatField<F>>> flatViews;
    private final List<AbstractField.Member.Mandatory> childMembers;

    private DerivedTxIntAFKChildIntAFKOnlyModel(
        PV parent,
        TxModel.ChildIntAFKOnly<F, CH> model) {

        this.parent = parent;
        this.model = model;

        flatViews = model.toFlat();
        childMembers = new ArrayList<>();
        if (!flatViews.empty()) {
            View<TxModel.ChildIntAFKOnly.FlatField<F>> flatFieldView = flatViews.firstUnlessEmpty();
            childMembers.add(
                flatFieldView.field().PK());
            childMembers.add(
                flatFieldView.field().AFK());
        }
    }

    public TxModel.ChildIntAFKOnly<F, CH> getModel() {
        return model;
    }

    public ImmutVOs<View<TxModel.ChildIntAFKOnly.FlatField<F>>> getFlatViews() {
        return flatViews;
    }

    public
    List<AbstractField.Member.Mandatory>
    childMembers() {
        return childMembers;
    }

    public
    List<AbstractField.Member.Optional>
    childOptionalMembers() {
        return Collections.EMPTY_LIST;
    }

    public
    PV
    view() {
        return parent;
    }

    public
    ImmutVOs<? extends Read<CH>>
    children() {
        return model.children();
    }

    public static <
    E extends DerivedTxEntityIntAFK<?, X, M>,
    X extends SealedTxParent<?>,
    M extends aloha3.module.object.record.master.spec.CoreEntity,
    F extends TxStarView.FieldOf.AndIntAFK<E>,
    CH extends ChildTxEntityIntAFKOnly.Of<E,CM>,
    CM extends CoreEntity,
    PV extends TxStarView.Read<F>>
    DerivedTxIntAFKChildIntAFKOnlyModel<E,X,M,F,CH,CM, PV>
    of(
        TxModel.ChildIntAFKOnly<F, CH> model) {

        return new DerivedTxIntAFKChildIntAFKOnlyModel( model.view(), model ) ;
    }

    public static <
    E extends DerivedTxEntityIntAFK<?, X, M>,
    X extends SealedTxParent<?>,
    M extends aloha3.module.object.record.master.spec.CoreEntity,
    F extends TxStarView.FieldOf.AndIntAFK<E>,
    CH extends ChildTxEntityIntAFKOnly.Of<E,CM>,
    CM extends CoreEntity,
    PV extends OneToOne<TxStarView.Read<F>, ?>>
    DerivedTxIntAFKChildIntAFKOnlyModel<E,X,M,F,CH,CM, PV>
    of(
        OneToOne<TxStarView.Read<F>, ?> parent,
        TxModel.ChildIntAFKOnly<F, CH> model) {

        return new DerivedTxIntAFKChildIntAFKOnlyModel( parent, model ) ;
    }

}