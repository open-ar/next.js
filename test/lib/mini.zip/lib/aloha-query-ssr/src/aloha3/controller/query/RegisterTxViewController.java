package aloha3.controller.query;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.module.object.view.View;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.HashSet;
import java.util.Set;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_NAV_MENU_HTML;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;

public class RegisterTxViewController extends AbstractController {
    public static final RegisterTxViewController INSTANCE = new RegisterTxViewController();

    public static final String MAIN_TEMPLATE = "registerTxView.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Tx";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void 
    handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST");
        request.unlessNull_(
            PIVOT,
            pivot ->
                AlohaCRUD.saveStarView(
                    pivot,
                    request.keyValues(),
                    container()));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Long::valueOf, 0L)),
                INSTANCE::getWelcomeContent
            );
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                COMPONENTS_NAV_MENU_HTML,
                Context.Builder.create().
                    add("title", "トランザクション一覧").
                    add(AlohaMeta.getTxPivots(container())).
                    build());
        }
    }

    private static
    String
    renderMainContent(
        String pivot,
        OperationType operation,
        Long id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        Logger.INFO.log("registerTxView: " + viewInfo);
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("views", AlohaCRUD.starViews(pivot, container())).
            add("views_fk",
                getFkPivot(viewInfo).unlessNull(
                    fkPivot ->
                        AlohaCRUD.starViews(fkPivot, container()),
                    ImmutVOs.emptyVOs()));

        getAfkPivots(viewInfo).foreach(
            afkPivot -> {
                var views = AlohaCRUD.starViews(afkPivot, container());
                context.add("views_afk_" + StringUtil.decapitalize(afkPivot) + "Id", views);
            });

        AlohaCRUD.starView(id, pivot, container()).unlessNull_(
            view ->
                context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static
    MayNullValue<String>
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
            view ->
                view.
                    mandatoryValue(f->f.IsFK) == Bool.TRUE).
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static
    ImmutValues<String>
    getAfkPivots(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            filter(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE).
            toValues(view->
                view.optionalValue(f->f.Foreign).assertNonNull());
    }
}
