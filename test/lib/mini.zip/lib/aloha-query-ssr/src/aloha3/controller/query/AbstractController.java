package aloha3.controller.query;

import aloha.concurrent.pattern.ParallelFor;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_SHARED_MENU_HTML;

abstract class AbstractController {

    public static void handle(Request request, aloha3.tool.stream.response.Response response, AbstractController controller) {
        aloha.module.func.Func.accept(
            response.chunked(),
            (body) -> aloha.module.func.Func.accept(
                Context.Builder.create().
                    add("mainViewContent", controller.getMainViewContentSlot()).
                    add("title", controller.getTitle()).
                    addStream(
                        controller.createStream(request, body, () -> {})
                    ).
                    build(),
                body.asWriter(),
                (ctx, writer) ->
                    aloha.module.func.Func.accept(
                        aloha3.controller.Server.engine().processThrottled(aloha3.controller.query.IndexController.INDEX_STREAM, ctx),
                        throttled -> {
                            while (!throttled.isFinished()) {
                                throttled.process(128, writer);
                            }
                        },
                        _ -> body.end())));
    }

    protected abstract String getMainTemplate();

    protected abstract String getTitle();

    protected abstract Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery);

    /**
     * 主コンテンツスロット名（必要に応じてオーバーライド）
     */
    protected String getMainViewContentSlot() {
        return "mainViewContent-welcome";
    }

    /**
     * ウェルカムコンテンツ（必要に応じてオーバーライド）
     */
    protected String getWelcomeContent() {
        return "<p>Please select menu.</p>";
    }

    /**
     * ナビメニュー用テンプレート（必要に応じてオーバーライド）
     */
    protected String getNavMenuTemplate() {
        return aloha3.controller.query.IndexController.COMPONENTS_NAV_MENU_HTML;
    }

    /**
     * 共通Stream実装。サブクラスはgenMainViewContentとrenderNavMenuのみ実装すればよい
     */
    public abstract static class StreamBase implements Runnable {
        protected final Request request;
        protected final ChunkedResponseMessageBody body;
        protected final Runnable afterQuery;

        public StreamBase(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            this.request = request;
            this.body = body;
            this.afterQuery = afterQuery;
        }

        @Override
        public void run() {
            ParallelFor.exec(
                () ->
                    body.addSlot(
                        "shared-menu",
                        engine().process(
                            COMPONENTS_SHARED_MENU_HTML,
                            Context.Builder.create().build())),
                () ->
                    body.addSlot(
                        getNavMenuSlot(),
                        renderNavMenu()),
                () ->
                    body.addSlot(
                        getMainViewContentSlot(),
                        genMainViewContent(request)));
            afterQuery.run();
        }

        /**
         * ナビメニュースロット名（必要に応じてオーバーライド）
         */
        protected String getNavMenuSlot() {
            return "nav-menu";
        }

        /**
         * メインコンテンツ生成（サブクラスで実装）
         */
        protected abstract String genMainViewContent(Request request);

        /**
         * ナビメニュー生成（サブクラスで実装）
         */
        protected abstract String renderNavMenu();

        /**
         * 主コンテンツスロット名（必要に応じてオーバーライド）
         */
        protected String getMainViewContentSlot() {
            return "mainViewContent-welcome";
        }
    }
}

