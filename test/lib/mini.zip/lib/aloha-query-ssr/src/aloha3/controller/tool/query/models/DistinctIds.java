package aloha3.controller.tool.query.models;

import aloha.module.object.ImmutValues;
import aloha.module.object.NonEmptyArray;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.ValueObject;
import aloha.module.object.record.IRecord;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.TxStarView;

import java.util.ArrayList;
import java.util.List;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;

public class DistinctIds {

    public static
    NonEmptyArray.DistinctInts
    toIntIDs(
        List<Integer> ids ){

        if (ids.isEmpty())
            throw new IllegalArgumentException();
        if (ids.size() == 1)
            return NonEmptyArray.DistinctInts.createInts(ids.get(0));

        int[] others = new int[ids.size() - 1];
        for(int i = 0; i < others.length; i++) {
            others[i] = ids.get(i + 1);
        }
        return NonEmptyArray.DistinctInts.
            createInts(
                ids.get(0),
                others);
    }

    public static
    NonEmptyArray.DistinctLongs
    toLongIDs(
        List<Long> ids ){

        if (ids.isEmpty())
            throw new IllegalArgumentException();
        if (ids.size() == 1)
            return NonEmptyArray.DistinctLongs.createLongs(ids.get(0));

        long[] others = new long[ids.size() - 1];
        for(int i = 0; i < others.length; i++) {
            others[i] = ids.get(i + 1);
        }
        return NonEmptyArray.DistinctLongs.
            createLongs(
                ids.get(0),
                others);
    }

    public static
    List<Long>
    toLongIDList(
        NonEmptyArray.DistinctLongs ids) {

        List<Long> idList = new ArrayList<>();
        for(int i= 0; i < ids.size(); i++) {
            idList.add(ids.getElement(i));
        }
        return idList;
    }

    public static
    List<Integer>
    toIntIDList(
        NonEmptyArray.DistinctInts ids) {

        List<Integer> idList = new ArrayList<>();
        for(int i= 0; i < ids.size(); i++) {
            idList.add(ids.getIntElementAt(i));
        }
        return idList;
    }

    public static
    List<Integer>
    toIntIDList(
        ImmutValues<Integer> ids) {

        return ids.asList().stream().distinct().toList();
    }

    public static
    <V extends ValueObject>
    NonEmptyArray.DistinctInts
    intIDsFromRecords(
        NonEmptyVOs<V> vos,
        ToIntFunction<V> f){

        return aloha3.dml.hidden.Distinct.intIDs(vos, f);
    }

    public static
    <R extends IRecord>
    NonEmptyArray.DistinctLongs
    longIDsFromRecords(
        NonEmptyVOs<R> vos,
        java.util.function.Function<R,Long> f){

        return aloha3.dml.hidden.Distinct.longIDs(vos, f::apply);
    }

    public static
    <V extends AbstractView<?>>
    NonEmptyArray.DistinctInts
    intIDsFromViews(
        NonEmptyVOs<V> vos,
        ToIntFunction<V> f){

        int[] ints = new int[vos.size()];
        for( int v = 0 ; v < vos.size() ; v++ ) {
            ints[v] = f.applyAsInt(vos.eltAt(v));
        }
        return NonEmptyArray.DistinctInts.distinct(NonEmptyArray.Ints.ensureNonEmptyInts(ints));
    }

    public static
    <F extends AbstractField,
        V extends AbstractView<F>>
    NonEmptyArray.DistinctLongs
    longIDsFromViews(
        NonEmptyVOs<V> vos,
        ToLongFunction<V> f){

        long[] longs = new long[vos.size()];
        for( int v = 0 ; v < vos.size() ; v++ ) {
            longs[v] = f.applyAsLong(vos.eltAt(v));
        }
        return NonEmptyArray.DistinctLongs.distinct(NonEmptyArray.Longs.ensureNonEmptyLongs(longs));
    }

    public static <
    X extends SealedTxParent<?> & MakeCancellable<X>,
    F extends AbstractField & TxStarView.Field<X>,
    M extends TxMgt.StarView<X,F,?>,
    VX extends TxEntityLongFK<? super VX,X>,
    VF extends TxStarView.FieldOf.AndLongFK<VX>>
    NonEmptyArray.DistinctLongs
    longIDsFromCrudViews(
        NonEmptyVOs<OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>>> vos){

        long[] longs = new long[vos.size()];
        for( int v = 0 ; v < vos.size() ; v++ ) {
            longs[v] = vos.eltAt(v).left.txRead().getRowId();
        }
        return NonEmptyArray.DistinctLongs.distinct(NonEmptyArray.Longs.ensureNonEmptyLongs(longs));
    }
}
