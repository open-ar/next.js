package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime.YMDHMS;
import aloha3.module.object.view.StarView.Read;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.List;

public interface GraphChainWrapper
    extends GraphWrapper {

    int registerRoot(JsonArray var1);

    int updateRoot(JsonObject var1);

    int removeRoot(Integer var1);

    default JsonArray queryChain() {
        return queryChain(YMDHMS.current());
    }

    JsonArray queryChain(YMDHMS var1);

    default List<List<Read>> selectAllChains() {
        return selectAllChains(YMDHMS.current());
    }

    List<List<Read>> selectAllChains(YMDHMS var1);
}
