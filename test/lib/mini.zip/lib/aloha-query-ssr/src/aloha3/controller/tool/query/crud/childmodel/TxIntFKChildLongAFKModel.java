package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel.ChildLongAFK;
import aloha3.module.object.model.read.TxModel.ChildLongAFK.FlatField;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.TxEntityIntFK.On;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView.FieldOf.AndIntFK;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.List;

public class TxIntFKChildLongAFKModel<
    E extends On<M>,
    M extends Pivot<?>,
    F extends AndIntFK<E>,
    CH extends ChildTxEntityLongAFK.Of<E, CM, CV>,
    CM extends TxKey.Category<?>,
    CV extends Comparable<? super CV>,
    PV extends ValueObject>
    extends TxChildModel<F, PV, FlatField<F, CV>> {

    private final PV parent;
    private final ChildLongAFK<F, CH> model;
    private final ImmutVOs<View<FlatField<F, CV>>> flatViews;
    private final List<Mandatory> childMembers;

    private TxIntFKChildLongAFKModel(PV parent, ChildLongAFK<F, CH> model) {
        this.parent = parent;
        this.model = model;
        this.flatViews = ChildLongAFK.toFlat(model);
        this.childMembers = new ArrayList();
        if (!this.flatViews.empty()) {
            View<FlatField<F, CV>> flatFieldView = this.flatViews.firstUnlessEmpty();
            this.childMembers.add(((FlatField)flatFieldView.field()).PK());
            this.childMembers.add(((FlatField)flatFieldView.field()).AFK());
            this.childMembers.add(((FlatField)flatFieldView.field()).Attribute());
        }

    }

    private TxIntFKChildLongAFKModel(PV parent) {
        this.parent = parent;
        this.model = null;
        this.flatViews = ImmutVOs.emptyVOs();
        this.childMembers = new ArrayList();
    }

    public ChildLongAFK<F, CH> getModel() {
        return this.model;
    }

    public ImmutVOs<View<FlatField<F, CV>>> getFlatViews() {
        return this.flatViews;
    }

    public List<Mandatory> childMembers() {
        return this.childMembers;
    }

    public PV view() {
        return this.parent;
    }

    public ImmutVOs<? extends Read<CH>> children() {
        return this.model.children();
    }

    public static <E extends On<M>, M extends Pivot<?>, F extends AndIntFK<E>, CH extends ChildTxEntityLongAFK.Of<E, CM, CV>, CM extends TxKey.Category<?>, CV extends Comparable<? super CV>, PV extends aloha3.module.object.view.TxStarView.Read<F>> TxIntFKChildLongAFKModel<E, M, F, CH, CM, CV, PV> of(ChildLongAFK<F, CH> model) {
        return new TxIntFKChildLongAFKModel(model.view(), model);
    }

    public static <E extends On<M>, M extends Pivot<?>, F extends AndIntFK<E>, CH extends ChildTxEntityLongAFK.Of<E, CM, CV>, CM extends TxKey.Category<?>, CV extends Comparable<? super CV>, PV extends OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?>> TxIntFKChildLongAFKModel<E, M, F, CH, CM, CV, PV> of(OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?> parent, ChildLongAFK<F, CH> model) {
        return new TxIntFKChildLongAFKModel(parent, model);
    }

    public static <E extends On<M>, M extends Pivot<?>, F extends AndIntFK<E>> TxIntFKChildLongAFKModel<E, M, F, ?, ?, ?, ?> of(OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?> parent) {
        return new TxIntFKChildLongAFKModel(parent);
    }
}
