package aloha3.controller.tool.query.models;

import aloha.module.object.DateTime;
import aloha.module.object.DecimalScale;
import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.MayNullValue;
import aloha.module.object.NonEmptyArray;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.NonNullValue;
import aloha.module.object.Type;
import aloha.module.object.ValueObject;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.BusinessMgrContainer;
import aloha3.controller.tool.query.crud.childmodel.TxChildModel;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildLongAFKOnlyModel;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.TxEntityIntFKValue;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.record.transaction.read.ChildTxIntAFK;
import aloha3.module.object.record.transaction.read.ChildTxIntAFKOnly;
import aloha3.module.object.record.transaction.read.ChildTxLongAFK;
import aloha3.module.object.record.transaction.read.ChildTxLongAFKOnly;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TemporalView;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.Unsafe;
import aloha3.module.object.view.View;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonValue;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static aloha3.controller.tool.query.ViewMgr.BIND_TX_WITH_CHILD;

@SuppressWarnings("all")
public class JsonUtils {

    public static
    JsonObject
    removeKey(
        JsonObject json,
        String removeKey ) {

        if (!json.containsKey(removeKey))
            return json;
        JsonObjectBuilder builder = Json.createObjectBuilder();
        for(String key : json.keySet()) {
            if (removeKey.equals(key))
                continue;
            builder.add(key, json.get(key));
        }
        return builder.build();
    }

    public static
    JsonObject
    readJsonObject(
        String jsonString) {

        if (isEmpty(jsonString))
            return Json.createObjectBuilder().build();

        JsonReader parser = Json.createReader(new StringReader(jsonString));
        return  parser.readObject();
    }

    private static
    Comparable
    getFirstId(
        JsonValue value) {

        if (value.getValueType() == JsonValue.ValueType.OBJECT) {
            JsonObject jsonObject = value.asJsonObject();
            while(jsonObject != null) {
                String[] keys = jsonObject.keySet().toArray(new String[0]);
                JsonValue first = jsonObject.get(keys[0]);
                /*
                 * TODO : LONG
                 */
                if (first.getValueType() == JsonValue.ValueType.NUMBER)
                    return jsonObject.getInt(keys[0]);
                else if (first.getValueType() == JsonValue.ValueType.STRING)
                    return jsonObject.getString(keys[0]);
                else if (first.getValueType() == JsonValue.ValueType.OBJECT)
                    jsonObject = jsonObject.getJsonObject(keys[0]);
            }
        } else if (value.getValueType() == JsonValue.ValueType.ARRAY) {
            return getFirstId(value.asJsonArray().get(0));
        }

        return 0;
    }

    @SuppressWarnings("unchecked")
    public static
    <E extends CoreEntity,
     F extends AbstractField & StarView.Field<E>>
    StarView.Write.Prepare<E,F>
    toRegisterView(
        JsonObject view,
        Class<F> fieldType) {

        StarView.Write.Prepare.Builder <E, F> builder =
            StarView.Write.Prepare.Builder.
                create(
                    (Class)fieldType);

        builder.field.attributeMembers().
            foreach(
                (member)->{
                    String name = member.javaName();
                    Comparable value;
                    if (!view.containsKey(name)) {
                        if (name.endsWith("Id"))
                            value = -1;
                        else
                            return;
                    }else {
                        value = getValue(
                            view.getString(name),
                            member.refType());
                    }
                    if (member instanceof AbstractField.Member.Optional) {
                        if (name.endsWith("Id") && value instanceof Integer) {
                            int id = (Integer) value;
                            if (id <= 0)
                                return;
                        }else if(value instanceof String) {
                            String str = (String) value;
                            if (str.isEmpty())
                                return;
                        }
                        builder.setOptionalValue(
                            (f)-> (AbstractField.Member.Optional) member,
                            value);
                    }else{
                        builder.setMandatoryValue(
                            (f)-> (AbstractField.Member.Mandatory) member,
                            value);
                    }
                }
            );

        return builder.build();
    }

    public static
    String
    toCsv(
        List<JoinedView> joinedViews) {

        Collections.sort(
            joinedViews,
            (view1, view2)->{
                Comparable id1 = (Comparable)view1.getFirstValue();
                Comparable id2 = (Comparable)view2.getFirstValue();
                return id1.compareTo(id2);
            });
        return toCsv(joinedViews, false);
    }

    public static
    String
    toCsv(
        List<JoinedView> joinedViews,
        boolean validation) {

        StringBuilder csv = new StringBuilder();
        int numberOfViews = 0;

        JoinedView title = new JoinedView();
        for(JoinedView joinedView : joinedViews) {
            numberOfViews = Math.max(numberOfViews, joinedView.size());
            for(FlatView view : joinedView) {
            }
        }

        JoinedView titleView = new JoinedView();
        for(int indexOfView = 0; indexOfView < numberOfViews; indexOfView++) {
            for (JoinedView joinedView : joinedViews) {
                if (indexOfView >= joinedView.size())
                    continue;
                titleView.add(joinedView.get(indexOfView));
                break;
            }
        }

        /*
         * views names
         */
        for(FlatView view : titleView) {
            if (csv.length() > 0)
                csv.append(",");
            csv.append(
                ViewMgr.toViewName(
                    view.getName()));

            for (int k = 1; k < view.keys().size(); k++) {
                csv.append(",");
            }
        }
        csv.append("\n");

        /*
         * columns names
         */
        //Arrays.sort(keys);
        boolean first = true;
        for(FlatView view : titleView) {
            for(String column : view.keys()){
                if (first)
                    first = false;
                else
                    csv.append(",");
                csv.append(
                    ViewMgr.toColumnName(
                        view.getName(),
                        column));

            }
        }

        boolean debug = false;
        if (debug) {
            System.out.println();
            System.out.println("Views");
            debug(joinedViews);
        }

        if (validation) {
            List<JoinedView> dubplicates = new ArrayList<>();
            NEXT_VIEW : for (JoinedView joinedView : joinedViews) {
                for(FlatView view : joinedView) {
                    for(FieldMemberValue member : view.getValues()) {
                        if (lookup(view, member, joinedView)){
                            dubplicates.add(joinedView);
                            continue NEXT_VIEW;
                        }
                    }
                }
            }
            if (debug) {
                System.out.println();
                System.out.println("Dubplicated Views  " + dubplicates.size() +"/"+joinedViews.size());
                debug(dubplicates);
            }
            joinedViews.removeAll(dubplicates);
        }

        for(JoinedView joinedView : joinedViews) {
            csv.append("\n");
            first = true;
            for (Object value : joinedView.values(titleView)) {
                if (first)
                    first = false;
                else
                    csv.append(",");
                if (value != null)
                    csv.append(
                        value);
            }
        }
        /*
        csv.append(0xef);
        csv.append(0xbb);
        csv.append(0xbf);
         */
        return csv.toString();
    }

    private static
    void
    debug (
        List<JoinedView> joinedViews) {

        for (JoinedView joinedView : joinedViews) {
            System.out.println("JoinedViews");
            System.out.println();
            System.out.println("Join Info: ");
            int index = 0;
            for(FlatView view : joinedView) {
                for(int i = 0; i < index; i++)
                    System.out.print("    ");
                if (index > 0 )
                    System.out.print( "JOIN  ");
                System.out.print(view.getName());
                if (index > 0 && (index - 1) < joinedView.getJoinKeys().size() )
                    System.out.print( " BY " + joinedView.getJoinKeys().get(index-1));
                System.out.println();
                index++;
            }
            System.out.println();
            for(FlatView view : joinedView) {
                System.out.print("\t");
                System.out.println("View : " + view.getName());
                for(FieldMemberValue member : view.getValues()) {
                    System.out.print("\t\t");
                    System.out.print("Field=" + member.getFieldMember().getFieldName());
                    System.out.print(" Member=" + member.getFieldMember().getMemberName());
                    System.out.print(" Value=" + member.getValue());
                    System.out.println();
                }
            }
        }
    }

    private static
    boolean
    lookup(
        FlatView view,
        FieldMemberValue member,
        JoinedView joinedView) {

        if (!member.getFieldMember().getMemberName().endsWith("Id"))
            return false;

        for (FlatView otherVview : joinedView) {
            if (otherVview == view)
                continue;

            for (FieldMemberValue otherVviewMember : otherVview.getValues()) {

                if (member.getFieldMember().getMemberName().equals(otherVviewMember.getFieldMember().getMemberName())) {
                    if (member.getValue().toString().compareTo(otherVviewMember.getValue().toString()) != 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static
    JsonArray
    toJsons(
        List<JoinedView> views) {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for(JoinedView joinedView : views) {
            JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
            for(FlatView view : joinedView) {
                for(FieldMemberValue value : view.getValues()) {
                    String name = view.getName() + "." + value.getFieldMember().getMemberName();
                    jsonObjectBuilder.add(
                        name,
                        String.valueOf(
                            value.getValue()));
                }
            }
            arrayBuilder.add(jsonObjectBuilder);
        }

        return arrayBuilder.build();
    }

    public static
    ImmutValues<Integer>
    getIntKeys(
        List<JoinedView> views,
        String keyName) {

        sortByInt(views, keyName);

        int[] ids = new int[views.size()];
        int count = 0;
        sortByInt(views, keyName);
        for(JoinedView view : views) {
            int value = getInt(view, keyName);
            /*
             * Caused by: aloha.module.object.NonEmptyVOs$EmptyNotAllowedException
             * 	at aloha.module.object.NonEmptyVOs.eval(NonEmptyVOs.java:177)
             * 	at aloha.module.object.NonEmptyVOs._assert(NonEmptyVOs.java:39)
             * 	at aloha3.dml.master.SelectView.createView00(SelectView.java:294)
             * 	at aloha3.dml.master.SelectView.createView(SelectView.java:212)
             * 	at aloha3.module.function.business.master.ForeignCore$StarView.createViews(ForeignCore.java:161)
             */
            if (value <= 0)
                continue;
            if (count == 0)
                ids[count++] = value;
            else if (value != ids[count - 1])
                ids[count++] = value;
        }

        if (count > 0) {
            return ImmutValues.of(ids);
        }else{
            // throw new IllegalStateException("[getIntKeys] views:"+ views.size() + " keyName="+keyName +
            //     "  "+ (views.isEmpty() ? "" : views.get(0).keys()));
            return ImmutValues.emptyInstance();
        }
    }

    public static
    NonEmptyArray.DistinctLongs
    getLongKeys(
        List<JoinedView> views,
        String keyName) {

        sortByLong(views, keyName);

        long[] ids = new long[views.size()];
        int count = 0;
        sortByLong(views, keyName);
        for(JoinedView view : views) {
            long value = getLong(view, keyName);
            if (value <= 0)
                continue;
            if (count == 0)
                ids[count++] = value;
            else if (value != ids[count - 1])
                ids[count++] = value;
        }

        if (count == 1)
            return NonEmptyArray.DistinctLongs.createLongs(ids[0]);
        else if (count > 0) {
            long[] idsFrom2nd = new long[count - 1];
            System.arraycopy(ids, 1, idsFrom2nd, 0, idsFrom2nd.length);
            return NonEmptyArray.DistinctLongs.createLongs(ids[0],idsFrom2nd);
        }else{
            throw new IllegalStateException("[getLongKeys] views:"+ views.size() + " keyName="+keyName +
                "  "+ (views.isEmpty() ? "" : views.get(0).keys()));
        }
    }

    public static
    void
    sortByInt(
        List<JoinedView> views,
        String sortName) {

        Collections.sort(
            views,
            (core1, core2)->
                getInt(core1, sortName) -  getInt(core2, sortName));
    }

    public static
    void
    sortByLong(
        List<JoinedView> jsons,
        String sortName) {

        jsons.sort((view1, view2) ->
            (int) ((getLong(view1, sortName) - getLong(view2, sortName))) >> 32);
    }

    public static
    List<JoinedView>
    joinByInt(
        List<JoinedView> views,
        String idName,
        List<JoinedView> relations,
        String joinIdName) {

        if (relations.isEmpty()) {
            List<JoinedView> result = new ArrayList<>();
            for(JoinedView view1 : views) {
                JoinedView objectBuilder = new JoinedView();
                copyFrom(objectBuilder, view1);
                objectBuilder.addJoinKey(idName);
                copyFrom(objectBuilder, JoinedView.EMPTY_JOINED_VIEW);
                result.add(objectBuilder);
            }

            views.clear();
            views.addAll(result);
            return views;
        }

        sortByInt(
            views,
            idName);

        sortByInt(
            relations,
            joinIdName);

        int indexOfRelation = 0;
        JoinedView emptyRelation = relations.get(0).cloneEmpty();
        List<JoinedView> result = new ArrayList<>();
        for (int indexOfCore = 0; indexOfCore < views.size(); indexOfCore++) {
            JoinedView view1 = views.get(indexOfCore);
            int coreId = getInt(view1, idName);
            int firstFound = -1;
            while (indexOfRelation < relations.size()) {
                JoinedView view2 = relations.get(indexOfRelation);
                // 画面の選択順が決まらないので、両方チェック
                boolean isMasterAfterTx = 
                    isIsMasterAfterTx(view2, view1) || 
                    isIsMasterAfterTx(view1, view2);
                if (isMasterAfterTx) {
                    indexOfRelation++;
                    continue;
                }
                
                int coreIdOfView2 = getInt(view2, joinIdName);
                if (coreId > coreIdOfView2) {
                    indexOfRelation++;
                    continue;
                } else if (coreId == coreIdOfView2) {
                    if (firstFound == -1)
                        firstFound = indexOfRelation;

                    JoinedView objectBuilder = new JoinedView();
                    copyFrom(objectBuilder, view1);
                    objectBuilder.addJoinKey(joinIdName);
                    copyFrom(objectBuilder, view2);
                    result.add(objectBuilder);
                    indexOfRelation++;
                    continue;
                }
                break;
            }
            if (firstFound != -1) {
                indexOfRelation = firstFound;
            } else {
                JoinedView objectBuilder = new JoinedView();
                copyFrom(objectBuilder, view1);
                objectBuilder.addJoinKey(joinIdName);
                copyFrom(objectBuilder, emptyRelation);
                result.add(objectBuilder);
            }
        }

        views.clear();
        views.addAll(result);

        return views;
    }

    private static boolean 
    isIsMasterAfterTx(
        JoinedView viewToJoin, 
        JoinedView viewAlreadyJoin) {
        // View to join is a relation table?
        final var txMustAfterMasterTimeIfRelationExist = viewToJoin.stream()
            .filter(v -> v.getView() instanceof StarView.Relation.Read relationView)
            .findFirst()
            .map(v -> ((StarView.Relation.Read)v.getView()).relationRead().getRegTime());
        if (txMustAfterMasterTimeIfRelationExist.isPresent()) {
            final var masterTime = txMustAfterMasterTimeIfRelationExist.get();
            // master登録後txが登録するので、masterの時間はtxより前のは正
            // 逆に、masterの時間はtxより後のは不正で、スキップする必要
            return viewAlreadyJoin.stream().anyMatch(v -> {
                final var alohaView = v.getView();
                if (alohaView instanceof TxStarView.Read txStarView) {
                    // 逆に、masterの時間はtxより後のは不正で、スキップ(return true)する必要
                    return masterTime.getAsLong() > txStarView.txTime().getAsLong();
                }
                return false;
            });
            
        }
        return false;
    }

    public static
    List<JoinedView>
    joinByLong(
        List<JoinedView> views,
        List<JoinedView> relations,
        String joinIdName) {

        if (relations.isEmpty()) {
            List<JoinedView> result = new ArrayList<>();
            for(JoinedView view1 : views) {
                JoinedView objectBuilder = new JoinedView();
                copyFrom(objectBuilder, view1);
                objectBuilder.addJoinKey(joinIdName);
                copyFrom(objectBuilder, JoinedView.EMPTY_JOINED_VIEW);
                result.add(objectBuilder);
            }

            views.clear();
            views.addAll(result);
            return views;
        }

        sortByLong(
            views,
            joinIdName);

        sortByLong(
            relations,
            joinIdName);

        int indexOfRelation = 0;
        JoinedView emptyRelation = relations.get(0).cloneEmpty();
        List<JoinedView> result = new ArrayList<>();
        for (int indexOfCore = 0; indexOfCore < views.size(); indexOfCore++) {
            JoinedView view1 = views.get(indexOfCore);
            long coreId = getLong(view1, joinIdName);
            int firstFound = -1;
            while (indexOfRelation < relations.size()) {
                JoinedView view2 = relations.get(indexOfRelation);
                long coreIdOfView2 = getLong(view2, joinIdName);
                if (coreId > coreIdOfView2) {
                    indexOfRelation++;
                    continue;
                } else if (coreId == coreIdOfView2) {
                    if (firstFound == -1)
                        firstFound = indexOfRelation;

                    JoinedView objectBuilder = new JoinedView();
                    copyFrom(objectBuilder, view1);
                    objectBuilder.addJoinKey(joinIdName);
                    copyFrom(objectBuilder, view2);
                    result.add(objectBuilder);
                    indexOfRelation++;
                    continue;
                }
                break;
            }
            if (firstFound != -1) {
                indexOfRelation = firstFound;
            } else {
                JoinedView objectBuilder = new JoinedView();
                copyFrom(objectBuilder, view1);
                objectBuilder.addJoinKey(joinIdName);
                copyFrom(objectBuilder, emptyRelation);
                result.add(objectBuilder);
            }
        }

        views.clear();
        views.addAll(result);

        return views;
    }

    public static
    int
    getInt(
        JoinedView view,
        String name ) {

        return view.getInt(name);
    }

    public static
    long
    getLong(
        JoinedView view,
        String name ) {

        return view.getLong(name);
    }

    public static JoinedView
    copyFrom (
        JoinedView objectBuilder,
        JoinedView obj) {

        return objectBuilder.copyFrom(obj);
    }

    public static
    NonEmptyVOs<Core.Read>
    getCores(
        List<JoinedView> views,
        String name) {

        List<Read> cores = new ArrayList<>();
        views.forEach(
            (view)-> {
                Object starView = view.getAlohaViews(name);
                if (starView instanceof StarView.Read)
                    cores.add(
                        ((StarView.Read) starView).coreRead());
                else if (starView instanceof StarView.Relation.Read)
                    cores.add(
                        ((StarView.Relation.Read) starView).relationRead());
                else
                    System.out.println("Unkown Type : " + starView.getClass().getSimpleName());
            });

        return (NonEmptyVOs)ImmutVOs.create(cores).mustNonEmpty();
    }

    public static
    <E extends CoreEntity,
     F extends AbstractField & StarView.Field<E>>
    List<JoinedView>
    toJsonFromStarViews(
        ImmutVOs<StarView.Read<F>> views) {

        return toJsons(
            views.map(
                StarView.Read::asView));
    }
    public static
    List<JoinedView>
    toJsonFromTemporalViews(
        ImmutVOs<TemporalView.Read<?>> views) {

        return toJsons(views);
    }

    public static
    <F extends AbstractField & TxStarView.Field<?>>
    List<JoinedView>
    toJsonFromTxStarViews(
        ImmutVOs<TxStarView.Read<F>> views) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        if (views.size() == 0)
            return arrayBuilder;

        views.foreach(
            (view)->{
                arrayBuilder.add(
                    toJson(
                        view));
            }
        );

        return arrayBuilder;
    }

    public static
    <F extends AbstractField & TxStarView.Field<?>>
    List<JoinedView>
    toJsonFromDerivedTxs(
        ImmutVOs<aloha3.module.object.record.transaction.read.DerivedTx> views) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        if (views.size() == 0)
            return arrayBuilder;

        views.foreach(
            (view)->{
                arrayBuilder.add(
                    toJson(
                        view));
            }
        );

        return arrayBuilder;
    }

    public static <
        E extends TxEntityIntFK.On<M>,
        M extends CoreEntity,
        F extends TxStarView.FieldOf.AndIntFK<E>,
        CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
        CM extends CoreEntity,
        CV extends Comparable<? super CV>>
    List<JoinedView>
    toJsonFromTxChildModels(
        ImmutVOs<TxIntFKChildIntAFKModel<E,M,F,CH,CM,CV,TxStarView.Read<F>>> models) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        for(TxIntFKChildIntAFKModel<E,M,F,CH,CM,CV,TxStarView.Read<F>> model : models.get()) {
            String name = model.view().field().getClass().getSimpleName();
            if (name.endsWith("Field"))
                name = name.substring(0,name.length() - "Field".length());
            if (BIND_TX_WITH_CHILD) {
                for (View<TxModel.ChildIntAFK.FlatField<F, CV>> view : model.getFlatViews().get()) {
                    arrayBuilder.add(
                        toJson(
                            name,
                            view));
                }
            } else {
                arrayBuilder.add(
                    toJson(
                        model.view()));
            }
        }
        return arrayBuilder;
    }
    public static <
        E extends TxEntityIntFK.On<M>,
        M extends CoreEntity,
        F extends TxStarView.FieldOf.AndIntFK<E>,
        CH extends ChildTxEntityLongAFKOnly.Of<E,CX>,
        CX extends TxKey.Category<?>>
    List<JoinedView>
    toJsonFromTxChildLongAFKOnlyModels(
        ImmutVOs<TxIntFKChildLongAFKOnlyModel<E,M,F,CH,CX,TxStarView.Read<F>>> models) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        for(TxIntFKChildLongAFKOnlyModel<E,M,F,CH,CX,TxStarView.Read<F>> model : models.get()) {
            String name = model.view().field().getClass().getSimpleName();
            if (name.endsWith("Field"))
                name = name.substring(0,name.length() - "Field".length());
            if (BIND_TX_WITH_CHILD) {
                for (View<TxModel.ChildLongAFKOnly.FlatField<F>> view : model.getFlatViews().get()) {
                    arrayBuilder.add(
                        toJson(
                            name,
                            view));
                }
            } else {
                arrayBuilder.add(
                    toJson(
                        model.view()));
            }
        }
        return arrayBuilder;
    }

    public static <
        X extends SealedTxParent<?>,
        M extends SealedPivot<?>,
        T extends Comparable<? super T>,
        E extends ChildTxEntityIntAFK.Of<X,M,T>>
    List<JoinedView>
    toJsonFromTxChildIntAFKs(
        ImmutVOs<ChildTxIntAFK<E,X, M,T>> models) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        for(ChildTxIntAFK<E,X, M,T> model : models.get()) {
            arrayBuilder.add(toFlatView(model));
        }
        return arrayBuilder;
    }

    public 
    static <
        E extends ChildTxEntityIntAFKOnly.Of<X, M>, 
        X extends SealedTxParent<?>, 
        M extends SealedPivot<?>>
    JoinedView
    toFlatView(ChildTxIntAFKOnly<E, X, M> model) {
        String name = model.getPrimaryKeyColumn().getJavaName();
        name = name.substring(0, name.length() - 2);
        FlatView flatView = new FlatView(name, null);

        IColumn column = model.getPrimaryKeyColumn();
        flatView.add(
            FieldMemberValue.
                create(
                    new FieldMember(
                        flatView.getName(),
                        column.getJavaName(),
                        getMemberTypeOf(
                            column.getRefType())),
                    model.getRowId()));

        column = model.getForeignKeyColumn();
        flatView.add(
            FieldMemberValue.
                create(
                    new FieldMember(
                        flatView.getName(),
                        column.getJavaName(),
                        getMemberTypeOf(
                            column.getRefType())),
                    model.getTxId()));

        column = model.getAdditionalForeignKeyColumn();
        flatView.add(
            FieldMemberValue.
                create(
                    new FieldMember(
                        flatView.getName(),
                        column.getJavaName(),
                        getMemberTypeOf(
                            column.getRefType())),
                    model.additionalForeignKeyValue()));
        JoinedView joinedView = new JoinedView();
        joinedView.add(flatView);
        return joinedView;
    }

    public 
    static <X extends SealedTxParent<?>, M extends SealedPivot<?>, T extends Comparable<? super T>, E extends ChildTxEntityIntAFK.Of<X,M,T>>
    JoinedView
    toFlatView(ChildTxIntAFK<E, X, M, T> model) {
        String name = model.getPrimaryKeyColumn().getJavaName();
        name = name.substring(0, name.length() - 2);
        FlatView flatView = new FlatView(name, null);

        IColumn column = model.getPrimaryKeyColumn();
        flatView.add(
            FieldMemberValue.
                create(
                    new FieldMember(
                        flatView.getName(),
                        column.getJavaName(),
                        getMemberTypeOf(
                            column.getRefType())),
                    model.getRowId()));

        column = model.getForeignKeyColumn();
        flatView.add(
            FieldMemberValue.
                create(
                    new FieldMember(
                        flatView.getName(),
                        column.getJavaName(),
                        getMemberTypeOf(
                            column.getRefType())),
                    model.getTxId()));

        column = model.getAdditionalForeignKeyColumn();
        flatView.add(
            FieldMemberValue.
                create(
                    new FieldMember(
                        flatView.getName(),
                        column.getJavaName(),
                        getMemberTypeOf(
                            column.getRefType())),
                    model.additionalForeignKeyValue()));

        column = model.attributeColumn();
        Class memberType = getMemberTypeOf(column.getRefType());
        if (memberType == String.class)
            flatView.add(
                FieldMemberValue.
                    create(
                        new FieldMember(
                            flatView.getName(),
                            column.getJavaName(),
                            getMemberTypeOf(
                                column.getRefType())),
                        (String) model.attributeValue()));
        else if (memberType == Integer.class)
            flatView.add(
                FieldMemberValue.
                    create(
                        new FieldMember(
                            flatView.getName(),
                            column.getJavaName(),
                            getMemberTypeOf(
                                column.getRefType())),
                        (Integer) model.attributeValue()));
        else if (memberType == Long.class)
            flatView.add(
                FieldMemberValue.
                    create(
                        new FieldMember(
                            flatView.getName(),
                            column.getJavaName(),
                            getMemberTypeOf(
                                column.getRefType())),
                        (Long) model.attributeValue()));
        else if (memberType == Double.class)
            flatView.add(
                FieldMemberValue.
                    create(
                        new FieldMember(
                            flatView.getName(),
                            column.getJavaName(),
                            getMemberTypeOf(
                                column.getRefType())),
                        (Double) model.attributeValue()));
        JoinedView joinedView = new JoinedView();
        joinedView.add(flatView);
        return joinedView;
    }

    public static <
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & TxStarView.Field<X>,
        M extends TxMgt.StarView<X,F,?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends TxStarView.FieldOf.AndLongFK<VX>>
    List<JoinedView>
    toJsonFromCrudViews(
        ImmutVOs<OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>>> views) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        if (views.size() == 0)
            return arrayBuilder;

        views.foreach(
            (view)->{
                arrayBuilder.add(
                    toJson(
                        view));
            }
        );

        return arrayBuilder;
    }

    public static
    List<JoinedView>
    toJsons(
        ImmutVOs views) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        if (views.size() == 0)
            return arrayBuilder;

        for(int i = 0; i < views.size(); i++) {
            Object view = views.eltAt(i);
            arrayBuilder.add(
                toJson(
                    view));
        }

        return arrayBuilder;
    }

    public static
    <F extends AbstractField & StarView.Field<?>>
    List<JoinedView>
    toJsonsFromViewMayNullVO(
        ImmutVOs<OneToOne.MayZero<StarView.Read<F>,StarView.Read<F>>> views) {

        List<JoinedView> arrayBuilder = new ArrayList<>();
        if (views.size() == 0)
            return arrayBuilder;

        for(int i = 0; i < views.size(); i++) {
            OneToOne.MayZero<StarView.Read<F>,StarView.Read<F>> mayNullView = views.eltAt(i);
            mayNullView.right.
                unlessNull_(
                    (view)->
                        arrayBuilder.add(
                            toJson(
                                view)));
        }

        return arrayBuilder;
    }

    @SuppressWarnings("unchecked")
    public static JoinedView
    toJson(
        Object view) {

        if (view instanceof TemporalView.Read)
            return toJson((TemporalView.Read)view);
        if (view instanceof View)
            return toJson((View) view);
        if (view instanceof StarView.Read)
            return toJson((StarView.Read) view);
        if (view instanceof TxStarView.Read)
            return toJson((TxStarView.Read) view);
        if (view instanceof StarView.Relation.Read)
            return toJson((StarView.Relation.Read) view);

        throw new IllegalArgumentException(view.getClass().getName());
    }

    public static
    <F extends AbstractField>
    List<JoinedView>
    toJsonsFromViews(
        ImmutVOs<View<F>> views) {

        List<JoinedView> jsons = new ArrayList<>();
        if (views.size() == 0)
            return jsons;

        for(int i = 0; i < views.size(); i++) {
            Object view = views.eltAt(i);
            jsons.add(
                toJson(
                    view));
        }
        return jsons;
    }

    public static
    <F extends AbstractField>
    List<JoinedView>
    toJsonsFromViews(
        String name,
        ImmutVOs<View<F>> views) {

        List<JoinedView> jsons = new ArrayList<>();
        if (views.size() == 0)
            return jsons;

        for(int i = 0; i < views.size(); i++) {
            View view = views.eltAt(i);
            jsons.add(
                toJson(
                    view,
                    name,
                    view.toString()));
        }
        return jsons;
    }

    public static
    List<JoinedView>
    toJsonsFromStarViews(
        ImmutVOs<StarView.Read> views) {

        List<JoinedView> jsons = new ArrayList<>();
        if (views.size() == 0)
            return jsons;

        for(int i = 0; i < views.size(); i++) {
            Object view = views.eltAt(i);
            jsons.add(
                toJson(
                    view));
        }
        return jsons;
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    List<JoinedView>
    toJsonsFromStarViewArray(
        ImmutableArray<StarView.Read<F>> views) {

        List<JoinedView> jsons = new ArrayList<>();
        if (views.size() == 0)
            return jsons;

        for(int i = 0; i < views.size(); i++) {
            Object view = views.eltAt(i);
            jsons.add(
                toJson(
                    view));
        }
        return jsons;
    }

    public static
    List<JoinedView>
    toJsonsFromRelationViews(
        ImmutVOs<StarView.Relation.Read> views) {

        List<JoinedView> jsons = new ArrayList<>();
        if (views.size() == 0)
            return jsons;

        for(int i = 0; i < views.size(); i++) {
            Object view = views.eltAt(i);
            jsons.add(
                toJson(
                    view));
        }
        return jsons;
    }

    public static
    List<JoinedView>
    toJsonsFromTxStarViews(
        ImmutVOs<TxStarView.Read> views) {

        List<JoinedView> jsons = new ArrayList<>();
        if (views.size() == 0)
            return jsons;

        for(int i = 0; i < views.size(); i++) {
            Object view = views.eltAt(i);
            jsons.add(
                toJson(
                    view));
        }
        return jsons;
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    List<JoinedView>
    toJsons(
        Tree.Star<F> node,
        int level)  {

        List<JoinedView> result = new ArrayList<>();
        ImmutVOs<StarView.Read<F>> leaves = node.leaves();

        JoinedView nodeJson = JsonUtils.
            toJson(
                node.node());
        String treeName = nodeJson.get(0).getName();

        List<JoinedView> leafJsons = JsonUtils.
            toJsonsFromStarViews(
                (ImmutVOs) leaves);
        if (leafJsons.isEmpty()) {
            result.add(nodeJson);
        }else{
            for(JoinedView leafJson : leafJsons) {
                JoinedView parentChild = new JoinedView();
                copyFrom(parentChild, nodeJson);
                copyFrom(parentChild, leafJson);
                result.add(parentChild);
            }
        }

        node.branches().
            foreach(
                (branch)-> {
                    JoinedView beanchJson = JsonUtils.toJson(branch.node());
                    JoinedView parentChild = new JoinedView();
                    copyFrom(parentChild, nodeJson);
                    copyFrom(parentChild, beanchJson);
                    result.add(parentChild);

                    result.addAll(
                        toJsons(branch, level + 1));
                });
        return result;
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    List<JoinedView>
    toJsons(
        Tree.StarArrow<F,HF> node,
        int level)  {

        List<JoinedView> result = new ArrayList<>();

        ImmutableArray<StarView.Read<F>> leaves = node.leaves();
        JoinedView nodeJson = JsonUtils.
            toJson(
                node.from());
        String treeName = nodeJson.get(0).getName();

        List<JoinedView> leafJsons = JsonUtils.
            toJsonsFromStarViewArray(
                leaves);
        if (leafJsons.isEmpty()) {
            result.add(nodeJson);
        }else{
            for(JoinedView leafJson : leafJsons) {
                JoinedView parentChild = new JoinedView();
                copyFrom(parentChild, nodeJson);
                copyFrom(parentChild, leafJson);
                result.add(parentChild);
            }
        }

        node.branches().
            foreach(
                (branch)-> {
                    JoinedView beanchJson = JsonUtils.toJson(branch.from());
                    JoinedView parentChild = new JoinedView();
                    copyFrom(parentChild, nodeJson);
                    copyFrom(parentChild, beanchJson);
                    result.add(parentChild);

                    result.addAll(
                        toJsons(branch, level + 1));
                });
        return result;
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    JsonObjectBuilder
    toJsonTree(
        Tree.StarArrow<F,HF> tree,
        String title)  {

        JsonObjectBuilder jsonWorkflow = Json.createObjectBuilder();
        JsonArrayBuilder jsonTransitions = Json.createArrayBuilder();
        JsonArrayBuilder jsonStates = Json.createArrayBuilder();

        toJsonTree(
            tree,
            jsonStates,
            jsonTransitions);

        jsonWorkflow.
            add(
                "workflow",
                title).
            add(
                "transitions",
                jsonTransitions).
            add(
                "startState",
                tree.from().coreRead().rowId()).
            add(
                "states",
                jsonStates);

        return jsonWorkflow;
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    JsonObjectBuilder
    toJsonTree(
        Tree.Star<F> tree,
        String title)  {

        JsonObjectBuilder jsonWorkflow = Json.createObjectBuilder();
        JsonArrayBuilder jsonTransitions = Json.createArrayBuilder();
        JsonArrayBuilder jsonStates = Json.createArrayBuilder();

        toJsonTree(
            tree,
            jsonStates,
            jsonTransitions);

        jsonWorkflow.
            add(
                "workflow",
                title).
            add(
                "transitions",
                jsonTransitions).
            add(
                "startState",
                tree.node().coreRead().rowId()).
            add(
                "states",
                jsonStates);

        return jsonWorkflow;
    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    void
    toJsonTree(
        Tree.StarArrow<F,HF> root,
        JsonArrayBuilder jsonStates,
        JsonArrayBuilder jsonTransitions)  {

        JsonObjectBuilder myTransitions = Json.createObjectBuilder();
        JsonArrayBuilder mySateTos = Json.createArrayBuilder();
        myTransitions.add(
            "id",
            root.from().coreRead().coreId());

        jsonStates.add(
            buildTreeNode(
                root.from()));

        root.
            leaves().
            foreach(
                (node)-> {
                    jsonStates.add(
                        buildTreeNode(
                            node));
                    mySateTos.add(
                        node.coreRead().coreId());
                });

        root.branches().
            foreach(
                (branch)-> {
                    mySateTos.add(
                        branch.from().coreRead().coreId());

                    toJsonTree(
                        branch,
                        jsonStates,
                        jsonTransitions);
                });

        myTransitions.add(
            "to",
            mySateTos);

        jsonTransitions.add(
            myTransitions);

    }

    public static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>>
    void
    toJsonTree(
        Tree.Star<F> root,
        JsonArrayBuilder jsonStates,
        JsonArrayBuilder jsonTransitions)  {

        JsonObjectBuilder myTransitions = Json.createObjectBuilder();
        JsonArrayBuilder mySateTos = Json.createArrayBuilder();
        myTransitions.add(
            "id",
            root.node().coreRead().coreId());

        jsonStates.add(
            buildTreeNode(
                root.node()));

        root.
            leaves().
            foreach(
                (node)-> {
                    jsonStates.add(
                        buildTreeNode(
                            node));
                    mySateTos.add(
                        node.coreRead().coreId());
                });

        root.branches().
            foreach(
                (branch)-> {
                    mySateTos.add(
                        branch.node().coreRead().coreId());

                    toJsonTree(
                        branch,
                        jsonStates,
                        jsonTransitions);
                });

        myTransitions.add(
            "to",
            mySateTos);

        jsonTransitions.add(
            myTransitions);

    }

    private
    static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    JsonObjectBuilder
    buildTreeNode(
        StarView.Read<F>  view) {

        JsonObjectBuilder builder = Json.createObjectBuilder();
        builder.add(
            "id",
            view.coreRead().getRowId());
        JoinedView json = toJson(view);
        boolean setName = false;
        for(String name : json.keys()) {
            if (name.contains("Name")) {
                builder.add(
                    "name",
                    json.getString(name));
                setName = true;
                break;
            }
        }
        if (setName == false)
            builder.add(
                "name",
                "Node-"+ view.coreRead().getRowId());

        return builder;
    }

    public static<
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    List<JoinedView>
    toJsonsFromChain(
        NonEmptyVOs<StarView.Read<F>> node,
        int chainNo)  {

        List<JoinedView> jsons = new ArrayList<>();
        if (node.size() == 0)
            return jsons;

        for(int i = 0; i < node.size(); i++) {
            JoinedView json = toJson(
                node.eltAt(i));
            jsons.add(json);
        }
        return jsons;
    }

    public static
    List<JoinedView>
    toJsonsFromObjects(
        List<View> objs) {

        List<JoinedView> jsons = new ArrayList<>();
        if (objs.size() == 0)
            return jsons;

        for(int i = 0; i < objs.size(); i++) {
            View obj = objs.get(i);
            jsons.add(
                toJson(
                    obj,
                    null,
                    obj.toString()));
        }
        return jsons;
    }

    public static
    JoinedView
    toJson(TemporalView.Read view) {
        return toJson(
            view,
            view.field().getClass().getSimpleName(),
            view.toString());
    }

    public static
    <F extends AbstractField>
    JoinedView
    toJson(
        View<F> view) {

        return toJson(
            view,
            view.field().getClass().getSimpleName(),
            view.toString());
    }

    public static
    <F extends AbstractField>
    JoinedView
    toJson(
        String name,
        View<F> view) {

        return toJson(
            view,
            name,
            view.toString());
    }

    public static JoinedView
    toJson(
        StarView.Read view) {

        return toJson(
            view,
            view.field().getClass().getSimpleName(),
            view.toString());
    }

    public static JoinedView
    toJson(
        StarView.Relation.Read view) {

        return toJson(
            view,
            view.field().getClass().getSimpleName(),
            view.toString());
    }

    public static <
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & TxStarView.Field<X>,
        M extends TxMgt.StarView<X,F,?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends TxStarView.FieldOf.AndLongFK<VX>>
    JoinedView
    toJson(
        OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>> view) {

        JoinedView result = toJson(
            view.left,
            view.left.field().getClass().getSimpleName(),
            view.left.toString());

        JoinedView attrs = toJson(
            view.right,
            view.right.field().getClass().getSimpleName(),
            view.right.toString());

        String pkName = view.left.txRead().getPrimaryKeyColumn().getJavaName();
        String attrPkName = view.right.txRead().getPrimaryKeyColumn().getJavaName();
        for(String attrName: attrs.keys()) {
            if (attrName.equals(pkName))
                continue;
            if (attrName.equals(attrPkName))
                continue;
            result.get(0).add(attrs.getMemberValue(attrName));
        }
        return result;
    }

    public static <
        E extends ChildTxEntityLongAFKOnly.Of<X, A>, 
        X extends SealedTxParent<?>, 
        A extends TxKey.Category<?>>
    JoinedView
    toFlatView(ChildTxLongAFKOnly<E,X,A> view) {

        String viewName = view.getPrimaryKeyColumn().getJavaName();
        if (viewName.endsWith("Id"))
            viewName = viewName.substring(0, viewName.length() - 2);
        FlatView flatView = new FlatView(viewName, null);
        flatView.add(
            FieldMemberValue.create(
                new FieldMember(
                    flatView.getName(),
                    view.getPrimaryKeyColumn().getJavaName(),
                    getMemberTypeOf(view.getPrimaryKeyColumn().getRefType())),
                view.getTxId()));
        flatView.add(
            FieldMemberValue.create(
                new FieldMember(
                    flatView.getName(),
                    view.getAdditionalForeignKeyColumn().getJavaName(),
                    getMemberTypeOf(view.getAdditionalForeignKeyColumn().getRefType())),
                view.additionalForeignKeyValue()));
        JoinedView result = new JoinedView();
        result.add(flatView);
        return result;
    }

    public static <
        X extends SealedTxParent<?>,
        A extends TxKey.Category<?>,
        T extends Comparable<? super T>,
        E extends ChildTxEntityLongAFK.Of<X,A,T>>
    JoinedView
    toFlatView(
        ChildTxLongAFK<E,X,A,T> view) {

        String viewName = view.getPrimaryKeyColumn().getJavaName();
        if (viewName.endsWith("Id"))
            viewName = viewName.substring(0, viewName.length() - 2);
        FlatView flatView = new FlatView(viewName, null);
        flatView.add(
            FieldMemberValue.create(
                new FieldMember(
                    flatView.getName(),
                    view.getPrimaryKeyColumn().getJavaName(),
                    getMemberTypeOf(view.getPrimaryKeyColumn().getRefType())),
                view.getTxId()));

        flatView.add(
            FieldMemberValue.create(
                new FieldMember(
                    flatView.getName(),
                    view.getAdditionalForeignKeyColumn().getJavaName(),
                    getMemberTypeOf(view.getAdditionalForeignKeyColumn().getRefType())),
                view.additionalForeignKeyValue()));

        ChildTxEntityLongAFK.Attribute<T> attributeColumn = view.attributeColumn();
        if (attributeColumn.getRefType() == Type.RefType.LONG)
            flatView.add(
                FieldMemberValue.create(
                    new FieldMember(
                        flatView.getName(),
                        attributeColumn.getJavaName(),
                        getMemberTypeOf(attributeColumn.getRefType())),
                    (Long)view.attributeValue()));
        else if (attributeColumn.getRefType() == Type.RefType.INTEGER)
            flatView.add(
                FieldMemberValue.create(
                    new FieldMember(
                        flatView.getName(),
                        attributeColumn.getJavaName(),
                        getMemberTypeOf(attributeColumn.getRefType())),
                    (Integer)view.attributeValue()));
        else if (attributeColumn.getRefType() == Type.RefType.STRING)
            flatView.add(
                FieldMemberValue.create(
                    new FieldMember(
                        flatView.getName(),
                        attributeColumn.getJavaName(),
                        getMemberTypeOf(attributeColumn.getRefType())),
                    (String)view.attributeValue()));

        JoinedView result = new JoinedView();
        result.add(flatView);
        return result;
    }

    public static
    <F extends AbstractField & TxStarView.Field<?>>
    JoinedView
    toJson(
        TxStarView.Read<F> view) {

        JoinedView result = toJson(
            view,
            view.field().getClass().getSimpleName(),
            view.toString());

        boolean needTxTime = false;
        if (needTxTime) {
            int txTimeLength = "yyyymmddhhmmss".length();
            StringBuffer txTime = new StringBuffer(Long.toString(view.txRead().getTxTimeAsLong()));
            txTime.insert(txTimeLength - 2, ':');
            txTime.insert(txTimeLength - 4, ':');
            txTime.insert(txTimeLength - 6, ' ');
            txTime.insert(txTimeLength - 8, '/');
            txTime.insert(txTimeLength - 10, '/');
            result.get(0).
                add(
                    FieldMemberValue.create(
                        new FieldMember(
                            "TxTime",
                            "TxTime",
                            String.class),
                        txTime.toString()));
        }
        return result;
    }

    public static
    <F extends AbstractField & TxStarView.Field<?>>
    JoinedView
    toJson(
        AbstractView view,
        String fieldName,
        String viewAsString) {

        String prefixOfAppFields = fieldName + "...";

        //System.out.println(viewAsString);
        JoinedView viewValuesArray = new JoinedView();
        FlatView currentViewValues = new FlatView(fieldName, view);
        String prefix = "";
        String currentView = fieldName;
        int fieldNumber = 1;
        for(String line : viewAsString.split("\n")) {
            if (line.endsWith("]")) {
                if (line.contains("->")) {
                    String composedView = line.substring(0, line.indexOf("[")).trim();
                    String[] composedViewNameValue = composedView.split("->");
                    if (prefix != "" || !composedViewNameValue[0].equals("field1")) {
                        prefix = composedViewNameValue[1];
                        if (prefix.endsWith("Field"))
                            prefix = prefix.substring(0, prefix.length() - "Field".length());
                    }
                    String fieldNo = composedViewNameValue[0];
                    fieldNumber = Integer.parseInt(fieldNo.substring("Field".length()));
                    String field = composedViewNameValue[1];

                    if (field.contains("Field")) {
                        String name = field.substring(0, field.indexOf("Field"));
                        currentView = name;
                        currentViewValues = new FlatView(currentView, view);
                        viewValuesArray.add(currentViewValues);
                    }else{
                        viewValuesArray.add(currentViewValues);
                    }
                } else {
                    String field = line.
                        substring(
                            0,
                            line.indexOf("[")).trim();
                    if (field.endsWith("Field")) {
                        String name = field.substring(0, field.indexOf("Field"));
                        if ("Flat".equals(name)) {
                            currentView = fieldName;
                            currentViewValues = new FlatView(currentView, view);
                            viewValuesArray.add(currentViewValues);
                        } else {
                            currentView = name;
                            currentViewValues = new FlatView(currentView, view);
                            viewValuesArray.add(currentViewValues);
                        }
                    } else {
                        currentView = field;
                        currentViewValues = new FlatView(currentView, view);
                        viewValuesArray.add(currentViewValues);
                    }
                }
                line = line.
                    substring(
                        line.indexOf("[") + 1,
                        line.length() - 1);
            }

            if (line.contains(prefixOfAppFields)) {
                line = line.
                    substring(
                        line.indexOf(prefixOfAppFields) + prefixOfAppFields.length());
            }

            for(String field : line.split(",")) {
                if (field.contains("=")) {
                    int pos = field.indexOf("=");
                    String memberName = field.substring(0, pos);
                    while(!Character.isAlphabetic(memberName.charAt(0)) && memberName.length() > 1) {
                        memberName = memberName.substring(1);
                    }
                    if (!memberName.startsWith(prefix))
                        memberName = prefix + memberName;
                    String value = field.substring(pos+1);
                    if ("NOT_GIVEN".equals(value))
                        value = "";

                    String oldName = memberName;
                    if (fieldNumber > 1 && memberName.startsWith(currentView))
                        memberName = memberName.substring(currentView.length());

                    if (memberName.toUpperCase().equals("ID"))
                        memberName = "ID";
                    if (memberName.toUpperCase().equals("ID")) {
                        memberName = currentView + "Id";
                    }

                    FieldMember fieldMember = new FieldMember(
                        currentViewValues.getName(),
                        memberName,
                        getMemberTypeOf(
                            currentViewValues.getView(),
                            memberName));

                    currentViewValues.add(
                        FieldMemberValue.
                            create(
                                fieldMember,
                                value));
                }
            }
        }
        return viewValuesArray;
    }


    private static
    Class
    getMemberTypeOf(
        AbstractView view,
        String memberName) {

        return Unsafe.
            typeOf(
                view.field(),
                memberName).
            apply(
                type ->
                    getMemberTypeOf(type),
                () -> {
                    throw new RuntimeException(memberName + " not exist in view " + view.getClass().getSimpleName());
                });
    }

    private static
    Class
    getMemberTypeOf(
        Type.RefType type) {

        if (type == Type.RefType.STRING)
            return String.class;
        if (type == Type.RefType.INTEGER)
            return Integer.class;
        if (type == Type.RefType.YearMonth)
            return Integer.class;
        if (type == Type.RefType.YMD)
            return Integer.class;
        if (type == Type.RefType.LONG)
            return Long.class;
        if (type == Type.RefType.YMDHMS)
            return Long.class;
        if (type == Type.RefType.YMDHMSMSEC)
            return Long.class;
        if (type == Type.RefType.DECIMALSCALE5)
            return Double.class;
        if (type == Type.RefType.DECIMALSCALE4)
            return Double.class;
        if (type == Type.RefType.DECIMALSCALE3)
            return Double.class;
        if (type == Type.RefType.DECIMALSCALE2)
            return Double.class;
        if (type == Type.RefType.DECIMALSCALE1)
            return Double.class;
        if (type == Type.RefType.PRECISION18SCALE2)
            return Double.class;
        if (type == Type.RefType.PRECISION18SCALE5)
            return Double.class;
        if (type == Type.RefType.BYTE)
            return String.class;
        if (type == Type.RefType.TEXT)
            return String.class;
        throw new RuntimeException("Unsupport type yet:" + type);
    }

    public static
    Comparable
    getValue(
        String stringValue,
        Type.RefType refType) {

        Comparable value = null;
        switch(refType) {
            case STRING:
                value = String.valueOf(stringValue);
                break;
            case INTEGER:
                value = toInteger(stringValue);
                break;
            case LONG:
                value = toLong(stringValue);
                break;
            case YearMonth:
                value = toYearMonth(stringValue);
                break;
            case YMD:
                value = toYMD(stringValue);
                break;
            case DECIMALSCALE4:
                value = toDecimalScale4(stringValue);
                break;
            case DECIMALSCALE5:
                value = toDecimalScale5(stringValue);
                break;
            case DECIMALSCALE1:
                value = toDecimalScale1(stringValue);
                break;
            case DECIMALSCALE2:
                value = toDecimalScale2(stringValue);
                break;
            case DECIMALSCALE3:
                value = toDecimalScale3(stringValue);
                break;
            case PRECISION18SCALE5:
                value = toPrecision18Scale5(stringValue);
                break;
            case PRECISION18SCALE2:
                value = toPrecision18Scale2(stringValue);
                break;
            default:
                throw new RuntimeException();
        }
        return value;
    }

    public static
    Integer
    toInteger(
        String s) {

        Integer value =  (isEmpty(s)) ? null : Integer.valueOf(s);
        if (value == null && s.endsWith("Id"))
            value = -1;
        return value;
    }

    public static
    BigDecimal
    toBigDecimal(
        String s) {

        return (isEmpty(s)) ? null : new BigDecimal(s);
    }

    public static
    Double
    toDouble(
        String s) {

        return (isEmpty(s)) ? null : Double.valueOf(s);
    }

    public static
    boolean
    toBoolean(
        String s) {

        int value =  (isEmpty(s)) ? 0 : Integer.parseInt(s);
        return value > 0;
    }

    public static
    Long
    toLong(
        String s) {

        return (isEmpty(s)) ? null : Long.valueOf(s);
    }
    public static
    DateTime.YearMonth
    toYearMonth(
        String s) {

        return (isEmpty(s)) ? null : DateTime.YearMonth.create(
            toInteger(
                s.
                    replaceAll(
                        "/",
                        "")));
    }
    public static
    DateTime.YMD
    toYMD(
        String s) {

        return (isEmpty(s)) ? null : DateTime.YMD.create(
            toInteger(
                s.
                    replaceAll(
                        "/",
                        "")));
    }

    public static
    DateTime.YMDHMS
    toYMDHMS(
        String s) {

        return (isEmpty(s)) ? null : DateTime.YMDHMS.create(
            toLong(
                s.
                    replaceAll(
                        "/",
                        "").
                    replaceAll(
                        ":",
                        "").
                    replaceAll(
                        " ",
                        "")));
    }

    public static
    DecimalScale.DecimalScale4
    toDecimalScale4(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.DecimalScale4.of(
                toDouble(s));
    }
    public static
    DecimalScale.DecimalScale5
    toDecimalScale5(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.DecimalScale5.of(
                toDouble(s));
    }
    public static
    DecimalScale.DecimalScale3
    toDecimalScale3(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.DecimalScale3.of(
                toDouble(s));
    }
    public static
    DecimalScale.DecimalScale2
    toDecimalScale2(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.DecimalScale2.of(
                toDouble(s));
    }
    public static
    DecimalScale.DecimalScale1
    toDecimalScale1(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.DecimalScale1.of(
                toDouble(s));
    }

    public static
    DecimalScale.Precision18Scale2
    toPrecision18Scale2(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.Precision18Scale2.of(
                toBigDecimal(s));
    }

    public static
    DecimalScale.Precision18Scale5
    toPrecision18Scale5(
        String s) {

        return  (isEmpty(s)) ? null :
            DecimalScale.Precision18Scale5.of(
                toBigDecimal(s));
    }

    public static
    boolean
    isEmpty(
        String s) {

        return s == null || s.isEmpty();
    }

    public static boolean
    nonEmpty(
        String s) {

        return !isEmpty(s);
    }

    public static ImmutValues<Integer>
    getIntValues(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;

        JsonArray valuearray = json.getJsonArray(name);

        List<Integer> values = new ArrayList<>();
        valuearray.forEach(
            (value)->
                values.
                    add(
                        toInteger( value)));
        return ImmutValues.of(values.toArray(new Integer[0]));
    }

    private static
    Integer
    toInteger(
        JsonValue value) {

        if (value.getValueType() == JsonValue.ValueType.STRING)
            return Integer.valueOf(((JsonString) value).getString());
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return ((JsonNumber) value).intValue();
        return null;
    }

    public static
    Integer
    getIntValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name)) {
            return null;
        }
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING) {
            String sValue = ((JsonString) value).getString();
            if (sValue.length() == 0)
                return null;
            return Integer.valueOf(sValue);
        }
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return ((JsonNumber) value).intValue();
        return null;
    }

    public static
    Long
    getLongValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING) {
            String sValue = ((JsonString) value).getString();
            if (sValue.length() == 0)
                return null;
            return Long.valueOf(sValue);
        }
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return ((JsonNumber) value).longValue();
        return null;
    }

    public static
    BigDecimal
    getBigDecimal(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING)
            return new BigDecimal(((JsonString) value).getString());
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return BigDecimal.valueOf(((JsonNumber) value).doubleValue());
        return null;
    }

    public static
    Double
    getDoubleValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING)
            return Double.valueOf(((JsonString) value).getString());
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return ((JsonNumber) value).doubleValue();
        return null;
    }

    public static
    DecimalScale.Precision18Scale2
    getPrecision18Scale2Value(
        JsonObject json,
        String name ) {

        BigDecimal value = getBigDecimal(json, name);
        if (value == null)
            return null;
        return DecimalScale.Precision18Scale2.of(value);
    }

    public static
    DecimalScale.Precision18Scale5
    getPrecision18Scale5Value(
        JsonObject json,
        String name ) {

        BigDecimal value = getBigDecimal(json, name);
        if (value == null)
            return null;
        return DecimalScale.Precision18Scale5.of(value);
    }

    public static
    DecimalScale.DecimalScale5
    getDecimalScale5Value(
        JsonObject json,
        String name ) {

        Double value = getDoubleValue(json, name);
        if (value == null)
            return null;
        return DecimalScale.DecimalScale5.of(value);
    }

    public static
    DecimalScale.DecimalScale4
    getDecimalScale4Value(
        JsonObject json,
        String name ) {

        Double value = getDoubleValue(json, name);
        if (value == null)
            return null;
        return DecimalScale.DecimalScale4.of(value);
    }

    public static
    DecimalScale.DecimalScale2
    getDecimalScale2Value(
        JsonObject json,
        String name ) {

        Double value = getDoubleValue(json, name);
        if (value == null)
            return null;
        return DecimalScale.DecimalScale2.of(value);
    }

    public static
    DecimalScale.DecimalScale1
    getDecimalScale1Value(
        JsonObject json,
        String name ) {

        Double value = getDoubleValue(json, name);
        if (value == null)
            return null;
        return DecimalScale.DecimalScale1.of(value);
    }

    public static
    DecimalScale.DecimalScale3
    getDecimalScale3Value(
        JsonObject json,
        String name ) {

        Double value = getDoubleValue(json, name);
        if (value == null)
            return null;
        return DecimalScale.DecimalScale3.of(value);
    }
    public static
    DateTime.YMD
    getYMDValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if ( ((JsonString) value).getString().equals(""))
            return null;
        if (value.getValueType() == JsonValue.ValueType.STRING)
            return DateTime.YMD.create(Integer.parseInt(((JsonString) value).getString()));
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return DateTime.YMD.create(((JsonNumber) value).intValue());
        return null;
    }
    public static
    DateTime.YearMonth
    getYearMonthValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING)
            return DateTime.YearMonth.create(Integer.parseInt(((JsonString) value).getString()));
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return DateTime.YearMonth.create(((JsonNumber) value).intValue());
        return null;
    }

    public static
    DateTime.YMDHMS
    getYMDHMSValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING) {
            String val = ((JsonString) value).getString();
            return StringUtil.toYMDHMS(val).apply(v -> v, null);
        }
        if (value.getValueType() == JsonValue.ValueType.NUMBER) {
            long val = ((JsonNumber) value).longValue();
            return StringUtil.toYMDHMS(String.valueOf(val)).apply(v -> v, null);
        }
        return null;
    }

    public static
    NonNullValue<Long>
    getMandatoryLongValue(
        JsonObject json,
        String name ) {

        try {
            return NonNullValue.of(
                getLongValue(json, name));
        }catch (NonNullValue.NullNotAllowedException e) {
            throw new IllegalArgumentException(name + " は必須です。");
        }
    }

    public static
    NonNullValue<Integer>
    getMandatoryIntValue(
        JsonObject json,
        String name ) {

        try {
            return NonNullValue.of(
                getIntValue(json, name));
        }catch (NonNullValue.NullNotAllowedException e) {
            throw new IllegalArgumentException(name + " は必須です。");
        }
    }

    public static
    NonNullValue<String>
    getMandatoryStringValue(
        JsonObject json,
        String name ) {

        try {
            return NonNullValue.of(
                getStringValue(json, name));
        }catch (NonNullValue.NullNotAllowedException e) {
            throw new IllegalArgumentException(name + " は必須です。");
        }
    }

    public static
    NonNullValue<DateTime.YMD>
    getMandatoryYMDValue(
        JsonObject json,
        String name ) {

        try {
            return NonNullValue.of(
                getYMDValue(json, name));
        }catch (NonNullValue.NullNotAllowedException e) {
            throw new IllegalArgumentException(name + " は必須です。");
        }
    }

    public static
    NonNullValue<DateTime.YMDHMS>
    getMandatoryYMDHMSValue(
        JsonObject json,
        String name ) {

        try {
            return NonNullValue.of(
                getYMDHMSValue(json, name));
        }catch (NonNullValue.NullNotAllowedException e) {
            throw new IllegalArgumentException(name + " は必須です。");
        }
    }

    public static
    MayNullValue<Long>
    getOptionalLongValue(
        JsonObject json,
        String name ) {

        return MayNullValue.of(
            getLongValue(json, name));
    }

    public static
    MayNullValue<Integer>
    getOptionalIntValue(
        JsonObject json,
        String name ) {

        return MayNullValue.of(
            getIntValue(json, name));
    }

    public static
    MayNullValue<String>
    getOptionalStringValue(
        JsonObject json,
        String name ) {

        return MayNullValue.of(
            getStringValue(json, name));
    }

    public static
    MayNullValue<DateTime.YMD>
    getOptionalYMDValue(
        JsonObject json,
        String name ) {

        return MayNullValue.of(
            getYMDValue(json, name));
    }

    public static
    MayNullValue<DateTime.YMDHMS>
    getOptionalYMDHMSValue(
        JsonObject json,
        String name ) {

        return MayNullValue.of(
            getYMDHMSValue(json, name));
    }


    public static
    String
    getStringValue(
        JsonObject json,
        String name ) {

        if (!json.containsKey(name))
            return null;
        JsonValue value = json.get(name);
        if (value.getValueType() == JsonValue.ValueType.STRING)
            return ((JsonString) value).getString();
        if (value.getValueType() == JsonValue.ValueType.NUMBER)
            return  value.toString();
        return null;
    }

    public static
    <T extends IdentifiableEnum>
    T
    getEnumValue(
        JsonObject json,
        String name,
        Class<T> enumType) {

        String value = getStringValue(json, name);
        if (value == null)
            return null;
        return getEnumValue(enumType, value);
    }

    public static
    <T extends IdentifiableEnum>
    String
    toEnumRespValue(
        T obj) {

        try {
            Method getRespNameMethod = obj.getClass().getMethod("getRespName");
            if ((getRespNameMethod.getReturnType() == String.class)) {
                return (String) getRespNameMethod.invoke(obj);
            }
        }catch (Exception e) {
            //nothing to do
        }
        return obj.name();
    }

    @SuppressWarnings(value="unchecked")
    public static
    <T extends IdentifiableEnum>
    T
    getEnumValue(
        Class<T> enumType,
        String name) {

        try {
            Method getByRespNameMethod = enumType.getMethod("getByRespName", String.class);
            if ((getByRespNameMethod.getReturnType() == enumType) && Modifier.isStatic(getByRespNameMethod.getModifiers())) {
                return (T) getByRespNameMethod.invoke(null, name);
            } else {
                Method valueOfMethod = enumType.getMethod("valueOf", String.class);
                if ((valueOfMethod.getReturnType() == enumType) && Modifier.isStatic(valueOfMethod.getModifiers())) {
                    return (T) valueOfMethod.invoke(null, name);
                }
            }
        }catch (Exception e) {
            System.err.println(e);
        }
        return null;
    }

    public static
    <F extends AbstractField>
    JsonArray
    toJsons(
        String viewName,
        ImmutVOs<? extends AbstractView<F>> views) {

        List<AbstractField.Member.Mandatory> mandatoryMembers = BusinessMgrContainer.getMandatoryMembers(viewName);
        List<AbstractField.Member.Optional> optionalMembers = BusinessMgrContainer.getOptionalMembers(viewName);

        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        views.foreach(
            (view)->
                jsonArrayBuilder.add(
                    toJson(
                        mandatoryMembers,
                        optionalMembers,
                        view)));
        return jsonArrayBuilder.build();
    }

    public static
    <E extends aloha3.module.object.record.master.spec.RelationEntity<?,?>,
        F extends StarView.Relation.FieldOf<E>>
    JsonArray
    toJsonsFromRelations(
        String viewName,
        ImmutVOs<StarView.Relation.Read<F>> views) {

        List<AbstractField.Member.Mandatory> mandatoryMembers = BusinessMgrContainer.getMandatoryMembers(viewName);
        List<AbstractField.Member.Optional> optionalMembers = BusinessMgrContainer.getOptionalMembers(viewName);

        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        views.foreach(
            (view)->
                jsonArrayBuilder.add(
                    toJson(
                        mandatoryMembers,
                        optionalMembers,
                        view)));
        return jsonArrayBuilder.build();
    }

    public static <
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & TxStarView.Field<X>,
        M extends TxMgt.StarView<X,F,?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends TxStarView.FieldOf.AndLongFK<VX>>
    JsonArray
    toJsonsFromTxCRUDs(
        String viewName,
        ImmutVOs<OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>>> views) {

        List<AbstractField.Member.Mandatory> mandatoryMembers = BusinessMgrContainer.getMandatoryMembers(viewName);
        List<AbstractField.Member.Optional> optionalMembers = BusinessMgrContainer.getOptionalMembers(viewName);

        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        views.foreach(
            (view)->
                jsonArrayBuilder.add(
                    toJson(
                        mandatoryMembers,
                        optionalMembers,
                        view)));
        return jsonArrayBuilder.build();
    }

    public static
    <F extends AbstractField & TxStarView.Field<?>>
    JsonArray
    toJsonsFromTxStarViews(
        String viewName,
        ImmutVOs<TxStarView.Read<F>> views) {

        List<AbstractField.Member.Mandatory> mandatoryMembers = BusinessMgrContainer.getMandatoryMembers(viewName);
        List<AbstractField.Member.Optional> optionalMembers = BusinessMgrContainer.getOptionalMembers(viewName);

        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        views.foreach(
            (view)->
                jsonArrayBuilder.add(
                    toJson(
                        mandatoryMembers,
                        optionalMembers,
                        view)));
        return jsonArrayBuilder.build();
    }

    public static JsonArray toJsonsFromTxModels(String viewName, ImmutVOs models) {
        if (models.size() == 0) {
            return Json.createArrayBuilder().build();
        } else {
            return models.eltAt(0) instanceof TxChildModel ? toJsonsFromTxChildModels(viewName, models) : Json.createArrayBuilder().build();
        }
    }
    public static <F extends AbstractField & TxStarView.Field<?>, V extends ValueObject, FF extends TxModel.AbstractFlatField<F, ?>, T extends TxChildModel<F, V, FF>> JsonArray toJsonsFromTxChildModels(String viewName, ImmutVOs<T> models) {
        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        if (models.empty()) {
            return jsonArrayBuilder.build();
        } else {
            List<AbstractField.Member.Mandatory> mandatoryMembers = BusinessMgrContainer.getMandatoryMembers(viewName);
            List<AbstractField.Member.Optional> optionalMembers = BusinessMgrContainer.getOptionalMembers(viewName);
            models.foreach((model) -> {
                JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
                Object parent = model.view();
                if (parent instanceof TxStarView.Read) {
                    jsonBuilder.add("parent", toJson(mandatoryMembers, optionalMembers, (TxStarView.Read)parent));
                } else if (parent instanceof OneToOne) {
                    jsonBuilder.add("parent", toJson(mandatoryMembers, optionalMembers, (OneToOne)parent));
                } else {
                    System.out.println("Unknown Parant type " + parent.getClass().getName());
                }

                JsonArrayBuilder childArrayBuilder = Json.createArrayBuilder();
                model.getFlatViews().foreach((child) -> {
                    childArrayBuilder.add(toJson(model.childMembers(), model.childOptionalMembers(), child));
                });
                jsonBuilder.add("child", childArrayBuilder.build());
                jsonArrayBuilder.add(jsonBuilder);
            });
            return jsonArrayBuilder.build();
        }
    }

    public static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    JsonObject
    toJson(
        String viewName,
        MayNullVO<StarView.Read<F>> view) {

        return view.apply(
            (vo)->
                toJson(
                    BusinessMgrContainer.getMandatoryMembers(viewName),
                    BusinessMgrContainer.getOptionalMembers(viewName),
                    vo),
            ()->
                Json.createObjectBuilder().build() );
    }

    public static
    <F extends AbstractField>
    JsonObject
    toJson(
        List<AbstractField.Member.Mandatory> membersMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        AbstractView<F> view) {

        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        AbstractField abstractField = view.field();

        if (abstractField instanceof  StarView.FieldOf sField) {
            jsonBuilder.add(
                sField.unsafeCenterMember().name(),
                view.intValue(f -> sField.unsafeCenterMember()));

            membersMembers.
                forEach(
                    (member) ->

                        setValue(
                            jsonBuilder,
                            member.javaName(),
                            view.mandatoryValue(f->member)));

            optionalMembers.
                forEach(
                    (member) ->
                        setValue(
                            jsonBuilder,
                            member.javaName(),
                            (Comparable)view.optionalValue(f->member).
                                apply(v->v,()->null)));

            return jsonBuilder.build();
        } else if (abstractField instanceof  StarView.FieldOf.ForeignCore fcField) {
            StarView.FieldOf.ForeignCore field = (StarView.FieldOf.ForeignCore)abstractField;

            jsonBuilder.add(
                field.unsafeCenterMember().name(),
                ((StarView.Read)view).coreRead().rowId());

            String str = view.toString();
            str = str.substring(str.indexOf('[') + 1, str.length() -1);
            Map<String, String> viewAsJson = toMap(membersMembers, optionalMembers, (StarView.Read)view);
            membersMembers.
                forEach(
                    (member) ->
                        setValue(
                            jsonBuilder,
                            member.javaName(),
                            viewAsJson.get(member.javaName())));

            optionalMembers.
                forEach(
                    (member) ->
                        setValue(
                            jsonBuilder,
                            member.javaName(),
                            viewAsJson.get(member.javaName())));

            return jsonBuilder.build();
        } else if ( view instanceof TemporalView.Read tView) {

            membersMembers.
                forEach(
                    (member) ->
                        setValue(
                            jsonBuilder,
                            member.javaName(),
                            view.mandatoryValue(f->member)));

            optionalMembers.
                forEach(
                    (member) ->
                        setValue(
                            jsonBuilder,
                            member.javaName(),
                            (Comparable)view.optionalValue(f->member).
                                apply(v->v,()->null)));

            return jsonBuilder.build();
        } else
            return null;
    }

    public static
    <E extends aloha3.module.object.record.master.spec.RelationEntity<?,?>,
        F extends StarView.Relation.FieldOf<E>>
    JsonObject
    toJson(
        List<AbstractField.Member.Mandatory> membersMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        StarView.Relation.Read<F> view) {

        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        AbstractField abstractField = ((StarView.Relation.Read) view).field();

        jsonBuilder.add(
            view.field().unsafeCenterMember().name(),
            view.intValue(f -> f.unsafeCenterMember()));

        jsonBuilder.add(
            view.field().unsafePivotFKMember().name(),
            view.intValue(f -> f.unsafePivotFKMember()));
        jsonBuilder.add(
            view.field().unsafePivotAFKMember().name(),
            view.intValue(f -> f.unsafePivotAFKMember()));

        membersMembers.
            forEach(
                (member) ->

                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        optionalMembers.
            forEach(
                (member) ->
                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        return jsonBuilder.build();
    }

    public static
    <X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & TxStarView.Field<X>,
        M extends TxMgt.StarView<X,F,?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends TxStarView.FieldOf.AndLongFK<VX>>
    JsonObject
    toJson(
        List<AbstractField.Member.Mandatory> membersMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>> view) {

        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
//        AbstractField abstractField = view.left;
//
//        jsonBuilder.add(
//            view.field().centerMember().name(),
//            view.intValue(f -> f.centerMember()));
//
//        jsonBuilder.add(
//            view.field().relationFK().name(),
//            view.intValue(f -> f.relationFK()));
//        jsonBuilder.add(
//            view.field().relationAFK().name(),
//            view.intValue(f -> f.relationAFK()));

        membersMembers.
            forEach(
                (member) ->

                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        optionalMembers.
            forEach(
                (member) ->
                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        return jsonBuilder.build();
    }

    public static
    <F extends AbstractField & TxStarView.Field<?>>
    JsonObject
    toJson(
        List<AbstractField.Member.Mandatory> membersMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        TxStarView.Read<F> view) {

        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        jsonBuilder.add(
            view.field().unsafeCenterMember().name(),
            view.txRead().getRowId());

        membersMembers.
            forEach(
                (member) ->
                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        optionalMembers.
            forEach(
                (member) ->
                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        return jsonBuilder.build();
    }

    public static
    <F extends AbstractField>
    JsonObject
    toJson(
        List<AbstractField.Member.Mandatory> mandatoryMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        View<F> view) {

        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        mandatoryMembers.
            forEach(
                (member) ->
                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        optionalMembers.
            forEach(
                (member) ->
                    setValue(
                        jsonBuilder,
                        member.javaName(),
                        getValue(
                            member,
                            view)));

        return jsonBuilder.build();
    }

    public static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    Map<String, String>
    toMap(
        List<AbstractField.Member.Mandatory> mandatoryMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        StarView.Read<F> view) {

        return toMap(mandatoryMembers, optionalMembers, view.toString());
    }

    public static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    Map<String, String>
    toMap(
        List<AbstractField.Member.Mandatory> mandatoryMembers,
        List<AbstractField.Member.Optional>  optionalMembers,
        String str) {

        str = str.substring(str.indexOf('[') + 1, str.length() -1);
        Map<String, String> viewAsJson = new HashMap<>();
        for(String values : str.split(",")) {
            String[] split = values.split("=");
            String name = split[0];
            String value = split[1];
            viewAsJson.put(name, value);
        }
        return viewAsJson;
    }

    private static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Mandatory<T> member,
        StarView.Read<F> view) {

        return view.
            mandatoryValue(
                f->member);
    }

    private static
   <F extends AbstractField,
    T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Mandatory<T> member,
        View<F> view) {

        return view.
            mandatoryValue(
                f->member);
    }

    private static
    <F extends AbstractField,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Optional<T> member,
        View<F> view) {

        return view.
            optionalValue(
                f->member).
            apply(
                value->value,
                ()->null );
    }

    private static
    <E extends aloha3.module.object.record.master.spec.RelationEntity<?,?>,
        F extends StarView.Relation.FieldOf<E>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Mandatory<T> member,
        StarView.Relation.Read<F> view) {

        return view.
            mandatoryValue(
                f->member);
    }

    private static <
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & TxStarView.Field<X>,
        M extends TxMgt.StarView<X,F,?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends TxStarView.FieldOf.AndLongFK<VX>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Mandatory<T> member,
        OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>> view) {

        if (view.left.field().getClass() == member.field().getClass())
            return view.left.
                mandatoryValue(
                    f -> member);
        else
            return view.right.
                mandatoryValue(
                    f -> member);
    }

    private static
    <E extends CoreEntity,
        F extends StarView.FieldOf<E>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Optional<T> member,
        StarView.Read<F> view) {

        return view.
            optionalValue(
                f->member).
            apply(
                value->value,
                ()->null );
    }

    private static
    <E extends aloha3.module.object.record.master.spec.RelationEntity<?,?>,
        F extends StarView.Relation.FieldOf<E>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Optional<T> member,
        StarView.Relation.Read<F> view) {

        return view.
            optionalValue(
                f->member).
            apply(
                value->value,
                ()->null );
    }

    private static <
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & TxStarView.Field<X>,
        M extends TxMgt.StarView<X,F,?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends TxStarView.FieldOf.AndLongFK<VX>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Optional<T> member,
        OneToOne<TxStarView.Read<F>,TxStarView.Read<VF>> view) {

        if (view.left.field().getClass() == member.field().getClass())
            return view.left.
                optionalValue(
                    f->member).
                apply(
                    value->value,
                    ()->null );
        else
            return view.right.
                optionalValue(
                    f->member).
                apply(
                    value->value,
                    ()->null );
    }

    private static
    <F extends AbstractField & TxStarView.Field<?>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Mandatory<T> member,
        TxStarView.Read<F> view) {

        return view.
            mandatoryValue(
                f->member);
    }

    private static
    <F extends AbstractField & TxStarView.Field<?>,
        T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Optional<T> member,
        TxStarView.Read<F> view) {

        return view.
            optionalValue(
                f->member).
            apply(
                value->value,
                ()->null );
    }

    private static
    JsonObjectBuilder
    setValue(
        JsonObjectBuilder jsonBuilder,
        String name,
        Comparable value) {

        if (value == null)
            return jsonBuilder;

        if (value instanceof String)
            jsonBuilder.add(
                name,
                (String) value);
        else if (value instanceof Integer)
            jsonBuilder.add(
                name,
                (Integer) value);
        else if (value instanceof Long)
            jsonBuilder.add(
                name,
                (Long) value);
        else if (value instanceof DecimalScale)
            jsonBuilder.add(
                name,
                ((DecimalScale) value).getValue());
        else if (value instanceof DateTime.SuperAsInt<?>)
            jsonBuilder.add(
                name,
                ((DateTime.SuperAsInt) value).getAsInt());
        else if (value instanceof DateTime.SuperAsLong<?>)
            jsonBuilder.add(
                name,
                ((DateTime.SuperAsLong) value).getAsLong());
        else if (value instanceof IdentifiableEnum)
            jsonBuilder.add(
                name,
                toEnumRespValue((IdentifiableEnum) value));
        return jsonBuilder;
    }

    public static
    JsonObject
    create(
        String name,
        JsonValue value ) {

        JsonObjectBuilder builder = Json.createObjectBuilder();
        builder.add(name, value);
        return builder.build();
    }

    private static
    < T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Mandatory<T> member,
        JsonObject view) {

        if (member.getRefType() == Type.RefType.STRING)
            view.getString(member.javaName());
        else if (member.getRefType() == Type.RefType.INTEGER)
            view.getInt(member.javaName());
        return null;
    }

    private static
    <T extends Comparable<? super T>>
    T
    getValue(
        AbstractField.Member.Optional<T> member,
        JsonObject view) {

        if (member.getRefType() == Type.RefType.STRING)
            view.getString(member.javaName());
        else if (member.getRefType() == Type.RefType.INTEGER)
            view.getInt(member.javaName());
        return null;
    }

    public static
    <E extends TxEntityIntFKValue.On<M, Integer>,
        M extends CoreEntity,
        T extends aloha3.module.object.record.meta.transaction.TxIntFKValue.Read<E>>
    JsonArray
    toJsonsFromTxGroup(String viewName, ImmutVOs<T> views) {
        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        if (views.empty()) {
            return jsonArrayBuilder.build();
        } else {
            views.foreach((view) -> {
                JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
                if (viewName != null) {
                    jsonBuilder.add(viewName + "Id", view.rowId());
                } else {
                    jsonBuilder.add(view.PK().getJavaName(), view.rowId());
                }

                EntityValues values = EntityValues.parse(view.toString());
                jsonBuilder.add(((TxEntityIntFKValue)view.entity()).getForeignKeyColumn().getJavaName(), values.getInt("foreignId"));
                jsonBuilder.add(((TxEntityIntFKValue)view.entity()).attributeColumn().getJavaName(), values.getInt("value"));
                jsonArrayBuilder.add(jsonBuilder);
            });
            return jsonArrayBuilder.build();
        }
    }

}
