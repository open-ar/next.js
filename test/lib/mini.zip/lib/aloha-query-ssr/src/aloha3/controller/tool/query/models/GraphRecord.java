package aloha3.controller.tool.query.models;

import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.object.record.master.spec.meta.Pivot;

import java.util.List;

class GraphRecord<E, M> extends AlohaRecord<Pivot<?>, Graph> {
    public GraphRecord(RECORD_TYPE type, String name, Pivot<?> entity, Graph dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
