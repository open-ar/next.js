package aloha3.controller.tool.meta;

import aloha3.module.object.view.AbstractField;

import java.io.File;
import java.lang.reflect.Field;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.SequencedCollection;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

// Same as aloha3.api.server.ClassFinder
class ClassFinder {

    static
    Class<?>[]
    getClasses(
        String packageName,
        ClassLoader classLoader
    ) throws Exception {

        //ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        assert classLoader != null;
        String path = packageName.replace('.', '/');
        ArrayList<Class<?>> classes = new ArrayList<>();
        Enumeration<URL> resources = classLoader.getResources(path);
        while (resources.hasMoreElements()) {
            URL resource = resources.nextElement();
            if (resource.getProtocol().equals("jar")) {
                classes.addAll(
                    findJarClasses(
                        resource,
                        packageName,
                        classLoader));
            } else if (resource.getProtocol().equals("file")) {
                classes.addAll(
                    findClasses(
                        safeURLToFile(resource),
                        packageName,
                        classLoader));
            } else {
                throw new RuntimeException("Not support " + resource.getProtocol());
            }
        }

        return classes.toArray(new Class[0]);
    }

    private static File safeURLToFile(URL resource) {
        try {
            return Path.of(resource.toURI()).toFile();
        } catch (URISyntaxException e) {
            System.err.println("Error URL resource not a file: " + resource.getFile());
            throw new RuntimeException(e);
        }
    }
    private static File safeURLToFile(String resource) {
        if (isWindows()) {
            // Fix Path.of exception while resource like "/C:/path/to/file.jar"
            resource = resource.replaceFirst("^/", "");
        }
        return Path.of(URLDecoder.decode(resource, StandardCharsets.UTF_8)).toFile();
    }
    private static boolean isWindows() {
        String osName = System.getProperty("os.name").toLowerCase();
        return osName.contains("win");
    }
    private static List<Class<?>>
    findJarClasses(
        URL resource,
        String packageName,
        ClassLoader classLoader
    ) throws Exception {

        List<Class<?>> classes = new ArrayList<>();
        String jarFilename = resource.getFile();
        if (jarFilename.startsWith("file:") && jarFilename.contains("!")) {
            jarFilename = jarFilename.substring("file:".length(), jarFilename.lastIndexOf("!"));
        }
        JarFile jarFile = new JarFile(safeURLToFile(jarFilename));
        Enumeration<JarEntry> entries = jarFile.entries();
        while (entries.hasMoreElements()) {
            JarEntry jarEntry = entries.nextElement();
            String clazz = jarEntry.getName().replaceAll("/", "\\.");
            if (
                clazz.startsWith(packageName) &&
                    clazz.endsWith(".class") &&
                    !clazz.endsWith("module-info.class") &&
                    !clazz.startsWith("META-INF") // Ignore META-INF.versions.9.org.junit...ModuleUtils.class or META-INF.versions.9.module-info.class
            ) {

                clazz = clazz.replaceAll("/", "\\.");
                try {
                    classes.add(
                        classLoader.loadClass(
                            clazz.substring(0, clazz.length() - 6)));
                } catch (Throwable e) {
                    //do nothing
                }
            }
        }
        return classes;
    }

    private static
    List<Class<?>>
    findClasses(
        File directory,
        String packageName,
        ClassLoader classLoader) {

        List<Class<?>> classes = new ArrayList<>();
        if (!directory.exists()) {
            return classes;
        }
        String prefix = packageName.isEmpty() ? "" : packageName + ".";
        File[] files = directory.listFiles();
        assert files != null;
        for (File file : files) {
            String className = file.getName();
            if (className.contains("$"))
                continue;
            if (file.isDirectory()) {
                assert !className.contains(".");
                classes.addAll(
                    findClasses(
                        file,
                        prefix + className,
                        classLoader));
            } else if (className.endsWith(".class")) {
                try {
                    classes.add(
                        classLoader.loadClass(
                            prefix + className.substring(0, className.length() - 6)));
                } catch (Throwable e) {
                    //do nothing
                }
            }
        }
        return classes;
    }


    private static Field 
    getFieldRecursive(Class<?> clazz, String fieldName) throws NoSuchFieldException {
        while (clazz != null) {
            try {
                Field field = clazz.getDeclaredField(fieldName);
                field.setAccessible(true);
                return field;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        throw new NoSuchFieldException(fieldName);
    }
    
    private static 
    Object 
    reflectMember(Object f, String fieldName) {
        try {
            Field membersField = getFieldRecursive(f.getClass(), fieldName);
            return membersField.get(f);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    SequencedCollection<AbstractField.TypedMember>
    getFieldMembers(AbstractField f) {
        return (SequencedCollection<AbstractField.TypedMember>)ClassFinder.reflectMember(f, "members");
    }
}
