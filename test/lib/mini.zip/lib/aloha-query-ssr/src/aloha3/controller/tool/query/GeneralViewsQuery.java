package aloha3.controller.tool.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutValues;
import aloha.module.object.Type;
import aloha3.controller.tool.query.crud.GenericSearch;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecord;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.model.read.ViewManyRecords;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class GeneralViewsQuery {

    private static AlohaRecord.RECORD_TYPE toFlat(AlohaRecord.RECORD_TYPE type) {
        if (type == AlohaRecord.RECORD_TYPE.DistinctTree) {
            return AlohaRecord.RECORD_TYPE.Core;
        }
        return type;
    }
    private static JsonObjectBuilder getField(String viewModelName, AlohaColumn field) {
        JsonObjectBuilder elemBuilder = Json.createObjectBuilder();
        elemBuilder.add("Name", ViewMgr.toColumnName(viewModelName, field.getName()));
        elemBuilder.add("Field", field.getName());
        elemBuilder.add("ColumnType", field.getType().name());
        elemBuilder.add("DataCategory", field.isNumeric() ? "Numeric" : "Text");
        elemBuilder.add("DataType", field.getDataType().name());
        elemBuilder.add("Foreign", field.isForeign() ? ViewMgr.toViewName(field.getForeignRecord()) : "");
        elemBuilder.add("immutable", field.isImmutable());
        elemBuilder.add("optional", field.isOptional());
        elemBuilder.add("isEnum", field.isEnum());
        if (field.isEnum()) {
            JsonArrayBuilder enumValues = Json.createArrayBuilder();
            field.getEnums().forEach((value) -> {
                enumValues.add(value.name());
            });
            elemBuilder.add("EnumValues", enumValues);
        }

        return elemBuilder;
    }

    private static
    JsonArrayBuilder
    getFields(
        String viewModelName) {

        return getFields(
            viewModelName,
            ViewMgr.getMembersNamesOf(viewModelName));
    }

    private static
    JsonArrayBuilder
    getFields(
        String viewModelName,
        List<AlohaColumn> columns) {

        JsonArrayBuilder fieldsBuilder = Json.createArrayBuilder();
        for (AlohaColumn field : columns) {
            JsonObjectBuilder elemBuilder = Json.createObjectBuilder();
            elemBuilder.add(
                "Name",
                ViewMgr.toColumnName(
                    viewModelName,
                    field.getName()));
            elemBuilder.add(
                "Field",
                field.getName());
            elemBuilder.add(
                "ColumnType",
                field.getType().name());
            elemBuilder.add(
                "DataCategory",
                field.isNumeric() ? "Numeric" : "Text");
            elemBuilder.add(
                "DataType",
                field.getDataType().name());
            elemBuilder.add(
                "Foreign",
                field.isForeign() ? ViewMgr.toViewName(field.getForeignRecord()) : "");

            elemBuilder.add(
                "immutable",
                field.isImmutable());

            elemBuilder.add(
                "optional",
                field.isOptional());

            elemBuilder.add(
                "isEnum",
                field.isEnum());
            if (field.isEnum()) {
                JsonArrayBuilder enumValues = Json.createArrayBuilder();
                field.getEnums().forEach(
                    (value) ->
                        enumValues.add(value.name()));
                elemBuilder.add(
                    "EnumValues",
                    enumValues);
            }
            fieldsBuilder.add(elemBuilder);
        }
        return fieldsBuilder;
    }

    private static
    boolean
    isImmutable(
        String viewModelName) {

        for (AlohaColumn field : ViewMgr.getMembersNamesOf(viewModelName)) {
            if (!field.isImmutable())
                return false;
        }
        return true;
    }

    public static
    Map<String, ViewConnections>
    getJoinedViews(
        JsonObject jsonParams  ) {

        final String startNodeInJson = jsonParams.getString("startNode");
        String startNode = ViewMgr.toViewModelName(startNodeInJson);
        JsonArray nodes = jsonParams.getJsonArray("nodes");
        JsonArray edges = jsonParams.getJsonArray("edges");
        Map<String, ViewConnections> joinedViews = new HashMap<>();
        for(int i = 0; i < nodes.size(); i++) {
            JsonObject node = nodes.getJsonObject(i);
            String viewName = node.getString("name");
            String viewId = node.getString("id");
            String modelName = ViewMgr.toViewModelName(viewName);

            if (viewName.contains(".")) {
                String linkColumn = viewName.substring(viewName.indexOf(".")+1);
                AlohaColumn tryColumn = ViewMgr.
                    getColumn(
                        startNode,
                        linkColumn);
                if (tryColumn!=null)
                    joinedViews.put(
                        viewId,
                        new ViewConnections(
                            viewId,
                            modelName,
                            tryColumn));
                else
                    joinedViews.put(
                        viewId,
                        new ViewConnections(viewId, modelName));
            } else {
                joinedViews.put(
                    viewId,
                    new ViewConnections(viewId, modelName));
            }
        }

        for(int i = 0; i < edges.size(); i++) {
            JsonObject edgeeValues = edges.getJsonObject(i);
            String fromView = edgeeValues.getString("from");
            String toView = edgeeValues.getString("to");
            //fromView = ViewMgr.toViewModelName(fromView);
            //toView = ViewMgr.toViewModelName(toView);

            joinedViews.
                get(
                    fromView).
                referentViews.
                add(
                    joinedViews.
                        get(
                            toView));
        }

        ViewConnections startView = joinedViews.get(startNodeInJson);

        for( ViewConnections joinedView: joinedViews.values()) {
            joinedView.joined= false;
        }

        processJoins(
            startView,
            joinedViews);

        //System.out.println(joinedViews);
        return joinedViews;
    }

    private static
    void
    processJoins(
        ViewConnections centerView,
        Map<String, ViewConnections> joinedViews) {

        centerView.joined = true;
        for( ViewConnections joinedView: joinedViews.values()) {
            if (joinedView.joined)
                continue;
            if (joinedView.referentViews.contains(centerView)) {
                joinedView.referentViews.
                    remove(
                        centerView);
                centerView.referrerViews.
                    add(
                        joinedView);
            }
        }

        for(ViewConnections view  : centerView.referrerViews.toArray(new ViewConnections[0])){
            processJoins(
                joinedViews.
                    get(
                        view.id),
                joinedViews);
        }

        for(ViewConnections view  : centerView.referentViews.toArray(new ViewConnections[0])){
            processJoins(
                joinedViews.
                    get(
                        view.id),
                joinedViews);
        }
    }

    public static class ViewConnections {
        final String id;
        final String name;
        final String primaryKey;
        final List<ViewConnections> referentViews = new ArrayList<>();
        final List<ViewConnections> referrerViews = new ArrayList<>();
        boolean joined = false;

        final Optional<AlohaColumn> link;

        ViewConnections(String id, String name) {
            this.id = id;
            this.name = name;
            this.primaryKey = name + "Id";
            this.link = Optional.empty();
        }
        ViewConnections(String id, String name, AlohaColumn linkColumn) {
            this.id = id;
            this.name = name;
            this.primaryKey = name + "Id";
            this.link = Optional.of(linkColumn);
        }

        @Override
        public
        String
        toString() {

            StringBuilder sb = new StringBuilder();
            sb.append(name);

            sb.append("\n\tJOIN:");
            for(ViewConnections referentView : referentViews ) {
                sb.append(referentView.name);
                sb.append(",");
            }
            sb.append("  <- ");
            for(ViewConnections referrerView : referrerViews ) {
                sb.append(referrerView.name);
                sb.append(",");
            }
            sb.replace(sb.length()-1, sb.length(),"\n");

            return sb.toString();
        }
    }

    private static
    JsonArray
    toJson(
        String viewName,
        List<CDC> cdcs) {

        JsonArrayBuilder builder = Json.createArrayBuilder();
        AlohaRecord<?, ?> record = ViewMgr.getRecord(viewName);
        List<AlohaColumn> columns = record.getColumns();
        for(CDC cdc : cdcs) {
            /*
             * initial at :20200316095557 values:ProductField [ProductId=10,Name=dfdf111,Code=code2]
             * updated at :20200330174937 values:ProductField [ProductId=10,Name=2222,Code=code2]
             * initial at :20200318145232 values:SupplierField [SupplierId=40,Name=Apple Co., Ltd,RegisteredByEmployeeId=30,ApprovedByEmployeeId=NOT_GIVEN]
             */
            //System.out.println(cdc);
            JsonObjectBuilder cdcBuilder = Json.createObjectBuilder();
            JsonArrayBuilder cdcValuesBuilder = Json.createArrayBuilder();
            for(String history : cdc.toString().split("\n")) {
                String[] parts = history.substring(0, history.indexOf("[")).split(" ");
                String type = parts[0];
                String timestamp = parts[2].substring(1);
                String values = history.substring(history.indexOf("["));
                values = "," + values.substring(1, values.length() - 1);

                JsonObjectBuilder historyBuilder = Json.createObjectBuilder();
                historyBuilder.add("type", type);
                historyBuilder.add("timestamp", timestamp);
                JsonObjectBuilder objectBuilder = Json.createObjectBuilder();

                List<Integer> positions = new ArrayList<>();
                for (AlohaColumn column : columns) {
                    int  pos = values.indexOf(","+ column.getName() + "=");
                    if (pos < 0)
                        continue;
                    positions.add(pos);
                }
                Collections.sort(positions);

                int pk = -1;
                for(int i = 0; i < positions.size(); i++) {
                    int pos1 = positions.get(i) + 1;
                    int pos2;
                    if (i >= (positions.size() - 1))
                        pos2 = values.length();
                    else
                        pos2 = positions.get(i+1);
                    String[] attr = values.substring(pos1, pos2).split("=");
                    String attrName = attr[0];
                    String attrValue = attr[1];
                    if (attrValue.equals("NOT_GIVEN"))
                        attrValue = "";
                    objectBuilder.add(ViewMgr.toColumnName(viewName, attrName), attrValue);
                    if (attrName.equals(viewName+"Id")) {
                        cdcBuilder.add("PK", attrValue);
                        pk = Integer.valueOf(attrValue);
                    }
                }
                for (AlohaColumn column : columns) {
                    if (column.getType() != AlohaRecord.COLUMN_TYPE.MultiValue)
                        continue;
                    CoreMgr.StarView.OneToMany oneToManyMgr = record.getOneToManyMgr(column);
                    if (oneToManyMgr == null)
                        continue;

                    GenericSearch.
                        queryMasterViewByPK(
                            viewName,
                            pk).
                        unlessNull_(
                            (core)->
                                objectBuilder.add(
                                    ViewMgr.toColumnName(
                                        viewName,
                                        column.getName()),
                                    queryMultiAttributes(
                                        column,
                                        oneToManyMgr,
                                        core,
                                        DateTime.YMDHMS.create(
                                            Long.valueOf(timestamp))))
                        );
                }

                historyBuilder.add("values", objectBuilder);
                cdcValuesBuilder.add(historyBuilder);
            }
            cdcBuilder.add("cdcs", cdcValuesBuilder);
            builder.add(cdcBuilder);
        }
        return builder.build();
    }

    private static
    JsonArray
    queryMultiAttributes(
        AlohaColumn column,
        CoreMgr.StarView.OneToMany oneToManyMgr,
        StarView.Read<StarView.FieldOf<CoreEntity>> core,
        DateTime.YMDHMS asOf) {

        ViewManyRecords viewManyRecords = oneToManyMgr.createViewManyRecords(core.coreRead(), asOf);
        if (viewManyRecords == null)
            return null;

        if (viewManyRecords instanceof ViewManyRecords.AttributeAFK attributeAFKs) {
            ImmutValues<Integer> values = attributeAFKs.manyValues();
            JsonArrayBuilder builder = Json.createArrayBuilder();
            values.foreach(
                (value)->
                    builder.add(value));
            return builder.build();
        } else if (viewManyRecords instanceof ViewManyRecords.Attribute attributes) {
            if (column.getDataType() == Type.RefType.STRING) {
                ImmutValues<String> values = getStringManyAttributes(attributes);
                JsonArrayBuilder builder = Json.createArrayBuilder();
                values.foreach(
                    (value)->
                        builder.add(value));
                return builder.build();
            }
        }
        return null;
    }

    private static
    <F extends
        AbstractField &
        Field.ofStarView.Around.Pivot<?>,
        A extends aloha3.module.object.record.master.AttributeEntity.Cancellable.Many<?,String>>
    ImmutValues<String>
    getStringManyAttributes(
        ViewManyRecords.Attribute<F,A> attributes) {

        return attributes.
            manyValues(
                ViewManyRecords.Attribute::valueOf);
    }

}
