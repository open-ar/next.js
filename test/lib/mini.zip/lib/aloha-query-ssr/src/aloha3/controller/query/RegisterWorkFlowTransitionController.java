package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.master.coc.StateField;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.function.business.transaction.coc.FlowableReadMgt;
import aloha3.module.object.record.AbstractColumn;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.opt.spec.MakeFlowable;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractCompositeField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_NAV_MENU_HTML;
import static aloha3.controller.query.RegisterWorkFlowController.getGraphViewById;
import static aloha3.controller.tool.meta.MappingConst.FLOW_ID;
import static aloha3.controller.tool.meta.MappingConst.FLOW_MGR;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.NEXT_STATE_ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.meta.MappingConst.WORK_FLOW_ID;

public class RegisterWorkFlowTransitionController extends AbstractController {
    public static final RegisterWorkFlowTransitionController INSTANCE = new RegisterWorkFlowTransitionController();

    public static final String MAIN_TEMPLATE = "registerWorkFlowTransition.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Workflow Transition";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void 
    handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST add new tx + transition");

        // save tx
        request.unlessNull_(
            PIVOT,
            pivot -> 
                AlohaCRUD.saveTxStarViewWithWorkFlow(
                    pivot,
                    request.keyValues(),
                    container()));
    
        // response.redirectTo("/aloha-query/registerWorkFlow/?pivot=State&operation=preview&workFlowId=" + workFlowId + "&flowId=" + flowId + "&flowMgr=" + flowMgr);
        response.redirectTo(request.target());
    }

    public static void 
    handlePut(
        Request request,
        Response response) {
        
        System.out.println("handle transition Put");
        transition(request, response);
        response.redirectTo(request.target());
    }

    // Ref: aloha3.controller.query.RegisterWorkFlowController.Stream.computedStateIds
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static
    void
    transition(Request request, Response response) {
        final var flowId = request.unlessNull(FLOW_ID, Long::valueOf, 0L);
        final var flowMgr = request.unlessNull(FLOW_MGR, String::valueOf, "");
        final var nextStateId = request.unlessNull(NEXT_STATE_ID, Integer::valueOf, 0);
        if (flowId > 0 && !flowMgr.isEmpty()) {
            for (final var txm : container().allTxM()) {
                if (txm instanceof TxIntFKMgr.StarView.Flowable<?, ?, ?> txmGeneric) {
                    // FlowableReadMgt flowableReadMgt = (FlowableReadMgt) txm;
                    if (txmGeneric.entity().getClass().getSimpleName().equals(flowMgr)) {
                        Read.TxTime flowable = txmGeneric.selectTx(flowId).mustNonNull();
                        ImmutVOs<StarView.Read<StateField>> nextStates = WorkFlow.nextStates(flowable);
                        StarView.Read<StateField> toState = nextStates.find(s ->
                                Objects.equals(s.mandatoryValue(StateField::StateId), nextStateId)).mustNonNull();
                        WorkFlow.transition(flowable, toState, DateTime.YMDHMS.current());
                    }
                }
            }
        }
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        computedStateIds(request),
                        request.unlessNull(FLOW_ID, Long::valueOf, 0L),
                        request.unlessNull(WORK_FLOW_ID, Integer::valueOf, 0)),
                INSTANCE::getWelcomeContent
            );
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                COMPONENTS_NAV_MENU_HTML,
                Context.Builder.create().
                    add("title", "Flowable Tx List").
                    add(AlohaMeta.getTxFlowables(container())).
                    build());
        }
    }

    private static <
        E extends MakeFlowable<?> & SealedTxParent<? extends AbstractColumn.PKAndMore<?>>
    >
    String
    renderMainContent(
        String pivot,
        OperationType operation,
        String computedStateIds,
        Long flowId,
        Integer workFlowId) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        Logger.INFO.log("registerTxView: " + viewInfo);
        var transitions = AlohaCRUD.workflowTransitions(pivot, container());

        // transitions.foreach(view -> {
        //     // view.mandatoryValue(f -> f.f1().ApplyId); // Can't not recognize in tool env
        //     view.mandatoryValue(f -> f.f1().WorkFlowId);
        //     view.mandatoryValue(f -> f.f1().StateId);
        //     view.mandatoryValue(f -> f.f1().TxTime);
        //     view.mandatoryValue(f -> f.f2().WorkFlowId());
        //     view.mandatoryValue(f -> f.f2().Name);
        //     view.mandatoryValue(f -> f.f3().StateId());
        //     view.mandatoryValue(f -> f.f3().Name);
        //     view.optionalValue(f -> f.f3().Note);
        // });
        
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, flowId).
            add(FLOW_ID, flowId).
            add(WORK_FLOW_ID, workFlowId).
            add("computedStateIds", computedStateIds).
            add("viewSchemas", viewInfo).
            add("workFlows", WorkFlow.allWorkFlows(DateTime.YMDHMS.current())).
            add("views", transitions).
            // add("nextStates", nextStates(flowId, pivot)). // TODO SSR buttons
            // add("currentState", currentState(flowId, pivot)). // TODO current state
            add("views_fk",
                getFkPivot(viewInfo).unlessNull(
                    fkPivot ->
                        AlohaCRUD.starViews(fkPivot, container()),
                    ImmutVOs.emptyVOs()));

        getAfkPivots(viewInfo).foreach(
            afkPivot -> {
                var views = AlohaCRUD.starViews(afkPivot, container());
                context.add("views_afk_" + StringUtil.decapitalize(afkPivot) + "Id", views);
            });

        // AlohaCRUD.starView(flowId, pivot, container()).unlessNull_(
        //     view ->
        //         context.add("view_of_id", view));
        getGraphViewById(workFlowId, DateTime.YMDHMS.current()).unlessNull_(
            view ->
                context.add("view_of_id", view));
        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static
    String
    computedStateIds(Request request) {
        final var flowId = request.unlessNull(FLOW_ID, Long::valueOf, 0L);
        final var mgrName = request.unlessNull(FLOW_MGR, String::valueOf, "");
        if (flowId > 0 && !mgrName.isEmpty()) {
            for (final var txm : container().allTxM()) {
                if (txm instanceof TxIntFKMgr.StarView.Flowable<?, ?, ?> txmGeneric) {
                    FlowableReadMgt flowableReadMgt = (FlowableReadMgt) txm;
                    if (txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {

                        Read.TxTime read = txmGeneric.selectTx(flowId).mustNonNull();

                        int currentStateId = WorkFlow.current(read).stateId();
                        String nextStateIds = ((java.util.List<?>) WorkFlow.
                            nextStates(read).asList()).stream().
                            map(v ->
                                ((StarView.Read<StateField>) v).mandatoryValue(StateField::StateId).toString()).
                            collect(Collectors.joining(","));
                        String historyStateIds = ((java.util.List<?>) WorkFlow.
                            historyOf(read, flowableReadMgt).asList()).stream().
                            map(history ->
                                ((View<AbstractCompositeField.Field.Two<?, StateField>>) history).mandatoryValue(f -> f.f2().StateId()).toString()).
                            collect(Collectors.joining(","));

                        // e.g. current=30, nextStates=20,40, history=10,20,30
                        String result = "currentStateId=" + currentStateId + " | nextStateIds=" + nextStateIds + " | historyStateIds=" + historyStateIds;
                        Logger.INFO.log(result);
                        return result;
                    }
                }
            }
        }
        return "";
    }

    private static
    MayNullValue<String>
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
            view ->
                view.
                    mandatoryValue(f->f.IsFK) == Bool.TRUE).
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static
    ImmutValues<String>
    getAfkPivots(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            filter(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE).
            toValues(view->
                view.optionalValue(f->f.Foreign).assertNonNull());
    }
}
