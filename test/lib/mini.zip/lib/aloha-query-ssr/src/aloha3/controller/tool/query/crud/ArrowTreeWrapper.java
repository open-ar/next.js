package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple.Pair;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecordFactory;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.conceptual.master.Graph.Tree.Distinct.StarArrow;
import aloha3.module.function.business.master.CoreMgr.StarView.OneToMany;
import aloha3.module.object.model.MayNull;
import aloha3.module.object.model.read.AbstractTree.SuperTree;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.HierarchyEntity.Of.Tree;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.StarView.FieldOf;
import aloha3.module.object.view.StarView.Read;
import aloha3.module.object.view.StarView.Write.Prepare;
import aloha3.module.object.view.StarView.Write.Prepare.Builder;
import aloha3.module.object.view.StarView.Write.Update;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonValue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ArrowTreeWrapper<
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends Tree<E>,
    HF extends StarView.Hierarchy.FieldOf<H>,
    HM extends StarArrow<E, H, F, HF>,
    T extends Read<F>>
    extends BaseMgrWrapper<T, Integer, Integer>
    implements GraphTreeWrapper<E, F, H> {

    private final String name;
    private final F field;
    private final HF linkField;
    private final HM mgr;
    private final Map<String, Class> afks;
    private final Class<H> treeType;
    private final Map<String, OneToMany> oneToManyMgrs = new HashMap();
    private CoreMgrStarViewWrapper<E, F, T> coreMgr;

    public ArrowTreeWrapper(String name, F field, HM mgr, List<Class> types) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
        this.linkField = mgr.arrowField();
        this.treeType = (Class<H>) mgr.hierarchyEntity().getClass();
        this.afks = new HashMap();
        Class nodeLinkType = this.treeType;
        Class[] var6 = nodeLinkType.getDeclaredClasses();
        int var7 = var6.length;

        for(int var8 = 0; var8 < var7; ++var8) {
            Class c = var6[var8];
            String fieldName = c.getSimpleName();
            if (FixedAttributeEntityAFK.Of.class == c.getSuperclass() ||
                FixedAttributeEntityAFK.Unique.class == c.getSuperclass()) {
                Class afk = AlohaRecordFactory.getTypeArguments(c).get(1);
                this.afks.put(fieldName + "Id", afk);
            }
        }

    }

    public CoreMgrStarViewWrapper<E, F, T> getCoreMgr() {
        return this.coreMgr;
    }

    public void setCoreMgr(CoreMgrStarViewWrapper<E, F, T> coreMgr) {
        this.coreMgr = coreMgr;
    }

    public Map<String, OneToMany> getOneToManyMgrs() {
        return this.oneToManyMgrs;
    }

    public boolean isOneToMany() {
        return !this.oneToManyMgrs.isEmpty();
    }

    public Class<H> getHierarchyEntity() {
        return this.treeType;
    }

    public String getName() {
        return this.name;
    }

    public boolean isMaster() {
        return true;
    }

    public Mandatory getCenterMember() {
        return ((FieldOf)this.mgr.coreReadMgt().field()).unsafeCenterMember();
    }

    public Class<H> getTreeType() {
        return this.treeType;
    }

    public HF getLinkField() {
        return this.linkField;
    }

    public String getLinkName() {
        String name = this.linkField.getClass().getSimpleName();
        if (name.endsWith("Field")) {
            name = name.substring(0, name.length() - "Field".length());
        }

        return name;
    }

    public int registerRoot(JsonArray json) {
        int resultGraphId = -1;
        Iterator var3 = json.iterator();

        while(var3.hasNext()) {
            JsonValue node = (JsonValue)var3.next();
            int graphId = node.asJsonObject().getInt("graphId");
            if (graphId <= 0) {
                JsonArray nodes = node.asJsonObject().getJsonArray("nodes");
                if (nodes.size() >= 1) {
                    JsonObject firstNode = nodes.get(0).asJsonObject();
                    int rootId = firstNode.getInt("id");
                    Read<F> root = this.mgr.coreReadMgt().createView(rootId, YMDHMS.current()).apply((v) -> {
                        return v;
                    }, () -> {
                        return null;
                    });
                    if (root != null) {
                        aloha3.module.object.model.write.Tree.StarArrow<F, H, HF> tree = aloha3.module.object.model.write.Tree.StarArrow.create(root, this.linkField.getClass(), YMDHMS.current());
                        this.buildTree(tree, firstNode.getJsonArray("nodes"));
                        resultGraphId = this.mgr.save(tree).get().coreId();
                    }
                }
            }
        }

        return resultGraphId;
    }

    public int updateRoot(JsonObject json) {
        Integer graphId = JsonUtils.getIntValue(json, "graphId");
        if (graphId != 0 && graphId > 0) {
            JsonArray nodes = json.getJsonArray("nodes");
            if (nodes.size() < 1) {
                return -1;
            } else {
                JsonObject firstNode = nodes.get(0).asJsonObject();
                int rootId = firstNode.getInt("id");
                Read<F> root = this.mgr.coreReadMgt().createView(rootId, YMDHMS.current()).apply((v) -> {
                    return v;
                }, () -> {
                    return null;
                });
                if (root == null) {
                    return -1;
                } else {
                    aloha3.module.object.model.write.Tree.StarArrow<F, H, HF> tree = aloha3.module.object.model.write.Tree.StarArrow.create(root, this.linkField.getClass(), YMDHMS.current());
                    this.buildTree(tree, firstNode.getJsonArray("nodes"));
                    this.mgr.selectGraph(graphId, YMDHMS.current()).unlessNull_((graph) -> {
                        this.mgr.update(graph, tree);
                    });
                    return graphId;
                }
            }
        } else {
            return -1;
        }
    }

    public int removeRoot(Integer graphId) {
        this.mgr.selectGraph(graphId, YMDHMS.current()).unlessNull_((graph) -> {
            this.mgr.deleteGraph(graph, YMDHMS.current());
        });
        return graphId;
    }

    private void buildTree(aloha3.module.object.model.write.Tree.StarArrow<F, H, HF> tree, JsonArray nodes) {
        Iterator var3 = nodes.iterator();

        while(var3.hasNext()) {
            JsonValue node = (JsonValue)var3.next();
            this.buildTree(tree, node.asJsonObject());
        }

    }

    private void buildTree(aloha3.module.object.model.write.Tree.StarArrow<F, H, HF> tree, JsonObject json) {
        int leafId = json.getInt("id");
        Read<F> leaf = this.mgr.coreReadMgt().createView(leafId, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        if (leaf != null) {
            JsonObject attrs = json.getJsonObject("attributes");
            if (json.getJsonArray("nodes").isEmpty()) {
                tree.addLeaf(leaf, (builder) -> {
                    this.getLinkAttributes().forEach((member) -> {
                        this.setMandatoryValue(attrs, member, builder);
                    });
                });
            } else {
                tree.addBranch(leaf, (builder) -> {
                    this.getLinkAttributes().forEach((member) -> {
                        this.setMandatoryValue(attrs, member, builder);
                    });
                }, (sunTree) -> {
                    this.buildTree(sunTree, json.getJsonArray("nodes"));
                });
            }

        }
    }

    public List<Mandatory> getLinkAttributes() {
        List<Mandatory> members = new ArrayList();
        this.linkField.attributeMembers().foreach((f) -> {
            if (f instanceof Mandatory) {
                members.add((Mandatory)f);
            }

        });
        return members;
    }

    public Class getAfk(String name) {
        return this.afks.get(name);
    }

    public void addNode(JsonObject json) {
        int fromId = json.getInt("FromId");
        int toId = json.getInt("ToId");
        int graphId = json.getInt("GraphId");
        Read<F> parent = this.mgr.coreReadMgt().createView(fromId, YMDHMS.current()).mustNonNull();
        Read<F> newLeaf = this.mgr.coreReadMgt().createView(toId, YMDHMS.current()).mustNonNull();
        Core.Read<Graph> graphRead = this.mgr.selectGraph(graphId, YMDHMS.current()).mustNonNull();
        JsonObject attrs = json.getJsonObject("Attributes");
        this.mgr.addLeaf(graphRead, parent.coreRead(), newLeaf, YMDHMS.current(), (builder) -> {
            this.getLinkAttributes().forEach((member) -> {
                this.setMandatoryValue(attrs, member, builder);
            });
        });
    }

    public void modifyNode() {
    }

    public void removeNode(JsonObject json) {
        int id = json.getInt("Id");
        int graphId = json.getInt("GraphId");
        Read<F> leafToBeDeleted = this.mgr.coreReadMgt().createView(id, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        Core.Read<Graph> graphRead = this.mgr.selectGraph(graphId, YMDHMS.current()).apply((v) -> {
            return v;
        }, () -> {
            return null;
        });
        if (leafToBeDeleted != null && graphRead != null) {
            this.mgr.deleteLeaf(graphRead, leafToBeDeleted, NonEmptyVOs::first, YMDHMS.current());
        }
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return this.mgr.coreReadMgt().selectAllCores(YMDHMS.current());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return ImmutVOs.emptyVOs();
    }

    public List<Long> getHistoryRegTimes() {
        return GraphMgr.selectGraphHistories(this.mgr);
    }

    public JsonArray queryTree(YMDHMS asOf) {
        List<Pair<Core.Read<Graph>, aloha3.module.object.model.read.Tree.StarArrow<F, HF>>> trees = new ArrayList();
        GraphMgr.selectAllGraph(this.mgr, asOf).foreach((graph) -> {
            try {
                this.mgr.createModel(graph, asOf).unlessNull_((model) -> {
                    trees.add(Pair.of(graph, model));
                });
            } catch (Exception var5) {
            }

        });
        Collections.sort(trees, Comparator.comparingInt((graph) -> {
            return graph.getT1().coreId();
        }));
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        trees.forEach((tree) -> {
            arrayBuilder.add(UGraph.toTreeNode(tree.getT1(), (aloha3.module.object.model.read.Tree.StarArrow)tree.getT2()));
        });
        return arrayBuilder.build();
    }

    public ImmutVOs<Core.Read<Graph>> queryAllGraphs() {
        return GraphMgr.selectAllGraph(this.mgr);
    }

    public List<SuperTree> selectAllRoots(YMDHMS at) {
        List<SuperTree> roots = new ArrayList();
        GraphMgr.selectAllGraph(this.mgr, at).foreach((graph) -> {
            try {
                MayNull var10000 = this.mgr.createModel(graph, at);
                Objects.requireNonNull(roots);
                var10000.unlessNull_(r->roots.add((SuperTree) r));
            } catch (Exception var5) {
            }

        });
        return roots;
    }

    @Override
    public Object getMgr() {
        return this.coreMgr.getMgr();
    }

    public Object register(JsonObject json) {
        if (this.coreMgr != null) {
            return this.coreMgr.register(json);
        } else {
            Value<Integer> id = this.mgr.save(this.generateView(json), YMDHMS.current());
            return id.get();
        }
    }

    public ImmutVOs<T> query() {
        return this.coreMgr != null ? this.coreMgr.query() : (ImmutVOs)this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).unlessEmpty((cores) -> {
            return this.mgr.coreReadMgt().createViews(cores, YMDHMS.current());
        }, ImmutVOs.emptyVOs());
    }

    public MayNullVO<T> queryByPK(Integer id) {
        return (MayNullVO<T>) this.mgr.coreReadMgt().createView(id, YMDHMS.current());
    }

    public ImmutVOs<T> queryByPKs(List<Integer> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : (ImmutVOs<T>) this.mgr.coreReadMgt().createViews(DistinctIds.toIntIDs(pkIDs), YMDHMS.current());
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs afkViews, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName);
    }

    private ImmutVOs queryByIntAFKViews(ImmutVOs<Read> afkViews, String afkName) {
        return afkViews.apply((afks) -> {
            AlohaColumn referenceColumn = ViewMgr.getJoinColumn(this.name, afkName);
            ImmutVOs mayEmptyCores;
            if (FixedAttributeEntityAFK.Of.class.isAssignableFrom(referenceColumn.getDeclaredClass()) || 
                FixedAttributeEntityAFK.Unique.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                mayEmptyCores = this.mgr.coreReadMgt().
                    selectCoresOfFixedAttribute(
                    (NonEmptyVOs)afks.map((v) -> {
                            return v.coreRead();
                        }),
                    referenceColumn.getDeclaredClass(),
                    YMDHMS.current());
            } else {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOf(
                    (NonEmptyVOs)afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            }

            return (ImmutVOs)mayEmptyCores.unlessEmpty((cores) -> {
                return this.mgr.coreReadMgt().createViews(DistinctIds.intIDsFromRecords((NonEmptyVOs)cores, core->((Core.Read)core).coreId()), YMDHMS.current());
            }, ImmutVOs.emptyVOs());
        }, () -> {
            return ImmutVOs.emptyVOs();
        });
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public void update(JsonObject json) {
        if (this.coreMgr != null) {
            this.coreMgr.update(json);
        } else {
            String primaryKeyName = this.getCenterMember().javaName();
            Integer targetId = JsonUtils.getIntValue(json, primaryKeyName);
            if (targetId == null) {
                return;
            }

            JsonUtils.removeKey(json, primaryKeyName);
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((exists) -> {
                this.mgr.save(this.generateView(exists, json));
            });
        }

    }

    public void delete(JsonObject json) {
        Integer targetId = JsonUtils.getIntValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((view) -> {
                this.mgr.delete(view, YMDHMS.current());
            });
        }
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(this.field);
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    private Prepare<E, F> generateView(JsonObject json) {
        Builder<E, F> builder = Builder.create(this.getFieldClass());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    private Update<F> generateView(Read<F> exists, JsonObject json) {
        Update.Builder<E, F> builder = Update.Builder.create(exists, YMDHMS.current());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public List<CDC> fetchHistories() {
        List<CDC> histories = new ArrayList();
        this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).foreach((core) -> {
            MayNull var10000 = this.mgr.coreReadMgt().cdcOfView(core.coreId());
            Objects.requireNonNull(histories);
            var10000.unlessNull_(r->histories.add((CDC) r));
        });
        return histories;
    }
}
