package aloha3.controller.tool;

import aloha.module.object.DateTime;
import aloha3.tool.template.Context;

public class SsrContextUtil {

    public enum UTIL_KEY implements Context.UtilityKey {
        DATE,
        STRING
    }

    public static final class Dates implements Context.StateLessUtility<UTIL_KEY> {
        public String format(DateTime.YMD ymd) {
            return
                ymd.getYear() + "/" +
                    ymd.getMonth() + "/" +
                    ymd.getDate();
        }
        public String format(DateTime.YMDHMS ymdhms) {
            return
                ymdhms.getYear() + "/" +
                ymdhms.getMonth() + "/" +
                ymdhms.getDate() + " " +
                (ymdhms.getHMS().hourOfDay < 10 ? "0" : "") +
                ymdhms.getHMS().hourOfDay + ":" +
                (ymdhms.getHMS().minute < 10 ? "0" : "") +
                ymdhms.getHMS().minute + ":" +
                (ymdhms.getHMS().second < 10 ? "0" : "") +
                ymdhms.getHMS().second;
        }
        public String formatJP(DateTime.YMD ymd) {
            return
                ymd.getYear() + "年" +
                    ymd.getMonth() + "月" +
                    ymd.getDate() + "日";
        }
        public String formatJP(DateTime.YMDHMS ymdhms) {
            return
                ymdhms.getYear()  + "年" +
                ymdhms.getMonth() + "月" +
                ymdhms.getDate() + "日" +
                (ymdhms.getHMS().hourOfDay < 10 ? "0" : "") +
                ymdhms.getHMS().hourOfDay + ":" +
                (ymdhms.getHMS().minute < 10 ? "0" : "") +
                ymdhms.getHMS().minute + ":" +
                (ymdhms.getHMS().second < 10 ? "0" : "") +
                ymdhms.getHMS().second;
        }
        public String formatISO(Object value) {
            if (value instanceof DateTime.YMD v) {
                return formatISO_(v);
            }
            if (value instanceof DateTime.YMDHMS v) {
                return formatISO_(v);
            }
            if (value instanceof Long v) {
                return formatISO_(v);
            }
            if (value instanceof Integer v) {
                return formatISO_(v);
            }
            // if is number & YYYYMMDD format, then convert to ISO YYYY-MM-DD
            // if is number & YYYYMMDDHHMMSS format, then convert to ISO YYYY-MM-DDTHH:MM:SS
            // otherwise return empty string
            if (value instanceof String) {
                try {
                    final var num = Long.parseLong((String) value);
                    if (num > 10000000000000L) {
                        return formatISO_(num);
                    }
                    if (num > 10000000L && num < 99991231) {
                        return formatISO_( (int) num);
                    }
                } catch (NumberFormatException e) {
                    return "";
                }
            }
            return "";
        }
        private String formatISO_(DateTime.YMD ymd) {
            return
                String.format(
                    "%04d-%02d-%02d",
                    ymd.getYear().getAsInt(),
                    ymd.getMonth().getAsInt(),
                    ymd.getDate().getAsInt());
        }
        private String formatISO_(Long ymdhms) {
            // if is > 1000000000000000, then it is a timestamp
            if (ymdhms > 10000000000000L) {
                return formatISO(DateTime.YMDHMS.create(ymdhms));
            }
            return "";
        }
        private String formatISO_(Integer ymd) {
            // if is > 1000000000000000, then it is a timestamp
            if (ymd > 10000000L && ymd < 99991231) {
                return formatISO(DateTime.YMD.create(ymd));
            }
            return "";
        }
        private String formatISO_(DateTime.YMDHMS ymdhms) {
            return
                String.format(
                    "%04d-%02d-%02dT%02d:%02d:%02d",
                    ymdhms.getYear().getAsInt(),
                    ymdhms.getMonth().getAsInt(),
                    ymdhms.getDate().getAsInt(),
                    ymdhms.getHMS().hourOfDay,
                    ymdhms.getHMS().minute,
                    ymdhms.getHMS().second);
        }
        public String todayYMDHMSBegin() {
            final var ymd = DateTime.YMD.today();
            return
                String.format(
                    "%04d-%02d-%02dT%02d:%02d:%02d",
                    ymd.getYear().getAsInt(),
                    ymd.getMonth().getAsInt(),
                    ymd.getDate().getAsInt(),
                    0,
                    0,
                    0);
        }
        public String todayYMDHMSEnd() {
            final var ymd = DateTime.YMD.today();
            return
                String.format(
                    "%04d-%02d-%02dT%02d:%02d:%02d",
                    ymd.getYear().getAsInt(),
                    ymd.getMonth().getAsInt(),
                    ymd.getDate().getAsInt(),
                    23,
                    59,
                    59);
        }
        public int toDecimalIfNullZero(DateTime.YMD mayNull) {
            return mayNull == null ?  0 : mayNull.decimal() ;
        }
        @Override
        public UTIL_KEY key() {
            return UTIL_KEY.DATE;
        }
    }
    public static final class Strings implements Context.StateLessUtility<UTIL_KEY> {
        public String newlineToBrTag(String str) {
            return str.replaceAll("\n", "<br>");
        }
        public String concat(CharSequence... elements) {
            if (elements == null) {
                return "";
            }
            return String.join("", elements);
        }
        @Override
        public UTIL_KEY key() {
            return UTIL_KEY.STRING;
        }
    }

}
