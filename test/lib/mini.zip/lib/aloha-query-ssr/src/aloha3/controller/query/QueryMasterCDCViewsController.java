package aloha3.controller.query;

import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.HashSet;
import java.util.Set;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;

public class QueryMasterCDCViewsController extends AbstractController {

    public static final QueryMasterCDCViewsController INSTANCE = new QueryMasterCDCViewsController();
    public static final String MAIN_TEMPLATE = "queryMasterCDCViews.html";

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Master";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return 
                request.apply(
                    PIVOT,
                    QueryMasterCDCViewsController::renderMainContent,
                    INSTANCE::getWelcomeContent);
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                INSTANCE.getNavMenuTemplate(),
                Context.Builder.create().
                    add(AlohaMeta.getPivots(container())).
                    build());
        }
    }

    private static String renderMainContent(String pivot) {
        return renderMainContent(pivot, OperationType.list, 0L);
    }

    private static String renderMainContent(String pivot, OperationType operation, Long id) {
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        final var histories = AlohaCRUD.starViewsCDC(pivot, container());
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("cdcs", histories).
            add("views_fk", getFkPivot(viewInfo).unlessNull(
                fkPivot -> AlohaCRUD.starViews(fkPivot, container()), ImmutVOs.emptyVOs())).
            add("views_afk", getAfkPivot(viewInfo).unlessNull(
                afkPivot -> AlohaCRUD.starViews(afkPivot, container()), ImmutVOs.emptyVOs()));

        AlohaCRUD.starView(id, pivot, container()).unlessNull_(
            view -> context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());

        return engine().process(MAIN_TEMPLATE, components, context.build());
    }

    private static MayNullValue<String> getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {
        return viewInfo
            .find(view -> view.mandatoryValue(f -> f.IsFK) == Bool.TRUE)
            .apply(
                view -> MayNullValue.of(view.optionalValue(f -> f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static MayNullValue<String> getAfkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {
        return viewInfo
            .find(view -> view.mandatoryValue(f -> f.IsAFK) == Bool.TRUE) // グラフは無視
            .apply(
                view -> MayNullValue.of(view.optionalValue(f -> f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }
}
