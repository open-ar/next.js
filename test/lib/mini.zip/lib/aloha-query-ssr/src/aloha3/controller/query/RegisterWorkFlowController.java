package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaCRUD.GraphField;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.master.coc.StateField;
import aloha3.module.function.business.master.coc.WorkFlowField;
import aloha3.module.object.model.read.Chain;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import java.io.StringReader;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.Function;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_NAV_MENU_HTML;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.NODES;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.query.AlohaQueryV1.getId;

public class RegisterWorkFlowController extends AbstractController {
    public static final RegisterWorkFlowController INSTANCE = new RegisterWorkFlowController();
    public static final String MAIN_TEMPLATE = "registerWorkFlow.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Workflow";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void handlePost(Request request, Response response) {
        System.out.println("handle POST");
        final var allStates = WorkFlow.allStates();
        request.unlessNull_(
            NODES,
            jsonNodes ->
                WorkFlow.saveThen(
                    request.unlessNull("workFlowName", "Workflow_" + System.currentTimeMillis()),
                    DateTime.YMDHMS.current(),
                    parseJsonNodes(
                        jsonNodes,
                        targetId ->
                            allStates.
                                find(v -> v.coreRead().coreId() == targetId).
                                mustNonNull())));
        response.redirectTo(request.target());
    }

    public static void handlePut(Request request, Response response) {
        System.out.println("handle Put");
        final var allStates = WorkFlow.allStates();
        final var asOf = DateTime.YMDHMS.current();
        request.unlessNull_(
            NODES, ID,
            (jsonNodes, workFlowId) ->
                getWorkFlowViewById(Integer.parseInt(workFlowId), asOf).
                    unlessNull_(
                        workFlowRead ->
                            WorkFlow.fullUpdate(
                                workFlowRead,
                                asOf,
                                parseJsonNodes(
                                    jsonNodes,
                                    targetId ->
                                        allStates.
                                            find(v -> v.coreRead().coreId() == targetId).
                                            mustNonNull()))));
        response.redirectTo(request.target());
    }

    public static void handleDelete(Request request, Response response) {
        System.out.println("handle Delete");
        request.unlessNull_(
            ID, 
            workFlowId ->
                getWorkFlowViewById(Integer.parseInt(workFlowId), DateTime.YMDHMS.current()).unlessNull_(
                    workFlowRead ->
                        WorkFlow.workFlowMgr.delete(
                            workFlowRead,
                            DateTime.YMDHMS.current())));
        response.redirectTo(request.target());
    }

    @SuppressWarnings("unchecked")
    static <
        F extends AbstractField & StarView.Field<?>>
    Tuple.Pair<StarView.Read<F>, StarView.Read<F>>[]
    parseJsonNodes(
        String jsonNodes,
        Function<Integer, StarView.Read<F>> getCurrentNode) {
        try (JsonReader reader = Json.createReader(new StringReader(jsonNodes))) {
            JsonArray rootArray = reader.readArray();
            if (rootArray.isEmpty()) {
                return new Tuple.Pair[0];
            }

            JsonObject firstElement = rootArray.getJsonObject(0);
            JsonArray nodesArray = firstElement.getJsonArray("nodes");
            if (nodesArray.isEmpty()) {
                return new Tuple.Pair[0];
            }

            Set<Tuple.Pair<StarView.Read<F>, StarView.Read<F>>> pairs = new LinkedHashSet<>();
            for (JsonValue nodeValue : nodesArray) {
                JsonObject node = nodeValue.asJsonObject();
                int currentId = getId(node);

                processDirectChildNodes(
                    node,
                    getCurrentNode.apply(currentId),
                    getCurrentNode,
                    pairs);
            }

            return pairs.toArray(new Tuple.Pair[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return new Tuple.Pair[0];
        }
    }

    private static <
        F extends AbstractField & StarView.Field<?>>
    void 
    processDirectChildNodes(
        JsonObject node,
        StarView.Read<F> sourceState,
        Function<Integer, StarView.Read<F>> getCurrentNode,
        Set<Tuple.Pair<StarView.Read<F>, StarView.Read<F>>> pairs) {
        
        JsonArray childNodes = node.getJsonArray("nodes");
        if (childNodes != null && !childNodes.isEmpty()) {
            for (JsonValue childNodeValue : childNodes) {
                JsonObject childNode = childNodeValue.asJsonObject();
                int targetId = getId(childNode);
                StarView.Read<F> targetState = getCurrentNode.apply(targetId);

                pairs.add(new Tuple.Pair<>(sourceState, targetState));
                processDirectChildNodes(childNode, targetState, getCurrentNode, pairs);
            }
        }
    }

    private static MayNullVO<StarView.Read<WorkFlowField>>
    getWorkFlowViewById(Integer workFlowId, DateTime.YMDHMS asOf) {
        return WorkFlow.
                selectWorkFlowByPK(workFlowId).
                flatMap(
                    v ->
                        WorkFlow.workFlowOf(v, asOf));
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Integer::valueOf, 0)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder.
                add("title", "ワークフロー一覧").
                add(
                    "pivots",
                    NonEmptyVOs.create(
                        AlohaMeta.createPivotField(
                            "State",
                            "Workflow")));
        }
    }

    private static 
    String 
    renderMainContent(
        String pivot,
        OperationType operation,
        Integer id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        Logger.INFO.log("registerWorkFlowView: " + viewInfo);
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("stars", AlohaCRUD.starViews(pivot, container())).
            add("views", getGraphViews(DateTime.YMDHMS.current()));

        getGraphViewById(id, DateTime.YMDHMS.current()).unlessNull_(
            view ->
                context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static String workflowToMarkdownChart(
        StarView.Read<WorkFlowField> workFlowFieldView,
        DateTime.YMDHMS asOf) {
        return workflowToMarkdownChart(
            workFlowFieldView,
            asOf,
            MayNullVO.nullInstance());
    }

    private static String workflowToMarkdownChart(
        StarView.Read<WorkFlowField> workFlowFieldView,
        DateTime.YMDHMS asOf,
        MayNullVO<AbstractView<StateField>> current) {
        final var sb = new StringBuilder();
        sb.append("graph LR\n");
        chainToMdGraph(
            getChain(workFlowFieldView.mandatoryValue(WorkFlowField::WorkFlowId), asOf),
            sb);
        current.unlessNull_(
            currentNode ->
                sb.
                    append("    class ").append(getNodeLabel(currentNode)).append(" selectedItemClass\n").
                    append("    style ").append(getNodeLabel(currentNode)).append(" fill:selectedItemStyle\n"));
        return sb.toString();
    }

    private static Chain.Star<StateField> getChain(Integer workflowId, DateTime.YMDHMS asOf) {
        return WorkFlow.chain(
            getWorkFlowViewById(workflowId, asOf).mustNonNull(),
            asOf);
    }

    private static void chainToMdGraph(Chain.Star<StateField> chain, StringBuilder sb) {
        chain.posts().foreach(post ->
            chainToMdGraph(post,
                sb.
                    append("    ").
                    append(chain.node().pivotRead().coreId()).
                    append("[").append(getNodeLabel(chain.node())).append("]").
                    append("-->").
                    append(post.node().pivotRead().coreId()).
                    append("[").append(getNodeLabel(post.node())).append("]").
                    append("\n")));
    }

    private static String getNodeLabel(AbstractView<StateField> current) {
        return current.
            optionalValue(f -> f.Note).
            apply(
                note -> note,
                () -> current.stringValue(f -> f.Name));
    }

    private static ImmutVOs<View<GraphField>> getGraphViews(DateTime.YMDHMS asOf) {
        return WorkFlow.allWorkFlows(asOf).map(v ->
            View.Builder.
                create(GraphField.class).
                setMandatoryValue(
                    f -> f.GraphId,
                    v.mandatoryValue(WorkFlowField::WorkFlowId)).
                setOptionalValue(
                    f -> f.WorkFlowName,
                    v.mandatoryValue(f -> f.Name)).
                setMandatoryValue(
                    f -> f.Graph,
                    workflowToMarkdownChart(v, asOf)).
                build());
    }

    static MayNullVO<View<GraphField>> getGraphViewById(Integer id, DateTime.YMDHMS asOf) {
        return getWorkFlowViewById(id, asOf).
            map(v ->
                View.Builder.
                    create(GraphField.class).
                    setMandatoryValue(
                        f -> f.GraphId,
                        v.mandatoryValue(f -> f.GraphId)).
                    setOptionalValue(
                        f -> f.WorkFlowName,
                        v.mandatoryValue(f -> f.Name)).
                    setMandatoryValue(
                        f -> f.Graph,
                        workflowToMarkdownChart(v, asOf)).
                    build());
    }
}
