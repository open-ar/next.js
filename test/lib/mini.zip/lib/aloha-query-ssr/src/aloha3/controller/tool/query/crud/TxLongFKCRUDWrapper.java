package aloha3.controller.tool.query.crud;

import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.transaction.TxMgt;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class TxLongFKCRUDWrapper<
    X extends TxEntityLongFK.On<C> & MakeCancellable<X>,
    C extends SealedTxParent<?>,
    CF extends TxStarView.FieldOf<?>,
    F extends TxStarView.FieldOf.AndLongFK<X>,
    M extends TxMgt.StarView<X, F, ?>,
    VX extends TxEntityLongFK.On<X>,
    VF extends TxStarView.FieldOf.AndLongFK<VX>,
    T extends OneToOne<TxStarView.Read<F>, TxStarView.Read<VF>>>
    extends BaseMgrWrapper<T, Long, Long> {

    private final String name;
    private final F field;
    private final VF vField;
    private final CRUD<X, F, M, VX, VF> mgr;
    private final aloha3.module.function.business.transaction.TxLongFKMgr.StarView<X, C, F> txMainMgr;


    public TxLongFKCRUDWrapper(String name, F field, VF vFields, CRUD<X, F, M, VX, VF> mgr, aloha3.module.function.business.transaction.TxLongFKMgr.StarView<X, C, F> txMgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
        this.vField = vFields;
        this.txMainMgr = txMgr;
    }

    public String getName() {
        return this.name;
    }

    public boolean isCRUD() {
        return true;
    }

    @Override
    public Object getMgr() {
        return this.txMainMgr;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((TxEntity)this.txMainMgr.foreignEntity()).getClass().getSimpleName();
        long fkId = Integer.parseInt(json.getString(foreignEntity + "Id"));
        MayNullVO<TxStarView.Read<CF>> cores = GenericSearch.queryTxViewByPK(foreignEntity, fkId);
        return cores.apply((fk) -> {
            TxStarView.Write.Prepare.Builder vBuilder = TxStarView.Write.Prepare.Builder.create(this.vField.getClass());
            this.setValues(json, this.vField, vBuilder);
            return ((TxLongFK.Read)this.mgr.create(((TxStarView.Write.Prepare.Builder)this.setValues(json, this.field, TxStarView.Write.Prepare.Builder.create(this.getFieldClass()))).build(), (txMgr, txTime) -> {
                return this.txMainMgr.create((Read)fk.unsafeTx(), txTime);
            }, vBuilder.build()).get()).rowId();
        }, () -> {
            return -1L;
        });
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeFK().javaName());
    }

    public ImmutVOs<? extends Read> queryTxs() {
        return Query.select(TxLongFK.Read.createCriteria(this.field.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->mgr.reads((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        MayNullVO var10000 = this.txMainMgr.selectTx(id);
        CRUD var10001 = this.mgr;
        Objects.requireNonNull(var10001);
        return (MayNullVO)var10000.apply(v->var10001.read((Read.TxTime) v), MayNullVO::nullInstance);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        if (pkIDs.isEmpty()) {
            return ImmutVOs.emptyVOs();
        } else {
            ImmutVOs var10000 = this.txMainMgr.selectTxs(DistinctIds.toLongIDs(pkIDs));
            CRUD var10001 = this.mgr;
            Objects.requireNonNull(var10001);
            return (ImmutVOs)var10000.apply(v->var10001.reads((NonEmptyVOs) v), ImmutVOs::emptyVOs);
        }
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return fkViews.empty() ? ImmutVOs.emptyVOs() : this.queryByFKViews(toTxViews(fkViews));
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<TxStarView.Read<CF>> fkViews) {
        return (ImmutVOs)fkViews.apply(
            foreignTxs -> 
                this.txMainMgr.selectByFK(foreignTxs.map(TxStarView.Read::txRead)).
                    apply(
                        this.mgr::reads, 
                        ImmutVOs::emptyVOs), 
            ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.view.StarView.Read> afkViews, String afkName) {
        return TxFamilyQuery.queryByIntAFKs(toCores(afkViews), ViewMgr.getColumn(this.name, afkName), this.txMainMgr, this);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.isForeignKey(afkName) ? this.queryByFKs(afkViews, params) : TxFamilyQuery.queryByLongAFKs(toTxs(afkViews), ViewMgr.getColumn(this.name, afkName), this.txMainMgr, this);
    }

    public void update(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.txMainMgr.selectTx(targetId).unlessNull_((txRead) -> {
                TxStarView.Write.Prepare.Builder vBuilder = TxStarView.Write.Prepare.Builder.create(this.vField.getClass());
                this.setValues(json, this.vField, vBuilder);
                this.mgr.update(txRead, vBuilder.build());
            });
        }
    }

    public void delete(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            MayNullVO var10000 = this.txMainMgr.selectTx(targetId);
            CRUD var10001 = this.mgr;
            Objects.requireNonNull(var10001);
            var10000.unlessNull_(v->var10001.delete((Read)v));
        }
    }

    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((TxStarView.FieldOf.AndLongFK)this.txMainMgr.field()).unsafeFK());
        members.addAll(this.getMandatoryAttributeMembers(this.vField));
        return members;
    }

    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        List<AbstractField.Member.Optional> members = this.getOptionalAttributeMembers(this.field);
        members.addAll(this.getOptionalAttributeMembers(this.vField));
        return members;
    }

    public AbstractField.Member.Mandatory getCenterMember() {
        return ((TxStarView.FieldOf.AndLongFK)this.txMainMgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    public aloha3.module.function.business.transaction.TxLongFKMgr.StarView<X, C, F> getTxMainMgr() {
        return this.txMainMgr;
    }
}
