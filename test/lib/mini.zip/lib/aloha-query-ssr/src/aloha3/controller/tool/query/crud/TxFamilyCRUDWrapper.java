package aloha3.controller.tool.query.crud;

import aloha.module.object.ImmutVOs;

public interface TxFamilyCRUDWrapper extends TxFamilyWrapper {
    ImmutVOs queryParents();
}
