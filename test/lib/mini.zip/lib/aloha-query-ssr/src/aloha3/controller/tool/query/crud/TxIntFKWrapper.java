package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class TxIntFKWrapper
    <E extends TxEntityIntFK.On<M>,
        M extends CoreEntity,
        F extends TxStarView.FieldOf.AndIntFK<E>,
        MF extends StarView.FieldOf<M>,
        T extends TxStarView.Read<F> >
    extends BaseMgrWrapper<T, Long, Integer> {

    private final String name;
    private final F field;
    private final TxIntFKMgr.StarView<E,M,F> mgr;

    public TxIntFKWrapper(String name, F field, TxIntFKMgr.StarView<E, M, F> mgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((Pivot)this.mgr.foreignEntity()).getClass().getSimpleName();
        int fkId = Integer.parseInt(json.getString(foreignEntity + "Id"));
        MayNullVO<aloha3.module.object.record.master.read.meta.Read<M>> core = GenericSearch.queryPivotReadByPK(foreignEntity, fkId);
        return core.apply((fk) -> {
            TxStarView.Write.Prepare.Builder builder = TxStarView.Write.Prepare.Builder.create(this.getFieldClass());
            this.setValues(json, this.field, builder);
            Persist.Value<Long> ret = this.mgr.save(builder.build(), fk, DateTime.YMDHMS.current());
            return ret.get();
        }, () -> {
            return -1L;
        });
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxIntFK.Read.createCriteria(this.field.entity()));
//        ImmutVOs<aloha3.module.object.record.master.read.meta.Read<M>> pivots =
//            GenericSearch.queryPivotReads(((Pivot)this.mgr.foreignEntity()).getClass().getSimpleName(), (String)null);
//        TxIntFKMgr.StarView var10001 = this.mgr;
//        Objects.requireNonNull(var10001);
//        return (ImmutVOs)pivots.apply(var10001::selectTxsByFK, ImmutVOs::emptyVOs);
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->mgr.createViews((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        return (MayNullVO<T>) this.mgr.createView(id);
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeFK().javaName());
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : (ImmutVOs<T>) this.mgr.createViews(DistinctIds.toLongIDs(pkIDs));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return fkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByFKViews(toCores(fkViews), params);
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<M>> fkViews, Map<String, Object> params) {
        return params.containsKey("from") && params.containsKey("to") ? this.queryByFKAndBetween(fkViews, (DateTime.YMDHMS)params.get("from"), (DateTime.YMDHMS)params.get("to")) : (ImmutVOs)fkViews.apply((cores) -> {
            ImmutVOs var10000 = this.mgr.selectTxsByFK(cores);
            TxIntFKMgr.StarView var10001 = this.mgr;
            Objects.requireNonNull(var10001);
            return (ImmutVOs)var10000.apply(v->var10001.createViews((NonEmptyVOs)v), ImmutVOs::emptyVOs);
        }, ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryByFKAndBetween(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<M>> fkViews, DateTime.YMDHMS from, DateTime.YMDHMS to) {
        List<T> result = new ArrayList();
        fkViews.foreach((fk) -> {
            this.mgr.createViews(fk, from, to).foreach((txView) -> {
                result.add((T)txView);
            });
        });
        return ImmutVOs.create(result);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return afkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByIntAFKViews(toCores(afkViews), afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read> afkViews, String afkName, Map<String, Object> params) {
        return this.isForeignKey(afkName) ? this.queryByFKs(afkViews, params) : TxFamilyQuery.queryByIntAFKs(toCores(afkViews), ViewMgr.getColumn(this.name, afkName), this.mgr, this);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return TxFamilyQuery.queryByLongAFKs(toTxs(afkViews), ViewMgr.getColumn(this.name, afkName), this.mgr, this);
    }

    public void update(JsonObject json) {
    }

    public void delete(JsonObject json) {
    }

    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((TxStarView.FieldOf.AndIntFK)this.mgr.field()).unsafeFK());
        return members;
    }

    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    public AbstractField.Member.Mandatory getCenterMember() {
        return ((TxStarView.FieldOf.AndIntFK)this.mgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    public F getField() {
        return this.field;
    }

    public TxIntFKMgr.StarView<E, M, F> getMgr() {
        return this.mgr;
    }
}
