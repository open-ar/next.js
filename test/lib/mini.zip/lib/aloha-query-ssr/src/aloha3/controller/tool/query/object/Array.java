package aloha3.controller.tool.query.object;

import aloha.module.object.ImmutableArray;
import aloha.module.object.ValueObject;

import java.util.ArrayList;
import java.util.List;

public class Array {

    public static
    <T>
    void
    foreach(
        List<T> array,
        IForeach<T> atEach){
        
        int index = 0;
        for( T elem : array ) {
            atEach.elementAt(
                elem,
                index++);
        }
    }

    public static
    <T extends ValueObject,
     R>
    List<R>
    map(
        ImmutableArray<T> array,
        IMap<T,R> imap){

        List<R> result = new ArrayList<>();
        for(int index = 0; index < array.size(); index++) {
            result.add(
                imap.map(
                    array.eltAt(index)));
        }
        return result;
    }

    public static
    <T,
     R>
    List<R>
    map(
        List<T> array,
        IMapWithIndex<T,R> imap){
        
        List<R> result = new ArrayList<R>();
        int index = 0;
        for( T elem : array ) {
            result.add(
                imap.map(
                    elem,
                    index));
            index++;
        }
        return result;
    }

    public static
    <T,
     R>
    List<R>
    map(
        T[] array,
        IMapWithIndex<T,R> imap){
        
        List<R> result = new ArrayList<R>();
        int index = 0;
        for( T elem : array ) {
            result.add(
                imap.map(
                    elem,
                    index));
            index++;
        }
        return result;
    }

    public static
    <T>
    void
    foreach(
        T[] array,
        IForeach<T> atEach){
        
        int index = 0;
        for( T elem : array ) {
            atEach.elementAt(
                elem,
                index++);
        }
    }

    public static
    <T>
    void
    foreach(
        T[] array,
        IForeachNoIndex<T> atEach){

        int index = 0;
        for( T elem : array ) {
            atEach.elementAt(
                elem);
        }
    }

    public static
    <T>
    T
    find(
        T[] array,
        IComparator<T> comparator){
        
        for( T elem : array ) {
            if (comparator.compare(elem))
                return elem;
        }
        throw new IllegalStateException("Not found");
    }


    public interface IMap<T,R> {

        R
        map(
            T elem);
    }
    public interface IMapWithIndex<T,R> {

        R
        map(
            T elem,
            int i);
    }

    public interface IForeach<T> {

        void
        elementAt(
            T elem,
            int index);
    }

    public interface IForeachNoIndex<T> {

        void
        elementAt(
            T elem);
    }
    
    public interface IComparator<T> {

        boolean
        compare(
            T elem);
    }

}
