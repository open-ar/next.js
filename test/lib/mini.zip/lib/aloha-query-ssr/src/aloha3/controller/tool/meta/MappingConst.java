package aloha3.controller.tool.meta;

public final class MappingConst {

    public static final String VALUES = "values";
    public static final String DETAILS = "details";
    public static final String TX_TIME = "txTime";
    public static final String VARIABLE = "variable";

    public static final String GRAPH_ID = "graphId";
    public static final String GRAPH_UNDER_NODE_ID = "underNodeId";

    public static final String STATE = "state";
    public static final String PAGING = "paging";

    public static final String ID = "id";
    public static final String FORM_ID = "formId";
    public static final String PIVOT = "pivot";
    public static final String ROOT_ID = "rootId";
    public static final String OPERATION = "operation";
    public static final String YMD = "ymd";
    public static final String NODES = "nodes";
    public static final String PARAMS = "params";

    public static final String FLOW_ID = "flowId";
    public static final String WORK_FLOW_ID = "workFlowId";
    public static final String FLOW_MGR = "flowMgr";
    public static final String NEXT_STATE_ID = "nextStateId";

    static final String TX_CHILDREN_LINE_ITEM = DETAILS;
}
