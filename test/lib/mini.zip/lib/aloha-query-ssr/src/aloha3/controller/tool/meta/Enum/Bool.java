package aloha3.controller.tool.meta.Enum;

import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutableArray;

import static aloha.module.object.IdentifiableEnum.find;
import static aloha.module.object.IdentifiableEnum.toArray;

public enum Bool implements IdentifiableEnum<Bool> {
    TRUE((byte)1),
    FALSE((byte)2);

    private final byte id;
    Bool(byte id) {
        this.id = id;
    }
    @Override
    public byte id() {
        return this.id;
    }
    @Override
    public Bool of(byte b) {
        return find(id,array);
    }
    public boolean val() {
        return this == TRUE;
    }
    public static Bool of(boolean b) {
        return b ? TRUE : FALSE;
    }
    final static ImmutableArray<Bool> array = toArray(Bool.class);
}
