package aloha3.controller.tool.meta;

import aloha.module.func.Func;
import aloha.module.func.business.AbstractServiceContainer;
import aloha.module.object.DateTime;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.master.Relation;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;

import java.util.Map;

class _StarViewMapping {

    static <
        E extends CoreEntity,
        F extends StarView.FieldOf<E>>
    StarView.Write.Prepare<E,F>
    toStarView(
        Map<String, String> jsonObject,
        Class<F> fieldClass,
        AbstractServiceContainer<?> MDMs) {

        return
            Func.apply(
                StarView.Write.Prepare.Builder.create(fieldClass),
                builder->
                    _ViewMapping.fromJsonObject(
                        jsonObject,
                        builder,
                        MDMs),
                StarView.Write.Prepare.Builder::build);
    }
    static <
        P extends CoreEntity,
        S extends CoreEntity,
        E extends aloha3.module.object.record.master.RelationEntity.Of<P,S>,
        F extends StarView.Relation.FieldOf<E>>
    StarView.Relation.Write.Prepare<E,F>
    toRelationStarView(
        Map<String, String> jsonObject,
        Class<F> fieldClass,
        AbstractServiceContainer<?> MDMs) {

        return Func.apply(
            Field.instanceOf(fieldClass),
            field->
                Func.apply(
                    _ViewMapping.findPivotMgr(field.entity().getForeignEntity(),MDMs),
                    _ViewMapping.findPivotMgr(field.entity().getAdditionalForeignEntity(),MDMs),
                    (fkMgr,afkMgr)->
                        Func.apply(
                            fkMgr.
                                selectPivotByPK(
                                    Integer.parseInt(
                                        jsonObject.get(
                                            StringUtil.decapitalize(field.entity().getForeignKeyColumn().getJavaName())))).
                                mustNonNull(),
                            afkMgr.
                                selectPivotByPK(
                                    Integer.parseInt(
                                        jsonObject.get(
                                            StringUtil.decapitalize(field.entity().getAdditionalForeignKeyColumn().getJavaName())))).
                                mustNonNull(),
                            (fkRead,afkRead)->
                                Func.apply(
                                    StarView.Relation.Write.Prepare.Builder.
                                        create(
                                            fieldClass,
                                            fkRead,
                                            afkRead),
                                    builder->
                                        _ViewMapping.fromJsonObject(
                                            jsonObject,
                                            builder,
                                            MDMs),
                                    StarView.Relation.Write.Prepare.Builder::build))));
    }

    static <
        E extends CoreEntity,
        F extends StarView.FieldOf.ForeignCore<E,A>,
        FE extends CoreEntity,
        A extends FixedAttributeEntityAFK.Of<E,FE>>
    StarView.Write.Prepare<E,F>
    toStarView(
        Map<String, String> jsonObject,
        Class<F> fieldClass,
        Class<A> foreignAttributeClass,
        AbstractServiceContainer<?> MDMs) {

        return
            Func.apply(
                Instance.of(foreignAttributeClass),
                fa->
                    Func.apply(
                        _ViewMapping.findPivotMgr(fa.getAdditionalForeignEntity(),MDMs),
                        Integer.parseInt(
                            jsonObject.get(StringUtil.decapitalize(fa.getAdditionalForeignKeyColumn().getJavaName()))),
                        (pivotMgr, pivotId)->
                            Func.apply(
                                pivotMgr.
                                    selectPivotByPK(pivotId).mustNonNull(),
                                foreignCoreRead->
                                    Func.
                                        apply(
                                            StarView.Write.Prepare.Builder.
                                                create(
                                                    fieldClass,
                                                    foreignCoreRead),
                                            builder->
                                                _ViewMapping.fromJsonObject(
                                                    jsonObject,
                                                    builder,
                                                    MDMs),
                                            StarView.Write.Prepare.Builder::build))));
    }

    static <
        E extends CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    StarView.Write.Update<F>
    toStarView(
        Map<String, String> jsonObject,
        Core.Read<E> coreRead,
        Class<F> fieldClass,
        DateTime.YMDHMS regTime,
        AbstractServiceContainer<?> MDMs) {

        return
            Func.apply(
                StarView.Write.
                    Update.Builder.
                    create(
                        fieldClass,
                        coreRead,
                        regTime),
                builder->
                    _ViewMapping.fromJsonObject(
                        jsonObject,
                        builder,
                        MDMs),
                StarView.Write.Update.Builder::build);
    }
    static <
        E extends aloha3.module.object.record.master.RelationEntity<?,?>,
        F extends StarView.Relation.FieldOf<E>>
    StarView.Relation.Write.Update<F>
    toRelationStarView(
        Map<String, String> jsonObject,
        Relation.Read<E> relationRead,
        Class<F> fieldClass,
        DateTime.YMDHMS regTime,
        AbstractServiceContainer<?> MDMs) {

        return
            Func.apply(
                StarView.Relation.Write.
                    Update.Builder.
                    create(
                        fieldClass,
                        relationRead,
                        regTime),
                builder->
                    _ViewMapping.fromJsonObject(
                        jsonObject,
                        builder,
                        MDMs),
                StarView.Relation.Write.Update.Builder::build);
    }
}
