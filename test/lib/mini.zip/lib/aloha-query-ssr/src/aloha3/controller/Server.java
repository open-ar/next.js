package aloha3.controller;

import aloha.module.object.DateTime;
import aloha3.controller.exception.ExceptionHandler;
import aloha3.controller.tool.SsrContextUtil;
import aloha3.controller.tool.query.ReflectiveJoinTool;

import aloha3.module.function.business.ServiceContainer;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.template.Context;
import aloha3.tool.template.Engine;
import org.thymeleaf.ITemplateEngine;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Set;

public class Server {

    private static volatile Path webRoot;
    private static volatile ITemplateEngine engine;
    private static volatile aloha3.tool.stream.Server.Config config;
    private static volatile ServiceContainer container;

    private static volatile ServiceContainer.Conceptual conceptual;
    private static volatile Set<aloha.concurrent.Context.Resource> resources;

    public static void 
    start(
        ServiceContainer container,
        ServiceContainer.Conceptual conceptualContainer,
        int port,
        aloha.concurrent.Context.Resource... resources) {

        start(container, conceptualContainer, Set.of(resources), "www", port, true);
    }

    public static void 
    start(
        ServiceContainer container,
        ServiceContainer.Conceptual conceptualContainer,
        int port,
        boolean openBrowser,
        aloha.concurrent.Context.Resource... resources) {

        start(container, conceptualContainer, Set.of(resources), "www", port, openBrowser);
    }
    


    public static void start(
        ServiceContainer container,
        int port,
        aloha.concurrent.Context.Resource... resources) {

        start(container, new ServiceContainer.Conceptual(container), port, resources);
    }

    public static void start(
        ServiceContainer container,
        int port,
        boolean openBrowser,
        aloha.concurrent.Context.Resource... resources) {

        start(container, new ServiceContainer.Conceptual(container), port, openBrowser, resources);
    }

    public static void start(
        ServiceContainer container, 
        ServiceContainer.Conceptual conceptualContainer,
        Set<aloha.concurrent.Context.Resource> resources,
        String staticRoot,
        int port) {

        start(container, conceptualContainer, resources, staticRoot, port, true);
    }

    public static void start(
        ServiceContainer container, 
        ServiceContainer.Conceptual conceptualContainer,
        Set<aloha.concurrent.Context.Resource> resources,
        String staticRoot,
        int port,
        boolean openBrowser) {

        // Init config
        webRoot = getWebRoot(staticRoot);
        engine = Engine.buildTemplateEngine(new Engine.WebApplication(webRoot));
        config = new aloha3.tool.stream.Server.Config(port, webRoot, new ExceptionHandler(), openBrowser);
        Server.container = container;
        Server.conceptual = conceptualContainer;
        Server.resources = resources;

        initLegacyAlohaQuery();
        initSsrContextUtil();

        // Initialize Plugins via SPI
        java.util.ServiceLoader.load(aloha3.controller.spi.AlohaQuerySsrPlugin.class)
            .forEach(plugin -> plugin.init(container, conceptualContainer));

        // Start the server
        Logger.INFO.log("Server started...");
        aloha3.tool.stream.Server.start(
            config,
            DateTime.YMDHMSMSEC.current(),
            Router::handle);
    }

    private static void 
    initSsrContextUtil() {
        Context.UtilityBuilder.
            create(SsrContextUtil.UTIL_KEY.class).
            add(SsrContextUtil.Dates.class).
            add(SsrContextUtil.Strings.class).
            doneFunc();
    }

    private static void initLegacyAlohaQuery() {
        // 旧版のView Joinなど機能を利用するので、初期化
        ReflectiveJoinTool.init(Server.container);
        ReflectiveJoinTool.init(Server.conceptual);
    }
    private static Path getWebRoot(String staticRoot) {
        // 1. From file system
        Path[] actualPaths = {
            Paths.get(System.getProperty("user.dir"), "aloha/stream-template-server/" + staticRoot),
            Paths.get(System.getProperty("user.dir"), "stream-template-server/" + staticRoot),
            Paths.get(System.getProperty("user.dir"), staticRoot)
        };

        for (Path path : actualPaths) {
            Logger.INFO.log("Checking path: " + path);
            if (Files.exists(path)) {
                Logger.INFO.log("Using path: " + path);
                return path;
            }
        }

        // 2. From classpath (inside JAR)
        URL webRootUrl = Server.class.getClassLoader().getResource(staticRoot);
        Logger.INFO.log("Classpath www URL: " + webRootUrl);
        if (webRootUrl != null) {
            try {
                if ("jar".equals(webRootUrl.getProtocol())) {
                    String[] parts = webRootUrl.toString().split("!");
                    try (FileSystem fs = FileSystems.newFileSystem(
                        URI.create(parts[0]), Collections.emptyMap())) {
                        return fs.getPath(parts[1]);
                    }
                } else {
                    return Paths.get(webRootUrl.toURI());
                }
            } catch (IOException | URISyntaxException e) {
                throw new RuntimeException("[ERROR] Failed to resolve www directory in classpath", e);
            }
        }

        throw new RuntimeException("[ERROR] Cannot find www directory in any location");
    }
    public static ITemplateEngine engine() {
        return engine;
    }
    public static ServiceContainer container() {
        return container;
    }
    public static ServiceContainer.Conceptual conceptual() {
        return conceptual;
    }

    public static Set<aloha.concurrent.Context.Resource> resources() {
        return resources;
    }
}
