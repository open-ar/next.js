package aloha3.controller.tool.query.crud;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TxIntFKFamilyLongAFKWrapper<
    E extends TxEntityIntFK.On<M>,
    M extends Pivot<?>,
    F extends TxStarView.FieldOf.AndIntFK<E>,
    CH extends ChildTxEntityLongAFK.Of<E,CM,CV>,
    CM extends TxKey.Category<?>,
    CV extends Comparable<? super CV>,
    T extends Read<CH>>
    extends BaseMgrWrapper<T, Long, Integer> {

    private final String name;
    private final F parentField;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final Class<CV> childValueType;
    private final TxIntFKMgr.StarView<E,M,F> parentMgr;
    private final TxIntFKMgr.StarView.Family.ChildLongAFK<E,M,F,CH> familyMgr;
    private final String childAfkName;
    private final String childValueName;
    private final List<IColumn> attributeColumns;

    public TxIntFKFamilyLongAFKWrapper(
        String name,
        F parentField,
        Class<CH> childRecord,
        Class<CM> childAfkRecordType,
        Class<CV> childValueType,
        TxIntFKMgr.StarView<E,M,F> parentMgr,
        TxIntFKMgr.StarView.Family.ChildLongAFK<E,M,F,CH> familyMgr) {

        this.name = name;
        this.parentField = parentField;
        this.childRecord = childRecord;
        this.parentMgr = parentMgr;
        this.familyMgr = familyMgr;
        this.childValueType = childValueType;
        this.childAfkRecordType = childAfkRecordType;

        ImmutableArray<IColumn> immutableArray = familyMgr.childTx().columnArray();

        this.attributeColumns = new ArrayList<>();
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 2));
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 1));

        this.childAfkName = this.attributeColumns.get(0).getJavaName();
        this.childValueName = this.attributeColumns.get(1).getJavaName();
    }

    @Override
    public
    boolean
    isFamily() {
        return false;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        throw new IllegalCallerException();
    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(parentField.unsafeCenterMember().javaName());
    }

    @Override
    public
    ImmutVOs<T>
    query() {

        List<T> result = new ArrayList<>();
        queryTxs().
            foreach(
                (txRead)->
                    familyMgr.
                        createModel(
                            (TxIntFK.Read<E>)txRead).
                        children().
                        foreach(
                            (child)->
                                result.add((T)child)));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    MayNullVO<T>
    queryByPK(Long id) {

        throw new IllegalCallerException();
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Long> pkIDs) {

        List<T> result = new ArrayList<>();
        parentMgr.
            selectTxs(
                DistinctIds.toLongIDs(pkIDs)).
            foreach(
                (txRead)->
                    familyMgr.
                        createModel(
                            txRead).
                        children().
                        foreach(
                            (child)->
                                result.add((T)child)));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs foreigns,
        Map<String, Object> params) {

        if (foreigns.empty())
            return ImmutVOs.emptyVOs();

        if (foreigns.eltAt(0) instanceof TxIntFKChildIntAFKModel) {
            return queryByFKViews(
                foreigns.map((model)->((TxIntFKChildIntAFKModel)model).view()),
                params);
        }
        return queryByFKViews(foreigns, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKViews(
        ImmutVOs<TxStarView.Read<F>> foreigns,
        Map<String, Object> params) {

        List<T> result = new ArrayList<>();
        foreigns.foreach(
            (foreignTx)->
                familyMgr.
                    createModel(
                        (TxIntFK.Read)foreignTx.txRead()).
                    children().
                    foreach(
                        (child)->
                            result.add((T)child)));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        if (parentMgr.field().unsafeFK().javaName().equals(afkName))
            return queryByFKs(afkViews, params);
        throw new IllegalCallerException();
    }

    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByLongAFKViews(afkViews,  afkName, params);
    }

    private
    <AX extends SealedTxParent<?>,
    F extends AbstractField & TxStarView.Field<AX>>
    ImmutVOs<T>
    queryByLongAFKViews(
        ImmutVOs<TxStarView.Read<F>> afkViews,
        String afkName,
        Map<String, Object> params) {

        return afkViews.
            apply(
                (fks)-> {
                    ImmutVOs<aloha3.module.object.record.transaction.read.ChildTxLongAFK> children =
                        TxIntFKMgr.StarView.Family.ChildLongAFK.
                            selectChildren(
                                (NonEmptyVOs) fks.map(v->v.txRead()),
                                familyMgr);
                    return children.
                        apply(
                            (txChild) ->
                                queryByPKs(
                                    DistinctIds.toLongIDList(
                                        DistinctIds.longIDsFromRecords(
                                            txChild,
                                            child -> child.getTxId()))),
                            () -> ImmutVOs.emptyVOs());
                },
                ()->ImmutVOs.emptyVOs());
    }

    @Override
    public
    void
    update(
        JsonObject json) {

        throw new IllegalCallerException();
    }

    @Override
    public
    void
    delete(
        JsonObject json) {

        throw new IllegalCallerException();
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory>  members = getMandatoryAttributeMembers(parentField);
        members.add(0, parentMgr.field().unsafeFK());
        return members;
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(parentField);
    }

    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return parentMgr.field().unsafeCenterMember();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>) parentField.getClass();
    }

    public TxIntFKMgr.StarView<E, M, F> getMgr() {
        return parentMgr;
    }

    @Override
    public ImmutVOs<? extends Read> queryTxs() {
        return Query.select(TxIntFK.Read.createCriteria(this.parentField.entity()));
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

}
