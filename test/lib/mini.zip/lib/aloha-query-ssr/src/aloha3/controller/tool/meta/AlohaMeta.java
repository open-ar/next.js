package aloha3.controller.tool.meta;

import aloha.module.func.Func;
import aloha.module.func.business.IMasterDataMgt;
import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullValue;
import aloha.module.object.Type;
import aloha.module.object.record.IAdditionalReferenceEntity;
import aloha.module.object.record.master.IAdditionalForeignEntity;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.master.PivotReadMgt;
import aloha3.module.function.business.master.RelationMgr;
import aloha3.module.function.business.master.coc.GraphMgr;
import aloha3.module.function.business.transaction.DerivedTxIntAFKMgr;
import aloha3.module.function.business.transaction.DerivedTxLongAFKMgr;
import aloha3.module.function.business.transaction.DerivedTxMgr;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.function.business.transaction.TxLongFKMgr;
import aloha3.module.function.business.transaction.TxStarViewMgt;
import aloha3.module.object.SealedMember;
import aloha3.module.object.record.AbstractColumn;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.RelationEntity;
import aloha3.module.object.record.master.SealedAttribute;
import aloha3.module.object.record.master.spec.AttributeEntity;
import aloha3.module.object.record.spec.AttributeRow;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedChildTx;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.spec.DerivedTxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.TemporalField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Stream;

import static aloha3.controller.Server.conceptual;
import static aloha3.controller.tool.meta.MetaManager.decapitalize;

public class AlohaMeta {
    static final String WORK_FLOW = "WorkFlow";
    static final String STATE = "State";

    public static String starViewType(String pivot, ServiceContainer container) {
        for (var c : conceptual().all()) {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return "Tree";
            }
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return "StarArrow";
            }
            // Chain
            if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return "Chain";
            }
            // TODO support more
        };
        return "";
    }

    public static final class PivotField
        extends AbstractField {

        public final Mandatory<String> Pivot = mandatory("Pivot", String.class);
        public final Mandatory<String> Type = mandatory("Type", String.class);
    }

    public static View<PivotField>
    createPivotField(String pivot, String type) {
        return
            View.Builder.
                create(PivotField.class).
                setMandatoryValue(
                    f -> f.Pivot,
                    pivot).
                setMandatoryValue(
                    f -> f.Type,
                    type).
                build();
    }
    public static View<PivotField>
    createPivotField(String pivot, ServiceContainer container) {
        return
            View.Builder.
                create(PivotField.class).
                setMandatoryValue(
                    f -> f.Pivot,
                    pivot).
                setMandatoryValue(
                    f -> f.Type,
                    detectType(pivot, container)).
                build();
    }

    private static 
    String 
    detectType(String mgrName, ServiceContainer container) {
        PivotReadMgt.StarView<?, ?, ?, ?> mdm = MetaManager.StarViewMeta.mdm(mgrName);
        if (mdm != null) {
            return mdm.entity().type().name();
        }
        TxStarViewMgt<?, ?, ?> txm = MetaManager.StarViewMeta.txm(mgrName);
        if (txm != null) {
            return txm.entity().type().name();
        }
        throw new IllegalStateException("Not found: " + mgrName);
    }


    public static final class ViewField
        extends AbstractField {

        public final Mandatory<String> Name = mandatory("Name", String.class);
        public final Mandatory<String> Title = mandatory("Title", String.class);
    }

    public static final class ViewSchemaField
        extends AbstractField {

        public final Mandatory<String> ViewType = mandatory("ViewType", String.class);
        public final Mandatory<String> ViewName = mandatory("ViewName", String.class);
        public final Mandatory<String> Field = mandatory("Field", String.class);
        public final Mandatory<String> DataType = mandatory("DataType", String.class);

        public final Mandatory<Bool> IsPK = mandatory("IsPK", Bool.class);
        public final Mandatory<Bool> IsFK = mandatory("IsFK", Bool.class);
        public final Mandatory<Bool> IsAFK = mandatory("IsAFK", Bool.class);
        public final Optional<String> Foreign = optional("Foreign", String.class);
        public final Optional<String> ForeignUniqueStringColumn = optional("ForeignUniqueStringColumn", String.class);
        public final Optional<Bool> IsEnum = optional("IsEnum", Bool.class);
        public final Optional<String> EnumValues = optional("EnumValues", String.class);
        public final Optional<Bool> IsImmutable = optional("IsImmutable", Bool.class);
        public final Optional<Bool> IsRequired = optional("IsRequired", Bool.class);
        public final Optional<Bool> IsUnique = optional("IsUnique", Bool.class);
        public final Optional<Bool> IsOptional = optional("IsOptional", Bool.class);
        public final Optional<Bool> IsTemporal = optional("IsTemporal", Bool.class); // for temporal attribute
        public final Optional<Bool> IsPivot = optional("IsPivot", Bool.class);
    }

    public static final class SchemaField
        extends AbstractField {

        /*
            attrObj.add(FIELD, JsonBuilder.decapitalize(attr.javaName()));
            attrObj.add(DATA_TYPE, attr.refType().name());
            attrObj.add(IS_UNIQUE, isUnique(attr));
            attrObj.add(IS_OPTIONAL, isOptional(attr));
            attrObj.add(IS_IMMUTABLE, isImmutable(attr));
         */
        public final Mandatory<String> Name = mandatory("Name", String.class);
        public final Mandatory<String> Title = mandatory("Title", String.class);
    }

    // create pivot field instance
    public static View<ViewField>
    createDataField(String title, String name) {
        return
            View.Builder.
                create(ViewField.class).
                setMandatoryValue(
                    f -> f.Name,
                    name).
                setMandatoryValue(
                    f -> f.Title,
                    title).
                build();
    }

    public static
    ImmutVOs<View<PivotField>>
    getChainPivots() {
        return 
            ImmutVOs.create(
                conceptual().all().stream().flatMap(c -> {
                    // System.out.println("Conceptual: " + c.getClass().getSimpleName());
                    if (c instanceof Graph.Chain.Straight.Generic hm) {
                        return Stream.of(
                            createPivotField(
                                hm.coreMgr().entity().getClass().getSimpleName(),
                                "StraightChain"));
                    }
                    // TODO support more
                    return Stream.empty();
                }).
                toList());
    }

    public static
    ImmutVOs<View<PivotField>>
    getTreePivots() {
        return 
            ImmutVOs.create(
                conceptual().all().stream().flatMap(c -> {
                    // System.out.println("Conceptual: " + c.getClass().getSimpleName());
                    if (c instanceof Graph.Tree.Distinct.Generic hm) {
                        return Stream.of(
                            createPivotField(
                                hm.coreMgr().entity().getClass().getSimpleName(),
                                "DistinctTree"));
                    }
                    if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm) {
                        return Stream.of(
                            createPivotField(
                                hm.coreMgr().entity().getClass().getSimpleName(),
                                "StarArrowTree"));
                    }
                    // TODO support more
                    return Stream.empty();
                }).
                toList());
    }

    public static
    ImmutVOs<View<PivotField>>
    getPivots(ServiceContainer container) {
        return
            ImmutVOs.create(
                container.
                allMDM().
                stream().
                flatMap(mdm -> {
                    // core with temporal attributes
                    if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                        return Stream.of(
                            createPivotField(
                                mdmGeneric.entity().getClass().getSimpleName(),
                                mdmGeneric.entity().type().name() + " Temporal"));
                    }
                    // core
                    if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric) {
                        return Stream.of(
                            createPivotField(
                                mdmGeneric.entity().getClass().getSimpleName(),
                                mdmGeneric.entity().type().name()));
                    }
                    // relation
                    if (mdm instanceof RelationMgr.StarView.Generic<?,?,?,?> mdmGeneric) {
                        return Stream.of(
                            createPivotField(
                                mdmGeneric.entity().getClass().getSimpleName(),
                                mdmGeneric.entity().type().name()));
                    }
                    // Graph
                    // if (mdm instanceof GraphMgr) {
                    //     return Stream.of(
                    //         createPivotField(
                    //             "Graph",
                    //             "CORE"));
                    // }
                    return Stream.empty();
                }).
                toList());
    }

    public static
    ImmutVOs<View<PivotField>>
    getTxFlowables(ServiceContainer container) {
        return
            ImmutVOs.create(
                container.
                    allTxM().
                    stream(). 
                    map(txm -> {
                        if (txm instanceof TxIntFKMgr.StarView.Flowable<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof TxLongFKMgr.StarView.Flowable<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        return null;
                    }).
                    filter(Objects::nonNull).
                    toList());
    }

    public static
    ImmutVOs<View<PivotField>>
    getTxPivots(ServiceContainer container) {
        return
            ImmutVOs.create(
                container.
                    allTxM().
                    stream().
                    map(txm -> {
                        if (txm instanceof TxIntFKMgr.StarView.Generic<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof TxIntFKMgr.StarView.Family<?,?,?,?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof TxIntFKMgr.StarView.Flowable<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof TxLongFKMgr.StarView.Family<?,?,?,?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof TxLongFKMgr.StarView.Flowable<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof DerivedTxIntAFKMgr.StarView.Family<?,?,?,?,?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof DerivedTxLongAFKMgr.StarView.Family<?,?,?,?,?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof TxLongFKMgr.StarView.Generic<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof DerivedTxMgr.StarView.Generic<?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof DerivedTxIntAFKMgr.StarView.Generic<?,?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        if (txm instanceof DerivedTxLongAFKMgr.StarView.Generic<?,?,?,?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.entity().getClass().getSimpleName(),
                                txmGeneric.entity().type().name());
                        }
                        return null;
                    }).
                    filter(Objects::nonNull).
                    toList());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    ImmutVOs<View<ViewSchemaField>>
    getTxChildReferrers(
        String mgrName, // pivot
        ServiceContainer container) {

        return ImmutVOs.create(
            // Tx Child Only
            (List) getTxChild(container).asList().stream().flatMap(pivotMgrName -> {
                    final var masterReferrer = getViewInfos_TxChild(pivotMgrName.mandatoryValue(f -> f.Pivot), container);
                    return
                        masterReferrer.
                            find(refererGiven ->
                                refererGiven.
                                    optionalValue(ff -> ff.Foreign).
                                    unlessNull(
                                        foreignMgr -> foreignMgr.equalsIgnoreCase(mgrName), // Referrer Mgr name
                                        false)).
                            apply(
                                Stream::of,
                                Stream::empty);
                }).
                toList());
    }


    public static
    ImmutVOs<View<PivotField>>
    getTxChild(ServiceContainer container) {
        return
            ImmutVOs.create(
                container.
                    allTxM().
                    stream().
                    map(txm -> {
                        if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmGeneric) {
                            return createPivotField(
                                txmGeneric.childTx().getClass().getSimpleName(),
                                txmGeneric.childTx().type().name());
                        }
                        return null;
                    }).
                    filter(Objects::nonNull).
                    toList());
    }


    public static
    ImmutVOs<View<PivotField>>
    getTxReferrerPivots(ServiceContainer container) {
        return
            ImmutVOs.create(
                container.
                    allTxM().
                    stream().
                    flatMap(txm -> {
                        if (txm instanceof TxIntFKMgr.StarView.Generic<?,?,?> txmGeneric) {
                            return
                                getAllForeign(
                                    txmGeneric.entity().getClass().getSimpleName(),
                                    container).
                                    map(ref ->
                                        createPivotField(
                                            ref.optionalValue(f->f.Foreign).assertNonNull(),
                                            container)).
                                    asList().
                                    stream();
                        }
                        if (txm instanceof TxIntFKMgr.StarView.Family<?,?,?,?,?,?> txmGeneric) {
                            return
                                getAllForeign(
                                    txmGeneric.entity().getClass().getSimpleName(),
                                    container).
                                    filter(f -> 
                                        Type.RefType.INTEGER.name().equals( // Only FK to master
                                            f.mandatoryValue(ff -> ff.DataType))).
                                    map(ref ->
                                        createPivotField(
                                            ref.optionalValue(f->f.Foreign).assertNonNull(),
                                            container)).
                                    asList().
                                    stream();
                        }
                        return Stream.empty();
                    }).
                    filter(distinctBy(e -> e.mandatoryValue(f->f.Pivot))).
                    toList());
    }

    private static <T, K> 
    java.util.function.Predicate<T>
    distinctBy(Function<? super T, K> keyExtractor) {
        Set<K> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    private static
    ImmutVOs<View<ViewSchemaField>>
    getAllForeign(
        String mgrName, // pivot
        ServiceContainer container) {

        return
            getViewInfos(mgrName, container).
                filter(refererGiven ->
                    refererGiven.
                        optionalValue(ff -> ff.Foreign).
                        unlessNull(
                            foreignMgr -> true, // Referrer from Tx is FK or AFK
                            false));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    ImmutVOs<View<ViewSchemaField>>
    getReferrers(
        String mgrName, // pivot
        ServiceContainer container) {
        
        return ImmutVOs.create(
            // Master Only
            (List)getPivots(container).asList().stream().flatMap(pivotMgrName -> {
                final var masterReferrer = getViewInfos(pivotMgrName.mandatoryValue(f->f.Pivot), container);
                return 
                    masterReferrer.
                        find(refererGiven -> 
                            refererGiven.
                                optionalValue(ff -> ff.Foreign).
                                unlessNull(
                                    foreignMgr -> foreignMgr.equalsIgnoreCase(mgrName), // Referrer Mgr name
                                    false)).
                        apply(
                            Stream::of, 
                            Stream::empty);
            }).
            toList());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    ImmutVOs<View<ViewSchemaField>>
    getTxReferrers(
        String mgrName, // pivot
        ServiceContainer container) {

        return ImmutVOs.create(
            // Tx Only
            (List)getTxPivots(container).asList().stream().flatMap(pivotMgrName -> {
                final var masterReferrer = getViewInfos(pivotMgrName.mandatoryValue(f->f.Pivot), container);
                return 
                    masterReferrer.
                        find(refererGiven -> 
                            refererGiven.
                                optionalValue(ff -> ff.Foreign).
                                unlessNull(
                                    foreignMgr -> foreignMgr.equalsIgnoreCase(mgrName), // Referrer Mgr name
                                    false)).
                        apply(
                            Stream::of, 
                            Stream::empty);
            }).
            toList());
    }

    public static
    ImmutVOs<View<ViewSchemaField>>
    allReferrersWithMasterAndTx(
        String mgrName, // pivot
        ServiceContainer container) {

        return 
            getReferrers(mgrName, container).
                append(
                    getTxReferrers(mgrName, container)).
                append(
                    getTxChildReferrers(mgrName, container));
    }
    
    public static
    ImmutVOs<View<ViewSchemaField>>
    getReferents(
        String mgrName, // pivot
        ServiceContainer container) {

        return getViewInfos(mgrName, container).
            filter(vi ->
                vi.optionalValue(f -> f.Foreign). // Referent Mgr name
                    unlessNull(referentGiven ->
                        !"Graph".equalsIgnoreCase(referentGiven), // Notice Ignore graph
                    false)).
            map(vi ->
                getViewInfos(
                    vi.optionalValue(f -> f.Foreign).assertNonNull(), 
                    container
                ).
                findOrException(
                    refererVi -> 
                        refererVi.mandatoryValue(f->f.IsPK).val())); // Only return PK
    }
    
    public static
    ImmutVOs<View<ViewSchemaField>>
    getViewInfos(
        String mgrName, // pivot
        ServiceContainer container) {

        MetaManager.StarViewMeta.init(container);

        return (
            MetaManager.StarViewMeta.isMdm(mgrName) ||
            WORK_FLOW.equals(mgrName) ||
            STATE.equals(mgrName)
        )
            ?
            viewInfoMaster(
                mgrName,
                container)
            :
            viewInfoTx(
                mgrName,
                container);
    }

    public static
    ImmutVOs<View<ViewSchemaField>>
    getViewInfos_TxChild(
        String mgrName, // pivot
        ServiceContainer container) {

        MetaManager.StarViewMeta.init(container);

        List<View<ViewSchemaField>> viewSchemas = new ArrayList<>();

        container.allTxM().forEach(txm -> {
            if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmChild &&
                txmChild.childTx().getClass().getSimpleName().equals(mgrName)) {

                // Add child tx fields
                viewInfoTxChild(viewSchemas, txmChild.childTx(), container);
            }
        });
        return ImmutVOs.create(viewSchemas);
    }

    private static
    ImmutVOs<View<ViewSchemaField>>
    viewInfoMaster(
        String name,
        ServiceContainer container) {

        MetaManager.StarViewMeta.init(container);
        List<View<ViewSchemaField>> viewSchemas = new ArrayList<>();
        // TODO support work flow
        // viewInfoWorkFlow(obj);
        // viewInfoWorkFlowState(obj);
        for (IMasterDataMgt mdm : container.allMDM()) {
            if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                // TODO more?
                viewInfoCore(name, viewSchemas, mdmGeneric.field(), mdmGeneric.entity(), container, true);
            } else if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric) {
                viewInfoCore(name, viewSchemas, mdmGeneric.field(), mdmGeneric.entity(), container);
            } else if (mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric) {
                viewInfoRelation(name, viewSchemas, mdmGeneric.field(), mdmGeneric.entity(), container);
            } else if (mdm instanceof GraphMgr) {
                // System.out.println("Ignore coc, " + mdm.getClass().getName());
            }
        }
        if (viewSchemas.isEmpty()) {
            // System.err.println("Not support type, " + name);
            return ImmutVOs.emptyVOs();
        }
        // System.out.println("viewSchemas size: " + viewSchemas.size());
        return ImmutVOs.create(viewSchemas);
    }

    public static
    ImmutVOs<View<ViewSchemaField>>
    viewInfoTemporalAttribute(
        String name,
        ServiceContainer container) {

        MetaManager.StarViewMeta.init(container);
        List<View<ViewSchemaField>> viewSchemas = new ArrayList<>();
        for (IMasterDataMgt mdm : container.allMDM()) {
            if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                // Basic view info
                // viewInfoCore(name, viewSchemas, mgr.field(), mgr.entity(), container, true);
                // Plus temporal attribute, e.g TaxRateField:
                // public final class TaxRateField
                //     extends TemporalField.OfAttribute<Tax.Rate,Integer> {
                // 
                //     public Mandatory<Integer> TaxId() { return pivotKey(); }
                //     public Mandatory<Integer> TaxRateId() { return TemporalRootKey; }
                //     public Mandatory<Integer> Rate() { return attributeColumn(); }
                //     public Optional<YMDHMS> TemporalFromTime() { return TemporalFromTime; }
                //     public Optional<YMDHMS> TemporalToTime() { return TemporalToTime; }
                // }
                // we must need add normal TaxField, then plus above Fields
                if (mdmGeneric.entity().getClass().getSimpleName().equals(name)) {
                    viewInfoTemporal(name, viewSchemas, mdmGeneric.temporalField(), mdmGeneric.temporalEntity(), container);
                }
            }
        }
        if (viewSchemas.isEmpty()) {
            // System.err.println("Not support type, " + name);
            return ImmutVOs.emptyVOs();
        }
        return ImmutVOs.create(viewSchemas);
    }

    private static void 
    viewInfoTemporal(
        String name, 
        List<View<ViewSchemaField>> viewSchemas, 
        TemporalField<?> field, 
        SealedAttribute<?,?,?> entity, 
        ServiceContainer container) {
        
        // pivotKey
        final var viewType = "Temporal Attribute"; // Not entity.type().name()

        // PK TemporalRootKey == field.entity().column().PK() , e.g TaxRateField.TexRateId
        List.of(field.TemporalRootKey).forEach(attr -> {
            View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
            attrObj.setMandatoryValue(f -> f.ViewType, viewType);
            attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

            attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.javaName()));
            attrObj.setMandatoryValue(f -> f.DataType, attr.refType().name());
            attrObj.setMandatoryValue(f -> f.IsPK, Bool.TRUE);
            attrObj.setOptionalValue(f -> f.IsUnique, Bool.TRUE); // TODO check?
            attrObj.setOptionalValue(f -> f.IsOptional, Bool.FALSE);
            attrObj.setOptionalValue(f -> f.IsTemporal, Bool.TRUE);
            attrObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
            attrObj.setOptionalValue(f -> f.IsRequired, Bool.TRUE);

            viewSchemas.add(attrObj.build());
        });

        // FK e.g TaxRateField.TaxId
        field.entity().column().asIColumnArray().foreach(a -> {
            if (a instanceof AttributeEntity.Column.FK<?> fk) {
                View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
                attrObj.setMandatoryValue(f -> f.ViewType, viewType);
                attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                attrObj.setMandatoryValue(f -> f.Field, decapitalize(fk.Name())); // javaName
                attrObj.setMandatoryValue(f -> f.DataType, accessProtectedSealedMember(fk, "refType")); // refType
                attrObj.setOptionalValue(f -> f.IsUnique, Bool.FALSE);
                attrObj.setOptionalValue(f -> f.IsOptional, Bool.FALSE);
                attrObj.setOptionalValue(f -> f.IsTemporal, Bool.TRUE);
                attrObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                attrObj.setOptionalValue(f -> f.IsRequired, Bool.TRUE);

                addForeignAndUniqueStringIfPossible(
                    container,
                    attrObj,
                    entity.getReferenceEntity().getSimpleName());

                viewSchemas.add(attrObj.build());
            }
        });

        // Attribute member. e.g. TaxRateField.Rate
        field.entity().column().asIColumnArray().foreach(a -> {
            if (a instanceof AttributeEntity.Attribute<?> attr) {
                View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
                attrObj.setMandatoryValue(f -> f.ViewType, viewType);
                attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.Name())); // javaName
                attrObj.setMandatoryValue(f -> f.DataType, accessProtectedSealedMember(attr, "refType")); // refType
                attrObj.setOptionalValue(f -> f.IsUnique, Bool.FALSE);
                attrObj.setOptionalValue(f -> f.IsOptional, isOptional(attr));
                attrObj.setOptionalValue(f -> f.IsTemporal, Bool.FALSE);
                attrObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE); // TODO Cant not update temporal attribute?!
                attrObj.setOptionalValue(f -> f.IsRequired, Bool.TRUE);

                viewSchemas.add(attrObj.build());
            }
        });

        // TemporalFromTime / TemporalToTime
        List.of(field.TemporalFromTime, field.TemporalToTime).forEach(attr -> {
            View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
            attrObj.setMandatoryValue(f -> f.ViewType, viewType);
            attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

            attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.javaName()));
            attrObj.setMandatoryValue(f -> f.DataType, attr.refType().name());
            attrObj.setOptionalValue(f -> f.IsUnique, Bool.FALSE);
            attrObj.setOptionalValue(f -> f.IsOptional, Bool.TRUE);
            attrObj.setOptionalValue(f -> f.IsTemporal, Bool.TRUE);
            attrObj.setOptionalValue(f -> f.IsImmutable, Bool.FALSE);
            attrObj.setOptionalValue(f -> f.IsRequired, Bool.FALSE);

            viewSchemas.add(attrObj.build());
        });
    }

    private static String accessProtectedSealedMember(Object obj, String fieldName) {
        try {
            var field = SealedMember.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(obj).toString();
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException("Unable to access field: " + fieldName, e);
        }
    }

    private static
    void
    viewInfoCore(
        String name,
        List<View<ViewSchemaField>> viewSchemas,
        Field.ofStarView.Around.Pivot<?> field,
        CoreEntity entity,
        ServiceContainer container
    ) {
        viewInfoCore(name, viewSchemas, field, entity, container, false);
    }
    private static
    void
    viewInfoCore(
        String name,
        List<View<ViewSchemaField>> viewSchemas,
        Field.ofStarView.Around.Pivot<?> field,
        CoreEntity entity,
        ServiceContainer container,
        Boolean isTemporalAttribute) {

        if (entity.getClass().getSimpleName().equals(name)) {
            // View Fields
            // PK
            Func.accept(
                entity.column().PK(),
                pk -> {
                    View.Builder<ViewSchemaField> pkObj = createDefaultViewInfoField();
                    pkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    pkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    pkObj.setMandatoryValue(f -> f.Field, decapitalize(pk.getJavaName()));
                    pkObj.setMandatoryValue(f -> f.DataType, pk.getRefType().name());
                    pkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                    pkObj.setOptionalValue(f -> f.IsTemporal, Bool.of(isTemporalAttribute));
                    pkObj.setMandatoryValue(f -> f.IsPK, Bool.TRUE);
                    viewSchemas.add(pkObj.build());
                    // System.out.println("Added PK view info: " + pkObj.build());
                    // System.out.println("viewSchemas size after adding PK: " + viewSchemas.size());
                }
            );

            // Attributes
            field.attributeMembers().foreach(attr -> {
                View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
                attrObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                // TODO renameされた場合一時対応 attr.attributeEntity().getSimpleName() + Id
                attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.javaName()));
                attrObj.setMandatoryValue(f -> f.DataType, attr.refType().name());
                attrObj.setOptionalValue(f -> f.IsUnique, isUnique(attr));
                attrObj.setOptionalValue(f -> f.IsOptional, isOptional(attr));
                attrObj.setOptionalValue(f -> f.IsTemporal, Bool.of(isTemporalAttribute));
                attrObj.setOptionalValue(f -> f.IsImmutable, isImmutable(attr));
                attrObj.setOptionalValue(f -> f.IsRequired,Bool.of(attr instanceof Mandatory));

                getForeignEntityIfAFK(attr).
                    unlessNull_(
                        foreign->
                            addForeignAndUniqueStringIfPossible(
                                container,
                                attrObj,
                                foreign,
                                true));
                addIfEnum(attrObj, attr);
                viewSchemas.add(attrObj.build());
            });
        }
    }

    private static
    void
    viewInfoRelation(
        String name,
        List<View<ViewSchemaField>> viewSchemas,
        Field.ofStarView.Around.Pivot<?> field,
        RelationEntity<?,?> entity,
        ServiceContainer container) {

        if (entity.getClass().getSimpleName().equals(name)) {
            // View Fields
            // PK
            Func.accept(
                entity.column().PK(),
                pk -> {
                    View.Builder<ViewSchemaField> pkObj = createDefaultViewInfoField();
                    pkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    pkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    pkObj.setMandatoryValue(f -> f.Field, decapitalize(pk.getJavaName()));
                    pkObj.setMandatoryValue(f -> f.DataType, pk.getRefType().name());
                    pkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                    pkObj.setMandatoryValue(f -> f.IsPK, Bool.TRUE);

                    viewSchemas.add(pkObj.build());
                }
            );
            // FK
            Func.accept(
                entity.column().FK(),
                fk -> {
                    View.Builder<ViewSchemaField> fkObj = createDefaultViewInfoField();
                    fkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    fkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    fkObj.setMandatoryValue(f -> f.Field, decapitalize(fk.getJavaName()));
                    fkObj.setMandatoryValue(f -> f.DataType, fk.getRefType().name());

                    addForeignAndUniqueStringIfPossible(
                        container,
                        fkObj,
                        entity.getReferenceEntity().getSimpleName());
                    fkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                    fkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);
                    viewSchemas.add(fkObj.build());
                }
            );
            // AFK
            Func.accept(
                entity.column().AFK(),
                afk -> {
                    View.Builder<ViewSchemaField> afkObj = createDefaultViewInfoField();
                    afkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    afkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    afkObj.setMandatoryValue(f -> f.Field, decapitalize(afk.getJavaName()));
                    afkObj.setMandatoryValue(f -> f.DataType, afk.getRefType().name());

                    addForeignAndUniqueStringIfPossible(
                        container,
                        afkObj,
                        entity.getAdditionalReferenceEntity().getSimpleName(),
                        true);
                    afkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                    afkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);
                    viewSchemas.add(afkObj.build());
                    //final var pkObj = Json.createObjectBuilder();
                    //pkObj.add(FIELD, JsonBuilder.decapitalize(afk.getJavaName())); // .name() =>
                    //pkObj.add(DATA_TYPE, afk.getRefType().name());
                    //pkObj.add(IS_IMMUTABLE, Bool.TRUE);
                    //pkObj.add(IS_AFK, Bool.TRUE);
                    //pkObj.add(IS_PIVOT, Bool.TRUE);
                    //fieldArray.add(pkObj);
                }
            );

            // Attributes
            field.attributeMembers().foreach(attr -> {
                View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
                attrObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.javaName()));
                attrObj.setMandatoryValue(f -> f.DataType, attr.refType().name());
                attrObj.setOptionalValue(f -> f.IsUnique, isUnique(attr));
                attrObj.setOptionalValue(f -> f.IsOptional, isOptional(attr));
                attrObj.setOptionalValue(f -> f.IsImmutable, isImmutable(attr));

                getForeignEntityIfAFK(attr).
                    unlessNull_(
                        foreign->
                            addForeignAndUniqueStringIfPossible(
                                container,
                                attrObj,
                                foreign,
                                true));
                addIfEnum(attrObj, attr);
                viewSchemas.add(attrObj.build());
            });
        }
    }

    private static
    ImmutVOs<View<ViewSchemaField>>
    viewInfoTx(
        String mgrName,
        ServiceContainer container) {

        // TxIntFKMgr.StarView.Generic<?,?,?>
        // TxIntFKMgr.StarView.Family.ChildIntAFK.Generic<?,?,?,?>
        // TxIntFKMgr.StarView.Family.ChildIntAFK.Flowable<?,?,?,?>
        // TxLongFKMgr.StarView.Family.ChildLongAFKOnly.Generic<?,?,?,?>
        // DerivedTxMgr.StarView.Generic<?,?,?>
        List<View<ViewSchemaField>> viewSchemas = new ArrayList<>();

        container.allTxM().forEach(txm -> {
            if (txm instanceof TxStarViewMgt<?, ?, ?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {

                viewInfoTx(viewSchemas, txmGeneric.field(), txmGeneric.entity(), container);
                // Add child tx fields
                // if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmChild) {
                //     viewInfoTxChild(viewSchemas, txmChild.childTx(), container);
                // }
            }
            if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmChild &&
                txmChild.childTx().getClass().getSimpleName().equals(mgrName)) {

                // Add child tx fields
                viewInfoTxChild(viewSchemas, txmChild.childTx(), container);
            }
        });
        return ImmutVOs.create(viewSchemas);
    }

    private static
    void
    viewInfoTxChild(
        List<View<ViewSchemaField>> viewSchemas,
        SealedChildTx<?, ?> child,
        ServiceContainer container) {
        // View Fields
        collectTxChildFields(child, viewSchemas, container);
        //Func.accept(
        //    Json.createArrayBuilder(),
        //    fieldArray -> {
        //        collectTxChildFields(child, fieldArray, container);
        //        obj.add(CHILD, fieldArray);
        //    });
    }

    private static
    void
    viewInfoTx(
        List<View<ViewSchemaField>> viewSchemas,
        TxStarView.Field<?> field,
        SealedTxParent<?> entity,
        ServiceContainer container) {

        // View Fields
        collectTxFields(field, entity, viewSchemas, container);
    }

    private static
    void
    collectTxFields(
        TxStarView.Field<?> field,
        SealedTxParent<?> entity,
        List<View<ViewSchemaField>> viewSchemas,
        ServiceContainer container) {

        View.Builder<ViewSchemaField> obj = createDefaultViewInfoField();
        // View info
        obj.setMandatoryValue(f -> f.ViewType, entity.type().name());
        obj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

        // PK
        Func.accept(
            entity.column().PK(),
            pk -> {
                View.Builder<ViewSchemaField> pkObj = createDefaultViewInfoField();
                pkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                pkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());
                pkObj.setMandatoryValue(f -> f.IsPK, Bool.TRUE);

                pkObj.setMandatoryValue(f -> f.Field, decapitalize(pk.getJavaName()));
                pkObj.setMandatoryValue(f -> f.DataType, pk.getRefType().name());
                pkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);

                //final var pkObj = Json.createObjectBuilder();
                //pkObj.add(FIELD, JsonBuilder.decapitalize(pk.getJavaName()));
                //pkObj.add(DATA_TYPE, pk.getRefType().name());
                //pkObj.add(IS_PK, Bool.TRUE);
                if (entity instanceof DerivedTxEntity entityFkEqualsPk) {
                    // FK == PK
                    addForeignAndUniqueStringIfPossible(
                        container,
                        pkObj,
                        entityFkEqualsPk.getReferenceEntity().getSimpleName());
                }
                viewSchemas.add(pkObj.build());
            }
        );

        // FK
        if (entity instanceof DerivedTxEntity entityFkEqualsPk) {
            // Ignore FK == PK
            // System.out.println("Ignore " + entityFkEqualsPk.getClass().getSimpleName());
        } else if (entity instanceof aloha.module.object.record.master.IForeignEntity entityWithFk) {
            // Master系のFK
            Func.accept(
                entityWithFk.getForeignKeyColumn(),
                fk -> {
                    View.Builder<ViewSchemaField> fkObj = createDefaultViewInfoField();
                    fkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    fkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    fkObj.setMandatoryValue(f -> f.Field, decapitalize(fk.getJavaName()));
                    fkObj.setMandatoryValue(f -> f.DataType, fk.getRefType().name());
                    fkObj.setMandatoryValue(f -> f.IsFK, Bool.TRUE);
                    fkObj.setOptionalValue(f -> f.IsRequired, Bool.TRUE);

                    addForeignAndUniqueStringIfPossible(
                        container,
                        fkObj,
                        entityWithFk.getReferenceEntity().getSimpleName());
                    fkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                    fkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);

                    //final var pkObj = Json.createObjectBuilder();
                    //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                    //pkObj.add(DATA_TYPE, fk.getRefType().name());
                    //addForeignAndUniqueStringIfPossible(
                    //    container,
                    //    pkObj,
                    //    entityWithFk.getReferenceEntity().getSimpleName());
                    //pkObj.add(IS_FK, Bool.TRUE);
                    //fieldArray.add(pkObj);
                    viewSchemas.add(fkObj.build());
                }
            );
        } else if (entity instanceof aloha.module.object.record.transaction.IForeignEntity entityWithFk) {
            // Tx系のFK
            Func.accept(
                entityWithFk.getForeignKeyColumn(),
                fk -> {
                    View.Builder<ViewSchemaField> fkObj = createDefaultViewInfoField();
                    fkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    fkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    fkObj.setMandatoryValue(f -> f.Field, decapitalize(fk.getJavaName()));
                    fkObj.setMandatoryValue(f -> f.DataType, fk.getRefType().name());
                    fkObj.setMandatoryValue(f -> f.IsFK, Bool.TRUE);
                    fkObj.setOptionalValue(f -> f.IsRequired, Bool.TRUE);

                    addForeignAndUniqueStringIfPossible(
                        container,
                        fkObj,
                        entityWithFk.getReferenceEntity().getSimpleName());
                    fkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                    fkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);

                    //final var pkObj = Json.createObjectBuilder();
                    //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                    //pkObj.add(DATA_TYPE, fk.getRefType().name());
                    //addForeignAndUniqueStringIfPossible(
                    //    container,
                    //    pkObj,
                    //    entityWithFk.getReferenceEntity().getSimpleName());
                    //pkObj.add(IS_FK,Bool.TRUE);
                    //fieldArray.add(pkObj);
                    viewSchemas.add(fkObj.build());
                }
            );
        }

        if (entity instanceof DerivedTxEntityIntAFK<?,?,?> || entity instanceof DerivedTxEntityLongAFK<?,?,?>) {

            // AFK
            if (entity instanceof aloha.module.object.record.master.IAdditionalForeignEntity entityWithAFK) {
                // Master系のAFK
                Func.accept(
                    entityWithAFK.getAdditionalForeignKeyColumn(),
                    afk -> {
                        View.Builder<ViewSchemaField> fkObj = createDefaultViewInfoField();
                        fkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                        fkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                        fkObj.setMandatoryValue(f -> f.Field, decapitalize(afk.getJavaName()));
                        fkObj.setMandatoryValue(f -> f.DataType, afk.getRefType().name());
                        fkObj.setMandatoryValue(f -> f.IsAFK, Bool.TRUE);

                        addForeignAndUniqueStringIfPossible(
                            container,
                            fkObj,
                            entityWithAFK.getAdditionalReferenceEntity().getSimpleName());
                        fkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                        fkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);

                        //final var pkObj = Json.createObjectBuilder();
                        //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                        //pkObj.add(DATA_TYPE, fk.getRefType().name());
                        //addForeignAndUniqueStringIfPossible(
                        //    container,
                        //    pkObj,
                        //    entityWithFk.getReferenceEntity().getSimpleName());
                        //pkObj.add(IS_FK, Bool.TRUE);
                        //fieldArray.add(pkObj);
                        viewSchemas.add(fkObj.build());
                    }
                );
            } else if (entity instanceof aloha.module.object.record.transaction.IAdditionalForeignEntity entityWithAFK) {
                // Tx系のAFK
                Func.accept(
                    entityWithAFK.getAdditionalForeignKeyColumn(),
                    afk -> {
                        View.Builder<ViewSchemaField> fkObj = createDefaultViewInfoField();
                        fkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                        fkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                        fkObj.setMandatoryValue(f -> f.Field, decapitalize(afk.getJavaName()));
                        fkObj.setMandatoryValue(f -> f.DataType, afk.getRefType().name());
                        fkObj.setMandatoryValue(f -> f.IsAFK, Bool.TRUE);

                        addForeignAndUniqueStringIfPossible(
                            container,
                            fkObj,
                            entityWithAFK.getAdditionalReferenceEntity().getSimpleName());
                        fkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                        fkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);

                        //final var pkObj = Json.createObjectBuilder();
                        //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                        //pkObj.add(DATA_TYPE, fk.getRefType().name());
                        //addForeignAndUniqueStringIfPossible(
                        //    container,
                        //    pkObj,
                        //    entityWithFk.getReferenceEntity().getSimpleName());
                        //pkObj.add(IS_FK,Bool.TRUE);
                        //fieldArray.add(pkObj);
                        viewSchemas.add(fkObj.build());
                    }
                );
            }
        }
        

        // Attrs
        field.attributeMembers().foreach(attr -> {

            // Attributes
            View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
            attrObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
            attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

            attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.javaName()));
            attrObj.setMandatoryValue(f -> f.DataType, attr.refType().name());
            // attrObj.setOptionalValue(f -> f.IsUnique, isUnique(attr)); // Tx not exist unique attr
            // attrObj.setMandatoryValue(f -> f.IsImmutable, isImmutable(attr)); // Tx not exist immutable attr
            attrObj.setOptionalValue(f -> f.IsOptional, isOptional(attr));
            attrObj.setOptionalValue(f -> f.IsRequired,Bool.of(attr instanceof Mandatory));

            getForeignEntityIfAFK(attr).
                unlessNull_(
                    foreign->
                        addForeignAndUniqueStringIfPossible(
                            container,
                            attrObj,
                            foreign,
                            true));
            addIfEnum(attrObj, attr);
            viewSchemas.add(attrObj.build());

            //final var attrObj = Json.createObjectBuilder();
            //attrObj.add(FIELD, JsonBuilder.decapitalize(attr.javaName()));
            //attrObj.add(DATA_TYPE, attr.refType().name());
            //attrObj.add(IS_OPTIONAL, isOptional(attr));
            //getForeignEntityIfAFK(attr).
            //    unlessNull_(
            //        foreign->
            //            addForeignAndUniqueStringIfPossible(
            //                container,
            //                attrObj,
            //                foreign));
            //addIfEnum(attrObj, attr);
            //fieldArray.add(attrObj);
        });
    }

    private static
    void
    collectTxChildFields(
        SealedChildTx<?, ?> entity,
        List<View<ViewSchemaField>> viewSchemas,
        ServiceContainer container) {
        // View info
        // PK
        Func.accept(
            entity.column().PK(),
            pk -> {
                View.Builder<ViewSchemaField> pkObj = createDefaultViewInfoField();
                // TODO is "Child"??
                pkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                pkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                pkObj.setMandatoryValue(f -> f.Field, decapitalize(pk.getJavaName()));
                pkObj.setMandatoryValue(f -> f.DataType, pk.getRefType().name());
                pkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);
                pkObj.setMandatoryValue(f -> f.IsPK, Bool.TRUE);

                viewSchemas.add(pkObj.build());
                //final var pkObj = Json.createObjectBuilder();
                //pkObj.add(FIELD, JsonBuilder.decapitalize(pk.getJavaName()));
                //pkObj.add(DATA_TYPE, pk.getRefType().name());
                //pkObj.add(IS_PK, Bool.TRUE);
                //fieldArray.add(pkObj);
            }
        );

        // FK
        Func.accept(
            entity.getForeignKeyColumn(),
            fk -> {
                View.Builder<ViewSchemaField> fkObj = createDefaultViewInfoField();
                fkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                fkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                fkObj.setMandatoryValue(f -> f.Field, decapitalize(fk.getJavaName()));
                fkObj.setMandatoryValue(f -> f.DataType, fk.getRefType().name());
                fkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);

                addForeignAndUniqueStringIfPossible(
                    container,
                    fkObj,
                    entity.getReferenceEntity().getSimpleName());
                fkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);
                viewSchemas.add(fkObj.build());
                //final var pkObj = Json.createObjectBuilder();
                //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                //pkObj.add(DATA_TYPE, fk.getRefType().name());
                //addForeignAndUniqueStringIfPossible(
                //    container,
                //    pkObj,
                //    entity.getReferenceEntity().getSimpleName());
                //pkObj.add(IS_FK, Bool.TRUE);
                //fieldArray.add(pkObj);
            }
        );

        // AFK
        if (entity instanceof IAdditionalForeignEntity entityWithAFk) {
            // Master系のAFK
            Func.accept(
                entityWithAFk.getAdditionalForeignKeyColumn(),
                afk -> {

                    View.Builder<ViewSchemaField> afkObj = createDefaultViewInfoField();
                    afkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    afkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    afkObj.setMandatoryValue(f -> f.Field, decapitalize(afk.getJavaName()));
                    afkObj.setMandatoryValue(f -> f.DataType, afk.getRefType().name());
                    afkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);

                    addForeignAndUniqueStringIfPossible(
                        container,
                        afkObj,
                        entityWithAFk.getAdditionalReferenceEntity().getSimpleName(),
                        true);
                    afkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);
                    viewSchemas.add(afkObj.build());
                    //final var pkObj = Json.createObjectBuilder();
                    //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                    //pkObj.add(DATA_TYPE, fk.getRefType().name());
                    //addForeignAndUniqueStringIfPossible(
                    //    container,
                    //    pkObj,
                    //    entityWithAFk.getAdditionalReferenceEntity().getSimpleName());
                    //pkObj.add(IS_AFK,Bool.TRUE);
                    //fieldArray.add(pkObj);
                }
            );
        } else if (entity instanceof aloha.module.object.record.transaction.IAdditionalForeignEntity entityWithAFk) {
            // Tx系のAFK
            Func.accept(
                entityWithAFk.getAdditionalForeignKeyColumn(),
                afk -> {
                    View.Builder<ViewSchemaField> afkObj = createDefaultViewInfoField();
                    afkObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    afkObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    afkObj.setMandatoryValue(f -> f.Field, decapitalize(afk.getJavaName()));
                    afkObj.setMandatoryValue(f -> f.DataType, afk.getRefType().name());
                    afkObj.setOptionalValue(f -> f.IsImmutable, Bool.TRUE);

                    addForeignAndUniqueStringIfPossible(
                        container,
                        afkObj,
                        entityWithAFk.getAdditionalReferenceEntity().getSimpleName(),
                        true);
                    afkObj.setOptionalValue(f -> f.IsPivot, Bool.TRUE);
                    viewSchemas.add(afkObj.build());
                    //final var pkObj = Json.createObjectBuilder();
                    //pkObj.add(FIELD, JsonBuilder.decapitalize(fk.getJavaName()));
                    //pkObj.add(DATA_TYPE, fk.getRefType().name());
                    //addForeignAndUniqueStringIfPossible(
                    //    container,
                    //    pkObj,
                    //    entityWithAFk.getAdditionalReferenceEntity().getSimpleName());
                    //pkObj.add(IS_AFK,Bool.TRUE);
                    //fieldArray.add(pkObj);
                }
            );
        }

        // Attr
        if (entity instanceof ChildTxEntityIntAFK.Of entityWithInt) {
            Func.accept(
                entityWithInt.attr(),
                attr -> {

                    // Attributes
                    View.Builder<ViewSchemaField> attrObj = createDefaultViewInfoField();
                    attrObj.setMandatoryValue(f -> f.ViewType, entity.type().name());
                    attrObj.setMandatoryValue(f -> f.ViewName, entity.getClass().getSimpleName());

                    attrObj.setMandatoryValue(f -> f.Field, decapitalize(attr.getJavaName()));
                    attrObj.setMandatoryValue(f -> f.DataType, attr.getRefType().name());
                    // attrObj.setOptionalValue(f -> f.IsUnique, isUnique(attr)); // Tx not exist unique attr
                    // attrObj.setMandatoryValue(f -> f.IsImmutable, isImmutable(attr)); // Tx not exist immutable attr
                    //attrObj.setOptionalValue(f -> f.IsOptional, isOptional(attr));

                    // TODO support AFK of child tx?
                    //getForeignEntityIfAFK(attr).
                    //    unlessNull_(
                    //        foreign->
                    //            addForeignAndUniqueStringIfPossible(
                    //                container,
                    //                attrObj,
                    //                foreign));
                    //addIfEnum(attrObj, attr);
                    viewSchemas.add(attrObj.build());

                    //final var pkObjAttr = Json.createObjectBuilder();
                    //pkObjAttr.add(FIELD, JsonBuilder.decapitalize(attrCol.getJavaName()));
                    //pkObjAttr.add(DATA_TYPE, attrCol.getRefType().name());
                    //fieldArray.add(pkObjAttr);
                }
            );
        }
    }

    private static 
    View.Builder<ViewSchemaField>
    createDefaultViewInfoField() {
        return View.Builder.create(ViewSchemaField.class).
            setMandatoryValue(f -> f.IsPK, Bool.FALSE).
            setMandatoryValue(f -> f.IsFK, Bool.FALSE).
            setMandatoryValue(f -> f.IsAFK, Bool.FALSE).
            setOptionalValue(f -> f.IsEnum, Bool.FALSE).
            setOptionalValue(f -> f.IsUnique, Bool.FALSE).
            setOptionalValue(f -> f.IsOptional, Bool.FALSE).
            setOptionalValue(f -> f.IsImmutable, Bool.FALSE).
            setOptionalValue(f -> f.IsPivot, Bool.FALSE);
    }

    private static
    void
    addIfEnum(
        View.Builder<ViewSchemaField> json,
        Field.Member.ofStarView.Attribute<?> attr) {

        Func.accept(
            AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(attr.attributeEntity()),
            isEnum -> {
                json.setOptionalValue(f -> f.IsEnum, Bool.of(isEnum));
                if (isEnum) {
                    final var enumValues = new ArrayList<String>();
                    IdentifiableEnum.
                        toArray(
                            ((AttributeRow.ForIdentifiableEnum<?>) Instance.of(attr.attributeEntity())).enumClass()).
                        foreach(
                            enumValue ->
                                enumValues.add(enumValue.toString()));
                    json.setOptionalValue(f -> f.EnumValues, String.join(",", enumValues));
                }
            });
    }

    private static Bool
    isUnique(
        Field.Member.ofStarView.Attribute<?> attr) {

        return Bool.of(FixedAttributeEntity.UniqueString.class.isAssignableFrom(attr.attributeEntity()));
    }

    private static Bool
    isImmutable(
        Field.Member.ofStarView.Attribute<?> attr) {

        return Bool.of(FixedAttributeEntity.class.isAssignableFrom(attr.attributeEntity()));
    }

    private static Bool
    isOptional(
        Field.Member.ofStarView.Attribute<?> attr) {

        return Bool.of(attr instanceof Optional<?>);
    }
    private static Bool
    isOptional(
        AbstractColumn.TypedMember<?> attr) {

        return Bool.of(attr instanceof Optional<?>);
    }

    private static MayNullValue<String>
    getForeignEntityIfAFK(
        Field.Member.ofStarView.Attribute<?> attr) {

        final var isAFK = IAdditionalReferenceEntity.class.isAssignableFrom(attr.attributeEntity());
        if (isAFK) {
            final var afk =
                ((IAdditionalReferenceEntity<?>) Instance.of(attr.attributeEntity())).getAdditionalReferenceEntity();
            return MayNullValue.of(afk.getSimpleName());
        } else {
            return MayNullValue.nullInstance();
        }
    }

    private static
    void
    addForeignAndUniqueStringIfPossible(
        ServiceContainer container,
        View.Builder<ViewSchemaField> json,
        String foreignEntityName) {
        
        addForeignAndUniqueStringIfPossible(
            container,
            json,
            foreignEntityName,
            false);
    }

    private static
    void
    addForeignAndUniqueStringIfPossible(
        ServiceContainer container,
        View.Builder<ViewSchemaField> json,
        String foreignEntityName,
        boolean isAFK) {
        
        if (isAFK) {
            json.setMandatoryValue(f -> f.IsAFK, Bool.TRUE);
        } else {
            json.setMandatoryValue(f -> f.IsFK, Bool.TRUE);
        }

        json.setOptionalValue(f -> f.Foreign, foreignEntityName);
        findUniqueString(
            foreignEntityName,
            container).
            unlessNull_(
                fkUniqueStringColumn ->
                    json.setOptionalValue(
                        f -> f.ForeignUniqueStringColumn, // FOREIGN_UNIQUE_STRING_COLUMN
                        fkUniqueStringColumn));
    }

    private static
    MayNullValue<String>
    findUniqueString(
        String simpleName,
        ServiceContainer container) {

        var viewSchemas = viewInfoMaster(simpleName, container);
        if (viewSchemas.empty()) {
            // fields = viewInfoTx(simpleName, container).build().getJsonArray(FIELDS);
            return MayNullValue.nullInstance();
        }
        return viewSchemas.asList().stream().
            filter(view ->
                view.
                    optionalValue(f -> f.IsUnique).
                    unlessNull(v -> v, Bool.FALSE).
                    val()).
            findFirst().
            map(
                view ->
                    MayNullValue.of(view.mandatoryValue(f -> f.Field))).
            orElse(MayNullValue.nullInstance());
    }
}
