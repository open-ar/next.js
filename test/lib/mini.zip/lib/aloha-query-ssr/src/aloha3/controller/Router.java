package aloha3.controller;

import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController;
import aloha3.controller.query.QueryMasterCDCViewsController;
import aloha3.controller.query.QueryMasterViewsController;
import aloha3.controller.query.QueryTxViewsController;
import aloha3.controller.query.RegisterChainController;
import aloha3.controller.query.RegisterDocumentController;
import aloha3.controller.query.RegisterMasterViewController;
import aloha3.controller.query.RegisterTemporalAttributeController;
import aloha3.controller.query.RegisterTreeController;
import aloha3.controller.query.RegisterTxViewController;
import aloha3.controller.query.RegisterWorkFlowController;
import aloha3.controller.query.RegisterWorkFlowTransitionController;
import aloha3.controller.query.RollbackController;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class Router {
    private static final Map<String, BiConsumer<Request, Response>> gets = new HashMap<>();
    private static final Map<String, BiConsumer<Request, Response>> posts = new HashMap<>();
    private static final Map<String, BiConsumer<Request, Response>> puts = new HashMap<>();
    private static final Map<String, BiConsumer<Request, Response>> deletes = new HashMap<>();

    static {
        gets.put("/", IndexController::handle);

        // Master CRUD
        gets.put("/aloha-query/registerMasterView/", RegisterMasterViewController::handle);
        posts.put("/aloha-query/registerMasterView/", RegisterMasterViewController::handlePost);
        puts.put("/aloha-query/registerMasterView/", RegisterMasterViewController::handlePut);
        deletes.put("/aloha-query/registerMasterView/", RegisterMasterViewController::handleDelete);
        // Temporal CRUD
        gets.put("/aloha-query/registerTemporalAttribute/", RegisterTemporalAttributeController::handle);
        posts.put("/aloha-query/registerTemporalAttribute/", RegisterTemporalAttributeController::handlePost);
        puts.put("/aloha-query/registerTemporalAttribute/", RegisterTemporalAttributeController::handlePut);
        deletes.put("/aloha-query/registerTemporalAttribute/", RegisterTemporalAttributeController::handleDelete);
    
        // CR (Tx)
        gets.put("/aloha-query/registerTxView/", RegisterTxViewController::handle);
        posts.put("/aloha-query/registerTxView/", RegisterTxViewController::handlePost);
        // Document (Tx)
        gets.put("/aloha-query/registerDocument/", RegisterDocumentController::handle);
        posts.put("/aloha-query/registerDocument/", RegisterDocumentController::handlePost);
        puts.put("/aloha-query/registerDocument/", RegisterDocumentController::handlePut);
        // Workflow
        gets.put("/aloha-query/registerWorkFlow/", RegisterWorkFlowController::handle);
        posts.put("/aloha-query/registerWorkFlow/", RegisterWorkFlowController::handlePost);
        puts.put("/aloha-query/registerWorkFlow/", RegisterWorkFlowController::handlePut);
        deletes.put("/aloha-query/registerWorkFlow/", RegisterWorkFlowController::handleDelete);
        // Workflow Transition
        gets.put("/aloha-query/registerWorkFlowTransition/", RegisterWorkFlowTransitionController::handle);
        posts.put("/aloha-query/registerWorkFlowTransition/", RegisterWorkFlowTransitionController::handlePost);
        puts.put("/aloha-query/registerWorkFlowTransition/", RegisterWorkFlowTransitionController::handlePut);
        // Tree
        gets.put("/aloha-query/registerTree/", RegisterTreeController::handle);
        posts.put("/aloha-query/registerTree/", RegisterTreeController::handlePost);
        puts.put("/aloha-query/registerTree/", RegisterTreeController::handlePut);
        deletes.put("/aloha-query/registerTree/", RegisterTreeController::handleDelete);
        // Chain
        gets.put("/aloha-query/registerChain/", RegisterChainController::handle);
        posts.put("/aloha-query/registerChain/", RegisterChainController::handlePost);
        puts.put("/aloha-query/registerChain/", RegisterChainController::handlePut);
        deletes.put("/aloha-query/registerChain/", RegisterChainController::handleDelete);
        // CDC
        gets.put("/aloha-query/queryMasterCDCViews/", QueryMasterCDCViewsController::handle);

        // Query Master
        gets.put("/aloha-query/queryMasterViews/", QueryMasterViewsController::handle);
        gets.put("/aloha-query/queryMasterViews/search?params=", QueryMasterViewsController::handleSearch);
        // Query Tx
        gets.put("/aloha-query/queryTxViews/", QueryTxViewsController::handle);
        gets.put("/aloha-query/queryTxViews/search?params=", QueryTxViewsController::handleSearch);

        // Rollback
        gets.put("/aloha-query/rollback", RollbackController::handle);
        posts.put("/aloha-query/rollback", RollbackController::handlePost);
    }

    public static void 
    handle(
        Request request, 
        Response response) {

        Logger.INFO.log("handle method: " + request.method() + ", target: " + request.target());

        var target = request.target();
        if (target == null) {
            Logger.ERROR.log("Invalid method: null");
            return;
        }

        // If is GET request
        final var method = request.method();
        if (method.equalsIgnoreCase("GET")) {
            gets.entrySet().stream()
                .filter(entry ->target.startsWith(entry.getKey()))
                .max(Comparator.comparingInt(a -> a.getKey().length()))
                .ifPresent(entry -> entry.getValue().accept(request, response));
        } else if (method.equalsIgnoreCase("PUT") || isFormInputIncludeMethod(request, "PUT")) {
            puts.entrySet().stream()
                .filter(entry -> target.startsWith(entry.getKey()))
                .max(Comparator.comparingInt(a -> a.getKey().length()))
                .ifPresent(entry -> entry.getValue().accept(request, response));
        } else if (method.equalsIgnoreCase("DELETE") || isFormInputIncludeMethod(request, "DELETE")) {
            deletes.entrySet().stream()
                .filter(entry -> target.startsWith(entry.getKey()))
                .max(Comparator.comparingInt(a -> a.getKey().length()))
                .ifPresent(entry -> entry.getValue().accept(request, response));
        } else if (method.equalsIgnoreCase("POST")) {
            posts.entrySet().stream()
                .filter(entry -> target.startsWith(entry.getKey()))
                .max(Comparator.comparingInt(a -> a.getKey().length()))
                .ifPresent(entry -> entry.getValue().accept(request, response));
        } else {
            System.err.println("Unsupported method: " + request.method());
        }
    }

    private static 
    boolean
    isFormInputIncludeMethod(
        Request request, 
        String methodName) {
        // get all form input while js not invalid, embedded in html: <input type="hidden" name="_method" value="put" >
        return 
            MayNullValue.of(
                request.keyValues().get("_method")).
                unlessNull(
                    method -> method.equalsIgnoreCase(methodName),
                    false);
    }
}
