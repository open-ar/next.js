package aloha3.controller.tool.query.crud;

import aloha3.controller.tool.query.ViewMgr;

import javax.json.Json;
import javax.json.JsonObject;
import java.io.StringReader;

public class GenericModification {

    @SuppressWarnings(value="unchecked")
    public static
    void
    modify(
        String viewName,
        String params ) {

        if (params == null || params.isEmpty())
            throw new IllegalArgumentException("paramsは必須です。");
        JsonObject json = Json.createReader(new StringReader(params)).readObject();

        viewName = viewName.contains(".") ? viewName.substring(viewName.indexOf(".") +1 ) : viewName;

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);

        dataMgt.update(json);
    }

}
