package aloha3.controller.spi;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.controller.Router;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.ServiceContainer.Conceptual;

public interface AlohaQuerySsrPlugin {
    
    /**
     * Initialize the plugin.
     */
    default void init(ServiceContainer container, Conceptual conceptual) {}

    /**
     * Register routes provided by the plugin.
     */
    default void registerRoutes(Router router) {}

    /**
     * Get menu items provided by the plugin.
     */
    default ImmutVOs<MenuItem> getMenuItems() {
        return ImmutVOs.emptyVOs();
    }

    /**
     * Menu item record.
     */
    record MenuItem(String category, String label, String url) implements ValueObject {}
}
