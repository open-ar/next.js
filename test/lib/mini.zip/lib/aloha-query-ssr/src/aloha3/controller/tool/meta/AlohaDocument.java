package aloha3.controller.tool.meta;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha3.dml.NaturalTransformation;
import aloha3.document.business.Service;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.business.txm.DocumentField;
import aloha3.document.business.txm.DocumentLineItemField;
import aloha3.document.record.SubmitLineItem;
import aloha3.module.function.business.master.coc.GraphField;
import aloha3.module.object.Views;
import aloha3.module.object.model.OneToMany;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.meta.transaction.ChildTxLongAFKOnly;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AlohaDocument {

    public static <
        F extends AbstractSubmitField>
    ImmutableArray<
        OneToMany<
            OneToOne<
                OneToOne<
                    StarView.Read<FormField>,
                    TxStarView.Read<DocumentField>>, 
                TxStarView.Read<F>>, 
            OneToOne<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                TxStarView.Read<F>, 
                                // ChildTxIntAFKOnly.Read<SubmitLineItem>>, 
                                TxStarView.Read<DocumentLineItemField>>,
                            StarView.Hierarchy.Read<NestedElementField>>, 
                        StarView.Read<FormElementField>>, 
                    TxStarView.Read<DocumentField>>, 
                StarView.Read<FormField>>>>
    allDocumentModels(
        Service<F> service) {

        var flatNT =
        NaturalTransformation.
            fromCore(
                allForms(service, DateTime.YMDHMS.current()),
                DateTime.YMDHMS.current()).
            join(service.documentMgr());
            // join(service.submitFamily());

        var flats = flatNT.done();
        var documentViews = flats.map(v -> v.right);

        var latestSubmits = readDocumentsOnlyWithLatestSubmit(documentViews, service);
        var uniqueSubmitIds = latestSubmits.asList().stream().map(v -> v.left.left.left.left.left.right.foreignKeyValue()).collect(Collectors.toSet());
        List<OneToMany<OneToOne<OneToOne<StarView.Read<FormField>, TxStarView.Read<DocumentField>>, TxStarView.Read<F>>, OneToOne<OneToOne<OneToOne<OneToOne<OneToOne<TxStarView.Read<F>, TxStarView.Read<DocumentLineItemField>>, StarView.Hierarchy.Read<NestedElementField>>, StarView.Read<FormElementField>>, TxStarView.Read<DocumentField>>, StarView.Read<FormField>>>> result = 
            uniqueSubmitIds.
            stream().map(submitId -> {
                var oneFlat = latestSubmits.findOrException(v -> submitId.equals(v.left.left.left.left.left.right.foreignKeyValue()));
                
                // OneToOne<
                //    OneToOne<
                //        StarView.Read<FormField>, 
                //        TxStarView.Read<DocumentField>>, 
                //    TxStarView.Read<F>>
                var one = 
                    OneToOne.of(
                        OneToOne.of(
                            oneFlat.right,
                            oneFlat.left.right),
                        oneFlat.left.left.left.left.left.left);
                
                // OneToOne<
                //   OneToOne<
                //       OneToOne<
                //           OneToOne<
                //               OneToOne<
                //                   TxStarView.Read<F>, 
                //                   // ChildTxIntAFKOnly.Read<SubmitLineItem>>, 
                //                   TxStarView.Read<DocumentLineItemField>>,
                //               StarView.Hierarchy.Read<NestedElementField>>, 
                //           StarView.Read<FormElementField>>, 
                //       // TxStarView.Read<DocumentField>>, 
                //       TxStarView.Read<DocumentField>>,
                //   StarView.Read<FormField>>>
                var matchedMany = ImmutVOs.create(
                    latestSubmits.asList().stream().
                        filter(
                        v -> submitId.equals(v.left.left.left.left.left.right.foreignKeyValue())).
                        // TxChild(SubmitLineItemId)のPKでソート
                        sorted(Comparator.comparing(v -> v.left.left.left.left.left.right().getRowId())).
                        map(v -> 
                            OneToOne.of(
                                OneToOne.of(
                                    OneToOne.of(
                                        OneToOne.of(
                                            OneToOne.of(
                                                v.left.left.left.left.left.left,
                                                v.left.left.left.left.right),
                                            v.left.left.left.right),
                                        v.left.left.right),
                                    v.left.right),
                                v.right)).
                        toList());
                return OneToMany.of(one, matchedMany);
            }).toList();
        return ImmutableArray.of(result);
    }

    private static <F extends AbstractSubmitField> 
    ImmutVOs<StarView.Read<FormField>> 
    allForms(Service<F> submitFieldService, DateTime.YMDHMS current) {
        return 
            submitFieldService.
                formMgr().
                selectAllCores(current).
                unlessEmpty(
                    cores-> 
                        submitFieldService.formMgr().createViews(cores, current));
    }
    private static <F extends AbstractSubmitField> 
    ImmutVOs<StarView.Read<FormElementField>>
    allFormElements(Service<F> submitFieldService, DateTime.YMDHMS current) {
        return 
            submitFieldService.
                formElementMgr().
                selectAllCores(current).
                unlessEmpty(
                    cores-> 
                        submitFieldService.formElementMgr().createViews(cores, current));
    }

    public static <F extends AbstractSubmitField>
    ImmutVOs<
        OneToOne<
            OneToOne<
                StarView.Read<FormField>, 
                StarView.Hierarchy.Read<NestedElementField>>, 
            StarView.Read<FormElementField>>>
    allFormToFormElements(Service<F> service, DateTime.YMDHMS current) {

        var forms = allForms(service, current);
        ImmutableArray<
            OneToOne.MayZero<
                OneToOne<
                    StarView.Read<FormField>, 
                    StarView.Read<GraphField>>, 
                OneToOne<StarView.Hierarchy.Read<NestedElementField>, 
                    StarView.Read<FormElementField>>>> mayZeroImmutableArray = 
            service.joinFormElements(Views.M.create(forms));

        var list = new java.util.ArrayList<
            OneToOne<
                OneToOne<
                    StarView.Read<FormField>, 
                    StarView.Hierarchy.Read<NestedElementField>>, 
                StarView.Read<FormElementField>>>();
        mayZeroImmutableArray.foreach(v -> {
            if (!v.right.unsafeIsNull()) {
                list.add(
                    OneToOne.of(
                        OneToOne.of(
                            v.left.left,
                            v.right.mustNonNull().left),
                        v.right.mustNonNull().right));
            }
        });
        return ImmutVOs.create(list);
        // var formElements = allFormElements(service, DateTime.YMDHMS.current());
        // var allTrees = AlohaCRUD.starViewsOfGraph("Form", current);
        //
        // var results = allTrees.stream().flatMap(tree -> {
        //     var graphId = tree.left().coreId();
        //     var form = forms.findOrException(f -> f.mandatoryValue(ff -> ff.GraphId).equals(graphId));
        //     ImmutVOs<StarView.Hierarchy.Read<NestedElementField>> allNestedElements = AlohaCRUD.getAllNestedElements((Tree.StarArrow) tree.right());
        //     return allNestedElements.asList().stream().map(
        //         nested -> {
        //             var fe = formElements.findOrException(
        //                 fev ->
        //                     fev.mandatoryValue(FormElementField::FormElementId).
        //                         equals(nested.mandatoryValue(nef -> nef.unsafePivotAFKMember())) // TO_ELEMENT_ID
        //             );
        //             return OneToOne.of(
        //                 OneToOne.of(
        //                     form,
        //                     nested),
        //                 fe);
        //         });
        // });
        // return ImmutVOs.create(results.toList());
    }

    public static <
        F extends AbstractSubmitField>
    ImmutableArray<
        OneToOne<
            OneToOne<
                OneToOne<
                    OneToOne<
                        OneToOne<
                            OneToOne<
                                TxStarView.Read<F>,
                                ChildTxLongAFKOnly.Read<SubmitLineItem>>, 
                            TxStarView.Read<DocumentLineItemField>>, 
                        StarView.Hierarchy.Read<NestedElementField>>, 
                    StarView.Read<FormElementField>>, 
                TxStarView.Read<DocumentField>>, 
            StarView.Read<FormField>>>
    readDocumentsOnlyWithLatestSubmit(
        ImmutVOs<TxStarView.Read<DocumentField>> documentReads,
        Service<F> submitFieldService) {

        return submitFieldService.readLatestSubmits(Views.T.create(documentReads));
    }
}
