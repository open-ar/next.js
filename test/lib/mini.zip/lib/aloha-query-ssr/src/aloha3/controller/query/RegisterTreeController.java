package aloha3.controller.query;

import aloha.module.func.TriFunction;
import aloha.module.object.DateTime;
import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.MayNullValue;
import aloha.module.object.Tuple;
import aloha.module.object.Type;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.spi.TreeDefaultValueProvider;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaCRUD.GraphField;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.spec.AttributeRow;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonValue;
import java.io.StringReader;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static aloha3.controller.Server.conceptual;
import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.NODES;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.query.AlohaQueryV1.getId;

public class RegisterTreeController extends AbstractController {
    public static final RegisterTreeController INSTANCE = new RegisterTreeController();

    public static final String MAIN_TEMPLATE = "registerTree.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Workflow";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST");
        request.unlessNull_(
            NODES, PIVOT,
            (jsonNodes, pivot) ->
                AlohaCRUD.saveOfGraph(
                    pivot,
                    parseJsonNodesStarArrow(
                        jsonNodes,
                        targetId -> 
                            AlohaCRUD.
                                starViewOfMaster(targetId, pivot, container()).
                                mustNonNull(),
                        (from, to, jsonNode) ->
                            newHierarchy(pivot, from, to, jsonNode))));
        
        response.redirectTo(request.target());
    }

    static JsonObject parseJsonGraph(String json) {
        return Json.createReader(new StringReader(json)).readArray().getJsonObject(0);
    }

    public static void handlePut(
        Request request,
        Response response) {
        
        System.out.println("handle Put");
        final var asOf = DateTime.YMDHMS.current();
        request.unlessNull_(
            NODES, ID, PIVOT,
            (jsonNodes, id, pivot) ->
                AlohaCRUD.
                    coreReadOfGraph(
                        Integer.parseInt(id), 
                        pivot, asOf).
                    unlessNull_(
                        graphRead ->
                            AlohaCRUD.updateOfGraph(
                                pivot,
                                graphRead,
                                parseJsonNodesStarArrow(
                                    jsonNodes,
                                    targetId -> 
                                        AlohaCRUD.
                                            starViewOfMaster(targetId, pivot, container()).
                                            mustNonNull(),
                                    (from, to, jsonNode) -> 
                                        newHierarchy(pivot, from, to, jsonNode)))));
        
        response.redirectTo(request.target());
    }

    @SuppressWarnings("unchecked")
    static <
        F extends StarView.Read<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    Tuple.Triplet<
        F,
        StarView.Hierarchy.Write.New<HF>,
        F>[]
    parseJsonNodesStarArrow(
        String jsonNodes,
        Function<Integer, F> getCurrentNode,
        TriFunction<F, F, JsonObject, StarView.Hierarchy.Write.New<HF>> getHierarchyNode) {

        try (JsonReader reader = Json.createReader(new StringReader(jsonNodes))) {
            JsonArray rootArray = reader.readArray();
            if (rootArray.isEmpty()) {
                return new Tuple.Triplet[0];
            }

            JsonObject firstElement = rootArray.getJsonObject(0);
            JsonArray nodesArray = firstElement.getJsonArray("nodes");
            if (nodesArray.isEmpty()) {
                return new Tuple.Triplet[0];
            }

            Set<Tuple.Triplet<F, StarView.Hierarchy.Write.New<HF>, F>> pairs = new LinkedHashSet<>();
            for (JsonValue nodeValue : nodesArray) {
                JsonObject node = nodeValue.asJsonObject();
                int currentId = getId(node);

                processDirectChildNodes(
                    node,
                    getCurrentNode.apply(currentId),
                    getCurrentNode,
                    getHierarchyNode,
                    pairs);
            }

            return pairs.toArray(new Tuple.Triplet[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return new Tuple.Triplet[0];
        }
    }

    private static <
        F extends StarView.Read<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    void
    processDirectChildNodes(
        JsonObject node,
        F sourceState,
        Function<Integer, F> getCurrentNode,
        TriFunction<F, F, JsonObject, StarView.Hierarchy.Write.New<HF>> getHierarchyNode,
        Set<Tuple.Triplet<F, StarView.Hierarchy.Write.New<HF>, F>> triplets) {
        
        JsonArray childNodes = node.getJsonArray("nodes");
        if (childNodes != null && !childNodes.isEmpty()) {
            for (JsonValue childNodeValue : childNodes) {
                JsonObject childNode = childNodeValue.asJsonObject();
                int targetId = getId(childNode);
                F targetState = getCurrentNode.apply(targetId);
                StarView.Hierarchy.Write.New<HF> hf = getHierarchyNode.apply(sourceState, targetState, childNode);

                triplets.add(new Tuple.Triplet<>(sourceState, hf, targetState));

                processDirectChildNodes(childNode, targetState, getCurrentNode, getHierarchyNode, triplets);
            }
        }
    }

    private static final Map<String, Map<String, String>> DEFAULT_VALUES_TO_SKIP = loadDefaultValues();

    private static java.util.Map<String, java.util.Map<String, String>> loadDefaultValues() {
        java.util.Map<String, java.util.Map<String, String>> map = new java.util.HashMap<>();
        java.util.ServiceLoader.load(TreeDefaultValueProvider.class)
            .forEach(provider -> map.putAll(provider.provideDefaultValues()));
        return java.util.Map.copyOf(map);
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private static <
        F extends AbstractField & StarView.Field<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    StarView.Hierarchy.Write.New<HF>
    newHierarchy(String pivot, StarView.Read<F> from, StarView.Read<F> to, JsonObject jsonNode) {

        for (final var c : conceptual().all()) {
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                final var builder = hm.createArrowBuilder(from, to, DateTime.YMDHMS.current());
                final JsonObject attributes = jsonNode.getJsonObject("attributes");
                hm.arrowField().attributeMembers().foreach(attr -> {
                    final Field.Member.ofStarView.Attribute<?> attribute =
                        (Field.Member.ofStarView.Attribute<?>) attr;
                    if (!hasAttributeValue(attributes, attribute)) {
                        return;
                    }
                    Comparable<?> value = convertAttributeValue(attributes, attribute);
                    if (value == null) {
                        return;
                    }
                    if (attribute instanceof AbstractField.Member.Mandatory vm) {
                        builder.setMandatoryValue(f -> vm, value);
                    } else if (attribute instanceof AbstractField.Member.Optional vo) {
                        // Check configured default values to skip
                        var defaults = DEFAULT_VALUES_TO_SKIP.get(pivot);
                        if (defaults != null) {
                            var defaultValue = defaults.get(attribute.javaName());
                            if (defaultValue != null && defaultValue.equals(value.toString())) {
                                return;
                            }
                        }
                        builder.setOptionalValue(f -> vo, value);
                    } else {
                        throw new RuntimeException("Never");
                    }
                });
                return builder.build();
            }
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return null; // Tripleの最後は無視される;
            }
        }
        throw new RuntimeException("Never");
    }

    public static void 
    handleDelete(
        Request request,
        Response response) {
        
        System.out.println("handle Delete");
        request.unlessNull_(
            PIVOT, ID,
            (pivot, id) ->
                AlohaCRUD.deleteOfGraph(
                    Integer.parseInt(id),
                    pivot));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Integer::valueOf, 0)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder.
                add("title", "ツリー一覧").
                add(AlohaMeta.getTreePivots());
        }
    }

    private static String
    renderMainContent(
        String pivot,
        OperationType operation,
        Integer id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        Logger.INFO.log("registerWorkFlowView: " + viewInfo);
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("stars", AlohaCRUD.starViews(pivot, container())).
            add("views", getGraphViews(pivot, DateTime.YMDHMS.current())).
            add("hierarchySchema", buildHierarchySchema(pivot));

        getGraphViewById(id, pivot, DateTime.YMDHMS.current()).unlessNull_(
            view ->
                context.add("view_of_id", view));
        
        context.add("treeType", AlohaMeta.starViewType(pivot, container()));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static 
    ImmutVOs<View<GraphField>>
    getGraphViews(String pivot, DateTime.YMDHMS asOf) {

        return ImmutVOs.create(
            AlohaCRUD.starViewsOfGraph(pivot, asOf).stream().map(v -> {
                GraphRenderResult render = renderGraph(pivot, v.right(), asOf);
                return View.Builder.
                    create(GraphField.class).
                    setMandatoryValue(
                        f -> f.GraphId,
                        v.left().coreId()).
                    setMandatoryValue(
                        f -> f.Graph,
                        render.markdown()).
                    setOptionalValue(
                        f -> f.GraphMeta,
                        render.edgeMeta()).
                    build();
            }).collect(Collectors.toList()));
    }

    private static GraphRenderResult renderGraph(String pivot, Object graph, DateTime.YMDHMS asOf) {
        JsonArrayBuilder meta = Json.createArrayBuilder();
        String markdown = graphToMarkdownChart(pivot, graph, asOf, meta);
        return new GraphRenderResult(markdown, meta.build().toString());
    }

    private static
    String
    graphToMarkdownChart(String pivot, Object graph, DateTime.YMDHMS asOf) {
        return graphToMarkdownChart(pivot, graph, asOf, null);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static
    String 
    graphToMarkdownChart(String pivot, Object graph, DateTime.YMDHMS asOf, JsonArrayBuilder edgeMeta) {
        final var sb = new StringBuilder();
        sb.append("graph TD\n");
        if (graph instanceof Tree.Star g) {
            treeStarToMdGraph(g, sb, edgeMeta);
            return sb.toString();
        }
        if (graph instanceof Tree.StarArrow g) {
            treeStarArrowToMdGraph(pivot, g, sb, edgeMeta);
            return sb.toString();
        }
        return "graph TD\n";
    }

    static <
        F extends AbstractField & StarView.Field<?>> void
    treeStarToMdGraph(
        Tree.Star<F> parant, 
        StringBuilder sb,
        JsonArrayBuilder edgeMeta) {
        
        parant.branches().foreach(child ->
            treeStarToMdGraph(child,
                sb.
                    append("    ").
                    append(parant.node().pivotRead().coreId()).
                    append("[").append(getNodeLabel(parant.node())).append("]").
                    append("-->").
                    append(child.node().pivotRead().coreId()).
                    append("[").append(getNodeLabel(child.node())).append("]").
                    append("\n"),
                edgeMeta));
        parant.leaves().foreach(child ->
            sb.
                append("    ").
                append(parant.node().pivotRead().coreId()).
                append("[").append(getNodeLabel(parant.node())).append("]").
                append("-->").
                append(child.pivotRead().coreId()).
                append("[").append(getNodeLabel(child)).append("]").
                append("\n"));
    }

    static <
        F extends AbstractField & StarView.Field<?>,
        HF extends StarView.Hierarchy.FieldOf<?>> void
    treeStarArrowToMdGraph(
        String pivot,
        Tree.StarArrow<F, HF> parant,
        StringBuilder sb,
        JsonArrayBuilder edgeMeta) {
        
        parant.arrowToBranches().foreach(child -> {
            String attr = getFirstAttributeFromStarArrow(pivot, child.getLeft());

            treeStarArrowToMdGraph(pivot, child.getRight(),
                sb.
                    append("    ").
                    append(parant.from().pivotRead().coreId()).
                    append("[").append(getNodeLabel(parant.from())).append("]").
                    append("-->").
                    append(attr.isEmpty() ? "" : "|" + attr + "|").
                    append(child.getRight().from().coreRead().coreId()).
                    append("[").append(getNodeLabel(child.getRight().from())).append("]").
                    append("\n"),
                edgeMeta);
            if (edgeMeta != null) {
                edgeMeta.add(
                    buildEdgeMetaEntry(
                        pivot,
                        parant.from().pivotRead().coreId(),
                        child.getRight().from().coreRead().coreId(),
                        child.getLeft()));
            }
        });

        parant.arrowToLeaves().foreach(child -> {
            String attr = getFirstAttributeFromStarArrow(pivot, child.left());
            sb.
                append("    ").
                append(parant.from().pivotRead().coreId()).
                append("[").append(getNodeLabel(parant.from())).append("]").
                append("-->").
                append(attr.isEmpty() ? "" : "|" + attr + "|").
                append(child.getRight().pivotRead().coreId()).
                append("[").append(getNodeLabel(child.getRight())).append("]").
                append("\n");
            if (edgeMeta != null) {
                edgeMeta.add(
                    buildEdgeMetaEntry(
                        pivot,
                        parant.from().pivotRead().coreId(),
                        child.getRight().pivotRead().coreId(),
                        child.left()));
            }
        });
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <
        F extends AbstractField & StarView.Field<?>, 
        HF extends StarView.Hierarchy.FieldOf<?>> 
    String
    getFirstAttributeFromStarArrow(
        String pivot,
        StarView.Hierarchy.Read<HF> arrow) {
        
        final var firstAttr= arrow.field().attributeMembers().eltAt(0);
        return (firstAttr instanceof AbstractField.Member.Optional) ? 
            arrow.
                optionalValue(_ -> (AbstractField.Member.Optional)firstAttr).
                apply(
                    Object::toString,
                    () -> {
                        // Check configured default values to restore
                        var defaults = DEFAULT_VALUES_TO_SKIP.get(pivot);
                        if (defaults != null) {
                            var defaultValue = defaults.get(firstAttr.javaName());
                            if (defaultValue != null) {
                                return defaultValue;
                            }
                        }
                        return "";
                    }).
                toString() :
            arrow.
                mandatoryValue(_ -> (AbstractField.Member.Mandatory)firstAttr).
                toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static 
    <F extends AbstractField & StarView.Field<?>> 
    String 
    getNodeLabel(StarView.Read<F> child) {
        return child.field().attributeMembers().asList().stream().filter(
            it -> 
                it.javaName().equalsIgnoreCase("Name") || 
                it.javaName().equalsIgnoreCase("Code")).
            findFirst().
            map(v -> {
                if (v instanceof AbstractField.Member.Mandatory vm) {
                    return child.mandatoryValue(f -> vm).toString();
                } else if (v instanceof AbstractField.Member.Optional vo) {
                    return child.optionalValue(f -> vo).
                        apply(
                            Object::toString,
                            () -> child.coreRead().coreId() + ""
                        );
                }
                return child.coreRead().coreId() + "";
            }).orElseGet(() -> child.coreRead().coreId() + "").toString();
    }

    private static 
    boolean 
    hasAttributeValue(
        JsonObject attributes, 
        Field.Member.ofStarView.Attribute<?> attr) {
        
        if (attributes == null || attributes.isEmpty()) {
            return false;
        }
        final String decap = StringUtil.decapitalize(attr.javaName());
        return attributes.containsKey(decap) || attributes.containsKey(attr.javaName());
    }

    private static 
    MayNullVO<View<GraphField>>
    getGraphViewById(Integer graphId, String pivot, DateTime.YMDHMS asOf) {
        
        return
            AlohaCRUD.starViewOfGraph(graphId, pivot, asOf).
                map(
                    v -> {
                        GraphRenderResult render = renderGraph(pivot, v.right(), asOf);
                        return MayNullVO.of(
                            View.Builder.
                                create(GraphField.class).
                                setMandatoryValue(
                                    f -> f.GraphId,
                                    v.left().coreId()).
                                setMandatoryValue(
                                    f -> f.Graph,
                                    render.markdown()).
                                setOptionalValue(
                                    f -> f.GraphMeta,
                                    render.edgeMeta()).
                                build());
                    }).
                orElse(MayNullVO.nullInstance());
    }

    private record GraphRenderResult(String markdown, String edgeMeta) {}

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static 
    JsonObjectBuilder 
    buildEdgeMetaEntry(
        String pivot,
        int from,
        int to,
        StarView.Hierarchy.Read<?> hierarchy
    ) {
        JsonObjectBuilder builder = Json.createObjectBuilder()
            .add("from", from)
            .add("to", to)
            .add("hierarchyId", hierarchy.pivotRead().rowId());
        JsonObject attributes = extractHierarchyAttributes(pivot, hierarchy);
        if (attributes != null && !attributes.isEmpty()) {
            builder.add("attributes", attributes);
        }
        return builder;
    }

    private static
    JsonObject 
    extractHierarchyAttributes(String pivot, StarView.Hierarchy.Read<?> hierarchy) {
        JsonObjectBuilder builder = Json.createObjectBuilder();
        hierarchy.field().attributeMembers().foreach(attr -> {
            Field.Member.ofStarView.Attribute<?> member = (Field.Member.ofStarView.Attribute<?>) attr;
            String value = readAttributeValue(pivot, hierarchy, member);
            if (value != null && !value.isBlank()) {
                builder.add(StringUtil.decapitalize(member.javaName()), value);
            }
        });
        JsonObject built = builder.build();
        return built.isEmpty() ? null : built;
    }

    private static 
    Comparable<?> 
    convertAttributeValue(
        JsonObject attributes,
        Field.Member.ofStarView.Attribute<?> member
    ) {
        JsonValue jsonValue = getAttributeJsonValue(attributes, member);
        if (jsonValue == null || jsonValue.getValueType() == JsonValue.ValueType.NULL) {
            return null;
        }
        if (AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(member.attributeEntity())) {
            AttributeRow.ForIdentifiableEnum<?> attr =
                (AttributeRow.ForIdentifiableEnum<?>) Instance.of(member.attributeEntity());
            String token = jsonValueToString(jsonValue);
            if (token == null || token.isBlank()) {
                return null;
            }
            return IdentifiableEnum.findBy(token.trim(), attr.enumClass());
        }
        String raw = jsonValueToString(jsonValue);
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Type.toComparable(raw.trim(), member.refType());
        } catch (RuntimeException ex) {
            return raw.trim();
        }
    }

    private static 
    JsonValue 
    getAttributeJsonValue(
        JsonObject attributes,
        Field.Member.ofStarView.Attribute<?> member
    ) {
        if (attributes == null || attributes.isEmpty()) {
            return null;
        }
        final String decap = StringUtil.decapitalize(member.javaName());
        if (attributes.containsKey(decap)) {
            return attributes.get(decap);
        }
        if (attributes.containsKey(member.javaName())) {
            return attributes.get(member.javaName());
        }
        return null;
    }

    private static 
    String 
    jsonValueToString(JsonValue value) {
        if (value == null || value.getValueType() == JsonValue.ValueType.NULL) {
            return null;
        }
        return switch (value.getValueType()) {
            case STRING -> ((JsonString) value).getString();
            case NUMBER -> ((JsonNumber) value).toString();
            case TRUE -> "true";
            case FALSE -> "false";
            default -> value.toString();
        };
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static 
    String 
    readAttributeValue(
        String pivot,
        StarView.Hierarchy.Read<?> hierarchy,
        Field.Member.ofStarView.Attribute<?> member
    ) {
        if (member instanceof AbstractField.Member.Mandatory mandatory) {
            Object val = hierarchy.mandatoryValue(f -> mandatory);
            return val == null ? "" : val.toString();
        }
        if (member instanceof AbstractField.Member.Optional optional) {
            MayNullValue<?> val = hierarchy.optionalValue(f -> optional);
            return val.apply(Object::toString, () -> {
                // Check configured default values to restore
                var defaults = DEFAULT_VALUES_TO_SKIP.get(pivot);
                if (defaults != null) {
                    var defaultValue = defaults.get(member.javaName());
                    if (defaultValue != null) {
                        return defaultValue;
                    }
                }
                return "";
            });
        }
        return "";
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static 
    String 
    buildHierarchySchema(String pivot) {
        for (final var c : conceptual().all()) {
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm &&
                hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                JsonArrayBuilder schema = Json.createArrayBuilder();
                hm.arrowField().attributeMembers().foreach(attr -> {
                    Field.Member.ofStarView.Attribute<?> member = (Field.Member.ofStarView.Attribute<?>) attr;
                    schema.add(buildAttributeSchemaEntry(member));
                });
                return schema.build().toString();
            }
        }
        return "[]";
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static 
    JsonObject 
    buildAttributeSchemaEntry(Field.Member.ofStarView.Attribute<?> member) {
        boolean optional = member instanceof AbstractField.Member.Optional<?>;
        boolean fixed = FixedAttributeEntity.class.isAssignableFrom(member.attributeEntity());
        boolean enumType = AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(member.attributeEntity());

        JsonObjectBuilder builder = Json.createObjectBuilder()
            .add("name", member.javaName())
            .add("field", StringUtil.decapitalize(member.javaName()))
            .add("label", StringUtil.humanize(member.javaName()))
            .add("dataType", member.refType().name())
            .add("optional", optional)
            .add("fixed", fixed)
            .add("enum", enumType);
        if (enumType) {
            builder.add("options", buildEnumOptions(member));
        }
        return builder.build();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static 
    JsonArray 
    buildEnumOptions(Field.Member.ofStarView.Attribute<?> member) {
        JsonArrayBuilder builder = Json.createArrayBuilder();
        if (!AttributeRow.ForIdentifiableEnum.class.isAssignableFrom(member.attributeEntity())) {
            return builder.build();
        }
        AttributeRow.ForIdentifiableEnum<?> attr =
            (AttributeRow.ForIdentifiableEnum<?>) Instance.of(member.attributeEntity());
        ImmutableArray<? extends IdentifiableEnum<?>> enums = IdentifiableEnum.toArray(attr.enumClass());
        enums.foreach(e ->
            builder.add(
                Json.createObjectBuilder()
                    .add("label", e.name())
                    .add("value", Byte.toString(e.id()))));
        return builder.build();
    }
}

