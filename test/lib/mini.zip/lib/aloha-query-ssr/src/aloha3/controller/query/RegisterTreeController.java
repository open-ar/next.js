package aloha3.controller.query;

import aloha.module.func.TriFunction;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.Tuple;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaCRUD.GraphField;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.ParameterMappingTo;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import java.io.StringReader;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static aloha3.controller.Server.conceptual;
import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.NODES;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.query.AlohaQueryV1.getId;

public class RegisterTreeController extends AbstractController {
    public static final RegisterTreeController INSTANCE = new RegisterTreeController();

    public static final String MAIN_TEMPLATE = "registerTree.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Workflow";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST");
        request.unlessNull_(
            NODES, PIVOT,
            (jsonNodes, pivot) ->
                AlohaCRUD.saveOfGraph(
                    pivot,
                    parseJsonNodesStarArrow(
                        jsonNodes,
                        targetId -> 
                            AlohaCRUD.
                                starViewOfMaster(targetId, pivot, container()).
                                mustNonNull(),
                        (from, to, jsonNode) ->
                            newHierarchy(pivot, from, to, jsonNode))));
        
        response.redirectTo(request.target());
    }

    static JsonObject parseJsonGraph(String json) {
        return Json.createReader(new StringReader(json)).readArray().getJsonObject(0);
    }

    public static void handlePut(
        Request request,
        Response response) {
        
        System.out.println("handle Put");
        final var asOf = DateTime.YMDHMS.current();
        request.unlessNull_(
            NODES, ID, PIVOT,
            (jsonNodes, id, pivot) ->
                AlohaCRUD.
                    coreReadOfGraph(
                        Integer.parseInt(id), 
                        pivot, asOf).
                    unlessNull_(
                        graphRead ->
                            AlohaCRUD.updateOfGraph(
                                pivot,
                                graphRead,
                                parseJsonNodesStarArrow(
                                    jsonNodes,
                                    targetId -> 
                                        AlohaCRUD.
                                            starViewOfMaster(targetId, pivot, container()).
                                            mustNonNull(),
                                    (from, to, jsonNode) -> 
                                        newHierarchy(pivot, from, to, jsonNode)))));
        
        response.redirectTo(request.target());
    }

    @SuppressWarnings("unchecked")
    static <
        F extends StarView.Read<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    Tuple.Triplet<
        F,
        StarView.Hierarchy.Write.New<HF>,
        F>[]
    parseJsonNodesStarArrow(
        String jsonNodes,
        Function<Integer, F> getCurrentNode,
        TriFunction<F, F, JsonObject, StarView.Hierarchy.Write.New<HF>> getHierarchyNode) {

        try (JsonReader reader = Json.createReader(new StringReader(jsonNodes))) {
            JsonArray rootArray = reader.readArray();
            if (rootArray.isEmpty()) {
                return new Tuple.Triplet[0];
            }

            JsonObject firstElement = rootArray.getJsonObject(0);
            JsonArray nodesArray = firstElement.getJsonArray("nodes");
            if (nodesArray.isEmpty()) {
                return new Tuple.Triplet[0];
            }

            Set<Tuple.Triplet<F, StarView.Hierarchy.Write.New<HF>, F>> pairs = new LinkedHashSet<>();
            for (JsonValue nodeValue : nodesArray) {
                JsonObject node = nodeValue.asJsonObject();
                int currentId = getId(node);

                processDirectChildNodes(
                    node,
                    getCurrentNode.apply(currentId),
                    getCurrentNode,
                    getHierarchyNode,
                    pairs);
            }

            return pairs.toArray(new Tuple.Triplet[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return new Tuple.Triplet[0];
        }
    }

    private static <
        F extends StarView.Read<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    void
    processDirectChildNodes(
        JsonObject node,
        F sourceState,
        Function<Integer, F> getCurrentNode,
        TriFunction<F, F, JsonObject, StarView.Hierarchy.Write.New<HF>> getHierarchyNode,
        Set<Tuple.Triplet<F, StarView.Hierarchy.Write.New<HF>, F>> triplets) {
        
        JsonArray childNodes = node.getJsonArray("nodes");
        if (childNodes != null && !childNodes.isEmpty()) {
            for (JsonValue childNodeValue : childNodes) {
                JsonObject childNode = childNodeValue.asJsonObject();
                int targetId = getId(childNode);
                F targetState = getCurrentNode.apply(targetId);
                StarView.Hierarchy.Write.New<HF> hf = getHierarchyNode.apply(sourceState, targetState, childNode);

                triplets.add(new Tuple.Triplet<>(sourceState, hf, targetState));

                processDirectChildNodes(childNode, targetState, getCurrentNode, getHierarchyNode, triplets);
            }
        }
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private static <
        F extends AbstractField & StarView.Field<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    StarView.Hierarchy.Write.New<HF>
    newHierarchy(String pivot, StarView.Read<F> from, StarView.Read<F> to, JsonObject jsonNode) {

        for (final var c : conceptual().all()) {
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                final var builder = hm.createArrowBuilder(from, to, DateTime.YMDHMS.current());
                final JsonObject attributes = jsonNode.getJsonObject("attributes");
                hm.arrowField().attributeMembers().foreach(attr -> {
                    if (attributes == null || attributes.isEmpty()) {
                        return;
                    }
                    if (attr instanceof AbstractField.Member.Mandatory vm) {
                        builder.setMandatoryValue(
                            f -> vm,
                            ParameterMappingTo.toComparable(attributes, vm));
                    } else if (attr instanceof AbstractField.Member.Optional vo) {
                        builder.setOptionalValue(
                            f -> vo,
                            ParameterMappingTo.toComparable(attributes, vo));
                    } else {
                        throw new RuntimeException("Never");
                    }
                });
                return builder.build();
            }
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return null; // Tripleの最後は無視される;
            }
        }
        throw new RuntimeException("Never");
    }

    public static void 
    handleDelete(
        Request request,
        Response response) {
        
        System.out.println("handle Delete");
        request.unlessNull_(
            PIVOT, ID,
            (pivot, id) ->
                AlohaCRUD.deleteOfGraph(
                    Integer.parseInt(id),
                    pivot));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(ID, Integer::valueOf, 0)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected String renderNavMenu() {
            return engine().process(
                INSTANCE.getNavMenuTemplate(),
                Context.Builder.create().
                    add("title", "ツリー一覧").
                    add(AlohaMeta.getTreePivots()).
                    build());
        }
    }

    private static String
    renderMainContent(
        String pivot,
        OperationType operation,
        Integer id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        Logger.INFO.log("registerWorkFlowView: " + viewInfo);
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("stars", AlohaCRUD.starViews(pivot, container())).
            add("views", getGraphViews(pivot, DateTime.YMDHMS.current()));

        getGraphViewById(id, pivot, DateTime.YMDHMS.current()).unlessNull_(
            view ->
                context.add("view_of_id", view));
        
        context.add("treeType", AlohaMeta.starViewType(pivot, container()));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static 
    ImmutVOs<View<GraphField>>
    getGraphViews(String pivot, DateTime.YMDHMS asOf) {

        return ImmutVOs.create(
            AlohaCRUD.starViewsOfGraph(pivot, asOf).stream().map(v ->
                View.Builder.
                    create(GraphField.class).
                    setMandatoryValue(
                        f -> f.GraphId,
                        v.left().coreId()).
                    setMandatoryValue(
                        f -> f.Graph,
                        graphToMarkdownChart(v.right(), asOf)).
                    build()).collect(Collectors.toList()));
    }

    private static
    String 
    graphToMarkdownChart(Object graph, DateTime.YMDHMS asOf) {
        final var sb = new StringBuilder();
        sb.append("graph TD\n");
        if (graph instanceof Tree.Star g) {
            treeStarToMdGraph(g, sb);
            return sb.toString();
        }
        if (graph instanceof Tree.StarArrow g) {
            treeStarArrowToMdGraph(g, sb);
            return sb.toString();
        }
        return "graph TD\n";
    }

    static <
        F extends AbstractField & StarView.Field<?>> void
    treeStarToMdGraph(
        Tree.Star<F> parant, 
        StringBuilder sb) {
        
        parant.branches().foreach(child ->
            treeStarToMdGraph(child,
                sb.
                    append("    ").
                    append(parant.node().pivotRead().coreId()).
                    append("[").append(getNodeLabel(parant.node())).append("]").
                    append("-->").
                    append(child.node().pivotRead().coreId()).
                    append("[").append(getNodeLabel(child.node())).append("]").
                    append("\n")));
        parant.leaves().foreach(child ->
            sb.
                append("    ").
                append(parant.node().pivotRead().coreId()).
                append("[").append(getNodeLabel(parant.node())).append("]").
                append("-->").
                append(child.pivotRead().coreId()).
                append("[").append(getNodeLabel(child)).append("]").
                append("\n"));
    }

    static <
        F extends AbstractField & StarView.Field<?>,
        HF extends StarView.Hierarchy.FieldOf<?>> void
    treeStarArrowToMdGraph(
        Tree.StarArrow<F, HF> parant,
        StringBuilder sb) {
        
        parant.arrowToBranches().foreach(child -> {
            String attr = getFirstAttributeFromStarArrow(child.getLeft());

            treeStarArrowToMdGraph(child.getRight(),
                sb.
                    append("    ").
                    append(parant.from().pivotRead().coreId()).
                    append("[").append(getNodeLabel(parant.from())).append("]").
                    append("-->").
                    append(attr.isEmpty() ? "" : "|" + attr + "|").
                    append(child.getRight().from().coreRead().coreId()).
                    append("[").append(getNodeLabel(child.getRight().from())).append("]").
                    append("\n"));
        });

        parant.arrowToLeaves().foreach(child -> {
            String attr = getFirstAttributeFromStarArrow(child.left());
            sb.
                append("    ").
                append(parant.from().pivotRead().coreId()).
                append("[").append(getNodeLabel(parant.from())).append("]").
                append("-->").
                append(attr.isEmpty() ? "" : "|" + attr + "|").
                append(child.getRight().pivotRead().coreId()).
                append("[").append(getNodeLabel(child.getRight())).append("]").
                append("\n");
        });
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <
        F extends AbstractField & StarView.Field<?>, 
        HF extends StarView.Hierarchy.FieldOf<?>> 
    String
    getFirstAttributeFromStarArrow(
        StarView.Hierarchy.Read<HF> arrow) {
        
        final var firstAttr= arrow.field().attributeMembers().eltAt(0);
        return (firstAttr instanceof AbstractField.Member.Optional) ? 
            arrow.
                optionalValue(_ -> (AbstractField.Member.Optional)firstAttr).
                apply(
                    Object::toString,
                    () -> "").
                toString() :
            arrow.
                mandatoryValue(_ -> (AbstractField.Member.Mandatory)firstAttr).
                toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static 
    <F extends AbstractField & StarView.Field<?>> 
    String 
    getNodeLabel(StarView.Read<F> child) {
        return child.field().attributeMembers().asList().stream().filter(
            it -> 
                it.javaName().equalsIgnoreCase("Name") || 
                it.javaName().equalsIgnoreCase("Code")).
            findFirst().
            map(v -> {
                if (v instanceof AbstractField.Member.Mandatory vm) {
                    return child.mandatoryValue(f -> vm).toString();
                } else if (v instanceof AbstractField.Member.Optional vo) {
                    return child.optionalValue(f -> vo).
                        apply(
                            Object::toString,
                            () -> child.coreRead().coreId() + ""
                        );
                }
                return child.coreRead().coreId() + "";
            }).orElseGet(() -> child.coreRead().coreId() + "").toString();
    }

    private static 
    MayNullVO<View<GraphField>>
    getGraphViewById(Integer graphId, String pivot, DateTime.YMDHMS asOf) {
        
        return
            AlohaCRUD.starViewOfGraph(graphId, pivot, asOf).
                map(
                    v ->
                        MayNullVO.of(
                            View.Builder.
                                create(GraphField.class).
                                setMandatoryValue(
                                    f -> f.GraphId,
                                    v.left().coreId()).
                                setMandatoryValue(
                                    f -> f.Graph,
                                    graphToMarkdownChart(v.right(), asOf)).
                                build())).
                orElse(MayNullVO.nullInstance());
    }
}

