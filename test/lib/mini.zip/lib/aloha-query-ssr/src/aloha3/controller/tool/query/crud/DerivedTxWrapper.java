package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist;
import aloha.module.object.Compare;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKModel;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.DerivedTxMgr;
import aloha3.module.object.record.meta.transaction.DerivedTx;
import aloha3.module.object.record.meta.transaction.TxAttributeIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntity;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import java.util.List;
import java.util.Map;

public class DerivedTxWrapper<
    E extends DerivedTxEntity.From<X>,
    X extends SealedTxParent<?>,
    F extends TxStarView.FieldOf<E>,
    MF extends AbstractField & TxStarView.Field<X>,
    T extends TxStarView.Read<F> >
    extends BaseMgrWrapper<T, Long, Long> {

    private final String name;
    private final F field;
    private final DerivedTxMgr.StarView<E,X,F> mgr;

    public DerivedTxWrapper(
        String name,
        F field,
        DerivedTxMgr.StarView<E,X,F> mgr ) {

        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    @Override
    public DerivedTxMgr.StarView<E,X,F> getMgr() {
        return this.mgr;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        String foreignEntity = mgr.foreignEntity().getClass().getSimpleName();
        long fkId = Long.valueOf(json.getString(getCenterMember().javaName() ));
        MayNullVO mayNullVO = GenericSearch.queryTxViewByPK(foreignEntity, fkId);

        return mayNullVO.apply(
            (vo)-> {
                if (vo instanceof  TxStarView.Read) {
                    TxStarView.Read<MF> fk = (TxStarView.Read<MF>)vo;
                    TxStarView.Write.Prepare.Builder builder = TxStarView.Write.Prepare.Builder.
                        create(
                            getFieldClass());

                    setValues(json, field, builder);

                    Persist.Value<Long> ret = mgr.
                        save(
                            builder.build(),
                            fk.txRead(),
                            DateTime.YMDHMS.current());
                    return ret.get();
                } else if (vo instanceof TxIntFKChildIntAFKModel fk) {
                    TxStarView.Write.Prepare.Builder builder = TxStarView.Write.Prepare.Builder.
                        create(
                            getFieldClass());

                    setValues(json, field, builder);

                    TxStarView.Write.Prepare build = builder.build();
                    System.out.println(json);
                    System.out.println(build);
                    getMandatoryAttributeMembers(field).
                        forEach(
                            (member)->
                                System.out.println(member));

                    Persist.Value<Long> ret = mgr.
                        save(
                            build,
                            ((TxStarView.Read<MF>)fk.view()).txRead(),
                            DateTime.YMDHMS.current());
                    return ret.get();
                } else {
                    throw new RuntimeException("Not supported type: " + vo.getClass().getName());
                }},
            ()->-1L);
    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.unsafeCenterMember().javaName());
    }

    @Override
    public
    ImmutVOs<T>
    query() {

        return queryTxs().apply(
            (txs)->mgr.createViews((NonEmptyVOs)txs),
            ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public MayNullVO<T>
    queryByPK(Long id) {

        return (MayNullVO<T>)mgr.createView(id);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Long> pkIDs) {

        return (ImmutVOs<T>)mgr.createViews(
            DistinctIds.toLongIDs(pkIDs));
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs fkViews,
        Map<String, Object> params) {

        if (fkViews.empty())
            return ImmutVOs.emptyVOs();
        if (fkViews.eltAt(0) instanceof TxIntFKChildIntAFKModel )
            return queryByTxIntFKChildIntAFKModels(fkViews);
        else
            return queryByFKViews(fkViews);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByTxIntFKChildIntAFKModels(
        ImmutVOs<TxIntFKChildIntAFKModel> foreigns) {

        return (ImmutVOs<T>)foreigns.apply(
            (txs)->
                mgr.createViews(DistinctIds.longIDsFromViews(txs.map(v -> (TxStarView.Read<MF>) v.view()), (tx) -> tx.txRead().getRowId())),
            ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKViews(
        ImmutVOs<TxStarView.Read> foreigns) {

        return (ImmutVOs<T>)foreigns.apply(
            (txs)->
                mgr.createViews(DistinctIds.longIDsFromViews(txs, (tx) -> (((TxStarView.Read<MF>)tx).txRead().getRowId()))),
            ()->ImmutVOs.emptyVOs());
    }


    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByIntAFKViews(afkViews, afkName, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName,
        Map<String, Object> params) {

        return (ImmutVOs<T>)afkViews.
            apply(
                (afks)->
                    ((ImmutVOs<TxAttributeIntAFK.Read>)mgr.
                        selectAttributeIntAFKs(
                            (Class) ViewMgr.getJoinColumn(name, afkName).getDeclaredClass(),
                            (NonEmptyVOs) afks.map(v -> v.coreRead()))).
                        apply(
                            (txAttrs)->
                                mgr.createViews(
                                    DistinctIds.longIDsFromRecords(
                                        txAttrs,
                                        txAttr->txAttr.getTxId())),
                            ()->ImmutVOs.emptyVOs()),
                ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        if (isForeignKey(afkName))
            return queryByFKs(afkViews, params);

        for(AbstractField.Member.Mandatory member : getMandatoryAttributeMembers()) {
            if (member.javaName().equals(afkName)) {
                final AbstractField.Member.Mandatory<Long> accessor = member;
                return query().
                    filter(
                        (view)->{
                            long afk = view.longValue(f->accessor);
                            return (boolean)afkViews.
                                find(
                                    (afkView)->
                                        Compare.eq(
                                            afk,
                                            ((TxStarView.Read)afkView).txRead().rowId())).
                                apply(
                                    (notEmpty)-> true,
                                    ()->false);
                        });
            }
        }
        throw new IllegalCallerException("Not Found : " + afkName);
    }

    @Override
    public
    void
    update(
        JsonObject json) {
    }

    @Override
    public
    void
    delete(
        JsonObject json) {
    }

    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return mgr.field().unsafeCenterMember();
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory>  members = getMandatoryAttributeMembers(field);
        //members.add(0, mgr.field().FK());
        return members;
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(field);
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }
    @Override
    public ImmutVOs<? extends Read> queryTxs() {
        return Query.select(DerivedTx.Read.createCriteria(this.field.entity()));
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

}

