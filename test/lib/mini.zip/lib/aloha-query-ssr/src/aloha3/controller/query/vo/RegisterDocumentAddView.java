package aloha3.controller.query.vo;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.Type;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaDocument;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.document.business.Service;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.document.business.txm.AbstractSubmitField;
import aloha3.document.record.Enum.REQUIRED;
import aloha3.document.record.NestedElement;
import aloha.module.object.Tuple;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.meta.Record;
import aloha3.module.object.view.View;
import aloha3.module.object.view.StarView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * View model for registerDocument add form.
 */
public record RegisterDocumentAddView(
    String pivot,
    OperationType operation,
    Integer formId,
    ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewSchemas,
    ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
    List<FormElementInputRow> formElements,
    List<FormTree> formTree) {

    private static final String NESTED_ELEMENT_INPUT_PREFIX = "NestedElementId_";

    public static 
    RegisterDocumentAddView 
    create(
        String pivot,
        OperationType operation,
        Integer formId,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewSchemas,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
        Service<? extends AbstractSubmitField> submitFieldService) {

        return create(
            pivot,
            operation,
            formId,
            viewSchemas,
            submitAttrSchemas,
            submitFieldService,
            Map.of());
    }

    public static 
    RegisterDocumentAddView 
    create(
        String pivot,
        OperationType operation,
        Integer formId,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewSchemas,
        ImmutVOs<View<AlohaMeta.ViewSchemaField>> submitAttrSchemas,
        Service<? extends AbstractSubmitField> submitFieldService,
        Map<Integer, Deque<String>> valueBuckets) {

        List<FormElementInputRow> formElements = resolveFormElementInputs(formId, submitFieldService);
        List<FormTree> formTree = buildFormTree(formElements, valueBuckets);
        return new RegisterDocumentAddView(
            pivot,
            operation,
            formId,
            viewSchemas,
            submitAttrSchemas,
            formElements,
            formTree);
    }

    public static 
    Map<Integer, List<FormElementInputRow>> 
    formElementsByFormId(
        Service<? extends AbstractSubmitField> submitFieldService) {

        return resolveFormElementInputs(0, submitFieldService).stream()
            .collect(Collectors.groupingBy(
                FormElementInputRow::formId,
                LinkedHashMap::new,
                Collectors.toList()));
    }

    public static 
    Map<Integer, List<FormTree>> 
    formTreesByFormId(
        Map<Integer, List<FormElementInputRow>> formElementsByFormId) {

        return formElementsByFormId.entrySet().stream()
            .filter(entry -> entry.getKey() != null)
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                entry -> buildFormTree(entry.getValue()),
                (existing, duplicate) -> existing,
                LinkedHashMap::new));
    }

    // Utility method to create form trees from service
    public static 
    Map<Integer, List<FormTree>> 
    formTreesByFormId(
        Service<? extends AbstractSubmitField> submitFieldService) {

        return formTreesByFormId(formElementsByFormId(submitFieldService));
    }

    public static List<FormTree> 
    formTreeForFormId(
        Integer formId,
        Service<? extends AbstractSubmitField> submitFieldService) {

        if (formId == null || formId == 0) {
            return List.of();
        }
        List<FormElementInputRow> formElements = resolveFormElementInputs(formId, submitFieldService);
        return buildFormTree(formElements);
    }

    public static 
    List<TxModel.ChildValue<NestedElement, String>> 
    collectChildValues(
        Map<String, String> keyValues,
        Service<? extends AbstractSubmitField> submitFieldService,
        DateTime.YMDHMS now,
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        Integer formId) {

        if (keyValues == null || keyValues.isEmpty()) {
            return List.of();
        }
        List<FormTree> formTrees = formTreeForFormId(formId, submitFieldService);
        if (formTrees.isEmpty()) {
            return List.of();
        }
        List<TxModel.ChildValue<NestedElement, String>> collector = new ArrayList<>();
        for (FormTree formTree : formTrees) {
            collectChildValuesFromNode(
                keyValues,
                submitFieldService,
                now,
                treeRead,
                formTree.node(),
                formTree.instances(),
                collector);
        }
        return collector;
    }

    public static 
    String 
    buildInputName(Integer nestedElementId, int inputIndex) {
        if (nestedElementId == null || inputIndex <= 0) {
            return null;
        }
        return NESTED_ELEMENT_INPUT_PREFIX + nestedElementId + "_" + inputIndex;
    }

    private static void 
    collectChildValuesFromNode(
        Map<String, String> keyValues,
        Service<? extends AbstractSubmitField> submitFieldService,
        DateTime.YMDHMS now,
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        FormTreeNode node,
        List<FormTreeNodeInstance> instances,
        List<TxModel.ChildValue<NestedElement, String>> collector) {

        if (node == null || instances == null || instances.isEmpty()) {
            return;
        }
        if (node.hasChildren()) {
            for (FormTreeNodeInstance instance : instances) {
                for (FormTreeChildGroup childGroup : instance.childGroups()) {
                    collectChildValuesFromNode(
                        keyValues,
                        submitFieldService,
                        now,
                        treeRead,
                        childGroup.node(),
                        childGroup.instances(),
                        collector);
                }
            }
            return;
        }

        Integer nestedElementId = node.nestedElementId();
        if (nestedElementId == null) {
            return;
        }
        StarView.Hierarchy.Read<NestedElementField> relView = getNestedElementById(treeRead, nestedElementId);
        var formElementView = submitFieldService.formElementMgr()
            .createView(
                relView.mandatoryValue(f -> f.unsafePivotAFKMember()).intValue(),
                now)
            .mustNonNull();
        if (isRootFormElement(formElementView)) {
            return;
        }
        for (FormTreeNodeInstance instance : instances) {
            String key = buildInputName(nestedElementId, instance.inputIndex());
            if (key == null) {
                continue;
            }
            var rawValue = keyValues.get(key);
            if (rawValue == null || rawValue.isBlank()) {
                continue;
            }
            var formatted = formatByRefType(formElementView, rawValue.trim());
            if (formatted.isBlank()) {
                continue;
            }
            collector.add(toChildValue(relView, formatted));
        }
    }

    private static 
    String 
    formatByRefType(StarView.Read<FormElementField> formElementView, String value) {
        return switch (formElementView.mandatoryValue(f -> f.RefType)) {
            case YMD -> value.replaceAll("[/-]", "");
            case YMDHMS ->
                (value.replaceAll("T", "").replaceAll("[:-]", "") + "0000").substring(0, 14);
            default -> value;
        };
    }

    private static boolean 
    isRootFormElement(StarView.Read<FormElementField> formElementView) {
        return Service.ROOT_FORM_ELEMENT_NAME.equals(
            formElementView.mandatoryValue(f -> f.Name));
    }

    private static 
    <T extends Comparable<? super T>> 
    TxModel.ChildValue<NestedElement, String> 
    toChildValue(
        StarView.Hierarchy.Read<NestedElementField> fc,
        T value) {

        return new TxModel.ChildValue<>(
            (Record.SinglePK) fc.pivotRead(),
            value.toString());
    }

    public static 
    StarView.Hierarchy.Read<NestedElementField> 
    getNestedElement(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        StarView.Read<FormElementField> formElement) {

        return findNestedElement(treeRead, formElement)
            .orElseThrow(() -> new RuntimeException(
                "NestedElement not found for FormElement: " + formElement.coreRead().coreId()));
    }

    public static 
    StarView.Hierarchy.Read<NestedElementField> 
    getNestedElementById(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        int nestedElementId) {

        return findNestedElementById(treeRead, nestedElementId)
            .orElseThrow(() ->
                new RuntimeException("NestedElement not found for NestedElementId: " + nestedElementId));
    }

    private static 
    Optional<StarView.Hierarchy.Read<NestedElementField>> 
    findNestedElement(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        StarView.Read<FormElementField> formElement) {

        var targetId = formElement.coreRead().coreId();

        Optional<StarView.Hierarchy.Read<NestedElementField>> leafResult =
            treeRead.arrowToLeaves().asList().stream()
                .filter(leaf -> leaf.right().mandatoryValue(FormElementField::FormElementId).equals(targetId))
                .map(Tuple.ImmutPair::left)
                .findFirst();

        if (leafResult.isPresent()) {
            return leafResult;
        }

        for (var branch : treeRead.arrowToBranches().asList()) {
            if (branch.right().from().mandatoryValue(FormElementField::FormElementId).equals(targetId)) {
                return Optional.of(branch.left());
            }

            Optional<StarView.Hierarchy.Read<NestedElementField>> branchResult =
                findNestedElement(branch.right(), formElement);
            if (branchResult.isPresent()) {
                return branchResult;
            }
        }

        return Optional.empty();
    }

    private static 
    Optional<StarView.Hierarchy.Read<NestedElementField>> 
    findNestedElementById(
        Tree.StarArrow<FormElementField, NestedElementField> treeRead,
        int nestedElementId) {

        Optional<StarView.Hierarchy.Read<NestedElementField>> leafResult =
            treeRead.arrowToLeaves().asList().stream()
                .map(Tuple.ImmutPair::left)
                .filter(leaf -> leaf.mandatoryValue(NestedElementField::NestedElementId).equals(nestedElementId))
                .findFirst();

        if (leafResult.isPresent()) {
            return leafResult;
        }

        for (var branch : treeRead.arrowToBranches().asList()) {
            var branchNode = branch.left();
            if (branchNode.mandatoryValue(NestedElementField::NestedElementId).equals(nestedElementId)) {
                return Optional.of(branchNode);
            }
            var branchResult = findNestedElementById(branch.right(), nestedElementId);
            if (branchResult.isPresent()) {
                return branchResult;
            }
        }
        return Optional.empty();
    }


    public boolean hasFormElements() {
        return !formElements.isEmpty();
    }

    public boolean hasFormTree() {
        return !formTree.isEmpty();
    }

    private static 
    List<FormElementInputRow> 
    resolveFormElementInputs(
        Integer formId,
        Service<? extends AbstractSubmitField> submitFieldService) {

        var now = DateTime.YMDHMS.current();
        return AlohaDocument.
            allFormToFormElements(submitFieldService, now).
            filter(o2o -> {
                var formIdToKeep = o2o.left.left.mandatoryValue(FormField::FormId);
                return formId == 0 || formIdToKeep.equals(formId);
            }).
            map(FormElementRow::create).
            asList().
            stream().
            map(FormElementInputRow::fromRow).
            collect(Collectors.toList());
    }

    public static 
    List<FormTree> 
    buildFormTree(List<FormElementInputRow> formElements) {
        return buildFormTree(formElements, Map.of());
    }

    public static 
    List<FormTree> 
    buildFormTree(
        List<FormElementInputRow> formElements,
        Map<Integer, Deque<String>> valueBuckets) {
        if (formElements.isEmpty()) {
            return List.of();
        }

        var byId = formElements.stream().collect(
            Collectors.toMap(
                FormElementInputRow::formElementId, 
                Function.identity(),
                (existing, duplicate) -> existing, LinkedHashMap::new));

        var childrenByParent = formElements.stream().collect(
            Collectors.groupingBy(
                FormElementInputRow::parentFormElementId,
                LinkedHashMap::new, 
                Collectors.toList()));

        return formElements.stream().
            filter(row -> isRootNode(row, byId)).
            distinct().
            map(row -> {
                var node = toTreeNode(row, childrenByParent);
                return new FormTree(node, instantiateNode(node, 1, valueBuckets));
            }).
            collect(Collectors.toList());
    }

    private static boolean 
    isRootNode(FormElementInputRow row, Map<Integer, FormElementInputRow> byId) {
        Integer parentId = row.parentFormElementId();
        return parentId == null || !byId.containsKey(parentId);
    }

    private static FormTreeNode
    toTreeNode(
        FormElementInputRow row,
        Map<Integer, List<FormElementInputRow>> childrenByParent) {

        List<FormTreeNode> children =
            childrenByParent.getOrDefault(row.formElementId(), List.of()).
                stream().
                map(child -> toTreeNode(child, childrenByParent)).
                collect(Collectors.toList());

        return new FormTreeNode(
            row.formElementId(),
            row.parentFormElementId(),
            row.nestedElementId(),
            row.name(),
            row.refType(),
            row.inputType(),
            row.arrayMaxSize(),
            row.required(),
            children);
    }

    private static 
    List<FormTreeNodeInstance> 
    instantiateNode(
        FormTreeNode node,
        int parentOccurrence,
        Map<Integer, Deque<String>> valueBuckets) {

        int repeat = node.arrayMaxSize() <= 0 ? 1 : node.arrayMaxSize();
        List<FormTreeNodeInstance> instances = new ArrayList<>();
        for (int i = 1; i <= repeat; i++) {
            int inputIndex = (parentOccurrence - 1) * repeat + i;
            List<FormTreeChildGroup> childGroups = node.children().stream().
                map(childNode ->
                    new FormTreeChildGroup(
                        childNode,
                        instantiateNode(childNode, inputIndex, valueBuckets))).
                collect(Collectors.toList());
            String value = null;
            if (!node.hasChildren() && node.nestedElementId() != null) {
                var queue = valueBuckets.get(node.nestedElementId());
                value = queue != null ? queue.pollFirst() : null;
            }
            instances.add(new FormTreeNodeInstance(node, inputIndex, childGroups, value));
        }
        return instances;
    }

    public static 
    Map<Integer, Deque<String>> 
    createValueBuckets(
        Map<Integer, List<String>> valuesByNestedElementId) {

        if (valuesByNestedElementId == null || valuesByNestedElementId.isEmpty()) {
            return Map.of();
        }

        return valuesByNestedElementId.entrySet().stream()
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                entry -> new ArrayDeque<>(entry.getValue()),
                (existing, duplicate) -> existing,
                LinkedHashMap::new));
    }

    public record FormElementInputRow(
        Integer formId,
        Integer formElementId,
        Integer parentFormElementId,
        Integer nestedElementId,
        String name,
        Type.RefType refType,
        InputType inputType,
        int arrayMaxSize,
        boolean required) {

        public static FormElementInputRow fromRow(FormElementRow row) {
            var nestedElement = row.nestedElement();
            var arraySize = row.arrayMaxSize() == null ? 1 : row.arrayMaxSize();
            var required = nestedElement.optionalValue(f -> f.Required).
                apply(value -> value == REQUIRED.MANDATORY, () -> false);
            return new FormElementInputRow(
                row.form().mandatoryValue(FormField::FormId),
                row.formElementId(),
                row.parentFormElementId(),
                row.nestedElementId(),
                row.name(),
                row.refType(),
                InputType.from(row.refType()),
                arraySize,
                required);
        }

        public enum InputType {
            TEXT("text"),
            NUMBER("number", "1"),
            DATE("date"),
            DATETIME("datetime-local");

            private final String htmlType;
            private final String step;

            InputType(String htmlType) {
                this(htmlType, null);
            }

            InputType(String htmlType, String step) {
                this.htmlType = htmlType;
                this.step = step;
            }

            public String htmlType() {
                return htmlType;
            }

            public String step() {
                return step;
            }

            static InputType from(Type.RefType refType) {
                return switch (refType) {
                    case INTEGER, LONG -> NUMBER;
                    case YMD -> DATE;
                    case YMDHMS -> DATETIME;
                    default -> TEXT;
                };
            }
        }
    }

    public record FormTree(FormTreeNode node, List<FormTreeNodeInstance> instances) {}

    public record FormTreeNode(
        Integer formElementId,
        Integer parentFormElementId,
        Integer nestedElementId,
        String name,
        Type.RefType refType,
        FormElementInputRow.InputType inputType,
        int arrayMaxSize,
        boolean required,
        List<FormTreeNode> children) {

        public boolean hasChildren() {
            return !children.isEmpty();
        }
    }

    public record FormTreeNodeInstance(
        FormTreeNode node,
        int inputIndex,
        List<FormTreeChildGroup> childGroups,
        String value) {

        public boolean hasChildren() {
            return !childGroups.isEmpty();
        }

        public boolean hasValue() {
            return value != null && !value.isEmpty();
        }

        public String inputName() {
            return buildInputName(node.nestedElementId(), inputIndex);
        }
    }

    public record FormTreeChildGroup(
        FormTreeNode node,
        List<FormTreeNodeInstance> instances) {}
}
