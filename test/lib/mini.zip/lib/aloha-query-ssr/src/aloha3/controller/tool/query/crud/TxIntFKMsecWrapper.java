package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.meta.transaction.TxAttributeIntAFK;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TxStarView;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TxIntFKMsecWrapper
    <E extends TxEntityIntFK.Msec<M>,
        M extends CoreEntity,
        F extends TxStarView.FieldOf.AndIntFK<E>,
        MF extends StarView.FieldOf<M>,
        T extends TxStarView.Read<F> >
    extends BaseMgrWrapper<T, Long, Integer> {

    private final String name;
    private final F field;
    private final TxIntFKMgr.StarView.Msec<E,M,F> mgr;

    public TxIntFKMsecWrapper(
        String name,
        F field,
        TxIntFKMgr.StarView.Msec<E,M,F> mgr ) {

        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    @Override
    public Object getMgr() {
        return this.mgr;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        String foreignEntity = mgr.foreignEntity().getClass().getSimpleName();
        int fkId = Integer.valueOf(json.getString(foreignEntity + "Id"));
        MayNullVO<StarView.Read<MF>> cores = GenericSearch.queryMasterViewByPK(foreignEntity, fkId);
        return cores.
            apply(
                (fk)->{
                    TxStarView.Write.Prepare.Builder builder = TxStarView.Write.Prepare.Builder.
                        create(
                            getFieldClass());

                    setValues(json, field, builder);
                    builder.setMandatoryValue(
                        (f)->mgr.field().unsafeFK(),
                        fk.coreRead().rowId());

                    Persist.Value<Long> ret = mgr.
                        save(
                            builder.build(),
                            fk.coreRead(),
                            DateTime.YMDHMSMSEC.now().get());
                    return ret.get();
                },
                ()->-1L);
    }

    @Override
    public
    ImmutVOs<T>
    query() {

        List<T> result = new ArrayList<>();
        queryTxs().unlessEmpty_(
            (txReads)->{
                mgr.
                    createViews(
                        (NonEmptyVOs)txReads).
                    foreach(
                        (txView)->
                            result.add((T)txView));
            });
        return ImmutVOs.create(result);
    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.unsafeFK().javaName());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public MayNullVO<T>
    queryByPK(Long id) {

        return (MayNullVO<T>)mgr.createView(id);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Long> pkIDs) {

        return (ImmutVOs<T>)mgr.createViews(
            DistinctIds.toLongIDs(pkIDs));
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs foreigns,
        Map<String, Object> params) {

        return queryByFKViews( foreigns, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKViews(
        ImmutVOs<StarView.Read<MF>> foreigns,
        Map<String, Object> params) {

        if (params.containsKey("from") && params.containsKey("to")) {
            return queryByFKAndBetween(
                foreigns,
                (DateTime.YMDHMS) params.get("from"),
                (DateTime.YMDHMS) params.get("to"));
        }
        List<T> result = new ArrayList<>();
        foreigns.foreach(
            (core)->{
                ImmutVOs<TxIntFK.Read.Msec<E>> txs = mgr.selectTxsByFK(core.coreRead());
                txs.unlessEmpty_(
                    (txReads)->{
                        mgr.
                            createViews(
                                txReads).
                            foreach(
                                (txView)->
                                    result.add((T)txView));
                    });
            });

        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByFKAndBetween(
        ImmutVOs<StarView.Read<MF>> fkViews,
        DateTime.YMDHMS from,
        DateTime.YMDHMS to) {

        List<T> result = new ArrayList<>();
        fkViews.
            foreach(
                (fk)->
                    mgr.
                        createViews(
                            fk.coreRead(),
                            from,
                            to).
                        foreach(
                            (txView)->
                                result.add((T)txView)));
        return ImmutVOs.create(result);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return queryByIntAFKViews(afkViews, afkName, params);
    }

    @SuppressWarnings({"unchecked"})
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName,
        Map<String, Object> params) {

        if (isForeignKey(afkName))
            return queryByFKs(afkViews, params);

        return (ImmutVOs<T>)afkViews.
            apply(
                (fks)->
                    ((ImmutVOs<TxAttributeIntAFK.Read>)mgr.
                        selectAttributeIntAFKs(
                            (Class) ViewMgr.getJoinColumn(name, afkName).getDeclaredClass(),
                            (NonEmptyVOs) fks.map(v -> v.coreRead()))).
                        apply(
                            (txAttrs)->
                                mgr.createViews(
                                    DistinctIds.longIDsFromRecords(
                                        txAttrs,
                                        txAttr->txAttr.getTxId())),
                            ()->ImmutVOs.emptyVOs()),
                ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }

    @Override
    public
    void
    update(
        JsonObject json) {

    }

    @Override
    public
    void
    delete(
        JsonObject json) {

    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        List<AbstractField.Member.Mandatory>  members = getMandatoryAttributeMembers(field);
        members.add(0, mgr.field().unsafeFK());
        return members;
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return getOptionalAttributeMembers(field);
    }

    @Override
    public AbstractField.Member.Mandatory getCenterMember() {
        return mgr.field().unsafeCenterMember();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }

    @Override
    public ImmutVOs<? extends Read> queryTxs() {
        return Query.select(TxIntFK.Read.Msec.createCriteria(this.field.entity()));
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

}
