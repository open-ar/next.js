package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel.ChildLongAFKOnly;
import aloha3.module.object.model.read.TxModel.ChildLongAFKOnly.FlatField;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly;
import aloha3.module.object.record.transaction.TxEntityIntFK.On;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.List;

public class TxIntFKChildLongAFKOnlyModel<
    E extends On<M>,
    M extends SealedPivot<?>,
    F extends AbstractField & Field<E>,
    CH extends ChildTxEntityLongAFKOnly.Of<E, CM>,
    CM extends TxKey.Category<?>,
    PV extends ValueObject>
    extends TxChildModel {

    private final PV parent;
    private final ChildLongAFKOnly<F, CH> model;
    private final ImmutVOs<View<FlatField<F>>> flatViews;
    private final List<Mandatory> childMembers;

    private TxIntFKChildLongAFKOnlyModel(PV parent, ChildLongAFKOnly<F, CH> model) {
        this.parent = parent;
        this.model = model;
        this.flatViews = model.toFlat();
        this.childMembers = new ArrayList();
        if (!this.flatViews.empty()) {
            View<FlatField<F>> flatFieldView = this.flatViews.firstUnlessEmpty();
            this.childMembers.add(((FlatField)flatFieldView.field()).PK());
            this.childMembers.add(((FlatField)flatFieldView.field()).AFK());
        }

    }

    private TxIntFKChildLongAFKOnlyModel(PV parent) {
        this.parent = parent;
        this.model = null;
        this.flatViews = ImmutVOs.emptyVOs();
        this.childMembers = new ArrayList();
    }

    public ChildLongAFKOnly<F, CH> getModel() {
        return this.model;
    }

    public ImmutVOs<View<FlatField<F>>> getFlatViews() {
        return this.flatViews;
    }

    public List<Mandatory> childMembers() {
        return this.childMembers;
    }

    public PV view() {
        return this.parent;
    }

    public ImmutVOs<? extends Read<CH>> children() {
        return this.model == null ? ImmutVOs.emptyVOs() : this.model.children();
    }

    public static <E extends On<M>, M extends SealedPivot<?>, F extends AbstractField & Field<E>, CH extends ChildTxEntityLongAFKOnly.Of<E, CM>, CM extends TxKey.Category<?>, PV extends aloha3.module.object.view.TxStarView.Read<F>> TxIntFKChildLongAFKOnlyModel<E, M, F, CH, CM, PV> of(ChildLongAFKOnly<F, CH> model) {
        return new TxIntFKChildLongAFKOnlyModel(model.view(), model);
    }

    public static <E extends On<M>, M extends SealedPivot<?>, F extends AbstractField & Field<E>, CH extends ChildTxEntityLongAFKOnly.Of<E, CM>, CM extends TxKey.Category<?>, PV extends OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?>> TxIntFKChildLongAFKOnlyModel<E, M, F, CH, CM, PV> of(OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?> parent, ChildLongAFKOnly<F, CH> model) {
        return new TxIntFKChildLongAFKOnlyModel(parent, model);
    }

    public static <E extends On<M>, M extends SealedPivot<?>, F extends AbstractField & Field<E>> TxIntFKChildLongAFKOnlyModel<E, M, F, ?, ?, ?> of(OneToOne<aloha3.module.object.view.TxStarView.Read<F>, ?> parent) {
        return new TxIntFKChildLongAFKOnlyModel(parent);
    }
}
