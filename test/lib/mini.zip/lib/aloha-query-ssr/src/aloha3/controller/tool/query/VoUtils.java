package aloha3.controller.tool.query;

import aloha3.module.object.view.AbstractField;

import java.util.List;

/**
 * Utility methods for VO operations.
 */
public final class VoUtils {
    private VoUtils() {
    }

    static String safeGetValue(AbstractField.Member.Mandatory<String> member) {
        try {
            return member.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static <T> List<T> emptyIfNull(List<T> list) {
        return list != null ? list : List.of();
    }

    public static String capitalize(String value) {
        if (value == null || value.isEmpty()) return "";
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    public static String decapitalize(String value) {
        if (value == null || value.isEmpty()) return "";
        return Character.toLowerCase(value.charAt(0)) + value.substring(1);
    }
}
