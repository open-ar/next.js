package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.master.RelationMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.RelationEntity;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.JsonObject;
import java.util.List;
import java.util.Map;

public class RelationMgrWrapper <
    P extends CoreEntity,
    S extends CoreEntity,
    E extends RelationEntity.Of<P,S>,
    F extends StarView.Relation.FieldOf<E>,
    T extends StarView.Relation.Read<F>>
    extends BaseMgrWrapper<T, Integer, Integer> {

    private final String name;
    private final F field;
    private final RelationMgr.StarView<P,S,E, F> mgr;

    public RelationMgrWrapper(
        String name,
        F field,
        RelationMgr.StarView<P,S,E, F> mgr ) {

        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public F getField() {
        return field;
    }

    public RelationMgr.StarView<P,S,E, F> getMgr() {
        return mgr;
    }

    @Override
    public
    boolean
    isMaster() {
        return true;
    }

    @Override
    @SuppressWarnings({"rawtypes"})
    public
    AbstractField.Member.Mandatory
    getCenterMember() {

        return mgr.field().unsafeCenterMember();
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        return mgr.
            save(
                generateView(
                    json),
                DateTime.YMDHMS.current()).
            get();
    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.unsafePivotFKMember().javaName());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public
    ImmutVOs<T>
    query() {

        return (ImmutVOs<T>)mgr.
            selectAllRelations(
                DateTime.YMDHMS.current()).
            unlessEmpty(
                (cores) ->
                    mgr.
                        createViews(
                            cores,
                            DateTime.YMDHMS.current()),
                ImmutVOs.emptyVOs());
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public MayNullVO<T>
    queryByPK(Integer id) {

        return (MayNullVO<T>)mgr.createView(id, DateTime.YMDHMS.current());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByPKs(
        List<Integer> pkIDs ) {

        return (ImmutVOs<T>)mgr.createViews(
            DistinctIds.toIntIDs(pkIDs),
            DateTime.YMDHMS.current());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByFKs(
        ImmutVOs afkViews,
        Map<String, Object> params ) {

        return queryByIntAFKs(
            afkViews,
            field.unsafePivotFKMember().javaName(),
            params);
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {
        return queryByIntAFKViews(afkViews, afkName, getToYMDHMS(params));
    }

    static 
    DateTime.YMDHMS
    getToYMDHMS(Map<String, Object> params) {
        if (params.get("to") instanceof DateTime.YMDHMS toYmdHMS) {
            return toYmdHMS;
        } else {
            return DateTime.YMDHMS.current();
        }
    }

    @SuppressWarnings(value="unchecked")
    private
    ImmutVOs<T>
    queryByIntAFKViews(
        ImmutVOs<StarView.Read> afkViews,
        String afkName,
        DateTime.YMDHMS toYMDHMS) {

        return (ImmutVOs<T>)afkViews.apply(
            (afks)->{
                if (mgr.field().unsafePivotFKMember().javaName().equals(afkName)) {
                    return mgr.createViewsByFK1(
                        afks.map(v->v.coreRead()),
                        toYMDHMS);
                } else {
                    return mgr.createViewsByFK2(
                        afks.map(v->v.coreRead()),
                        toYMDHMS);
                }
            },
            ()->ImmutVOs.emptyVOs());
    }

    @SuppressWarnings(value="unchecked")
    @Override
    public
    ImmutVOs<T>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }

    @Override
    public
    void
    update(
        JsonObject json) {

        String primaryKeyName = getCenterMember().javaName();
        Integer targetId = JsonUtils.getIntValue(
            json,
            primaryKeyName);
        if (targetId == null)
            return;
        JsonUtils.removeKey(json, primaryKeyName);

        mgr.
            createView(
                targetId,
                DateTime.YMDHMS.current()).
            unlessNull_(
                (exists)->
                    mgr.
                        save(
                            generateView(
                                exists,
                                json)));
    }

    @Override
    public
    void
    delete(
        JsonObject json) {

        Integer targetId = JsonUtils.getIntValue(json,  getCenterMember().javaName());
        if (targetId == null)
            return;
        mgr.createView(
                targetId,
                DateTime.YMDHMS.current()).
            unlessNull_(
                (exists) ->
                    mgr.
                        delete(
                            exists,
                            DateTime.YMDHMS.current()));
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(field);
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return super.getOptionalAttributeMembers(field);
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }

    @SuppressWarnings(value="unchecked")
    private
    StarView.Relation.Write.Prepare<E,F>
    generateView(
        JsonObject json ) {

        StarView.Relation.Write.Prepare.Builder<E, F> builder = StarView.Relation.Write.Prepare.Builder.
            create(
                getFieldClass());

        setValues(json, field, builder);
        return builder.build();
    }

    @SuppressWarnings(value="unchecked")
    private
    StarView.Relation.Write.Update<F>
    generateView(
        StarView.Relation.Read<F> exists,
        JsonObject json ) {

        StarView.Relation.Write.Update.Builder<E, F> builder = StarView.Relation.Write.Update.Builder.
            create(
                getFieldClass(),
                exists.relationRead(),
                DateTime.YMDHMS.current());
        setValues(json, field, builder);
        return builder.build();
    }
    @Override
    public ImmutVOs<? extends Read> queryTxs() {
        return null;
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return null;
    }

}
