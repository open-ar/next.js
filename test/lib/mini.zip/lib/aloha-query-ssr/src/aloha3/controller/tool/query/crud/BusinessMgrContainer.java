package aloha3.controller.tool.query.crud;

import aloha.module.func.business.IMasterDataMgt;
import aloha.module.func.business.ITransactionMgt;
import aloha.module.func.business.ServiceContainer;
import aloha.module.object.Type;
import aloha3.controller.tool.query.models.AlohaRecordFactory;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.master.HierarchyMgr;
import aloha3.module.function.business.master.RelationMgr;
import aloha3.module.function.business.master.TemporalMgt;
import aloha3.module.function.business.transaction.DerivedTxIntAFKMgr;
import aloha3.module.function.business.transaction.DerivedTxIntAFKMgt;
import aloha3.module.function.business.transaction.DerivedTxLongAFKMgr;
import aloha3.module.function.business.transaction.DerivedTxLongAFKMgt;
import aloha3.module.function.business.transaction.DerivedTxMgr;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.function.business.transaction.TxLongFKMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TemporalField;
import aloha3.module.object.view.TxStarView;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BusinessMgrContainer {
    @SuppressWarnings({"rawtypes"})
    public static Map<String, BaseMgrWrapper> dataMgts = new ConcurrentHashMap<>();

    public static BaseMgrWrapper
    getMasterDataMgt(String name) {

        if (name.endsWith("Id"))
            name = name.substring(0, name.length()-2);
        if (dataMgts.containsKey(name)) {
            BaseMgrWrapper baseMgrWrapper = dataMgts.get(name);
            if (baseMgrWrapper.isMaster())
                return baseMgrWrapper;
        }
        throw new RuntimeException(name);
    }

    public static BaseMgrWrapper getDataMgt(String name) {
        if (name.endsWith("Id")) {
            name = name.substring(0, name.length() - 2);
        }

        return GenericSearch.getMgrMapper(name);
    }

    @SuppressWarnings({"rawtypes"})
    public static List<AbstractField.Member.Mandatory>
    getMandatoryMembers(
        String name) {

        if (!dataMgts.containsKey(name))
            throw new RuntimeException(name);

        return dataMgts.get(name).getMandatoryMembers();
    }

    @SuppressWarnings({"rawtypes"})
    public static List<AbstractField.Member.Optional>
    getOptionalMembers(
        String name) {

        if (!dataMgts.containsKey(name))
            throw new RuntimeException(name);

        return dataMgts.get(name).getOptionalMembers();
    }

    @SuppressWarnings({"rawtypes"})
    public static <
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>>
    Type.RefType
    getMemberType(
        F field,
        String memberName) {

        if (field.unsafeCenterMember().javaName().equals(memberName))
            return field.unsafeCenterMember().getRefType();

        for (aloha3.module.object.view.Field.Member.ofStarView.Attribute attr : field.attributeMembers().get()) {
            if (attr instanceof AbstractField.Member.Mandatory) {
                if (attr.javaName().endsWith(memberName))
                    return ((AbstractField.Member.Mandatory) attr).getRefType();
            } else if (attr instanceof AbstractField.Member.Optional) {
                if (attr.javaName().endsWith(memberName))
                    return ((AbstractField.Member.Optional) attr).getRefType();
            }
        }
        throw new RuntimeException("Member Not Found by " + memberName + " at " + field.getClass().getName());
    }

    public static void
    load(
        Class<? extends Object> businessServiceClass) {

        ServiceContainer businessServiceContainer = null;
        try {
            businessServiceContainer = (ServiceContainer)
                businessServiceClass.
                    getMethod(
                        "container").
                    invoke(null);
        } catch (Exception e) {
            for (Field field : businessServiceClass.getDeclaredFields()) {
                if (!Modifier.isStatic(field.getModifiers()))
                    continue;
                if (field.getType() != ServiceContainer.class)
                    continue;
                field.setAccessible(true);
                try {
                    businessServiceContainer = (ServiceContainer) field.get(null);
                    break;
                } catch (Exception e1) {
                    throw new RuntimeException(e1);
                }
            }
        }

        if (businessServiceContainer != null)
            register(
                businessServiceContainer);
    }

    private static void
    register(
        ServiceContainer businessServiceContainer) {

        businessServiceContainer.
            allMDM().
            forEach(
                BusinessMgrContainer::register);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void
    register(IMasterDataMgt mgr) {

        if (mgr instanceof TemporalMgt.OnAttribute<?,?,?,?> tempMgr) {
            String fieldName = tempMgr.temporalField().getClass().getSimpleName();
            if (fieldName.endsWith("Field"))
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            dataMgts.put(
                AlohaRecordFactory.getTypeNameOf(tempMgr.temporalEntity()),
                new TemporalAttributeMgrWrapper(
                    fieldName,
                    (TemporalField.OfAttribute)tempMgr.temporalField(),
                    tempMgr));
        }

        if (mgr instanceof CoreMgr.StarView.ForeignCore m) {
            StarView.FieldOf.ForeignCore field = (StarView.FieldOf.ForeignCore) m.field();
            String fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field"))
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            dataMgts.put(
                fieldName,
                new CoreMgrStarViewForeignCoreWrapper(
                    fieldName,
                    field,
                    m));
        } else if (mgr instanceof CoreMgr.StarView m) {
            StarView.FieldOf field = (StarView.FieldOf) m.field();
            String fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field"))
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            dataMgts.put(
                fieldName,
                new CoreMgrStarViewWrapper(
                    fieldName,
                    field,
                    m));
        } else if (mgr instanceof RelationMgr.StarView m) {
            StarView.Relation.FieldOf field = m.field();
            String fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field"))
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            dataMgts.put(
                fieldName,
                new RelationMgrWrapper(
                    fieldName,
                    field,
                    m));
        } else {
            System.out.println("[register][BusinessMgrContainer] skip: " + mgr.getClass().getSimpleName() + "  " + mgr.getClass().getSuperclass().getName());
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    <E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends HierarchyEntity.Of<E>,
    HM extends HierarchyMgr<E, H, ?>>
    void
    register(Graph<E, F, H, HM> mgr, List<Class> types) {
        aloha3.module.function.business.master.CoreReadMgt.StarView<E, F> coreMgr = mgr.coreReadMgt();
        F field = coreMgr.field();
        String fieldName = field.getClass().getSimpleName();
        if (fieldName.endsWith("Field")) {
            fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
        }

        BaseMgrWrapper baseMgrWrapper;
        if (mgr instanceof Graph.Tree.Distinct.StarArrow) {
            ArrowTreeWrapper treeWrappper = new ArrowTreeWrapper(fieldName, field, (Graph.Tree.Distinct.StarArrow) mgr, types);
            if (dataMgts.containsKey(fieldName)) {
                baseMgrWrapper = dataMgts.get(fieldName);
                if (baseMgrWrapper instanceof CoreMgrStarViewWrapper) {
                    treeWrappper.setCoreMgr((CoreMgrStarViewWrapper) baseMgrWrapper);
                }
            }

            dataMgts.put(fieldName, treeWrappper);
        } else if (mgr instanceof Graph.Tree) {
            TreeWrapper treeWrapper = new TreeWrapper(fieldName, field, (Graph.Tree) mgr, types);
            if (dataMgts.containsKey(fieldName)) {
                baseMgrWrapper = dataMgts.get(fieldName);
                if (baseMgrWrapper instanceof CoreMgrStarViewWrapper) {
                    treeWrapper.setCoreMgr((CoreMgrStarViewWrapper) baseMgrWrapper);
                }
            }

            dataMgts.put(fieldName, treeWrapper);
        } else if (mgr instanceof Graph.Tree.Distinct) {
            DistinctTreeWrapper treeWrapper = new DistinctTreeWrapper(fieldName, field, (Graph.Tree.Distinct) mgr, types);
            if (dataMgts.containsKey(fieldName)) {
                baseMgrWrapper = dataMgts.get(fieldName);
                if (baseMgrWrapper instanceof CoreMgrStarViewWrapper) {
                    treeWrapper.setCoreMgr((CoreMgrStarViewWrapper) baseMgrWrapper);
                }
            }

            dataMgts.put(fieldName, treeWrapper);
        } else if (mgr instanceof Graph.Chain.StarArrow) {
            Graph.Chain.StarArrow graph = (Graph.Chain.StarArrow)mgr;
            ArrowChainWrapper chainWrapper = new ArrowChainWrapper(fieldName, field, (Graph.Chain.StarArrow) mgr, types);
            if (dataMgts.containsKey(fieldName)) {
                baseMgrWrapper = dataMgts.get(fieldName);
                if (baseMgrWrapper instanceof CoreMgrStarViewWrapper) {
                    chainWrapper.setCoreMgr((CoreMgrStarViewWrapper) baseMgrWrapper);
                }
            }

            dataMgts.put(fieldName, chainWrapper);
        } else if (mgr instanceof Graph.Chain.Straight) {
            StraightChainWrapper chainWrapper = new StraightChainWrapper(fieldName, field, (Graph.Chain.Straight) mgr, types);
            if (dataMgts.containsKey(fieldName)) {
                baseMgrWrapper = dataMgts.get(fieldName);
                if (baseMgrWrapper instanceof CoreMgrStarViewWrapper) {
                    chainWrapper.setCoreMgr((CoreMgrStarViewWrapper) baseMgrWrapper);
                }
            }

            dataMgts.put(fieldName, chainWrapper);
        } else if (mgr instanceof Graph.Chain) {
            ChainWrapper chainWrappper = new ChainWrapper(fieldName, field, (Graph.Chain) mgr, types);
            if (dataMgts.containsKey(fieldName)) {
                baseMgrWrapper = dataMgts.get(fieldName);
                if (baseMgrWrapper instanceof CoreMgrStarViewWrapper) {
                    chainWrappper.setCoreMgr((CoreMgrStarViewWrapper) baseMgrWrapper);
                }
            }

            dataMgts.put(fieldName, chainWrappper);
        } else {
            dataMgts.put(fieldName, new GenericGraphWrapper(fieldName, field, mgr));
        }

    }

    public static void register(ITransactionMgt mgr) {
        // System.out.println("Register: " + mgr.getClass().getName());
        // Field sumViewField;
        String fieldName;

        if (mgr instanceof TxIntFKMgr.StarView.Family.ChildIntAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxIntFKMgr.StarView.Family.ChildIntAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxIntFKMgr.StarView.Family.ChildLongAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxIntFKMgr.StarView.Family.ChildLongAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxLongFKMgr.StarView.Family.ChildIntAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxLongFKMgr.StarView.Family.ChildIntAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxLongFKMgr.StarView.Family.ChildLongAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof TxLongFKMgr.StarView.Family.ChildLongAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxIntAFKMgr.StarView.Family.ChildIntAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxIntAFKMgr.StarView.Family.ChildIntAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxIntAFKMgr.StarView.Family.ChildLongAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxIntAFKMgr.StarView.Family.ChildLongAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxLongAFKMgr.StarView.Family.ChildIntAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxLongAFKMgr.StarView.Family.ChildIntAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxLongAFKMgr.StarView.Family.ChildLongAFK m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        } else if (mgr instanceof DerivedTxLongAFKMgr.StarView.Family.ChildLongAFKOnly m) {
            registerTxFamily(m.childTx().getClass().getSimpleName(), m.childTx().getClass(), m);
        }
        // While tx-child, register both tx and child.(1)
        if (mgr instanceof TxIntFKMgr.StarView m) {
            TxStarView.FieldOf.AndIntFK field = (TxStarView.FieldOf.AndIntFK)m.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }
            dataMgts.put(fieldName, new TxIntFKWrapper(fieldName, field, m));
        } else if (mgr instanceof TxLongFKMgr.StarView m) {
            TxStarView.FieldOf.AndLongFK field = (TxStarView.FieldOf.AndLongFK)m.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }
            dataMgts.put(fieldName, new TxLongFKWrapper(fieldName, field, m));
        } else if (mgr instanceof DerivedTxMgr.StarView m) {
            TxStarView.FieldOf field = (TxStarView.FieldOf)m.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }
            dataMgts.put(fieldName, new DerivedTxWrapper(fieldName, field, m));
        } else if (mgr instanceof DerivedTxIntAFKMgr.StarView m) {
            TxStarView.FieldOf.AndIntAFK field = (TxStarView.FieldOf.AndIntAFK)m.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }
            dataMgts.put(fieldName, new DerivedTxIntAFKWrapper(fieldName, field, m));
        } else if (mgr instanceof DerivedTxLongAFKMgr.StarView m) {
            TxStarView.FieldOf.AndLongAFK field = (TxStarView.FieldOf.AndLongAFK)m.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }
            dataMgts.put(fieldName, new DerivedTxLongAFKWrapper(fieldName, field, m));
        } else {
            String var10000 = mgr.getClass().getSimpleName();
            System.out.println("[register][BusinessMgrContainer] skip: " + var10000 + "  " + mgr.getClass().getSuperclass().getName());
        }
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxIntFKMgr.StarView.Family.ChildIntAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxIntFKFamilyIntAFKWrapper(fieldName, (TxStarView.FieldOf.AndIntFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxIntFKMgr.StarView.Family.ChildIntAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxIntFKFamilyIntAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndIntFK)familyMgr.field(), childRecordType, fkRecordOfChild, null, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxIntFKMgr.StarView.Family.ChildLongAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxIntFKFamilyLongAFKWrapper(fieldName, (TxStarView.FieldOf.AndIntFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxIntFKMgr.StarView.Family.ChildLongAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxIntFKFamilyLongAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndIntFK)familyMgr.field(), childRecordType, fkRecordOfChild, familyMgr, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxLongFKMgr.StarView.Family.ChildIntAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxLongFKFamilyIntAFKWrapper(fieldName, (TxStarView.FieldOf.AndLongFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxLongFKMgr.StarView.Family.ChildIntAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxLongFKFamilyIntAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndLongFK)familyMgr.field(), childRecordType, fkRecordOfChild, null, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxLongFKMgr.StarView.Family.ChildLongAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxLongFKFamilyLongAFKWrapper(fieldName, (TxStarView.FieldOf.AndLongFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, null, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, TxLongFKMgr.StarView.Family.ChildLongAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new TxLongFKFamilyLongAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndLongFK)familyMgr.field(), childRecordType, fkRecordOfChild, null, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxIntAFKMgt.StarView.Family.ChildIntAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxIntAFKFamilyIntAFKWrapper(fieldName, (TxStarView.FieldOf.AndIntAFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxIntAFKMgt.StarView.Family.ChildIntAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxIntAFKFamilyIntAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndIntAFK)familyMgr.field(), childRecordType, fkRecordOfChild, familyMgr, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxIntAFKMgt.StarView.Family.ChildLongAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxIntAFKFamilyLongAFKWrapper(fieldName, (TxStarView.FieldOf.AndIntAFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxIntAFKMgt.StarView.Family.ChildLongAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxIntAFKFamilyLongAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndIntAFK)familyMgr.field(), childRecordType, fkRecordOfChild, familyMgr, familyMgr));
    }

    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxLongAFKMgt.StarView.Family.ChildIntAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxLongAFKFamilyIntAFKWrapper(fieldName, (TxStarView.FieldOf.AndLongAFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxLongAFKMgt.StarView.Family.ChildIntAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxLongAFKFamilyIntAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndLongAFK)familyMgr.field(), childRecordType, fkRecordOfChild, familyMgr, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxLongAFKMgt.StarView.Family.ChildLongAFK familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        Class valueTypeOfChild = typeArguments.get(2);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxLongAFKFamilyLongAFKWrapper(fieldName, (TxStarView.FieldOf.AndLongAFK)familyMgr.field(), childRecordType, fkRecordOfChild, valueTypeOfChild, familyMgr, familyMgr));
    }
    private static void registerTxFamily(String fieldName, Class childRecordType, DerivedTxLongAFKMgt.StarView.Family.ChildLongAFKOnly familyMgr) {
        List<Class> typeArguments = AlohaRecordFactory.getTypeArguments(childRecordType);
        Class upperTypeOfChild = typeArguments.get(0);
        Class fkRecordOfChild = typeArguments.get(1);
        String childName = childRecordType.getSimpleName();
        dataMgts.put(childName, new DerivedTxLongAFKFamilyLongAFKOnlyWrapper(fieldName, (TxStarView.FieldOf.AndLongAFK)familyMgr.field(), childRecordType, fkRecordOfChild, familyMgr, familyMgr));
    }

    public static void register(CRUD crudMgr, List<Class> types) throws Exception {
        Class txEntityType = crudMgr.txStarMgr().entity().getClass();
        Class txMgrType = crudMgr.txStarMgr().getClass();
        String name = txEntityType.getSimpleName();
        String fieldName;
        if (TxIntFKMgr.StarView.class.isAssignableFrom(txMgrType)) {
            TxIntFKMgr.StarView txMgr = ((TxIntFKWrapper)dataMgts.get(name)).getMgr();
            TxStarView.FieldOf.AndIntFK field = (TxStarView.FieldOf.AndIntFK)txMgr.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }

            dataMgts.put(fieldName, new TxIntFKCRUDWrapper(fieldName, field, crudMgr.variableField(), crudMgr, txMgr));
        } else if (TxLongFKMgr.StarView.class.isAssignableFrom(txMgrType)) {
            TxLongFKMgr.StarView txMgr = ((TxLongFKWrapper)dataMgts.get(name)).getMgr();
            TxStarView.FieldOf.AndLongFK field = (TxStarView.FieldOf.AndLongFK)txMgr.field();
            fieldName = field.getClass().getSimpleName();
            if (fieldName.endsWith("Field")) {
                fieldName = fieldName.substring(0, fieldName.length() - "Field".length());
            }

            dataMgts.put(fieldName, new TxLongFKCRUDWrapper(fieldName, field, crudMgr.variableField(), crudMgr, txMgr));
        }

    }

    public static void register(CRUD.Family crudMgr, List<Class> types) {
        Class txEntityType = crudMgr.txStarMgr().entity().getClass();
        Class txMgrType = crudMgr.txStarMgr().getClass();
        Class txChildType = crudMgr.childTx().getClass();
        List<Class> txChildParams = AlohaRecordFactory.getTypeArguments(txChildType);
        Class childAfkRecordType = txChildParams.get(1);
        Class childValueType = txChildParams.size() > 2 ? txChildParams.get(2) : null;
        String txChildName = txChildType.getSimpleName();
        String name = txEntityType.getSimpleName();
        if (TxIntFKMgr.StarView.class.isAssignableFrom(txMgrType)) {
            TxIntFKMgr.StarView txMgr = null;
            BaseMgrWrapper baseMgrWrapper = dataMgts.get(name);
            if (baseMgrWrapper instanceof TxIntFKWrapper) {
                txMgr = ((TxIntFKWrapper)baseMgrWrapper).getMgr();
            } else if (baseMgrWrapper instanceof TxIntFKCRUDWrapper) {
                txMgr = ((TxIntFKCRUDWrapper)baseMgrWrapper).getTxMainMgr();
            } else {
                System.out.println("Unknown Type : " + baseMgrWrapper.getClass().getSimpleName());
            }

            if (txMgr.field() instanceof TxStarView.FieldOf.AndIntFK field) {
                String fieldName = field.getClass().getSimpleName();
                if (fieldName.endsWith("Field")) {
                    fieldName.substring(0, fieldName.length() - "Field".length());
                }
                if (crudMgr instanceof CRUD.Family.ChildIntAFK) {
                    dataMgts.put(txChildName, new TxIntFKFamilyIntAFKCRUDWrapper(txChildName, field, crudMgr.variableField(), txChildType, childAfkRecordType, childValueType, (CRUD.Family.ChildIntAFK) crudMgr, txMgr));
                } else if (crudMgr instanceof CRUD.Family.ChildLongAFK) {
                    dataMgts.put(txChildName, new TxIntFKFamilyLongAFKCRUDWrapper(txChildName, field, crudMgr.variableField(), txChildType, childAfkRecordType, childValueType, (CRUD.Family.ChildLongAFK) crudMgr, txMgr));
                } else if (crudMgr instanceof CRUD.Family.ChildIntAFKOnly) {
                    dataMgts.put(txChildName, new TxIntFKFamilyIntAFKOnlyCRUDWrapper(txChildName, field, crudMgr.variableField(), txChildType, childAfkRecordType, (CRUD.Family.ChildIntAFKOnly) crudMgr, txMgr));
                } else if (crudMgr instanceof CRUD.Family.ChildLongAFKOnly) {
                    BaseMgrWrapper var14 = dataMgts.put(txChildName, new TxIntFKFamilyLongAFKOnlyCRUDWrapper(txChildName, field, crudMgr.variableField(), txChildType, childAfkRecordType, (CRUD.Family.ChildLongAFKOnly) crudMgr, txMgr));
                } else {
                    System.out.println("Unknown Type : " + txChildType.getSimpleName());
                }
            } else {
                System.out.println("Unknown Type : " + txChildType.getSimpleName());
            }
        } else {
            System.out.println("Unknown Type : " + txChildType.getSimpleName());
        }

    }
}
