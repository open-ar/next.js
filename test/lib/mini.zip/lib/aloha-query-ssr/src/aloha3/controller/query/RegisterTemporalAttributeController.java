package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutValues;
import aloha.module.object.MayNullValue;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.meta.Enum.Bool;
import aloha3.controller.tool.meta.StringUtil;
import aloha3.module.object.view.View;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import java.util.HashSet;
import java.util.Set;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;
import static aloha3.controller.tool.meta.MappingConst.ROOT_ID;
import static aloha3.controller.tool.meta.MappingConst.YMD;

public class RegisterTemporalAttributeController extends AbstractController {

    public static final RegisterTemporalAttributeController INSTANCE = new RegisterTemporalAttributeController();
    public static final String MAIN_TEMPLATE = "registerTemporalAttribute.html";
    public static final String COMPONENTS_NAV_MENU_HTML = "_components/nav-menu-temporal.html";

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Temporal Attribute";
    }

    @Override
    protected String getNavMenuTemplate() {
        return COMPONENTS_NAV_MENU_HTML;
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    public static void 
    handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST");
        request.unlessNull_(
            PIVOT,
            pivot ->
                AlohaCRUD.saveTemporalStarView(
                    pivot,
                    request.keyValues(),
                    container()));
        response.redirectTo(request.target());
    }

    public static void 
    handlePut(
        Request request,
        Response response) {
        
        System.out.println("handle Put");
        request.unlessNull_(
            PIVOT, ID,
            (pivot, id) ->
                AlohaCRUD.updateTemporalStarView(
                    Integer.parseInt(id),
                    request.keyValues(),
                    pivot,
                    container()));
        response.redirectTo(request.target());
    }

    public static void 
    handleDelete(
        Request request,
        Response response) {
        
        System.out.println("handle Delete");
        request.unlessNull_(
            PIVOT, ID, ROOT_ID,
            (pivot, id, rootId) ->
                AlohaCRUD.deleteStarView(
                    Integer.parseInt(id),
                    pivot,
                    MayNullValue.of(Integer.parseInt(rootId)),
                    container()));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT, ROOT_ID,
                (pivot, rootId) ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        Integer.valueOf(rootId),
                        request.map(ID, Integer::valueOf),
                        request.flatMap(YMD, StringUtil::toYMD)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder.
                add("pivot", request.unlessNull(PIVOT, "")).
                add("views", AlohaCRUD.starViews(request.unlessNull(PIVOT, ""), container()));
        }
    }

    private static
    String
    renderMainContent(
        String pivot,
        OperationType operation,
        Integer rootId,
        MayNullValue<Integer> idMayNull,
        MayNullValue<DateTime.YMD> asOf) {
        
        final var viewInfo = AlohaMeta.viewInfoTemporalAttribute(pivot, container());
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ROOT_ID, rootId).
            add(YMD, asOf.unlessNull(v -> v.decimal(), 0)).
            add(ID, idMayNull.unlessNull(v -> v, 0)).
            add("viewSchemas", viewInfo).
            add("views", AlohaCRUD.temporalViews(pivot, rootId, asOf, container())).
            add("views_fk",
                getFkPivot(viewInfo).unlessNull(
                    fkPivot ->
                        AlohaCRUD.starViews(fkPivot, container()),
                    ImmutVOs.emptyVOs()));

        getAfkPivots(viewInfo).foreach(
            afkPivot -> {
                var views = AlohaCRUD.starViews(afkPivot, container());
                // e.g views_afk_productId
                context.add("views_afk_" + StringUtil.decapitalize(afkPivot) + "Id", views);
            });

        AlohaCRUD.starView(rootId, pivot, container()).unlessNull_(
            view ->
                context.add("view_of_root_id", view));
        idMayNull.unlessNull_(id ->
            AlohaCRUD.
                temporalViewById(id, pivot, rootId, asOf, container()).
                unlessNull_(
                    view ->
                        context.add("view_of_id", view)));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static
    MayNullValue<String>
    getFkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
            view ->
                view.
                    mandatoryValue(f->f.IsFK) == Bool.TRUE).
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static
    MayNullValue<String>
    getAfkPivot(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            find(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE). // グラフは無視
            apply(
                view ->
                    MayNullValue.of(
                        view.optionalValue(f->f.Foreign).assertNonNull()),
                MayNullValue::nullInstance);
    }

    private static ImmutValues<String>
    getAfkPivots(ImmutVOs<View<AlohaMeta.ViewSchemaField>> viewInfo) {

        return viewInfo.
            filter(
                view ->
                    view.mandatoryValue(f->f.IsAFK) == Bool.TRUE &&
                        view.optionalValue(f->f.Foreign).unlessNull(v -> !"Graph".equals(v), true)).
            toValues(view->
                view.optionalValue(f->f.Foreign).assertNonNull());
    }
}

