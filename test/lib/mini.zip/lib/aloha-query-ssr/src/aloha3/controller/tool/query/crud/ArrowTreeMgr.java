package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.view.StarView;

import java.util.ArrayList;
import java.util.List;

public class ArrowTreeMgr<
        E extends CoreEntity,
        F extends StarView.FieldOf<E>,
        H extends HierarchyEntity.Of.Tree<E>,
        HF extends StarView.Hierarchy.FieldOf<H>> {

    private final Graph.Tree.Distinct.StarArrow<E,H, F, HF> masterDataMgt;

    public ArrowTreeMgr(
        Graph.Tree.Distinct.StarArrow<E,H, F, HF> masterDataMgt) {

        this.masterDataMgt = masterDataMgt;
    }

    public
    List<Tree.StarArrow<F, HF>>
    selectAllRoots() {

        return selectAllRoots(
            DateTime.YMDHMS.current());
    }

    public
    List<Tree.StarArrow<F, HF>>
    selectAllRoots(
        DateTime.YMDHMS at) {

        List<Tree.StarArrow<F, HF>> nodes = new ArrayList<>();
        GraphMgr.getAllGraphs().foreach(
            (coreGraph)->
                masterDataMgt.
                    selectGraph(
                        coreGraph.rowId(),
                        DateTime.YMDHMS.current()).
                    unlessNull_(
                        (graph)-> {
                            try {
                                masterDataMgt.
                                    createModel(
                                        graph,
                                        at).
                                    unlessNull_(
                                        (model) ->
                                            nodes.add(model));
                            }catch (Exception e) {
                                //do nothing
                            }
                        })
        );
        return nodes;
    }

    private
    ImmutVOs<Core.Read<E>>
    selectAllCores(
        DateTime.YMDHMS at ) {

        return masterDataMgt.
            coreReadMgt().
            selectAllCores(
                at);
    }

}
