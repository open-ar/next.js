package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxIntFKChildIntAFKOnlyModel;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.conceptual.transaction.CRUD.Family.ChildIntAFKOnly;
import aloha3.module.function.business.transaction.TxIntFKMgr.StarView;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.TxEntityIntFK.On;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.coc.generic.Bridge;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.TxStarView.FieldOf.AndIntFK;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class TxIntFKFamilyIntAFKOnlyCRUDWrapper<
    X extends On<FK> & MakeCancellable<X>,
    F extends AndIntFK<X>,
    M extends StarView<X, FK, F>,
    FK extends Pivot<?>,
    VX extends TxEntityLongFK.On<X>,
    VF extends AndLongFK<VX>,
    CH extends ChildTxEntityIntAFKOnly.Of<Bridge<X>, CM>,
    CM extends SealedPivot<?>,
    T extends TxIntFKChildIntAFKOnlyModel<X, FK, F, ?, CM, OneToOne<Read<F>, Read<VF>>>>
    extends BaseMgrWrapper<T, Long, Integer>
    implements TxFamilyCRUDWrapper {

    private final String name;
    private final F field;
    private final VF vField;
    private final ChildIntAFKOnly<X, F, M, VX, VF, CH> mgr;
    private final M txMainMgr;
    private final String childAfkName;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;

    public TxIntFKFamilyIntAFKOnlyCRUDWrapper(String name, F field, VF vField, Class<CH> childRecord, Class<CM> childAfkRecordType, ChildIntAFKOnly<X, F, M, VX, VF, CH> mgr, M txMainMgr) {
        this.name = name;
        this.field = field;
        this.vField = vField;
        this.mgr = mgr;
        this.childRecord = childRecord;
        this.childAfkRecordType = childAfkRecordType;
        this.txMainMgr = txMainMgr;
        this.childAfkName = childAfkRecordType.getSimpleName() + "Id";
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Object getMgr() {
        return this.txMainMgr;
    }

    public Object register(JsonObject json) {
        String foreignEntity = this.txMainMgr.foreignEntity().getClass().getSimpleName();
        int fkId = Integer.parseInt(json.getString(foreignEntity + "Id"));
        MayNullVO<aloha3.module.object.record.master.read.meta.Read<FK>> foreign = GenericSearch.queryPivotReadByPK(foreignEntity, fkId);
        if (foreign.apply((v) -> {
            return false;
        }, () -> {
            return true;
        })) {
            return -1L;
        } else {
            Prepare<X, F> fixAttribures = this.setValues(json, this.field, Builder.create(this.field.getClass())).build();
            Prepare<VX, VF> variableAttr = this.setValues(json, this.vField, Builder.create(this.vField.getClass())).build();
            JsonArray items = json.getJsonArray("child");
            List<aloha3.module.object.record.master.read.meta.Read<CM>> lineItemsMore = new ArrayList();

            for(int i = 0; i < items.size(); ++i) {
                JsonObject item = items.getJsonObject(i);
                int afkId = Integer.parseInt(item.getString(this.afkAttributeName()));
                MayNullVO<aloha3.module.object.record.master.read.meta.Read<CM>> afk = GenericSearch.queryPivotReadByPK(this.afkEntityName(), afkId);
                lineItemsMore.add(afk.mustNonNull());
            }

            aloha3.module.object.record.master.read.meta.Read<CM> first = lineItemsMore.get(0);
            aloha3.module.object.record.master.read.meta.Read[] others;
            if (lineItemsMore.size() > 1) {
                others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new aloha3.module.object.record.master.read.meta.Read[0]);
            } else {
                others = new aloha3.module.object.record.master.read.meta.Read[0];
            }

            return this.register(foreign.mustNonNull(), fixAttribures, variableAttr, first, others);
        }
    }

    public void update(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            Prepare<VX, VF> variableAttr = this.setValues(json, this.vField, Builder.create(this.vField.getClass())).build();
            JsonArray items = json.getJsonArray("child");
            List<aloha3.module.object.record.master.read.meta.Read<CM>> lineItemsMore = new ArrayList();

            for(int i = 0; i < items.size(); ++i) {
                JsonObject item = items.getJsonObject(i);
                int afkId = Integer.valueOf(item.getString(this.afkAttributeName()));
                MayNullVO<aloha3.module.object.record.master.read.meta.Read<CM>> afk = GenericSearch.queryPivotReadByPK(this.afkEntityName(), afkId);
                lineItemsMore.add(afk.mustNonNull());
            }

            aloha3.module.object.record.master.read.meta.Read<CM> first = lineItemsMore.get(0);
            aloha3.module.object.record.master.read.meta.Read[] others;
            if (lineItemsMore.size() > 1) {
                others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new aloha3.module.object.record.master.read.meta.Read[0]);
            } else {
                others = new aloha3.module.object.record.master.read.meta.Read[0];
            }

            this.update(targetId, variableAttr, first, others);
        }
    }

    public void delete(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.delete(targetId);
        }
    }

    public MayNullVO<T> queryByPK(Long id) {
        return (MayNullVO)this.txMainMgr.selectTx(id).apply((tx) -> {
            return this.mgr.readParent(tx).apply((parent) -> {
                return (MayNullVO)this.mgr.readChildren(tx).apply((model) -> {
                    return MayNullVO.of(TxIntFKChildIntAFKOnlyModel.of((OneToOne)parent, (TxModel.ChildIntAFKOnly)model));
                }, MayNullVO::nullInstance);
            }, MayNullVO::nullInstance);
        }, MayNullVO::nullInstance);
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxIntFK.Read.createCriteria(this.field.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return queryModels((ImmutVOs)queryTxs());
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : this.queryModels(this.txMainMgr.selectTxs(DistinctIds.toLongIDs(pkIDs)));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return fkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByFKViews(toCores(fkViews), params);
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<FK>> fkViews, Map<String, Object> params) {
        return params.containsKey("from") && params.containsKey("to") ? this.queryByFKAndBetween(fkViews, (YMDHMS)params.get("from"), (YMDHMS)params.get("to")) : (ImmutVOs)fkViews.apply((fks) -> {
            return this.queryModels(this.txMainMgr.selectTxsByFK(fks));
        }, ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryByFKAndBetween(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<FK>> fkViews, YMDHMS from, YMDHMS to) {
        List<T> result = new ArrayList();
        fkViews.foreach((fk) -> {
            result.addAll(this.queryModels(this.txMainMgr.createViews(fk, from, to).map(Read::txIntFKReadOf)).asList());
        });
        return ImmutVOs.create(result);
    }

    private ImmutVOs<T> queryModels(ImmutVOs<TxIntFK.Read<X>> txList) {
        List<T> result = new ArrayList();
        txList.unlessEmpty_((txs) -> {
            this.mgr.parentMgr().reads(txs, YMDHMS.current()).foreach((parent) -> {
                result.add(
                    (T)this.mgr.readChildren(((Read)parent.left).unsafeTx()).apply(
                        model -> 
                            TxIntFKChildIntAFKOnlyModel.of(
                                (OneToOne)parent, 
                                (TxModel.ChildIntAFKOnly)model), 
                        () -> TxIntFKChildIntAFKOnlyModel.of(parent)));
            });
        });
        return ImmutVOs.create(result);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return afkName.equals(this.txMainMgr.foreignEntity().getPrimaryKeyColumn().getJavaName()) ? this.queryByFKViews(afkViews, params) : this.queryByIntAFKViews(toCores(afkViews), afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read> afkViews, String afkName, Map<String, Object> params) {
        AlohaColumn afkColumn = ViewMgr.getColumn(this.name, afkName);
        if (afkColumn != null) {
            return TxFamilyQuery.queryByIntAFKs(toCores(afkViews), afkColumn, this.txMainMgr, this);
        } else {
            AlohaColumn afkColumnOfChild = ViewMgr.getColumnOfChild(this.name, afkName);
            return afkColumnOfChild != null ? TxFamilyQuery.filterByIntAFKViewsOfChild(this.query(), toCores(afkViews), afkName) : ImmutVOs.emptyVOs();
        }
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return TxFamilyQuery.queryByLongAFKs(toTxs(afkViews), ViewMgr.getColumn(this.name, afkName), this.txMainMgr, this);
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((AndIntFK)this.txMainMgr.field()).unsafeFK());
        members.addAll(this.getMandatoryAttributeMembers(this.vField));
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        List<Optional> members = this.getOptionalAttributeMembers(this.field);
        members.addAll(this.getOptionalAttributeMembers(this.vField));
        return members;
    }

    public Mandatory getCenterMember() {
        return ((AndIntFK)this.txMainMgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    public boolean isCRUD() {
        return true;
    }

    public boolean isFamily() {
        return true;
    }

    public String itemName() {
        return this.childRecord.getSimpleName();
    }

    public String afkEntityName() {
        return this.childAfkRecordType.getSimpleName();
    }

    public String afkAttributeName() {
        return this.childAfkName;
    }

    private long register(aloha3.module.object.record.master.read.meta.Read<FK> foreign, Prepare<X, F> fixAttribures, Prepare<VX, VF> variableAttr, aloha3.module.object.record.master.read.meta.Read<CM> atLeastOneLineItem, aloha3.module.object.record.master.read.meta.Read<CM>... lineItemsMore) {
        Value<? extends aloha3.module.object.record.transaction.read.meta.Read<X>> value = ChildIntAFKOnly.create(this.mgr, fixAttribures, (txMgr, txTime) -> {
            return this.txMainMgr.create(foreign, txTime);
        }, variableAttr, NonEmptyVOs.of(atLeastOneLineItem, lineItemsMore));
        return value.get().getTxId();
    }

    private long update(Long id, Prepare<VX, VF> variableAttr, aloha3.module.object.record.master.read.meta.Read<CM> atLeastOneLineItem, aloha3.module.object.record.master.read.meta.Read<CM>... lineItemsMore) {
        return this.txMainMgr.createView(id).apply(
            view ->
                this.modify(TxStarView.Read.txIntFKReadOf(view), variableAttr, atLeastOneLineItem, lineItemsMore),
            () -> -1L);
    }

    private long modify(TxIntFK.Read<X> cart, Prepare<VX, VF> variableAttr, aloha3.module.object.record.master.read.meta.Read<CM> atLeastOneLineItem, aloha3.module.object.record.master.read.meta.Read<CM>... lineItemsMore) {
        return ChildIntAFKOnly.update(this.mgr, cart, variableAttr, NonEmptyVOs.of(atLeastOneLineItem, lineItemsMore), YMDHMS.current()).get();
    }

    private void delete(Long id) {
        MayNullVO var10000 = this.txMainMgr.selectTx(id);
        ChildIntAFKOnly var10001 = this.mgr;
        Objects.requireNonNull(var10001);
        var10000.unlessNull_(v->var10001.delete((aloha3.module.object.record.transaction.read.meta.Read)v));
    }

    public String parentName() {
        return this.field.entity().getClass().getSimpleName();
    }

    public ImmutVOs queryParents() {
        List result = new ArrayList();
        ImmutVOs<aloha3.module.object.record.master.read.meta.Read<FK>> foreigns = GenericSearch.queryPivotReads(this.txMainMgr.foreignEntity().getClass().getSimpleName(), null);
        foreigns.unlessEmpty_((fks) -> {
            ImmutVOs<TxIntFK.Read<X>> txs = this.txMainMgr.selectTxsByFK(fks);
            txs.foreach((tx) -> {
                MayNullVO var10000 = this.txMainMgr.createView(tx.getTxId());
                Objects.requireNonNull(result);
                var10000.unlessNull_(result::add);
            });
        });
        return ImmutVOs.create(result);
    }
}
