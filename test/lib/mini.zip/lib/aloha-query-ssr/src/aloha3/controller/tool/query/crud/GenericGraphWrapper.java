package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.master.HierarchyMgr;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK.Of;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.StarView.FieldOf;
import aloha3.module.object.view.StarView.Read;
import aloha3.module.object.view.StarView.Write.Prepare;
import aloha3.module.object.view.StarView.Write.Prepare.Builder;
import aloha3.module.object.view.StarView.Write.Update;

import javax.json.JsonObject;
import java.util.List;
import java.util.Map;

public class GenericGraphWrapper<
    E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>,
    H extends HierarchyEntity<E>,
    HM extends HierarchyMgr<E, H, ?>,
    T extends Read<F>>
    extends BaseMgrWrapper<T, Integer, Integer> {
    private final String name;
    private final F field;
    private final Graph<E, F, H, HM> mgr;

    public GenericGraphWrapper(String name, F field, Graph<E, F, H, HM> mgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public boolean isMaster() {
        return true;
    }

    public Mandatory getCenterMember() {
        return ((FieldOf)this.mgr.coreReadMgt().field()).unsafeCenterMember();
    }

    public void registerRoot() {
    }

    public void addNode() {
    }

    public void modifyNode() {
    }

    public void removeNode() {
    }

    public void queryTree() {
    }

    @Override
    public Object getMgr() {
        return this.mgr.coreMgr();
    }

    public Object register(JsonObject json) {
        Value<Integer> id = this.mgr.save(this.generateView(json), YMDHMS.current());
        return id.get();
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)this.mgr.coreReadMgt().selectAllCores(YMDHMS.current()).unlessEmpty((cores) -> {
            return this.mgr.coreReadMgt().createViews(cores, YMDHMS.current());
        }, ImmutVOs.emptyVOs());
    }

    public MayNullVO<T> queryByPK(Integer id) {
        return (MayNullVO<T>) this.mgr.coreReadMgt().createView(id, YMDHMS.current());
    }

    public ImmutVOs<T> queryByPKs(List<Integer> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : (ImmutVOs<T>) this.mgr.coreReadMgt().createViews(DistinctIds.toIntIDs(pkIDs), YMDHMS.current());
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs afkViews, Map<String, Object> params) {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<Read> afkViews, String afkName) {
        return (ImmutVOs)afkViews.apply((afks) -> {
            AlohaColumn referenceColumn = ViewMgr.getJoinColumn(this.name, afkName);
            ImmutVOs mayEmptyCores;
            if (Of.class.isAssignableFrom(referenceColumn.getDeclaredClass())) {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOfFixedAttribute((NonEmptyVOs)afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            } else {
                mayEmptyCores = this.mgr.coreReadMgt().selectCoresOf((NonEmptyVOs)afks.map((v) -> {
                    return v.coreRead();
                }), referenceColumn.getDeclaredClass(), YMDHMS.current());
            }

            return (ImmutVOs)mayEmptyCores.unlessEmpty((cores) -> {
                return this.mgr.coreReadMgt().createViews(DistinctIds.intIDsFromRecords(
                        (NonEmptyVOs)cores,
                        r->((Core.Read)r).coreId()), YMDHMS.current());
            }, ImmutVOs.emptyVOs());
        }, ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        throw new IllegalStateException();
    }

    public void update(JsonObject json) {
        String primaryKeyName = this.getCenterMember().javaName();
        Integer targetId = JsonUtils.getIntValue(json, primaryKeyName);
        if (targetId != null) {
            JsonUtils.removeKey(json, primaryKeyName);
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((exists) -> {
                this.mgr.save(this.generateView(exists, json));
            });
        }
    }

    public void delete(JsonObject json) {
        Integer targetId = JsonUtils.getIntValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.mgr.coreReadMgt().createView(targetId, YMDHMS.current()).unlessNull_((view) -> {
                this.mgr.delete(view, YMDHMS.current());
            });
        }
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        return super.getMandatoryAttributeMembers(this.field);
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    private Prepare<E, F> generateView(JsonObject json) {
        Builder<E, F> builder = Builder.create(this.getFieldClass());
        this.setValues(json, this.field, builder);
        return builder.build();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    private Update<F> generateView(Read<F> exists, JsonObject json) {
        Update.Builder<E, F> builder = Update.Builder.create(exists, YMDHMS.current());
        this.setValues(json, this.field, builder);
        return builder.build();
    }
}
