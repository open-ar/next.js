package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DerivedTxIntAFKChildLongAFKModel<
    E extends DerivedTxEntityIntAFK<?, X, M>,
    X extends SealedTxParent<?>,
    M extends aloha3.module.object.record.master.spec.CoreEntity,
    F extends TxStarView.FieldOf.AndIntAFK<E>,
    CHT extends ChildTxEntityLongAFK.Of<E,CM,T>,
    CM extends TxKey.Category<?>,
    T extends Comparable<? super T>,
    PV extends ValueObject>
    extends TxChildModel {

    private final PV parent;
    private final TxModel.ChildLongAFK<F, CHT> model;
    private final ImmutVOs<View<TxModel.ChildLongAFK.FlatField<F, T>>> flatViews;
    private final List<AbstractField.Member.Mandatory> childMembers;

    private DerivedTxIntAFKChildLongAFKModel(
        PV parent,
        TxModel.ChildLongAFK<F, CHT> model) {
        // ChildLongAFK<F, CHT>

        this.parent = parent;
        this.model = model;

        flatViews = TxModel.ChildLongAFK.toFlat(model);
        childMembers = new ArrayList<>();
        if (!flatViews.empty()) {
            View<TxModel.ChildLongAFK.FlatField<F, T>> flatFieldView = flatViews.firstUnlessEmpty();
            childMembers.add(
                flatFieldView.field().PK());
            childMembers.add(
                flatFieldView.field().AFK());
            childMembers.add(
                flatFieldView.field().Attribute());
        }
    }

    public TxModel.ChildLongAFK<F, CHT> getModel() {
        return model;
    }

    public ImmutVOs<View<TxModel.ChildLongAFK.FlatField<F, T>>> getFlatViews() {
        return flatViews;
    }

    public
    List<AbstractField.Member.Mandatory>
    childMembers() {
        return childMembers;
    }

    public
    List<AbstractField.Member.Optional>
    childOptionalMembers() {
        return Collections.EMPTY_LIST;
    }

    public
    PV
    view() {
        return parent;
    }

    public
    ImmutVOs<? extends Read<CHT>>
    children() {
        return model.children();
    }

    public static <
    E extends DerivedTxEntityIntAFK<?, X, M>,
    X extends SealedTxParent<?>,
    M extends aloha3.module.object.record.master.spec.CoreEntity,
    F extends TxStarView.FieldOf.AndIntAFK<E>,
    CH extends ChildTxEntityLongAFK.Of<E,CM,CV>,
    CM extends TxKey.Category<?>,
    CV extends Comparable<? super CV>,
    PV extends TxStarView.Read<F>>
    DerivedTxIntAFKChildLongAFKModel<E,X,M,F,CH,CM,CV, PV>
    of(
        TxModel.ChildLongAFK<F, CH> model) {

        return new DerivedTxIntAFKChildLongAFKModel( model.view(), model ) ;
    }

    public static <
    E extends DerivedTxEntityIntAFK<?, X, M>,
    X extends SealedTxParent<?>,
    M extends aloha3.module.object.record.master.spec.CoreEntity,
    F extends TxStarView.FieldOf.AndIntAFK<E>,
    CH extends ChildTxEntityLongAFK.Of<E,CM,CV>,
    CM extends TxKey.Category<?>,
    CV extends Comparable<? super CV>,
    PV extends OneToOne<TxStarView.Read<F>, ?>>
    DerivedTxIntAFKChildLongAFKModel<E,X,M,F,CH,CM,CV, PV>
    of(
        OneToOne<TxStarView.Read<F>, ?> parent,
        TxModel.ChildLongAFK<F, CH> model) {

        return new DerivedTxIntAFKChildLongAFKModel( parent, model ) ;
    }

}