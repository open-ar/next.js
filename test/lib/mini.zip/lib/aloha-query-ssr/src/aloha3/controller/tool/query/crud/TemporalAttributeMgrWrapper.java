package aloha3.controller.tool.query.crud;

import aloha.mapping.read.IAttributeCondition;
import aloha.module.Assert;
import aloha.module.func.Func;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.record.master.coc.SealedHistory;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.dml.hidden.Distinct;
import aloha3.dml.master.Select;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.master.PivotReadMgtUnsafe;
import aloha3.module.function.business.master.TemporalMgt;
import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.meta.master.Attribute;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Isomorphic;
import aloha3.module.object.view.TemporalField;
import aloha3.module.object.view.TemporalView;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class TemporalAttributeMgrWrapper <
    E extends SealedPivot<?> & SealedHistory,
    T extends Comparable<? super T>,
    A extends AttributeEntity.Cancellable.Temporal<E,T>,
    F extends TemporalField.OfAttribute<A,T>>
    extends BaseMgrWrapper<TemporalView.Read<F>, Integer, Integer> {

    private final String name;
    private final F field;
    private final TemporalMgt.OnAttribute<E,T,A,F> mgr;

    public TemporalAttributeMgrWrapper(
        String name,
        F field,
        TemporalMgt.OnAttribute<E,T,A,F> mgr) {

        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public F getField() {
        return field;
    }

    public TemporalMgt.OnAttribute<E,T,A,F> getMgr() {
        return mgr;
    }

    @Override
    public
    boolean
    isMaster() {
        return true;
    }

    @Override
    @SuppressWarnings({"rawtypes"})
    public
    AbstractField.Member.Mandatory
    getCenterMember() {

        return mgr.temporalField().TemporalRootKey;
    }

    @Override
    public
    Object
    register(
        JsonObject json) {

        return mgr.
            save(generateView(json));
    }

    public
    boolean
    isForeignKey(String name) {
        return name.equals(field.TemporalRootKey.javaName());
    }

    @Override
    public
    ImmutVOs<TemporalView.Read<F>>
    query() {

        return Query.
            select(
                Attribute.Read.
                    createComparableCriteria(
                        this.field.entity())).
            unlessEmpty(
                attributes->
                    Select.excludeCancel(
                        (NonEmptyVOs) attributes, // TODO compile err if no cast
                        DateTime.YMDHMS.current()).
                    unlessEmpty(exists->
                        mgr.createTemporalViews(
                            (NonEmptyVOs)exists, // TODO compile err if no cast
                            DateTime.YMD.today())));
    }
    @Override
    public
    MayNullVO<TemporalView.Read<F>>
    queryByPK(Integer id) {

        return Func.apply(
            Attribute.Read.
                createComparableCriteria(
                    this.field.entity()),
            criteria->
                criteria.
                    unsafeAnd(
                        this.field.entity().column().PK(),
                        IAttributeCondition.OPERATOR.EQUAL,
                        id),
            criteria->
                Query.
                    unique(criteria).
                    unlessNull(
                        attribute->
                            Assert.mustUnique(
                                mgr.createTemporalViews(
                                    NonEmptyVOs.of(attribute),
                                    DateTime.YMD.today())),
                        MayNullVO.nullInstance()));
    }
    @Override
    public
    ImmutVOs<TemporalView.Read<F>>
    queryByPKs(
        List<Integer> pkIDs ) {

        return Func.apply(
            Attribute.Read.
                createComparableCriteria(
                    this.field.entity()),
            criteria->
                criteria.unsafeAndInts(
                    this.field.entity().column().PK(),
                    DistinctIds.toIntIDs(pkIDs)),
            criteria->
                Query.
                    select(criteria).
                    unlessEmpty(
                        attributes->
                            mgr.createTemporalViews(
                                attributes,
                                DateTime.YMD.today())));
    }
    @Override
    public
    ImmutVOs<TemporalView.Read<F>>
    queryByFKs(
        ImmutVOs afkViews,
        Map<String, Object> params ) {

        return queryByIntAFKs(
            afkViews,
            field.entity().column().FK().getJavaName(),
            params);
    }
    @Override
    public
    ImmutVOs<TemporalView.Read<F>>
    queryByIntAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        return afkViews.unlessEmpty(
            nonEmpty->
                queryByIntFKViews(
                    (NonEmptyVOs<Isomorphic.StarView.Read<?>>)nonEmpty,
                    afkName));
    }
    private
    ImmutVOs<TemporalView.Read<F>>
    queryByIntFKViews(
        NonEmptyVOs<Isomorphic.StarView.Read<?>> fkViews,
        String fkName) {

        Assert.mustTrue(
            fkName.equals(this.field.entity().column().FK().getJavaName()),
            "fkName=" + fkName +
                " but Attribute FK=" +
                    this.field.entity().column().FK().getJavaName());

        return Func.apply(
            Attribute.Read.
                createComparableCriteria(
                    this.field.entity()),
            criteria->
                criteria.unsafeAndInts(
                    this.field.entity().column().FK(),
                    Distinct.intIDs(
                        fkViews,
                        fkView->fkView.pivotRead().rowId())),
            criteria->
                Query.
                    select(criteria).
                    unlessEmpty(
                        attributes->
                            mgr.createTemporalViews(
                                attributes,
                                DateTime.YMD.today())));
    }
    @Override
    public
    ImmutVOs<TemporalView.Read<F>>
    queryByLongAFKs(
        ImmutVOs afkViews,
        String afkName,
        Map<String, Object> params) {

        throw new IllegalCallerException();
    }
    @Override
    public
    void
    update(
        JsonObject json) {

        String primaryKeyName = getCenterMember().javaName();
        Integer targetId = JsonUtils.getIntValue(
            json,
            primaryKeyName);
        if (targetId == null)
            return;
        JsonUtils.removeKey(json, primaryKeyName);

        Func.accept(
            createViewOf(targetId).mustNonNull(),
            current->
                Func.accept(
                    TemporalView.Write.Update.Builder.
                        create(
                            getFieldClass(),
                            current,
                            DateTime.YMDHMS.current()),
                    builder->
                        Func.accept(
                            JsonUtils.getYMDHMSValue(
                                json,
                                getMgr().temporalField().TemporalFromTime.javaName()),
                            from-> {
                                if (from != null)
                                    builder.setOptionalValue(f->f.TemporalFromTime,from);
                            }),
                    builder->
                        Func.accept(
                            JsonUtils.getYMDHMSValue(
                                json,
                                getMgr().temporalField().TemporalToTime.javaName()),
                            to-> {
                                if (to != null)
                                    builder.setOptionalValue(f->f.TemporalToTime,to);
                            }),
                    builder->
                        mgr.modify(builder.build())));
    }

    @SuppressWarnings("unchecked")
    @Override
    public
    void
    delete(
        JsonObject json) {

        Integer targetId = JsonUtils.getIntValue(json,  getCenterMember().javaName());
        if (targetId == null)
            return;

        createViewOf(targetId).
            unlessNull_(
                mgr::delete);
    }
    @SuppressWarnings("unchecked")
    private
    MayNullVO<TemporalView.Read<F>>
    createViewOf(int targetId) {
        return
            Func.apply(
                Query.select(
                    Attribute.Read.
                        createComparableCriteria(mgr.temporalEntity()).
                        unsafeAndInt(
                            mgr.temporalField().entity().column().PK(),
                            targetId)),
                attributes->
                    Assert.
                        mustUnique(attributes).
                        unlessNull(
                            attribute->
                                Func.apply(
                                    ((PivotReadMgtUnsafe<E,?>)BusinessMgrContainer.getDataMgt(
                                        mgr.temporalField().entity().column().FK().getJavaName()).getMgr()).
                                        selectPivotByPK(attribute.getPivotId()).
                                        mustNonNull(),
                                    (Read<E> pivot)->
                                        Assert.mustUnique(
                                            mgr.
                                                createAttributeTemporalViews(pivot).
                                                filter(view->view.intValue(f->f.TemporalRootKey) == targetId))),
                            MayNullVO.nullInstance()));
    }

    @Override
    public List<AbstractField.Member.Mandatory> getMandatoryAttributeMembers() {
        return Func.
            accept(
                new ArrayList<AbstractField.Member.Mandatory>(),
                list->list.add(field.pivotKey()),
                list->list.add(field.attributeColumn())).
            get();
    }

    @Override
    public List<AbstractField.Member.Optional> getOptionalAttributeMembers() {
        return Func.
            accept(
                new ArrayList<AbstractField.Member.Optional>(),
                list->list.add(field.TemporalFromTime),
                list->list.add(field.TemporalToTime)).
            get();
    }

    @SuppressWarnings(value="unchecked")
    public
    Class<F>
    getFieldClass() {

        return (Class<F>)field.getClass();
    }
    private
    TemporalView.Write.New<F>
    generateView(
        JsonObject json ) {

        Attribute.Write<A> write = Attribute.Write.
            create(
                this.field.entity(),
                valueOf(this.field.entity().column().FK(),json),
                valueOf(this.field.entity().column().attribute(),json),
                DateTime.YMDHMS.current());

        TemporalView.Write.New.Builder<F> builder = TemporalView.Write.New.Builder.
            create(
                getFieldClass(),
                write);

        getOptionalAttributeMembers().
            forEach(
                (member)->
                    setOptionalValue(
                        json,
                        member,
                        builder));
        return builder.build();
    }

    @Override
    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return null;
    }

    @Override
    public ImmutVOs<? extends Read> queryCores() {
        return null;
    }

}
