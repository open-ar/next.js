package aloha3.controller.tool.query.crud;

import aloha.module.object.Compare;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.record.transaction.ITxKey;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.DerivedTxIntAFKMgr.StarView;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.meta.transaction.DerivedTxIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK.From;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView.Field;
import aloha3.module.object.view.TxStarView.FieldOf.AndIntAFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonObject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DerivedTxIntAFKWrapper<
    E extends From<M, A>,
    M extends SealedTxParent<?>,
    A extends CoreEntity,
    F extends AndIntAFK<E>,
    AF extends AbstractField & Field<A>,
    MF extends AbstractField & aloha3.module.object.view.TxStarView.Field<M>,
    T extends Read<F>>
    extends
    BaseMgrWrapper<T, Long, Long> {
    private final String name;
    private final F field;
    private final StarView<E, M, A, F> mgr;

    public DerivedTxIntAFKWrapper(String name, F field, StarView<E, M, A, F> mgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public StarView<E, M, A, F> getMgr() {
        return this.mgr;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((TxEntity)this.mgr.foreignEntity()).getClass().getSimpleName();
        long fkId = Long.parseLong(json.getString(this.getCenterMember().javaName()));
        MayNullVO mayNullVO = GenericSearch.queryTxViewByPK(foreignEntity, fkId);
        String afkName = ((AndIntAFK)this.mgr.field()).unsafeAFK().javaName();
        String afkEntity = null;
        if (afkName.endsWith("Id")) {
            afkEntity = afkName.substring(0, afkName.length() - 2);
        }

        MayNullVO mayNullAfk = GenericSearch.queryMasterViewByPK(afkEntity, Integer.parseInt(json.getString(afkName)));
        aloha3.module.object.view.StarView.Read<AF> afk = (aloha3.module.object.view.StarView.Read)mayNullAfk.mustNonNull();
        return mayNullVO.apply((vo) -> {
            Builder builder;
            if (vo instanceof Read) {
                Read<MF> fk = (Read)vo;
                builder = Builder.create(this.getFieldClass());
                this.setValues(json, this.field, builder);
                return 
                    this.mgr.save(
                        builder.build(),
                        fk.txRead(), 
                        afk.coreRead(), 
                        YMDHMS.current()).get();
            } else {
                throw new RuntimeException("Not supported type: " + vo.getClass().getName());
            }
        }, () -> {
            return -1L;
        });
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeCenterMember().javaName());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(DerivedTxIntAFK.Read.createCriteria(this.field.entity()));
//        return (ImmutVOs)GenericSearch.queryTxs(((TxEntity)this.mgr.foreignEntity()).getClass().getSimpleName(), (String)null).apply((txs) -> {
//            return this.mgr.selectTxs(DistinctIds.longIDsFromRecords(txs, ITxKey::getTxId));
//        }, () -> {
//            return ImmutVOs.emptyVOs();
//        });
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)GenericSearch.queryTxs(((TxEntity)this.mgr.foreignEntity()).getClass().getSimpleName(), null).apply((txs) -> {
            return this.mgr.createViewsOf((NonEmptyVOs)txs);
        }, ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        return (MayNullVO<T>) this.mgr.createView(id);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return (ImmutVOs<T>)this.mgr.createViews(DistinctIds.toLongIDs(pkIDs));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return fkViews.empty() ? ImmutVOs.emptyVOs() : this.queryByFKViews(toTxs(fkViews));
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<aloha3.module.object.record.transaction.read.meta.Read> foreigns) {
        return (ImmutVOs)foreigns.apply((txs) -> {
            return this.mgr.createViews(DistinctIds.longIDsFromRecords(txs, ITxKey::getRowId));
        }, ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return afkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByIntAFKViews(toCores(afkViews), afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read> afkViews, String afkName, Map<String, Object> params) {
        return (ImmutVOs)afkViews.apply((afks) -> {
            return this.mgr.createViewsByAFK(DistinctIds.intIDsFromRecords(afks, aloha3.module.object.record.master.read.meta.Read::rowId));
        }, ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        if (this.isForeignKey(afkName)) {
            return this.queryByFKs(afkViews, params);
        } else {
            Iterator var4 = this.getMandatoryAttributeMembers().iterator();

            Mandatory member;
            do {
                if (!var4.hasNext()) {
                    return ImmutVOs.emptyVOs();
                }

                member = (Mandatory)var4.next();
            } while(!member.javaName().equals(afkName));

            final Mandatory m = member;
            return this.query().filter((view) -> {
                long afk = view.longValue(f->m);
                return (Boolean)afkViews.find((afkView) -> {
                    return Compare.eq(afk, toTx(afkView).rowId());
                }).apply((notEmpty) -> {
                    return true;
                }, () -> {
                    return false;
                });
            });
        }
    }

    public void update(JsonObject json) {
    }

    public void delete(JsonObject json) {
    }

    public Mandatory getCenterMember() {
        return ((AndIntAFK)this.mgr.field()).unsafeCenterMember();
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((AndIntAFK)this.mgr.field()).unsafeAFK());
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    public Class<F> getFieldClass() {
        return (Class)this.field.getClass();
    }
}
