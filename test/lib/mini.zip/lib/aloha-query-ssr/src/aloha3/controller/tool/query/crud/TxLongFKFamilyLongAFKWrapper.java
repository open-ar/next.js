package aloha3.controller.tool.query.crud;

import aloha.module.Array;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.ImmutableArray;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple.Pair;
import aloha.module.object.record.IColumn;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.crud.childmodel.TxLongFKChildLongAFKModel;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxLongFKMgr.StarView;
import aloha3.module.function.business.transaction.TxLongFKMgr.StarView.Family.ChildLongAFK;
import aloha3.module.object.model.write.TxModel;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK.On;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView.FieldOf;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonArray;
import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class TxLongFKFamilyLongAFKWrapper<
    E extends On<M>,
    M extends SealedTxParent<?>,
    F extends AndLongFK<E>,
    CH extends ChildTxEntityLongAFK.Of<E, CM, CV>,
    CM extends TxKey.Category<?>,
    CV extends Comparable<? super CV>,
    MF extends FieldOf<?>,
    T extends TxLongFKChildLongAFKModel<E, M, F, CH, CM, CV, Read<F>>>
    extends BaseMgrWrapper<T, Long, Integer>
    implements TxFamilyWrapper {

    private final String name;
    private final F field;
    private final Class<CH> childRecord;
    private final Class<CM> childAfkRecordType;
    private final Class<CV> childValueType;
    private final StarView<E, M, F> parentMgr;
    private final ChildLongAFK<E, M, F, CH> familyMgr;
    private final String childAfkName;
    private final String childValueName;
    private final List<IColumn> attributeColumns;

    public TxLongFKFamilyLongAFKWrapper(String name, F field, Class<CH> childRecord, Class<CM> childAfkRecordType, Class<CV> childValueType, StarView<E, M, F> parentMgr, ChildLongAFK<E, M, F, CH> familyMgr) {
        this.name = name;
        this.field = field;
        this.childRecord = childRecord;
        this.parentMgr = parentMgr;
        this.familyMgr = familyMgr;
        this.childValueType = childValueType;
        this.childAfkRecordType = childAfkRecordType;
        ImmutableArray<IColumn> immutableArray = ((ChildTxEntityLongAFK)familyMgr.childTx()).columnArray();
        this.attributeColumns = new ArrayList();
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 2));
        this.attributeColumns.add(immutableArray.eltAt(immutableArray.size() - 1));
        this.childAfkName = this.attributeColumns.get(0).getJavaName();
        this.childValueName = this.attributeColumns.get(1).getJavaName();
    }

    public String getName() {
        return this.name;
    }

    public boolean isFamily() {
        return true;
    }

    public String itemName() {
        return this.childRecord.getSimpleName();
    }

    public String afkEntityName() {
        return this.childAfkRecordType.getSimpleName();
    }

    public String afkAttributeName() {
        return this.childAfkName;
    }

    public String valueAttributeName() {
        return this.childValueName;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((TxEntity)this.familyMgr.foreignEntity()).getClass().getSimpleName();
        long fkId = Long.parseLong(json.getString(foreignEntity + "Id"));
        MayNullVO<Read<MF>> foreign = GenericSearch.queryTxViewByPK(foreignEntity, fkId);
        Builder builderParent = Builder.create(this.getFieldClass());
        this.setValues(json, this.field, builderParent);
        JsonArray items = json.getJsonArray("child");
        List<Pair<aloha3.module.object.record.transaction.read.meta.Read<CM>, CV>> lineItemsMore = new ArrayList();

        for(int i = 0; i < items.size(); ++i) {
            JsonObject item = items.getJsonObject(i);
            long afkId = Long.parseLong(item.getString(this.afkAttributeName()));
            CV value = null;
            if (this.childValueType == Integer.class) {
                value = (CV) Integer.valueOf(item.getString(this.valueAttributeName()));
            } else if (this.childValueType == String.class) {
                value = (CV) item.getString(this.valueAttributeName());
            }

            lineItemsMore.add(Pair.of((aloha3.module.object.record.transaction.read.meta.Read)((Read)GenericSearch.queryTxViewByPK(this.afkEntityName(), afkId).mustNonNull()).unsafeTx(), value));
        }

        Pair<aloha3.module.object.record.transaction.read.meta.Read<CM>, CV> first = lineItemsMore.get(0);
        Pair[] others;
        if (lineItemsMore.size() > 1) {
            others = lineItemsMore.subList(1, lineItemsMore.size()).toArray(new Pair[0]);
        } else {
            others = new Pair[0];
        }

        return this.familyMgr.save(
            builderParent.build(),
            (aloha3.module.object.record.transaction.read.meta.Read)((Read)foreign.mustNonNull()).unsafeTx(),
            YMDHMS.current(),
            (view, childTx) -> {
                return Array.create(
                        TxModel.Builder.
                            create(
                                view,
                                childTx,
                                first.getT1(),
                                first.getT2()),
                        others,
                        (builder, lineItem) -> {
                            builder.setValue(
                                (aloha3.module.object.record.transaction.read.meta.Read<CM>)lineItem.getT1(),
                                (CV)lineItem.getT2());},
                        (builder) -> {
                            return builder.build();
                        });
        }).get();
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeFK().javaName());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxLongFK.Read.createCriteria(this.field.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->queryModels((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        return (MayNullVO)this.familyMgr.selectTx(id).apply((tx) -> {
            return MayNullVO.of(TxLongFKChildLongAFKModel.of(this.familyMgr.createModel(tx)));
        }, MayNullVO::nullInstance);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : this.queryModels(this.familyMgr.selectTxs(DistinctIds.toLongIDs(pkIDs)));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return this.queryByFKViews(toTxViews(fkViews), params);
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<Read<MF>> fkViews, Map<String, Object> params) {
        return params.containsKey("from") && params.containsKey("to") ? 
            this.queryByFKAndBetween(fkViews, (YMDHMS)params.get("from"), (YMDHMS)params.get("to")) : 
            (ImmutVOs)fkViews.apply(
                (fks) -> this.queryModels(this.familyMgr.selectByFK(fks.map(Read::txRead))), 
                ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryByFKAndBetween(ImmutVOs<Read<MF>> fkViews, YMDHMS from, YMDHMS to) {
        return fkViews.apply(
            (fks) -> this.queryModels(this.familyMgr.selectByFK(fks.map(Read::txRead))), 
            ImmutVOs::emptyVOs);
    }

    private ImmutVOs<T> queryModels(ImmutVOs<TxLongFK.Read<E>> txList) {
        List<T> result = new ArrayList();
        txList.unlessEmpty_((txs) -> {
            this.familyMgr.createModels(txs).toFlat((model) -> {
                result.add((T)TxLongFKChildLongAFKModel.of(model));
                return ImmutVOs.emptyVOs();
            });
        });
        return ImmutVOs.create(result);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.view.StarView.Read> afkViews, String afkName, Map<String, Object> params) {
        return TxFamilyQuery.queryByIntAFKs(toCores(afkViews), ViewMgr.getColumn(this.name, afkName), this.familyMgr, this);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        if (this.isForeignKey(afkName)) {
            return this.queryByFKs(afkViews, params);
        } else {
            Iterator var4 = this.getMandatoryAttributeMembers().iterator();

            Mandatory member;
            do {
                if (!var4.hasNext()) {
                    AlohaColumn afkColumnOfChild = ViewMgr.getColumnOfChild(this.name, afkName);
                    if (afkColumnOfChild != null) {
                        return TxFamilyQuery.filterByLongAFKViewsOfChild(this.query(), afkViews, afkName);
                    }

                    return ImmutVOs.emptyVOs();
                }

                member = (Mandatory)var4.next();
            } while(!member.javaName().equals(afkName));

            return TxFamilyQuery.queryByLongAFKs(afkViews, ViewMgr.getColumn(this.name, afkName), this.familyMgr, this);
        }
    }

    public void update(JsonObject json) {
    }

    public void delete(JsonObject json) {
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((AndLongFK)this.familyMgr.field()).unsafeFK());
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    public Mandatory getCenterMember() {
        return ((AndLongFK)this.familyMgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    public StarView<E, M, F> getMgr() {
        return this.familyMgr;
    }

    public String parentName() {
        return this.field.entity().getClass().getSimpleName();
    }
}
