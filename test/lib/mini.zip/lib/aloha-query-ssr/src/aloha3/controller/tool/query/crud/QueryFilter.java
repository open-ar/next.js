package aloha3.controller.tool.query.crud;

import aloha.mapping.read.IAttributeCondition;
import aloha.module.object.MayNullValue;
import aloha3.dml.master.Select;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.Field;
import aloha3.module.object.view.StarView;

import java.util.Arrays;
import java.util.function.Function;

public class QueryFilter {
    private final String name;
    private final Object value;
    private final IAttributeCondition.OPERATOR comparator;

    public QueryFilter(
        String name,
        Object value,
        IAttributeCondition.OPERATOR comparator) {

        this.name = name;
        this.value = value;
        this.comparator = comparator;
    }

    @SuppressWarnings("unchecked")
    public
    <E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>>
    Select.SearchCriteria.Condition<F>
    toCondition(
        Class<F> fieldType) {

        return Select.SearchCriteria.Condition.of(
            (Function)Field.memberAccessor(
                fieldType,
                name),
            MayNullValue.of((Comparable)value),
            comparator);
    }

    public String getName() {
        return name;
    }

    public Object getValue() {
        return value;
    }

    public IAttributeCondition.OPERATOR getComparator() {
        return comparator;
    }

    @Override
    public
    String
    toString() {
        if (value instanceof  Object[])
            return name + " " + comparator + " " + Arrays.asList((Object[])value);
        else
            return name + " " + comparator + " " + value;
    }
}
