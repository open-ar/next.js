package aloha3.controller.tool.query.models;

import aloha3.module.function.business.master.TemporalMgt;
import aloha3.module.object.record.master.spec.meta.Temporal;

import java.util.List;

class AttributeRecord<E, M> extends AlohaRecord<Temporal.AttributeEntity<?,?,?>, TemporalMgt.OnAttribute<?,?,?,?>> {
    public AttributeRecord(String name, Temporal.AttributeEntity<?,?,?> entity, TemporalMgt.OnAttribute<?,?,?,?> dataMgt, List<AlohaColumn> columns) {
        super(RECORD_TYPE.TemporalAttribute, name, entity, dataMgt, columns);
    }
}
