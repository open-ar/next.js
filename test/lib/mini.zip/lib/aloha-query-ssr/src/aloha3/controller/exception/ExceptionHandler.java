package aloha3.controller.exception;

import aloha.concurrent.pattern.ParallelFor;
import aloha.module.func.Func;
import aloha3.tool.stream.exception.IExceptionHandler;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.Completed;
import aloha3.tool.stream.response.buildstep.Headers;
import aloha3.tool.stream.response.buildstep.ResponseMessageBody;
import aloha3.tool.stream.response.buildstep.StatusLine;
import aloha3.tool.stream.response.buildstep.chunked.Footer;
import aloha3.tool.template.Context;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Set;

import static aloha3.controller.Server.engine;
import static aloha3.controller.query.IndexController.COMPONENTS_SHARED_MENU_HTML;
import static aloha3.controller.query.IndexController.INDEX_STREAM;

public class ExceptionHandler implements IExceptionHandler {
    public static final String MAIN_TEMPLATE = "error.html";

    @Override
    synchronized public void handle(Request request, Response response, Exception exception) throws Exception {
        final var buildStep = response.getCurrentBuildStep();
        ResponseMessageBody body;

        switch (buildStep) {
            case null -> body = response.chunked();
            case StatusLine statusLine -> body = statusLine.ok().appendChunked().chunkBody();
            case Headers headers -> body = headers.appendChunked().chunkBody();
            case ResponseMessageBody responseBody -> body = responseBody;
            case Footer footer -> {
                footer.end();
                return;
            }
            case Completed _ -> {
                return;
            }
            default -> {
                var className = buildStep.getClass().getSimpleName();
                Logger.ERROR.log("You should handle " + className);
                throw new RuntimeException("Can not handle " + className);
            }
        }
        Func.accept(
            Context.Builder.create().
                add("mainViewContent", "error-content").
                add("title", "Error Page").
                add("withoutLeftMenu", true).
                addStream(() ->
                    ParallelFor.exec(
                        () ->
                            body.addSlot(
                                "shared-menu",
                                engine().process(
                                    COMPONENTS_SHARED_MENU_HTML,
                                    Context.Builder.create().build())),
                        () -> body.addSlot(
                            "error-content",
                            engine().process(
                                MAIN_TEMPLATE,
                                Set.of("style", "error-container"),
                                Context.Builder.
                                    create().
                                    add("message", exception.getMessage()).
                                    add("stack", getStackTrace(exception)).
                                    build())))).
                build(),
            body.asWriter(),
            (ctx, writer) ->
                Func.accept(
                    engine().processThrottled(INDEX_STREAM, ctx),
                    throttled ->
                    {
                        while (!throttled.isFinished()) {
                            throttled.process(128, writer);
                        }
                    },
                    _ -> body.end()));
    }

    private String getStackTrace(Exception exception) {
        try (StringWriter sw = new StringWriter(); PrintWriter pw = new PrintWriter(sw)) {
            exception.printStackTrace(pw);
            return sw.toString();
        } catch (Exception e) {
            return exception.toString();
        }
    }
}
