package aloha3.controller.tool.query.models;

import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.transaction.TxMgt.StarView;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;

import java.util.List;

class CRUDRecord<X extends SealedTxParent<?> & MakeCancellable<X>, F extends AbstractField & Field<X>, M extends StarView<X, F, ?>, VX extends TxEntityLongFK.On<X>, VF extends AndLongFK<VX>> extends AlohaRecord<TxEntity<?>, CRUD<X, F, M, VX, VF>> {
    public CRUDRecord(RECORD_TYPE type, String name, TxEntity<?> entity, CRUD<X, F, M, VX, VF> dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
