package aloha3.controller.tool.meta;

import aloha.module.object.DateTime;
import aloha.module.object.MayNullValue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class StringUtil {

    public static
    String
    decapitalize(String string) {
        return firstCharConvertor(string, Character::toLowerCase);
    }

    public static
    String
    decapitalize(Class<?> clz) {
        return decapitalize(clz.getSimpleName());
    }

    public static
    String
    capitalize(String string) {
        return firstCharConvertor(string, Character::toUpperCase);
    }

    private static
    String
    firstCharConvertor(String string, Function<Character, Character> fn) {
        if (string == null || string.length() == 0) {
            return string;
        }

        char[] c = string.toCharArray();
        c[0] = fn.apply(c[0]);

        return new String(c);
    }

    static long safeLong(Object txId) {
        return Long.parseLong(getJsonValueString(txId));
    }
    
    static int safeInt(Object masterId) {
        return Integer.parseInt(getJsonValueString(masterId));
    }

    static String longToString(long txId) {
        return String.valueOf(txId);
    }

    static String getJsonValueString(Object val) {
        return val.toString();
    }

    public static Map<Integer, Map<String, String>>
    toIdMap(
        List<Object> jsonArray,
        Function<Map<String, String>, Integer> idAccessor) {

        Map<Integer, Map<String, String>> map = new HashMap<>();
        for (Object jsonValue : jsonArray) {
            if (jsonValue instanceof Map) {
                map.put(
                    idAccessor.apply((Map<String, String>) jsonValue),
                    (Map<String, String>) jsonValue);
            }
        }
        return map;
    }


    public static
    MayNullValue<DateTime.YMDHMS>
    toYMDHMS(String dateTime) {
        if (dateTime == null || dateTime.isEmpty()) {
            return MayNullValue.nullInstance();
        }
        // Remove all non-numeric characters and parse as a long
        var dt = dateTime.replaceAll(
            "[^0-9]",
            "");
        // Front end may ignore seconds, so we ensure must have 14 digits
        if (dt.length() < 12) {
            return MayNullValue.nullInstance();
        } else if (dt.length() == 12) {
            dt += "00"; // Append seconds if missing
        } else if (dt.length() > 14) {
            dt = dt.substring(0, 14); // Trim to 14 digits
        }
        return MayNullValue.of(
            DateTime.YMDHMS.create(Long.parseLong(dt)));
    }

    public static
    MayNullValue<DateTime.YMD>
    toYMD(String date) {
        if (date == null || date.isEmpty()) {
            return MayNullValue.nullInstance();
        }
        var d = date.replaceAll(
            "[^0-9]",
            "");
        if (d.length() < 8) {
            return MayNullValue.nullInstance();
        } else if (d.length() > 8) {
            d = d.substring(0, 8); // Trim to 8 digits, for supporting YMDHMS etc
        }
        return MayNullValue.of(
            DateTime.YMD.create(Integer.parseInt(d)));
    }
}
