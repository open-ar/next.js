package aloha3.controller.tool.query.crud;

import aloha.module.object.ImmutVOs;
import aloha3.module.object.record.master.coc.Graph;
import aloha3.module.object.record.meta.master.Core.Read;

import java.util.List;

public interface GraphWrapper {

    Class getHierarchyEntity();

    ImmutVOs<Read<Graph>> queryAllGraphs();

    List<Long> getHistoryRegTimes();
}
