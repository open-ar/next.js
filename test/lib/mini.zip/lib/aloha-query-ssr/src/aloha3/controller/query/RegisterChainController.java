package aloha3.controller.query;

import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha3.controller.query.IndexController.OperationType;
import aloha3.controller.tool.meta.AlohaCRUD;
import aloha3.controller.tool.meta.AlohaCRUD.GraphField;
import aloha3.controller.tool.meta.AlohaMeta;
import aloha3.controller.tool.query.crud.BaseMgrWrapper;
import aloha3.controller.tool.query.crud.BusinessMgrContainer;
import aloha3.controller.tool.query.crud.GraphChainWrapper;
import aloha3.controller.tool.query.crud.GraphTreeWrapper;
import aloha3.module.object.model.read.Chain;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.View;
import aloha3.tool.stream.log.Logger;
import aloha3.tool.stream.request.Request;
import aloha3.tool.stream.response.Response;
import aloha3.tool.stream.response.buildstep.chunked.ChunkedResponseMessageBody;
import aloha3.tool.template.Context;

import javax.json.JsonObject;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static aloha3.controller.Server.container;
import static aloha3.controller.Server.engine;
import static aloha3.controller.query.RegisterTreeController.getNodeLabel;
import static aloha3.controller.query.RegisterTreeController.parseJsonGraph;
import static aloha3.controller.query.RegisterWorkFlowController.parseJsonNodes;
import static aloha3.controller.tool.meta.MappingConst.ID;
import static aloha3.controller.tool.meta.MappingConst.NODES;
import static aloha3.controller.tool.meta.MappingConst.OPERATION;
import static aloha3.controller.tool.meta.MappingConst.PIVOT;

public class RegisterChainController extends AbstractController {
    public static final RegisterChainController INSTANCE = new RegisterChainController();
    public static final String MAIN_TEMPLATE = "registerChain.html";

    public static void handle(Request request, Response response) {
        AbstractController.handle(request, response, INSTANCE);
    }

    @Override
    protected String getMainTemplate() {
        return MAIN_TEMPLATE;
    }

    @Override
    protected String getTitle() {
        return "Register Workflow";
    }

    @Override
    protected Runnable createStream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
        return new Stream(request, body, afterQuery);
    }

    public static void 
    handlePost(
        Request request,
        Response response) {
        
        System.out.println("handle POST");
        // e.g json: {"graphId":150,"nodes":[{"id":10,"nodes":[{"id":20,"nodes":[],"attributes":{}},{"id":30,"nodes":[{"id":40,"nodes":[],"attributes":{}}],"attributes":{}}],"attributes":{}}]}
        request.unlessNull_(
            NODES,
            jsonNodes ->
                request.unlessNull_(
                    PIVOT,
                    pivot ->
                        AlohaCRUD.saveOfGraph(
                            pivot,
                            parseJsonNodes(
                                jsonNodes,
                                targetId -> 
                                    AlohaCRUD.
                                        starViewOfMaster(targetId, pivot, container()).
                                        mustNonNull()))));
        response.redirectTo(request.target());
    }

    public static void 
    handlePut(
        Request request,
        Response response) {
        
        System.out.println("handle Put");
        request.unlessNull_(
            NODES,
            jsonNodes ->
                request.unlessNull_(
                    PIVOT,
                    pivot ->
                        // TODO 新版のPair<From, To>に対応する
                        updateGraph_legacy(
                            pivot,
                            parseJsonGraph(jsonNodes))));
        response.redirectTo(request.target());
    }

    private static int
    updateGraph_legacy(String pivot, JsonObject json) {
        BaseMgrWrapper<?, ?, ?> dataMgt = BusinessMgrContainer.getDataMgt(pivot);
        return switch (dataMgt) {
            case GraphTreeWrapper<?, ?, ?> wrapper -> wrapper.updateRoot(json);
            case GraphChainWrapper wrapper -> wrapper.updateRoot(json);
            default -> throw new IllegalArgumentException(pivot);
        };
    }

    public static void 
    handleDelete(
        Request request,
        Response response) {
        
        System.out.println("handle Delete");
        request.unlessNull_(
            PIVOT,
            pivot ->
                request.unlessNull_(
                    ID,
                    id ->
                        AlohaCRUD.deleteOfGraph(
                            Integer.parseInt(id),
                            pivot)));
        response.redirectTo(request.target());
    }

    public static class Stream extends StreamBase {
        public Stream(Request request, ChunkedResponseMessageBody body, Runnable afterQuery) {
            super(request, body, afterQuery);
        }

        @Override
        protected String genMainViewContent(Request request) {
            return request.apply(
                PIVOT,
                pivot ->
                    renderMainContent(
                        pivot,
                        OperationType.from(request),
                        request.unlessNull(
                            ID, 
                            Integer::valueOf, 
                            0)),
                INSTANCE::getWelcomeContent);
        }

        @Override
        protected void renderNavMenu(Context.Builder builder) {
            builder.
                add("title", "チェーン一覧").
                add(AlohaMeta.getChainPivots());
        }
    }

    private static String
    renderMainContent(
        String pivot,
        OperationType operation,
        Integer id) {
        
        final var viewInfo = AlohaMeta.getViewInfos(pivot, container());
        Logger.INFO.log("registerWorkFlowView: " + viewInfo);
        final var context = Context.Builder.create().
            add(PIVOT, pivot).
            add(ID, id).
            add("viewSchemas", viewInfo).
            add("stars", AlohaCRUD.starViews(pivot, container())).
            add("views", getGraphViews(pivot, DateTime.YMDHMS.current()));

        getGraphViewById(id, pivot, DateTime.YMDHMS.current()).unlessNull_(
            view ->
                context.add("view_of_id", view));

        Set<String> components = new HashSet<>();
        components.add("mainViewContent");
        components.add("style");
        components.add(operation.name());
        context.add(OPERATION, operation.name());
        return engine().process(
            MAIN_TEMPLATE,
            components,
            context.build());
    }

    private static 
    ImmutVOs<View<GraphField>>
    getGraphViews(String pivot, DateTime.YMDHMS asOf) {

        return ImmutVOs.create(
            AlohaCRUD.starViewsOfGraph(pivot, asOf).stream().map(v ->
                View.Builder.
                    create(GraphField.class).
                    setMandatoryValue(
                        f -> f.GraphId,
                        v.left().coreId()).
                    setMandatoryValue(
                        f -> f.Graph,
                        graphToMarkdownChart(v.right(), asOf)).
                    build()).collect(Collectors.toList()));
    }

    private static
    String 
    graphToMarkdownChart(Object graph, DateTime.YMDHMS asOf) {
        // TODO
        final var sb = new StringBuilder();
        sb.append("graph LR\n");
        if (graph instanceof Chain.Straight.Star g) {
            var nodeSeq = new AtomicInteger(0);
            straightChainToMdGraph(g, sb, nodeSeq);
            return sb.toString();
        }
        return "graph LR\n";
    }

    static <
        F extends AbstractField & StarView.Field<?>> void
    straightChainToMdGraph(
        Chain.Straight.Star<F> chain, 
        StringBuilder sb, 
        AtomicInteger nodeSeq) {
        // シーケンス番号でユニーク化
        chain.posts().foreach(post ->
            straightChainToMdGraph(post,
                sb.
                    append("    ").
                    append(chain.node().coreRead().coreId()).append("_").append(nodeSeq.incrementAndGet()).
                    append("[").append(getNodeLabel(chain.node())).append("]").
                    append("-->").
                    append(post.node().coreRead().coreId()).append("_").append(nodeSeq.get() + 1).
                    append("[").append(getNodeLabel(post.node())).append("]").
                    append("\n"), 
                nodeSeq));
    }

    private static 
    MayNullVO<View<GraphField>>
    getGraphViewById(Integer id, String pivot, DateTime.YMDHMS asOf) {

        return 
            AlohaCRUD.starViewOfGraph(id, pivot, asOf).map(v ->
                MayNullVO.of(
                    View.Builder.
                        create(GraphField.class).
                        setMandatoryValue(
                            f -> f.GraphId,
                            v.left().coreId()).
                        setMandatoryValue(
                            f -> f.Graph,
                            graphToMarkdownChart(v.right(), asOf)).
                        build())).
                orElse(MayNullVO.nullInstance());
    }
}
