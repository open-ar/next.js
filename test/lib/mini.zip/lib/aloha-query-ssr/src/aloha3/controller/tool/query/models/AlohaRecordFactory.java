package aloha3.controller.tool.query.models;

import aloha.module.func.Func;
import aloha.module.func.business.IMasterDataMgt;
import aloha.module.func.business.ITransactionMgt;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutableArray;
import aloha.module.object.record.IColumn;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.master.PivotReadMgt;
import aloha3.module.function.business.master.TemporalMgt;
import aloha3.module.function.business.transaction.TxFamilyMgt;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.function.business.transaction.TxIntFKValueMgr;
import aloha3.module.function.business.transaction.TxStarViewMgt;
import aloha3.module.function.business.transaction.coc.FlowableMgr;
import aloha3.module.object.record.AbstractColumn;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.AttributeEntityAFK;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.spec.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.spec.meta.AttributeEntity;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.spec.Schema;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFKOnly;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFK;
import aloha3.module.object.record.transaction.ChildTxEntityLongAFKOnly;
import aloha3.module.object.record.transaction.DerivedTxEntityIntAFK;
import aloha3.module.object.record.transaction.DerivedTxEntityLongAFK;
import aloha3.module.object.record.transaction.TxAttributeEntityIntAFK;
import aloha3.module.object.record.transaction.TxAttributeEntityLongAFK;
import aloha3.module.object.record.transaction.spec.DerivedTxEntity;
import aloha3.module.object.record.transaction.spec.TxEntityIntFK;
import aloha3.module.object.record.transaction.spec.TxEntityLongFK;
import aloha3.module.object.record.transaction.spec.meta.ChildTx;
import aloha3.module.object.record.transaction.spec.meta.TxAttribute;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TemporalField;
import aloha3.module.object.view.TxStarView;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@SuppressWarnings("all")
public class AlohaRecordFactory {

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    AlohaRecord<Schema<?>, ?>
    create(
        Graph mgr) {

        if (mgr instanceof Graph.Tree.Distinct.StarArrow ) {
            Graph.Tree.Distinct.StarArrow graphMgr = (Graph.Tree.Distinct.StarArrow) mgr;
            PivotReadMgt.StarView pivotMgr = graphMgr.coreReadMgt();
            Pivot entity = pivotMgr.entity();
            GraphRecord record = new GraphRecord(
                getRecordType(
                    entity.getClass(),
                    mgr),
                getTypeNameOf(entity),
                entity,
                mgr,
                getColumns(pivotMgr));

            return record;
        } else if (mgr instanceof Graph.Tree ) {
            Graph.Tree graphMgr = (Graph.Tree) mgr;
            PivotReadMgt.StarView pivotMgr = graphMgr.coreReadMgt();
            Pivot entity = pivotMgr.entity();
            GraphRecord record = new GraphRecord(
                getRecordType(
                    entity.getClass(),
                    mgr),
                getTypeNameOf(entity),
                entity,
                mgr,
                getColumns(pivotMgr));

            return record;
        } else if (mgr instanceof Graph.Tree.Distinct ) {
            Graph.Tree.Distinct graphMgr = (Graph.Tree.Distinct) mgr;
            PivotReadMgt.StarView pivotMgr = graphMgr.coreReadMgt();
            Pivot entity = pivotMgr.entity();
            GraphRecord record = new GraphRecord(
                getRecordType(
                    entity.getClass(),
                    mgr),
                getTypeNameOf(entity),
                entity,
                mgr,
                getColumns(pivotMgr));

            return record;
        } else if (mgr instanceof Graph.Chain.Straight ) {
            Graph.Chain.Straight graphMgr = (Graph.Chain.Straight) mgr;
            PivotReadMgt.StarView pivotMgr = graphMgr.coreReadMgt();
            Pivot entity = pivotMgr.entity();
            GraphRecord record = new GraphRecord(
                getRecordType(
                    entity.getClass(),
                    mgr),
                getTypeNameOf(entity),
                entity,
                mgr,
                getColumns(pivotMgr));

            return record;
        } else if (mgr instanceof Graph.Chain ) {
            Graph.Chain graphMgr = (Graph.Chain) mgr;
            PivotReadMgt.StarView pivotMgr = graphMgr.coreReadMgt();
            Pivot entity = pivotMgr.entity();
            GraphRecord record = new GraphRecord(
                getRecordType(
                    entity.getClass(),
                    mgr),
                getTypeNameOf(entity),
                entity,
                mgr,
                getColumns(pivotMgr));

            return record;
        } else {
            System.out.println("[register] skip: " + mgr.getClass().getName());
        }

        return null;
    }

    public static
    AlohaRecord<Schema<?>,?>
    create(
        TemporalMgt.OnAttribute<?,?,?,?> tempMgr ) {

        TemporalField<?> field =tempMgr.temporalField();

        Class pivot =
            ((aloha3.module.object.record.master.AttributeEntity)field.entity()).getForeignEntity();

        return new AttributeRecord(
            getTypeNameOf(tempMgr.temporalEntity()),
            tempMgr.temporalEntity(),
            tempMgr,
            Func.
                accept(
                    new ArrayList<AlohaColumn>(),
                    columns->
                        columns.add(
                            new AlohaColumn(
                                AlohaRecord.COLUMN_TYPE.FK,
                                field.entity().getClass(),
                                ((aloha3.module.object.record.master.AttributeEntity) field.entity()).getForeignKeyColumn().getJavaName(),
                                ((aloha3.module.object.record.master.AttributeEntity) field.entity()).getForeignKeyColumn().getRefType(),
                                pivot.getSimpleName())),
                    columns->
                        columns.add(
                            new AlohaColumn(
                                AlohaRecord.COLUMN_TYPE.Normal,
                                field.entity().getClass(),
                                ((aloha3.module.object.record.master.AttributeEntity) field.entity()).attributeColumn().getJavaName(),
                                ((aloha3.module.object.record.master.AttributeEntity) field.entity()).attributeColumn().getRefType(),
                                null)),
                    columns->
                        columns.add(
                            new AlohaColumn(
                                AlohaRecord.COLUMN_TYPE.Normal,
                                field.TemporalFromTime.getClass(),
                                field.TemporalFromTime.javaName(),
                                field.TemporalFromTime.refType(),
                                null).
                                setOptional(true)),
                    columns->
                        columns.add(
                            new AlohaColumn(
                                AlohaRecord.COLUMN_TYPE.Normal,
                                field.TemporalToTime.getClass(),
                                field.TemporalToTime.javaName(),
                                field.TemporalToTime.refType(),
                                null).
                                setOptional(true))).
                get());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    AlohaRecord<Schema<?>, ?>
    create(
        IMasterDataMgt mgr) {

        if (mgr instanceof PivotReadMgt.StarView ) {

            PivotReadMgt.StarView pivotMgr = (PivotReadMgt.StarView) mgr;
            Pivot entity = pivotMgr.entity();
            CoreRecord record = new CoreRecord(
                getRecordType(
                    entity.getClass(),
                    mgr),
                getTypeNameOf(entity),
                entity,
                mgr,
                getColumns(pivotMgr));

            if (mgr instanceof CoreMgr.StarView.OneToMany) {

                /*
                 * CoreMgr.StarView.OneToMany.Attribute
                 * CoreMgr.StarView.OneToMany.AttributeAFK
                 */
                CoreMgr.StarView.OneToMany oneToManyMgr = (CoreMgr.StarView.OneToMany) mgr;
                //List<Class> params = getTypeArguments(oneToManyMgr.getClass());
                Class oneToManyEntity = oneToManyMgr.manyAttrEntity().getClass();
                String columnName;
                if (AttributeEntityAFK.class.isAssignableFrom(oneToManyEntity)) {
                    //columnName = ((AttributeEntityAFK)Instance.of(oneToManyEntity)).getAdditionalForeignKeyColumn().getJavaName();
                    //columnName += "Id";
                    columnName = oneToManyEntity.getSimpleName() + "Id";
                } else {
                    columnName = oneToManyEntity.getSimpleName();
                }
                record.getOneToManyMgrs().
                    put(
                        columnName,
                        oneToManyMgr);
            }
            return record;

        } else {
            System.out.println("[register] skip: " + mgr.getClass().getName());
        }

        return null;
    }

    public static List<AlohaRecord> create(ITransactionMgt mgr) {
        if (mgr instanceof TxIntFKMgr.StarView.Family.ChildIntAFK.ChildSum) {
            System.out.println("[register] skip: " + mgr.getClass().getName());
            return List.of();
        } else if (!(mgr instanceof TxStarViewMgt)) {
            if (mgr instanceof TxIntFKValueMgr.IntAttribute.Sum) {
                return List.of(create((TxIntFKValueMgr.IntAttribute.Sum)mgr));
            } else if (mgr instanceof TxIntFKValueMgr) {
                return List.of(create((TxIntFKValueMgr)mgr));
            } else {
                System.out.println("[register] skip: " + mgr.getClass().getName());
                return List.of();
            }
        } else {
            TxStarViewMgt txMgr = (TxStarViewMgt)mgr;
            List<AlohaRecord> records = new ArrayList<>();
            if (txMgr instanceof TxFamilyMgt fmgr) {
                records.add(createTxChild(fmgr));
            }
            // While tx-child, register both tx and child.(2)
            List<AlohaColumn> columns = new ArrayList();
            List<AbstractField.TypedMember> members = getMembers(txMgr.field());
            int i = members.size() - txMgr.attributeTypes().attrs().length;
            TxAttribute[] var6 = txMgr.attributeTypes().attrs();
            int var7 = var6.length;

            for(int var8 = 0; var8 < var7; ++var8) {
                TxAttribute attribute = var6[var8];
                AbstractField.TypedMember member = i >= 0 && i < members.size() ? (AbstractField.TypedMember)members.get(i) : null;
                ++i;
                List<? extends Enum> enums = getEnums(attribute);
                String foreign;
                if (attribute.attributeColumn().getClass().getSimpleName().equals("AFK")) {
                    foreign = attribute.attributeColumn().getJavaName();
                    if (foreign.endsWith("Id")) {
                        foreign = foreign.substring(0, foreign.length() - 2);
                    }
                } else {
                    foreign = null;
                }

                Class declaredClass = attribute.getClass();
                AlohaColumn column;
                if (member != null) {
                    column = new AlohaColumn(declaredClass, member.javaName(), attribute.attributeColumn().getRefType(), foreign, attribute.attributeColumn().getJavaName(), enums);
                } else {
                    column = new AlohaColumn(declaredClass, attribute.attributeColumn().getJavaName(), attribute.attributeColumn().getRefType(), foreign, enums);
                }

                column.setOptional(member.getClass().getSuperclass().getSimpleName().equals("Optional"));
                column.setImmutable(true);
                columns.add(column);
            }

            TxEntity entity = getTxEntity(mgr);
            AlohaRecord.RECORD_TYPE recordType = getRecordType(entity.getClass(), mgr);
            records.add(new TxRecord(recordType, getTypeNameOf((Schema)entity), entity, mgr, columns));
            return records;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    AlohaRecord
    create(
        TxIntFKValueMgr txMgr) {

        List<AlohaColumn> columns = new ArrayList<>();

//        IColumn intFKColumn = (IColumn)txMgr.foreignEntity().columnArray().eltAt(0);
//        columns.add(
//            new AlohaColumn(
//                txMgr.entity().getClass(),
//                intFKColumn.getJavaName(),
//                intFKColumn.getRefType(),
//                txMgr.foreignEntity().getClass().getSimpleName(),
//                intFKColumn.getJavaName()));

        IColumn valueColumn = (IColumn)txMgr.entity().columnArray().eltAt(2);
        columns.add(
            new AlohaColumn(
                txMgr.entity().getClass(),
                valueColumn.getJavaName(),
                valueColumn.getRefType(),
                null,
                null));

        TxEntity entity = txMgr.entity();
        AlohaRecord.RECORD_TYPE recordType = getRecordType(
            entity.getClass(),
            txMgr);

        columns.forEach(c->c.setImmutable(true));
        return new TxRecord(
            recordType,
            getTypeNameOf(entity),
            entity,
            txMgr,
            columns);
    }

    public static AlohaRecord create(CRUD crudMgr) throws Exception {
        List<AlohaColumn> columns = new ArrayList();
        TxStarViewMgt txMgr = crudMgr.txStarMgr();
        List<AbstractField.TypedMember> members = getMembers(txMgr.field());
        int i = members.size() - txMgr.attributeTypes().attrs().length;
        TxStarView.FieldOf.AndLongFK variableFields = crudMgr.variableField();
        getFields((TxStarViewMgt)txMgr, columns);
        List<AlohaColumn> variableColumns = new ArrayList();
        getFields((TxStarView.FieldOf.AndLongFK)variableFields, variableColumns);
        columns.forEach((c) -> {
            c.setImmutable(true);
        });
        variableColumns.forEach((c) -> {
            c.setImmutable(false);
        });
        columns.addAll(variableColumns);
        TxEntity entity = getTxEntity(txMgr);
        AlohaRecord.RECORD_TYPE recordType = getRecordType(entity.getClass(), crudMgr);
        if (AlohaRecord.RECORD_TYPE.TxIntFK == recordType) {
            recordType = AlohaRecord.RECORD_TYPE.CrudIntFK;
        } else if (AlohaRecord.RECORD_TYPE.TxLongFK == recordType) {
            recordType = AlohaRecord.RECORD_TYPE.CrudLongFK;
        }

        return new CRUDRecord(recordType, getTypeNameOf((Schema)entity), entity, crudMgr, columns);
    }

    public static AlohaRecord create(CRUD.Family crudMgr) throws Exception {
        List<AlohaColumn> columns = new ArrayList();
        List<AlohaColumn> columnsOfChild = new ArrayList();
        TxStarViewMgt txMgr = crudMgr.txStarMgr();
        List<AbstractField.TypedMember> members = getMembers(txMgr.field());
        int i = members.size() - txMgr.attributeTypes().attrs().length;
        TxStarView.FieldOf.AndLongFK variableFields = crudMgr.parentMgr().variableField();
        getFields((TxStarViewMgt)txMgr, columns);
        List<AlohaColumn> variableColumns = new ArrayList();
        getFields((TxStarView.FieldOf.AndLongFK)variableFields, variableColumns);
        String nameOfChild = null;
        if (crudMgr instanceof CRUD.Family.ChildIntAFK) {
            ChildTxEntityIntAFK childInkAFKFields = (ChildTxEntityIntAFK)crudMgr.childTx();
            getFields((ChildTxEntityIntAFK)childInkAFKFields, columnsOfChild);
            nameOfChild = childInkAFKFields.getClass().getSimpleName();
        } else if (crudMgr instanceof CRUD.Family.ChildLongAFK) {
            ChildTxEntityLongAFK childLongAFKFields = (ChildTxEntityLongAFK)crudMgr.childTx();
            getFields((ChildTxEntityLongAFK)childLongAFKFields, columnsOfChild);
            nameOfChild = childLongAFKFields.getClass().getSimpleName();
        } else if (crudMgr instanceof CRUD.Family.ChildIntAFKOnly) {
            ChildTxEntityIntAFKOnly childLongAFKFields = (ChildTxEntityIntAFKOnly)crudMgr.childTx();
            getFields((ChildTxEntityIntAFKOnly)childLongAFKFields, columnsOfChild);
            nameOfChild = childLongAFKFields.getClass().getSimpleName();
        } else if (crudMgr instanceof CRUD.Family.ChildLongAFKOnly) {
            ChildTxEntityLongAFKOnly childLongAFKFields = (ChildTxEntityLongAFKOnly)crudMgr.childTx();
            getFields((ChildTxEntityLongAFKOnly)childLongAFKFields, columnsOfChild);
            nameOfChild = childLongAFKFields.getClass().getSimpleName();
        } else {
            System.out.println("Unkown CRUD: " + crudMgr.getClass().getName());
            System.out.println("           : " + crudMgr.getClass().getSuperclass().getName());
        }

        columns.forEach((c) -> {
            c.setImmutable(true);
        });
        variableColumns.forEach((c) -> {
            c.setImmutable(false);
        });
        columns.addAll(variableColumns);
        columnsOfChild.forEach((c) -> {
            c.setImmutable(false);
        });
        ((AlohaColumn)columnsOfChild.get(0)).setImmutable(true);
        TxEntity entity = getTxEntity(txMgr);
        AlohaRecord.RECORD_TYPE recordType = getRecordType(entity.getClass(), crudMgr);
        if (AlohaRecord.RECORD_TYPE.TxIntFK == recordType) {
            recordType = AlohaRecord.RECORD_TYPE.CrudIntFKChild;
        } else if (AlohaRecord.RECORD_TYPE.TxLongFK == recordType) {
            recordType = AlohaRecord.RECORD_TYPE.CrudLongFKChild;
        }

        if (crudMgr instanceof CRUD.Family.ChildIntAFK) {
            return (new CRUDFamilyIntAFKRecord(recordType, nameOfChild, entity, (CRUD.Family.ChildIntAFK)crudMgr, columns)).setColumnsOfChildOrDependant(columnsOfChild).setNameOfChildOrDependant(nameOfChild);
        } else if (crudMgr instanceof CRUD.Family.ChildLongAFK) {
            return (new CRUDFamilyLongAFKRecord(recordType, nameOfChild, entity, (CRUD.Family.ChildLongAFK)crudMgr, columns)).setColumnsOfChildOrDependant(columnsOfChild).setNameOfChildOrDependant(nameOfChild);
        } else if (crudMgr instanceof CRUD.Family.ChildLongAFKOnly) {
            return (new CRUDFamilyLongAFKOnlyRecord(recordType, nameOfChild, entity, (CRUD.Family.ChildLongAFKOnly)crudMgr, columns)).setColumnsOfChildOrDependant(columnsOfChild).setNameOfChildOrDependant(nameOfChild);
        } else if (crudMgr instanceof CRUD.Family.ChildIntAFKOnly) {
            return (new CRUDFamilyIntAFKOnlyRecord(recordType, nameOfChild, entity, (CRUD.Family.ChildIntAFKOnly)crudMgr, columns)).setColumnsOfChildOrDependant(columnsOfChild).setNameOfChildOrDependant(nameOfChild);
        } else {
            System.out.println("[SKIP] " + crudMgr.getClass().getName());
            return null;
        }
    }

    static void getFields(TxStarViewMgt txMgr, List<AlohaColumn> columns) {
        List<AbstractField.TypedMember> members = getMembers(txMgr.field());
        int i = members.size() - txMgr.attributeTypes().attrs().length;
        TxAttribute[] var4 = txMgr.attributeTypes().attrs();
        int var5 = var4.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            TxAttribute attribute = var4[var6];
            AbstractField.TypedMember member = i >= 0 && i < members.size() ? (AbstractField.TypedMember)members.get(i) : null;
            ++i;
            String owner;
            if (attribute.attributeColumn().getClass().getSimpleName().equals("AFK")) {
                owner = attribute.getClass().getSimpleName();
            } else {
                owner = null;
            }

            List<? extends Enum> enums = getEnums(attribute);
            String memberType = "";
            if (member != null) {
                memberType = member.getClass().getSuperclass().getSimpleName();
            }

            Class declaredClass = attribute.getClass();
            if (attribute instanceof TxAttributeEntityIntAFK) {
                TxAttributeEntityIntAFK intAFK = (TxAttributeEntityIntAFK)attribute;
                columns.add((new AlohaColumn(declaredClass, member.javaName(), attribute.attributeColumn().getRefType(), intAFK.getAdditionalForeignEntity().getSimpleName(), intAFK.getAdditionalForeignKeyColumn().getJavaName(), enums)).setOptional("Optional".equals(memberType)));
            } else if (attribute instanceof TxAttributeEntityLongAFK) {
                TxAttributeEntityLongAFK intAFK = (TxAttributeEntityLongAFK)attribute;
                columns.add((new AlohaColumn(declaredClass, member.javaName(), attribute.attributeColumn().getRefType(), intAFK.getAdditionalForeignEntity().getSimpleName(), intAFK.getAdditionalForeignKeyColumn().getJavaName(), enums)).setOptional("Optional".equals(memberType)));
            } else if (member != null) {
                columns.add((new AlohaColumn(declaredClass, member.javaName(), attribute.attributeColumn().getRefType(), owner, attribute.attributeColumn().getJavaName(), enums)).setOptional("Optional".equals(memberType)));
            } else {
                columns.add(new AlohaColumn(declaredClass, attribute.attributeColumn().getJavaName(), attribute.attributeColumn().getRefType(), owner, enums));
            }
        }

    }

    static void getFields(TxStarView.FieldOf.AndLongFK variableFields, List<AlohaColumn> columns) {
        variableFields.attributeMembers();
        ImmutableArray<aloha3.module.object.view.Field.Member.ofStarView.Attribute> attrs = variableFields.attributeMembers();
        attrs.foreach((attribute) -> {
            Class type = attribute.attributeEntity().getSuperclass().getSuperclass();
            aloha.module.object.Type.RefType refType = attribute.refType();
            String name = attribute.getClass().getName();
            String memberType = "";
            if (attribute != null) {
                memberType = attribute.getClass().getSuperclass().getSimpleName();
            }

            List<? extends Enum> enums = null;
            Class declaredClass = attribute.attributeEntity();
            if (TxAttributeEntityIntAFK.class.isAssignableFrom(attribute.attributeEntity())) {
                TxAttributeEntityIntAFK intAFK = (TxAttributeEntityIntAFK)Instance.of(attribute.attributeEntity());
                columns.add((new AlohaColumn(declaredClass, attribute.javaName(), refType, intAFK.getAdditionalForeignEntity().getSimpleName(), intAFK.getAdditionalForeignKeyColumn().getJavaName(), (List)enums)).setOptional("Optional".equals(memberType)));
            } else if (TxAttributeEntityLongAFK.class.isAssignableFrom(attribute.attributeEntity())) {
                TxAttributeEntityLongAFK intAFKx = (TxAttributeEntityLongAFK)Instance.of(attribute.attributeEntity());
                columns.add((new AlohaColumn(declaredClass, attribute.javaName(), refType, intAFKx.getAdditionalForeignEntity().getSimpleName(), intAFKx.getAdditionalForeignKeyColumn().getJavaName(), (List)enums)).setOptional("Optional".equals(memberType)));
            } else {
                columns.add((new AlohaColumn(declaredClass, attribute.javaName(), refType, (String)null, name, (List)enums)).setOptional("Optional".equals(memberType)));
            }

        });
    }

    static void getFields(TxStarView.FieldOf.AndIntFK variableFields, List<AlohaColumn> columns) {
        variableFields.attributeMembers();
        ImmutableArray<aloha3.module.object.view.Field.Member.ofStarView.Attribute> attrs = variableFields.attributeMembers();
        attrs.foreach((attribute) -> {
            Class type = attribute.attributeEntity().getSuperclass().getSuperclass();
            aloha.module.object.Type.RefType refType = attribute.refType();
            String name = attribute.getClass().getName();
            String memberType = "";
            if (attribute != null) {
                memberType = attribute.getClass().getSuperclass().getSimpleName();
            }

            List<? extends Enum> enums = null;
            Class declaredClass = attribute.attributeEntity();
            if (TxAttributeEntityIntAFK.class.isAssignableFrom(attribute.attributeEntity())) {
                TxAttributeEntityIntAFK intAFK = (TxAttributeEntityIntAFK) Instance.of(attribute.attributeEntity());
                columns.add((new AlohaColumn(declaredClass, attribute.javaName(), refType, intAFK.getAdditionalForeignEntity().getSimpleName(), intAFK.getAdditionalForeignKeyColumn().getJavaName(), (List)enums)).setOptional("Optional".equals(memberType)));
            } else if (TxAttributeEntityLongAFK.class.isAssignableFrom(attribute.attributeEntity())) {
                TxAttributeEntityLongAFK intAFKx = (TxAttributeEntityLongAFK)Instance.of(attribute.attributeEntity());
                columns.add((new AlohaColumn(declaredClass, attribute.javaName(), refType, intAFKx.getAdditionalForeignEntity().getSimpleName(), intAFKx.getAdditionalForeignKeyColumn().getJavaName(), (List)enums)).setOptional("Optional".equals(memberType)));
            } else {
                columns.add((new AlohaColumn(declaredClass, attribute.javaName(), refType, (String)null, name, (List)enums)).setOptional("Optional".equals(memberType)));
            }

        });
    }

    static void getFields(ChildTxEntityIntAFK childIntAFKFields, List<AlohaColumn> columns) {
        columns.add(new AlohaColumn(childIntAFKFields.getClass(), childIntAFKFields.getPrimaryKeyColumn().getJavaName(), childIntAFKFields.getPrimaryKeyColumn().getRefType(), (String)null, (String)null, (List)null));
        columns.add(new AlohaColumn(childIntAFKFields.getClass(), childIntAFKFields.getForeignKeyColumn().getJavaName(), childIntAFKFields.getForeignKeyColumn().getRefType(), childIntAFKFields.getForeignEntity().getSimpleName(), childIntAFKFields.getForeignKeyColumn().getJavaName(), (List)null));
        columns.add(createAlohaColumnAFK(childIntAFKFields.getClass(), childIntAFKFields.getAdditionalForeignEntity(), childIntAFKFields.getAdditionalForeignKeyColumn()));
        columns.add(createAttributeAlohaColumn(childIntAFKFields.attributeColumn()));
    }

    static void getFields(ChildTxEntityLongAFK childLongAFKFields, List<AlohaColumn> columns) {
        columns.add(new AlohaColumn(childLongAFKFields.getClass(), childLongAFKFields.getPrimaryKeyColumn().getJavaName(), childLongAFKFields.getPrimaryKeyColumn().getRefType(), (String)null, (String)null, (List)null));
        columns.add(new AlohaColumn(childLongAFKFields.getClass(), childLongAFKFields.getForeignKeyColumn().getJavaName(), childLongAFKFields.getForeignKeyColumn().getRefType(), childLongAFKFields.getForeignEntity().getSimpleName(), childLongAFKFields.getForeignKeyColumn().getJavaName(), (List)null));
        columns.add(createAlohaColumnAFK(childLongAFKFields.getClass(), childLongAFKFields.getAdditionalForeignEntity(), childLongAFKFields.getAdditionalForeignKeyColumn()));
        columns.add(createAttributeAlohaColumn(childLongAFKFields.attributeColumn()));
    }

    static void getFields(ChildTxEntityLongAFKOnly childLongAFKFields, List<AlohaColumn> columns) {
        columns.add(new AlohaColumn(childLongAFKFields.getClass(), childLongAFKFields.getPrimaryKeyColumn().getJavaName(), childLongAFKFields.getPrimaryKeyColumn().getRefType(), (String)null, (String)null, (List)null));
        columns.add(new AlohaColumn(childLongAFKFields.getClass(), childLongAFKFields.getForeignKeyColumn().getJavaName(), childLongAFKFields.getForeignKeyColumn().getRefType(), childLongAFKFields.getForeignEntity().getSimpleName(), childLongAFKFields.getForeignKeyColumn().getJavaName(), (List)null));
        columns.add(createAlohaColumnAFK(childLongAFKFields.getClass(), childLongAFKFields.getAdditionalForeignEntity(), childLongAFKFields.getAdditionalForeignKeyColumn()));
    }

    static void getFields(ChildTxEntityIntAFKOnly childIntAFKFields, List<AlohaColumn> columns) {
        columns.add(new AlohaColumn(childIntAFKFields.getClass(), childIntAFKFields.getPrimaryKeyColumn().getJavaName(), childIntAFKFields.getPrimaryKeyColumn().getRefType(), (String)null, (String)null, (List)null));
        columns.add(new AlohaColumn(childIntAFKFields.getClass(), childIntAFKFields.getForeignKeyColumn().getJavaName(), childIntAFKFields.getForeignKeyColumn().getRefType(), childIntAFKFields.getForeignEntity().getSimpleName(), childIntAFKFields.getForeignKeyColumn().getJavaName(), (List)null));
        columns.add(createAlohaColumnAFK(childIntAFKFields.getClass(), childIntAFKFields.getAdditionalForeignEntity(), childIntAFKFields.getAdditionalForeignKeyColumn()));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static
    AlohaColumn
    createAlohaColumnAFK(
        Class attribute,
        Class foreignEntry,
        IColumn column)  {

        Class type = foreignEntry.getSuperclass().getSuperclass();
        aloha.module.object.Type.RefType refType = column.getRefType();
        String name = column.getJavaName();

        return
            new AlohaColumn(
                attribute,
                name,
                refType,
                foreignEntry.getSimpleName(),
                name,
                null);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static
    AlohaColumn
    createAttributeAlohaColumn(
        AbstractColumn.Member.Attribute attribute)  {

        Class entity = attribute.entity;
        Class type = entity.getSuperclass().getSuperclass();
        aloha.module.object.Type.RefType refType = attribute.getRefType();
        String name = attribute.getJavaName();

        List<? extends Enum> enums = null;
        Class declaredClass = entity;
        if ((TxAttributeEntityIntAFK.class.isAssignableFrom(entity))) {
            TxAttributeEntityIntAFK intAFK = (TxAttributeEntityIntAFK) Instance.of(entity);
            return
                new AlohaColumn(
                    declaredClass,
                    name,
                    refType,
                    intAFK.getAdditionalForeignEntity().getSimpleName(),
                    intAFK.getAdditionalForeignKeyColumn().getJavaName(),
                    enums);
        } else if ((TxAttributeEntityLongAFK.class.isAssignableFrom(entity))) {
            TxAttributeEntityLongAFK intAFK = (TxAttributeEntityLongAFK) Instance.of(entity);
            return
                new AlohaColumn(
                    declaredClass,
                    name,
                    refType,
                    intAFK.getAdditionalForeignEntity().getSimpleName(),
                    intAFK.getAdditionalForeignKeyColumn().getJavaName(),
                    enums);
        } else {
            return
                new AlohaColumn(
                    declaredClass,
                    name,
                    refType,
                    null,
                    name,
                    enums);
        }
    }

    /*
    @SuppressWarnings({"unchecked", "rawtypes"})
    static
    AlohaRecord
    createFlowableTx(
        FlowableMgr mgr) {

        ParameterizedType pType = (ParameterizedType) mgr.getClass().getGenericSuperclass();
        try {
            Field entityField = mgr.getClass().getSuperclass().getSuperclass().getDeclaredField("entity");
            entityField.setAccessible(true);
            TxEntity txEntity = (TxEntity) entityField.get(mgr);

            Field fieldField = mgr.getClass().getSuperclass().getSuperclass().getDeclaredField("field");
            fieldField.setAccessible(true);
            FlowableField flowableField = (FlowableField) fieldField.get(mgr);

            List<AlohaColumn> columns = new ArrayList<>();
            Class declaredClass = txEntity.getClass();

            if (mgr instanceof FlowableMgr.TxIntFK) {
                FlowableField.TxIntFK afk = (FlowableField.TxIntFK) flowableField;
                String owner = afk.FK().javaName();
                owner = owner.substring(0, owner.length() - 2);
                columns.add(
                    new AlohaColumn(
                        AlohaRecord.COLUMN_TYPE.FK,
                        declaredClass,
                        afk.FK().javaName(),
                        afk.FK().getRefType(),
                        owner,
                        null));
            }

            columns.add(
                new AlohaColumn(
                    declaredClass,
                    flowableField.WorkFlowId.javaName(),
                    flowableField.WorkFlowId.getRefType(),
                    "WorkFlow",
                    null));

            columns.add(
                new AlohaColumn(
                    declaredClass,
                    flowableField.StateId.javaName(),
                    flowableField.StateId.getRefType(),
                    "State",
                    null));

            return new TxRecord(
                AlohaRecord.RECORD_TYPE.FlowableTx,
                getTypeNameOf(txEntity),
                txEntity,
                mgr,
                columns);
        }catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
    */

    static AlohaRecord createTxChild(TxFamilyMgt mgr) {
        TxStarViewMgt txMgr = (TxStarViewMgt)mgr;
        new ArrayList();
        if (txMgr instanceof TxIntFKMgr.StarView.Family.ChildIntAFKOnly.Flowable m) {
            return createTxChild_ChildIntAFKOnly_Flowable(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildLongAFKOnly m) {
            return createTxChild_ChildLongAFKOnly(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildLongAFK m) {
            return createTxChild_ChildLongAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildIntAFKOnly m) {
            return createTxChild_ChildIntAFKOnly(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildIntAFK m) {
            return createTxChild_ChildIntAFK(m);
        // support DerivedTx系のFamily
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildLongAFKOnly m) {
            return createTxChild_DerivedTxIntAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildLongAFK m) {
            return createTxChild_DerivedTxIntAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildIntAFKOnly m) {
            return createTxChild_DerivedTxIntAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildIntAFK m) {
            return createTxChild_DerivedTxIntAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildLongAFKOnly m) {
            return createTxChild_DerivedTxLongAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildLongAFK m) {
            return createTxChild_DerivedTxLongAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildIntAFKOnly m) {
            return createTxChild_DerivedTxLongAFK(m);
        } else if (txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildIntAFK m) {
            return createTxChild_DerivedTxLongAFK(m);
        } else {
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildIntAFK;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildIntAFKOnly;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildLongAFK;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildLongAFKOnly;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildIntAFK;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildIntAFKOnly;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildLongAFK;
            // txMgr instanceof aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildLongAFKOnly;
            return null;
        }
    }

    static void addTxChildColumn(AbstractColumn.Member member, String primaryKeyColumn, String foreignKeyColumn, List<AlohaColumn> columns) {
        List<? extends Enum> enums = null;
        if (member instanceof aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFK.Column.AFK) {
            aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFK.Column.AFK afkColumn = (aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFK.Column.AFK)member;
            columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.AFK, (Class)null, member.getJavaName(), member.getRefType(), afkColumn.original().entity().getSimpleName(), afkColumn.original().getJavaName(), (List)enums));
        } else if (member instanceof aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFK.Column.FK) {
            aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFK.Column.FK fkColumn = (aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFK.Column.FK)member;
            columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, member.getJavaName(), member.getRefType(), fkColumn.original().entity().getSimpleName(), fkColumn.original().getJavaName(), (List)enums)).setImmutable(true));
        } else if (member instanceof aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFKOnly.Column.FK) {
            aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFKOnly.Column.FK fkColumn = (aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFKOnly.Column.FK)member;
            columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, member.getJavaName(), member.getRefType(), fkColumn.original().entity().getSimpleName(), fkColumn.original().getJavaName(), (List)enums)).setImmutable(true));
        } else if (member instanceof aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFKOnly.Column.AFK) {
            aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFKOnly.Column.AFK afkColumn = (aloha3.module.object.record.transaction.spec.ChildTxEntityIntAFKOnly.Column.AFK)member;
            columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.AFK, (Class)null, member.getJavaName(), member.getRefType(), afkColumn.original().entity().getSimpleName(), afkColumn.original().getJavaName(), (List)enums));
        } else if (member instanceof aloha3.module.object.record.transaction.spec.ChildTxEntityLongAFKOnly.Column.FK) {
            aloha3.module.object.record.transaction.spec.ChildTxEntityLongAFKOnly.Column.FK fkColumn = (aloha3.module.object.record.transaction.spec.ChildTxEntityLongAFKOnly.Column.FK)member;
            columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, member.getJavaName(), member.getRefType(), fkColumn.original().entity().getSimpleName(), fkColumn.original().getJavaName(), (List)enums)).setImmutable(true));
        } else if (member instanceof aloha3.module.object.record.transaction.spec.ChildTxEntityLongAFKOnly.Column.AFK) {
            aloha3.module.object.record.transaction.spec.ChildTxEntityLongAFKOnly.Column.AFK afkColumn = (aloha3.module.object.record.transaction.spec.ChildTxEntityLongAFKOnly.Column.AFK)member;
            columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.AFK, (Class)null, member.getJavaName(), member.getRefType(), afkColumn.original().entity().getSimpleName(), afkColumn.original().getJavaName(), (List)enums));
        } else if (member.getJavaName().equals(primaryKeyColumn)) {
            columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, member.getJavaName(), member.getRefType(), (String)null, (List)enums)).setImmutable(true));
        } else if (member.getJavaName().equals(foreignKeyColumn)) {
            columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, member.getJavaName(), member.getRefType(), (String)null, (List)enums)).setImmutable(true));
        } else {
            columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.Normal, (Class)null, member.getJavaName(), member.getRefType(), (String)null, (List)enums));
        }

    }

    static AlohaRecord createTxChild_ChildLongAFKOnly(aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildLongAFKOnly afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntFK parentField = (TxStarView.FieldOf.AndIntFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        getFields((TxStarView.FieldOf.AndIntFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxIntAFK(aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildLongAFKOnly afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntAFK parentField = (TxStarView.FieldOf.AndIntAFK)afkMgr.field();
        // DerivedTx PK == FK
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndIntAFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxIntAFK(aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildLongAFK afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntAFK parentField = (TxStarView.FieldOf.AndIntAFK)afkMgr.field();
        // DerivedTx PK == FK
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndIntAFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxIntAFK(aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildIntAFKOnly afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntAFK parentField = (TxStarView.FieldOf.AndIntAFK)afkMgr.field();
        // DerivedTx PK == FK
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndIntAFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxIntAFK(aloha3.module.function.business.transaction.DerivedTxIntAFKMgt.StarView.Family.ChildIntAFK afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntAFK parentField = (TxStarView.FieldOf.AndIntAFK)afkMgr.field();
        // DerivedTx PK == FK
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndIntAFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxLongAFK(aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildLongAFKOnly afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndLongAFK parentField = (TxStarView.FieldOf.AndLongAFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // DerivedTx PK == FK
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndLongFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxLongAFK(aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildLongAFK afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndLongAFK parentField = (TxStarView.FieldOf.AndLongAFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // DerivedTx PK == FK
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndLongFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxLongAFK(aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildIntAFKOnly afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndLongAFK parentField = (TxStarView.FieldOf.AndLongAFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // DerivedTx PK == FK
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndLongFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }
    static AlohaRecord createTxChild_DerivedTxLongAFK(aloha3.module.function.business.transaction.DerivedTxLongAFKMgt.StarView.Family.ChildIntAFK afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndLongAFK parentField = (TxStarView.FieldOf.AndLongAFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        // DerivedTx PK == FK
        // columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        // getFields((TxStarView.FieldOf.AndLongFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }

    static AlohaRecord createTxChild_ChildIntAFKOnly(aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildIntAFKOnly afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntFK parentField = (TxStarView.FieldOf.AndIntFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        getFields((TxStarView.FieldOf.AndIntFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }

    static AlohaRecord createTxChild_ChildIntAFKOnly_Flowable(TxIntFKMgr.StarView.Family.ChildIntAFKOnly.Flowable afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntFK parentField = (TxStarView.FieldOf.AndIntFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        getFields((TxStarView.FieldOf.AndIntFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, childTx.txEntity().getSimpleName(), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }

    static AlohaRecord createTxChild_ChildLongAFK(aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildLongAFK afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntFK parentField = (TxStarView.FieldOf.AndIntFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        getFields((TxStarView.FieldOf.AndIntFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }

    static AlohaRecord createTxChild_ChildIntAFK(aloha3.module.function.business.transaction.TxIntFKMgt.StarView.Family.ChildIntAFK afkMgr) {
        List<AlohaColumn> columns = new ArrayList();
        TxStarView.FieldOf.AndIntFK parentField = (TxStarView.FieldOf.AndIntFK)afkMgr.field();
        columns.add((new AlohaColumn(AlohaRecord.COLUMN_TYPE.PK, (Class)null, parentField.unsafeCenterMember().javaName(), parentField.unsafeCenterMember().getRefType(), (String)null, Collections.EMPTY_LIST)).setImmutable(true));
        columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.FK, (Class)null, parentField.unsafeFK().javaName(), parentField.unsafeFK().getRefType(), parentField.unsafeFK().javaName().substring(0, parentField.unsafeFK().javaName().length() - 2), parentField.unsafeFK().javaName(), Collections.EMPTY_LIST));
        getFields((TxStarView.FieldOf.AndIntFK)parentField, columns);
        String primaryKeyColumn = afkMgr.childTx().getPrimaryKeyColumn().getJavaName();
        String foreignKeyColumn = afkMgr.childTx().getForeignKeyColumn().getJavaName();
        List<AlohaColumn> columnsOfChilds = new ArrayList();

        for(int k = 0; k < afkMgr.childTx().column().length(); ++k) {
            addTxChildColumn(afkMgr.childTx().column().at(k), primaryKeyColumn, foreignKeyColumn, columnsOfChilds);
        }

        ChildTx childTx = afkMgr.childTx();
        return (new TxChildRecord(AlohaRecord.RECORD_TYPE.TxChild, getTypeNameOf((Schema)childTx), childTx, afkMgr, columns)).setColumnsOfChildOrDependant(columnsOfChilds).setNameOfChildOrDependant(getTypeNameOf((Schema)childTx));
    }

    private static AlohaRecord.RECORD_TYPE getRecordType(Class entity, Object mgr) {
        if (mgr instanceof Graph.Tree.Distinct.StarArrow) {
            return AlohaRecord.RECORD_TYPE.ArrowTree;
        } else if (mgr instanceof Graph.Tree.Distinct) {
            return AlohaRecord.RECORD_TYPE.DistinctTree;
        } else if (mgr instanceof Graph.Tree) {
            return AlohaRecord.RECORD_TYPE.Tree;
        } else if (mgr instanceof Graph.Chain.StarArrow) {
            return AlohaRecord.RECORD_TYPE.ArrowChain;
        } else if (mgr instanceof Graph.Chain.Straight) {
            return AlohaRecord.RECORD_TYPE.StraightChain;
        } else if (mgr instanceof Graph.Chain) {
            return AlohaRecord.RECORD_TYPE.Chain;
        } else if (mgr instanceof aloha3.module.function.business.master.RelationMgr.StarView) {
            return AlohaRecord.RECORD_TYPE.Relation;
        } else if (mgr instanceof CoreMgr.StarView) {
            return AlohaRecord.RECORD_TYPE.Core;
        } else if (mgr instanceof CoreMgr.StarView.ForeignCore) {
            return AlohaRecord.RECORD_TYPE.Core;
        } else if (mgr instanceof FlowableMgr.TxIntFK) {
            return AlohaRecord.RECORD_TYPE.FlowableTxIntFK;
        } else if (DerivedTxEntity.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.DerivedTx;
        } else if (DerivedTxEntityIntAFK.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.DerivedTxIntAFK;
        } else if (DerivedTxEntityLongAFK.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.DerivedTxLongAFK;
        } else if (TxEntityIntFK.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.TxIntFK;
        } else if (TxEntityLongFK.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.TxLongFK;
        } else if (TxIntFKValueMgr.IntAttribute.Sum.class.isInstance(mgr)) {
            return AlohaRecord.RECORD_TYPE.TxIntValueGroup;
        } else if (TxIntFKValueMgr.IntAttribute.class.isInstance(mgr)) {
            return AlohaRecord.RECORD_TYPE.TxIntValue;
        } else if (TxIntFKMgr.StarView.Family.ChildIntAFK.ChildSum.class.isInstance(entity)) {
            return AlohaRecord.RECORD_TYPE.TxChildGroup;
        } else if (ChildTxEntityLongAFKOnly.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.TxChild;
        } else if (ChildTxEntityIntAFKOnly.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.TxChild;
        } else if (ChildTxEntityIntAFK.class.isAssignableFrom(entity)) {
            return AlohaRecord.RECORD_TYPE.TxChild;
        } else {
            String var10000 = entity.getSimpleName();
            System.out.println("Unkown Entity Type: " + var10000 + "  Mgr:" + mgr.getClass().getName());
            return null;
        }
    }


    @SuppressWarnings({"rawtypes"})
    public static
    String
    getTypeNameOf(
        Schema entity) {

        return getTypeNameOf(
            entity.getClass());
    }

    @SuppressWarnings({"rawtypes"})
    private static
    String
    getTypeNameOf(
        Class<? extends Schema> entity) {

        return entity.getEnclosingClass() == null ?
            entity.getSimpleName() :
            entity.getEnclosingClass().getSimpleName() + entity.getSimpleName();
    }

    @SuppressWarnings({"rawtypes"})
    private static
    TxEntity
    getTxEntity(
        ITransactionMgt mgr) {

        if (mgr instanceof TxStarViewMgt) {

            TxStarViewMgt txMgr = (TxStarViewMgt) mgr;
            return txMgr.entity();
        } else {
            System.out.println("Unkown ITransactionMgt Type: " + mgr.getClass().getName());
            System.out.println("[register] skip: " + mgr.getClass().getName());
        }

        return null;
    }

    @SuppressWarnings({"rawtypes"})
    private static
    List<AbstractField.TypedMember>
    getMembers(
        AbstractField fields ) {

        List<AbstractField.TypedMember> memebrs = new ArrayList<>();
        for(Field field : fields.getClass().getDeclaredFields()) {
            try {
                AbstractField.TypedMember member ;
                if (AbstractField.Member.Optional.class.isAssignableFrom(field.getType())) {
                    member = (AbstractField.Member.Optional) field.get(fields);
                }else{
                    member = (AbstractField.Member.Mandatory) field.get(fields);
                }
                memebrs.add(member);
            }catch (Exception e) {
                e.printStackTrace();
            }
        }

        return memebrs;
    }

    @SuppressWarnings({"rawtypes"})
    private static
    Field
    getFieldOfAttribute(
        Class attributeType ) {

        Field[] declaredFields = attributeType.getDeclaredFields();
        if (declaredFields.length != 1)
            return null;
        return declaredFields[0];
    }

    @SuppressWarnings({"rawtypes"})
    private static
    aloha.module.object.Type.RefType
    getFieldTypeOfAttribute(
        Field field ) {

        if (field == null)
            return null;

        try {
            ParameterizedType type = (ParameterizedType)field.getGenericType();
            Class fieldType = Class.forName(
                type.getActualTypeArguments()[0].getTypeName());
            return getFieldType(fieldType);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @SuppressWarnings({"rawtypes"})
    private static
    aloha.module.object.Type.RefType
    getFieldType(
        Class fieldType ) {

        if (fieldType == null)
            return null;

        if (fieldType == String.class)
            return aloha.module.object.Type.RefType.STRING;
        else if (fieldType == Integer.class)
            return aloha.module.object.Type.RefType.INTEGER;
        else if (fieldType == Long.class)
            return aloha.module.object.Type.RefType.LONG;
        else if (fieldType == Byte.class)
            return aloha.module.object.Type.RefType.BYTE;
        else if (fieldType == DateTime.YMD.class)
            return aloha.module.object.Type.RefType.YMD;
        return null;
    }

    @SuppressWarnings({"rawtypes"})
    private static
    List<Class>
    getManyFields(
        Pivot pivot ) {

        List<Class> memebrs = new ArrayList<>();
        for(Class field : pivot.getClass().getDeclaredClasses()) {
            if (aloha3.module.object.record.master.AttributeEntity.Cancellable.Many.class.isAssignableFrom(field))
                memebrs.add(field);
            else if (AttributeEntityAFK.Cancellable.Many.class.isAssignableFrom(field))
                memebrs.add(field);
        }

        return memebrs;
    }

    public static List<Class> getTypeArguments(Class clazz) {
        List<Class> types = new ArrayList();
        ParameterizedType parameterizedType = (ParameterizedType)clazz.getGenericSuperclass();
        Type[] var3 = parameterizedType.getActualTypeArguments();
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            Type type = var3[var5];
            if (type instanceof ParameterizedType) {
                type = (Type) ((ParameterizedType)type).getActualTypeArguments()[0];
                types.add((Class)type);
            } else if ( Class.class.isAssignableFrom(type.getClass()) ){
                types.add((Class)type);
            }
        }

        return types;
    }

    public static List<? extends Enum> getEnums(AttributeEntity.One attribute) {
        List<? extends Enum> enums = null;
        if (!attribute.getClass().getSuperclass().getSimpleName().equals("EnumOf")) {
            return enums;
        } else {
            Class<? extends Enum> enumType = (Class)getTypeArguments(attribute.getClass()).get(1);
            enums = Arrays.asList((Enum[])enumType.getEnumConstants());
            return enums;
        }
    }

    public static List<? extends Enum> getEnums(TxAttribute attribute) {
        List<? extends Enum> enums = null;
        if (!attribute.getClass().getSuperclass().getSimpleName().equals("EnumOf")) {
            return enums;
        } else {
            Class<? extends Enum> enumType = (Class)getTypeArguments(attribute.getClass()).get(1);
            enums = Arrays.asList((Enum[])enumType.getEnumConstants());
            return enums;
        }
    }

    private static List<AlohaColumn>
    getColumns(PivotReadMgt.StarView pivotMgr) {
        List<AlohaColumn> columns = new ArrayList();
        List<Class> manyFields = getManyFields(pivotMgr.entity());
        pivotMgr.field().numberOfSilentMembers();
        List<AbstractField.TypedMember> members = getMembers(pivotMgr.field());
        int i = members.size() - pivotMgr.attributeTypes().attrs().length;
        AttributeEntity.One[] var5 = pivotMgr.attributeTypes().attrs();
        int var6 = var5.length;

        for(int var7 = 0; var7 < var6; ++var7) {
            AttributeEntity.One attribute = var5[var7];
            AbstractField.TypedMember member = i >= 0 && i < members.size() ? (AbstractField.TypedMember)members.get(i) : null;
            ++i;
            boolean unique = attribute.getClass().getSuperclass() == FixedAttributeEntity.UniqueString.class;
            String memberType = "";
            if (member != null) {
                memberType = member.getClass().getSuperclass().getSimpleName();
            }

            List<? extends Enum> enums = getEnums(attribute);
            String owner;
            if (attribute.attributeColumn().getClass().getSimpleName().equals("AFK")) {
                owner = attribute.getClass().getSimpleName();
                IColumn foreignKeyColumn = null;
                if (attribute instanceof AttributeEntityAFK) {
                    foreignKeyColumn = ((AttributeEntityAFK)attribute).getAdditionalForeignKeyColumn();
                    owner = ((AttributeEntityAFK)attribute).getAdditionalReferenceEntity().getSimpleName();
                } else if (attribute instanceof FixedAttributeEntityAFK) {
                    foreignKeyColumn = ((FixedAttributeEntityAFK)attribute).getAdditionalForeignKeyColumn();
                    owner = ((FixedAttributeEntityAFK)attribute).getAdditionalReferenceEntity().getSimpleName();
                }
            } else {
                owner = null;
            }

            Class declaredClass = attribute.getClass();
            if (member != null) {
                columns.add((new AlohaColumn(declaredClass, member.javaName(), attribute.attributeColumn().getRefType(), owner, attribute.attributeColumn().getJavaName(), enums)).setOptional("Optional".equals(memberType)));
            } else {
                columns.add(new AlohaColumn(declaredClass, attribute.attributeColumn().getJavaName(), attribute.attributeColumn().getRefType(), owner, enums));
            }
        }

        Iterator var15 = manyFields.iterator();

        while(var15.hasNext()) {
            Class manyField = (Class)var15.next();
            String var10000;
            if (aloha3.module.object.record.master.AttributeEntity.Cancellable.Many.class.isAssignableFrom(manyField)) {
                List<Class> typeArguments = getTypeArguments(manyField);
                aloha.module.object.Type.RefType attrType = getFieldType((Class)typeArguments.get(1));
                if (attrType == null) {
                    var10000 = manyField.getName();
                    System.out.println("[SKIP] " + var10000 + " " + manyField.getSuperclass().getSimpleName());
                } else {
                    columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.MultiValue, manyField, manyField.getSimpleName(), attrType, (String)null, (List)null));
                }
            } else if (AttributeEntityAFK.Cancellable.Many.class.isAssignableFrom(manyField)) {
                Class fk = (Class)getTypeArguments(manyField).get(1);
                columns.add(new AlohaColumn(AlohaRecord.COLUMN_TYPE.MultiValue, manyField, manyField.getSimpleName() + "Id", aloha.module.object.Type.RefType.INTEGER, fk.getSimpleName(), fk.getSimpleName() + "Id", (List)null));
            } else {
                var10000 = manyField.getName();
                System.out.println("[SKIP] " + var10000 + " " + manyField.getSuperclass().getSimpleName());
            }
        }

        return columns;
    }

}