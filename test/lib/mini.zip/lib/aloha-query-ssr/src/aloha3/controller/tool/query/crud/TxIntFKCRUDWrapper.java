package aloha3.controller.tool.query.crud;

import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.controller.tool.query.models.JsonUtils;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.transaction.TxMgt.StarView;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.TxEntityIntFK.On;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView.FieldOf.AndIntFK;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class TxIntFKCRUDWrapper<
    X extends On<C> & MakeCancellable<X>,
    C extends Pivot<?>,
    F extends AndIntFK<X>,
    M extends StarView<X, F, ?>,
    VX extends TxEntityLongFK.On<X>,
    VF extends AndLongFK<VX>,
    T extends OneToOne<Read<F>, Read<VF>>>
    extends BaseMgrWrapper<T, Long, Integer>
    implements TxFamilyWrapper {

    private final String name;
    private final F field;
    private final VF vField;
    private final CRUD<X, F, M, VX, VF> mgr;
    private final aloha3.module.function.business.transaction.TxIntFKMgr.StarView<X, C, F> txMainMgr;

    public TxIntFKCRUDWrapper(String name, F field, VF vFields, CRUD<X, F, M, VX, VF> mgr, aloha3.module.function.business.transaction.TxIntFKMgr.StarView<X, C, F> txMgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
        this.vField = vFields;
        this.txMainMgr = txMgr;
    }

    public String getName() {
        return this.name;
    }

    public boolean isCRUD() {
        return true;
    }

    @Override
    public Object getMgr() {
        return this.txMainMgr;
    }

    public Object register(JsonObject json) {
        String foreignEntity = this.txMainMgr.foreignEntity().getClass().getSimpleName();
        int fkId = Integer.parseInt(json.getString(foreignEntity + "Id"));
        MayNullVO<aloha3.module.object.record.master.read.meta.Read<C>> core = GenericSearch.queryPivotReadByPK(foreignEntity, fkId);
        return core.apply((fk) -> {
            return ((TxIntFK.Read)this.mgr.create(((Builder)this.setValues(json, this.field, Builder.create(this.getFieldClass()))).build(), (txMgr, txTime) -> {
                return this.txMainMgr.create(fk, txTime);
            }, this.setValues(json, this.vField, Builder.create(this.vField.getClass())).build()).get()).rowId();
        }, () -> {
            return -1L;
        });
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeFK().javaName());
    }

    public MayNullVO<T> queryByPK(Long id) {
        MayNullVO var10000 = this.txMainMgr.selectTx(id);
        CRUD var10001 = this.mgr;
        Objects.requireNonNull(var10001);
        return (MayNullVO)var10000.apply(v->var10001.read((aloha3.module.object.record.transaction.read.meta.Read.TxTime) v), MayNullVO::nullInstance);
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxIntFK.Read.createCriteria(this.field.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->mgr.reads((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        if (pkIDs.isEmpty()) {
            return ImmutVOs.emptyVOs();
        } else {
            ImmutVOs var10000 = this.txMainMgr.selectTxs(DistinctIds.toLongIDs(pkIDs));
            CRUD var10001 = this.mgr;
            Objects.requireNonNull(var10001);
            return (ImmutVOs)var10000.apply(v->var10001.reads((NonEmptyVOs) v), ImmutVOs::emptyVOs);
        }
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return fkViews.size() == 0 ? ImmutVOs.emptyVOs() : this.queryByFKViews(toCores(fkViews), params);
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<C>> foreigns, Map<String, Object> params) {
        return params.containsKey("from") && params.containsKey("to") ? this.queryByFKAndBetween(foreigns, (YMDHMS)params.get("from"), (YMDHMS)params.get("to")) : (ImmutVOs)foreigns.apply((foreignCores) -> {
            ImmutVOs var10000 = this.txMainMgr.selectTxsByFK(foreignCores);
            CRUD var10001 = this.mgr;
            Objects.requireNonNull(var10001);
            return (ImmutVOs)var10000.apply(v->var10001.reads((NonEmptyVOs) v), ImmutVOs::emptyVOs);
        }, ImmutVOs::emptyVOs);
    }

    private ImmutVOs queryByFKAndBetween(ImmutVOs<aloha3.module.object.record.master.read.meta.Read<C>> fkViews, YMDHMS from, YMDHMS to) {
        List result = new ArrayList();
        fkViews.foreach((fk) -> {
            this.txMainMgr.createViews(fk, from, to).foreach((txView) ->
                result.add(this.mgr.read(txView.txRead()).mustNonNull())
            );
        });
        return ImmutVOs.create(result);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.view.StarView.Read> afkViews, String afkName, Map<String, Object> params) {
        return this.isForeignKey(afkName) ? this.queryByFKViews(afkViews.map((v) -> {
            return v.coreRead();
        }), params) : TxFamilyQuery.queryByIntAFKs(toCores(afkViews), ViewMgr.getColumn(this.name, afkName), this.txMainMgr, this);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return TxFamilyQuery.queryByLongAFKs(toTxs(afkViews), ViewMgr.getColumn(this.name, afkName), this.txMainMgr, this);
    }

    public void update(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            this.txMainMgr.selectTx(targetId).unlessNull_((txRead) -> {
                Builder vBuilder = Builder.create(this.vField.getClass());
                this.setValues(json, this.vField, vBuilder);
                this.mgr.update(txRead, vBuilder.build());
            });
        }
    }

    public void delete(JsonObject json) {
        Long targetId = JsonUtils.getLongValue(json, this.getCenterMember().javaName());
        if (targetId != null) {
            MayNullVO var10000 = this.txMainMgr.selectTx(targetId);
            CRUD var10001 = this.mgr;
            Objects.requireNonNull(var10001);
            var10000.unlessNull_(v->var10001.delete((aloha3.module.object.record.transaction.read.meta.Read)v));
        }
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((AndIntFK)this.txMainMgr.field()).unsafeFK());
        members.addAll(this.getMandatoryAttributeMembers(this.vField));
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        List<Optional> members = this.getOptionalAttributeMembers(this.field);
        members.addAll(this.getOptionalAttributeMembers(this.vField));
        return members;
    }

    public Mandatory getCenterMember() {
        return ((AndIntFK)this.txMainMgr.field()).unsafeCenterMember();
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    public String parentName() {
        return this.field.entity().getClass().getSimpleName();
    }

    public aloha3.module.function.business.transaction.TxIntFKMgr.StarView<X, C, F> getTxMainMgr() {
        return this.txMainMgr;
    }
}
