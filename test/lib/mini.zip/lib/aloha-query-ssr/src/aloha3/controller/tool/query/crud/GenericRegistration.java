package aloha3.controller.tool.query.crud;


import aloha3.controller.tool.query.ViewMgr;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import javax.json.Json;
import javax.json.JsonObject;
import java.io.StringReader;

public class GenericRegistration {

    @SuppressWarnings(value="unchecked")
    public static <
        E extends aloha3.module.object.record.master.CoreEntity,
        F extends AbstractField & StarView.Field<E>>
    Object
    register(
        String viewName,
        String params ) {

        if (params == null || params.isEmpty())
            throw new IllegalArgumentException("paramsは必須です。");
        JsonObject json = Json.createReader(new StringReader(params)).readObject();

        viewName = viewName.contains(".") ? viewName.substring(viewName.indexOf(".") +1 ) : viewName;

        BaseMgrWrapper dataMgt = BusinessMgrContainer.getDataMgt(ViewMgr.toViewModelName(viewName));
        if (dataMgt == null)
            throw new IllegalArgumentException(viewName);
        return dataMgt.register(json);
    }
}
