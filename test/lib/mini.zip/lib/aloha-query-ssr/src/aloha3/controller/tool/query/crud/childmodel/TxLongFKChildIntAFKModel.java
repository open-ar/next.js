package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha3.module.object.model.read.TxModel;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.record.transaction.spec.meta.TxKey;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TxLongFKChildIntAFKModel<
    E extends TxEntityLongFK<? super E,M>,
    M extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>>
    extends TxChildModel {

    private final TxModel.ChildIntAFK<F, CH> model;
    private final ImmutVOs<View<TxModel.ChildIntAFK.FlatField<F, CV>>> flatViews;
    private final List<AbstractField.Member.Mandatory> childMembers;

    private TxLongFKChildIntAFKModel(
        TxModel.ChildIntAFK<F, CH> model) {

        this.model = model;

        flatViews = model.toFlat(TxModel.ChildIntAFK::toFlat);
        childMembers = new ArrayList<>();
        if (!flatViews.empty()) {
            View<TxModel.ChildIntAFK.FlatField<F, CV>> flatFieldView = flatViews.firstUnlessEmpty();
            childMembers.add(
                flatFieldView.field().PK());
            childMembers.add(
                flatFieldView.field().AFK());
            childMembers.add(
                flatFieldView.field().Attribute());
        }
    }

    public TxModel.ChildIntAFK<F, CH> getModel() {
        return model;
    }

    public ImmutVOs<View<TxModel.ChildIntAFK.FlatField<F, CV>>> getFlatViews() {
        return flatViews;
    }

    public
    List<AbstractField.Member.Mandatory>
    childMembers() {
        return childMembers;
    }

    public
    List<AbstractField.Member.Optional>
    childOptionalMembers() {
        return Collections.EMPTY_LIST;
    }

    public
    TxStarView.Read<F>
    view() {
        return model.view();
    }

    public
    ImmutVOs<? extends Read<CH>>
    children() {
        return model.children();
    }

    public
    String
    txEntityName() {
        return view().field().entity().getClass().getSimpleName();
    }

    public
    String
    txChildEntityName() {
        return (children().empty()) ? null : children().firstUnlessEmpty().entity().getClass().getSimpleName();
    }

    public static <
    E extends TxEntityLongFK<? super E, M>,
    M extends TxKey<?>,
    F extends TxStarView.FieldOf.AndLongFK<E>,
    CH extends ChildTxEntityIntAFK.Of<E,CM,CV>,
    CM extends CoreEntity,
    CV extends Comparable<? super CV>>
    TxLongFKChildIntAFKModel<E,M,F,CH,CM,CV>
    of(
        TxModel.ChildIntAFK<F, CH> model) {

        return new TxLongFKChildIntAFKModel( model ) ;
    }


}
