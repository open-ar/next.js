package aloha3.controller.query.vo;

import aloha.module.object.Type;
import aloha.module.object.ValueObject;
import aloha3.document.business.mdm.FormElementField;
import aloha3.document.business.mdm.FormField;
import aloha3.document.business.mdm.NestedElementField;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.view.StarView;

public record FormElementRow(
    StarView.Read<FormField> form,
    StarView.Hierarchy.Read<NestedElementField> nestedElement,
    StarView.Read<FormElementField> formElement
) implements ValueObject {
    
    public static FormElementRow create(
        OneToOne<
            OneToOne<
                StarView.Read<FormField>,
                StarView.Hierarchy.Read<NestedElementField>>,
            StarView.Read<FormElementField>> o2o) {
        return new FormElementRow(
            o2o.left().left(),
            o2o.left().right(),
            o2o.right()
        );
    }
    
    public String name() { return formElement.mandatoryValue(f -> f.Name); }
    public Type.RefType refType() { return formElement.mandatoryValue(f -> f.RefType); }
    public Integer arrayMaxSize() { return nestedElement.optionalValue(f -> f.ArrayMaxSize).apply(Byte::intValue, () -> null); }
    public Integer parentFormElementId() { return nestedElement.mandatoryValue(NestedElementField::FromFormElementId); }
    public Integer nestedElementId() { return nestedElement.mandatoryValue(NestedElementField::NestedElementId); }
    public Integer formElementId() { return formElement.mandatoryValue(FormElementField::FormElementId); }
}

