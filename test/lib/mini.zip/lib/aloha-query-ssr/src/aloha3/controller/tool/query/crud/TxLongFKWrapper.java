package aloha3.controller.tool.query.crud;

import aloha.mapping.write.Persist.Value;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.MayNullVO;
import aloha.module.object.NonEmptyVOs;
import aloha3.controller.tool.query.ViewMgr;
import aloha3.controller.tool.query.models.DistinctIds;
import aloha3.dml.hidden.Distinct;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.transaction.TxLongFKMgr.StarView;
import aloha3.module.object.record.meta.transaction.TxLongFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK.On;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;
import aloha3.module.object.view.TxStarView.Read;
import aloha3.module.object.view.TxStarView.Write.Prepare.Builder;

import javax.json.JsonObject;
import java.util.List;
import java.util.Map;

public class TxLongFKWrapper<
    E extends On<M>,
    M extends SealedTxParent<?>,
    F extends AndLongFK<E>,
    MF extends AbstractField & Field<M>,
    T extends Read<F>>
    extends BaseMgrWrapper<T, Long, Long> {

    private final String name;
    private final F field;
    private final StarView<E, M, F> mgr;

    public TxLongFKWrapper(String name, F field, StarView<E, M, F> mgr) {
        this.field = field;
        this.mgr = mgr;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public Object register(JsonObject json) {
        String foreignEntity = ((TxEntity)this.mgr.foreignEntity()).getClass().getSimpleName();
        long fkId = Long.parseLong(json.getString(foreignEntity + "Id"));
        MayNullVO cores = GenericSearch.queryTxViewByPK(foreignEntity, fkId);
        return cores.apply((fk) -> {
            Builder builder = Builder.create(this.getFieldClass());
            this.setValues(json, this.field, builder);
            Value<Long> ret = this.mgr.save(builder.build(), toTx(fk), YMDHMS.current());
            return ret.get();
        }, () -> {
            return -1L;
        });
    }

    public boolean isForeignKey(String name) {
        return name.equals(this.field.unsafeFK().javaName());
    }

    public ImmutVOs<? extends aloha3.module.object.record.transaction.read.meta.Read> queryTxs() {
        return Query.select(TxLongFK.Read.createCriteria(this.field.entity()));
    }

    public ImmutVOs<? extends aloha3.module.object.record.master.read.meta.Read> queryCores() {
        return ImmutVOs.emptyVOs();
    }

    public ImmutVOs<T> query() {
        return (ImmutVOs)queryTxs().
            apply(
                vos->mgr.createViews((NonEmptyVOs)vos),
                ImmutVOs::emptyVOs);
    }

    public MayNullVO<T> queryByPK(Long id) {
        return (MayNullVO<T>) this.mgr.createView(id);
    }

    public ImmutVOs<T> queryByPKs(List<Long> pkIDs) {
        return pkIDs.isEmpty() ? ImmutVOs.emptyVOs() : (ImmutVOs<T>) this.mgr.createViews(DistinctIds.toLongIDs(pkIDs));
    }

    public ImmutVOs<T> queryByFKs(ImmutVOs fkViews, Map<String, Object> params) {
        return this.queryByFKViews(toTxViews(fkViews));
    }

    private ImmutVOs<T> queryByFKViews(ImmutVOs<Read<MF>> foreigns) {
        return (ImmutVOs)foreigns.apply((txs) -> {
            return this.mgr.createViewsByForeignIds(Distinct.longIDs(txs,tx->tx.txRead().rowId()));
        }, ImmutVOs::emptyVOs);
    }

    public ImmutVOs<T> queryByIntAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.queryByIntAFKViews(afkViews, afkName, params);
    }

    private ImmutVOs<T> queryByIntAFKViews(ImmutVOs<aloha3.module.object.view.StarView.Read> afkViews, String afkName, Map<String, Object> params) {
        return TxFamilyQuery.queryByIntAFKs(toCores(afkViews), ViewMgr.getColumn(this.name, afkName), this.mgr, this);
    }

    public ImmutVOs<T> queryByLongAFKs(ImmutVOs afkViews, String afkName, Map<String, Object> params) {
        return this.isForeignKey(afkName) ? this.queryByFKs(afkViews, params) : TxFamilyQuery.queryByLongAFKs(toTxs(afkViews), ViewMgr.getColumn(this.name, afkName), this.mgr, this);
    }

    public void update(JsonObject json) {
    }

    public void delete(JsonObject json) {
    }

    public Mandatory getCenterMember() {
        return ((AndLongFK)this.mgr.field()).unsafeCenterMember();
    }

    public List<Mandatory> getMandatoryAttributeMembers() {
        List<Mandatory> members = this.getMandatoryAttributeMembers(this.field);
        members.add(0, ((AndLongFK)this.mgr.field()).unsafeFK());
        return members;
    }

    public List<Optional> getOptionalAttributeMembers() {
        return this.getOptionalAttributeMembers(this.field);
    }

    public Class<F> getFieldClass() {
        return (Class<F>) this.field.getClass();
    }

    public StarView<E, M, F> getMgr() {
        return this.mgr;
    }
}
