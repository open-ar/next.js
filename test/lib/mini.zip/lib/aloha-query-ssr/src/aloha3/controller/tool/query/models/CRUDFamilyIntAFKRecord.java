package aloha3.controller.tool.query.models;

import aloha3.module.function.business.conceptual.transaction.CRUD.Family.ChildIntAFK;
import aloha3.module.function.business.transaction.TxMgt.StarView;
import aloha3.module.object.record.transaction.ChildTxEntityIntAFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import aloha3.module.object.record.transaction.coc.generic.Bridge;
import aloha3.module.object.record.transaction.opt.spec.MakeCancellable;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.TxStarView.FieldOf.AndLongFK;

import java.util.List;

class CRUDFamilyIntAFKRecord<
        X extends SealedTxParent<?> & MakeCancellable<X>,
        F extends AbstractField & Field<X>,
        M extends StarView<X, F, ?>,
        VX extends TxEntityLongFK.On<X>,
        VF extends AndLongFK<VX>, CH extends ChildTxEntityIntAFK.Of<Bridge<X>, ?, ?>>
        extends AlohaRecord<TxEntity<?>, ChildIntAFK<X, F, M, VX, VF, CH>> {
    public CRUDFamilyIntAFKRecord(RECORD_TYPE type, String name, TxEntity<?> entity, ChildIntAFK<X, F, M, VX, VF, CH> dataMgt, List<AlohaColumn> columns) {
        super(type, name, entity, dataMgt, columns);
    }
}
