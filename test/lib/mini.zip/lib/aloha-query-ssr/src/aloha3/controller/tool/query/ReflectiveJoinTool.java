package aloha3.controller.tool.query;

import aloha.module.func.business.AbstractServiceContainer;
import aloha.module.func.business.IMasterDataMgt;
import aloha.module.func.business.ITransactionMgt;
import aloha.module.object.ImmutValues;
import aloha.module.object.ImmutableArray;
import aloha3.controller.tool.query.crud.BusinessMgrContainer;
import aloha3.controller.tool.query.models.AlohaColumn;
import aloha3.controller.tool.query.models.AlohaRecord;
import aloha3.controller.tool.query.models.AlohaRecordFactory;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.conceptual.transaction.CRUD;
import aloha3.module.function.business.master.CoreReadMgt;
import aloha3.module.function.business.master.TemporalMgt;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.HierarchyEntity;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.spec.Schema;
import aloha3.module.object.record.transaction.opt.spec.MakeFlowable;
import aloha3.module.object.record.transaction.spec.meta.ChildTx;
import aloha3.module.object.record.transaction.spec.meta.TxEntity;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.StarView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ReflectiveJoinTool {

    public static final Map<Class, Object> dataMgrs = new HashMap();
    public static final Map<String, AlohaRecord<Schema<?>, ?>> records = new HashMap();
    public static final Map<String, AlohaRecord<Schema<?>, ?>> conceptuals = new HashMap();
    public static final Map<String, AlohaRecord<Schema<?>, ?>> removedRecords = new HashMap();

    public static
    void
    init(
        AbstractServiceContainer businessServiceContainer) {

        if (businessServiceContainer == null)
            return;

        businessServiceContainer.
            allMDM().forEach(mdm->register((IMasterDataMgt) mdm));

        businessServiceContainer.
            allTxM().forEach(txm->register((ITransactionMgt) txm));
    }

    public static void init(AbstractServiceContainer.Conceptual conceptualServiceContainer) {
        if (conceptualServiceContainer != null) {
            Iterator var1 = conceptualServiceContainer.all().iterator();

            while(var1.hasNext()) {
                Object mgr = var1.next();

                try {
                    // System.out.println("Register: " + mgr.getClass().getName());
                    if (mgr instanceof Graph) {
                        register((Graph) mgr, null);
                    } else if (mgr instanceof CRUD) {
                        register((CRUD) mgr, null);
                    } else if (mgr instanceof CRUD.Family) {
                        register((CRUD.Family) mgr, null);
                    } else {
                        System.out.println("[SKIP] " + mgr.getClass().getName());
                    }
                } catch (Exception var4) {
                    System.out.println(var4);
                }
            }

            register(WorkFlow.workFlowMgr);
            register(WorkFlow.chainMgr, null);
        }
    }

    private static
    void
    register(IMasterDataMgt mgr) {

        AlohaRecord<Schema<?>,?> record = AlohaRecordFactory.create(mgr);
        if (record != null) {
            String key = record.getName();
            if (records.containsKey(key)) {
                AlohaRecord<Schema<?>,?> exists = records.get(key);
                if (exists.isOneToMany() && !record.isOneToMany()) {
                    record.getOneToManyMgrs().
                        putAll(
                            exists.getOneToManyMgrs());
                } else if (!exists.isOneToMany() && record.isOneToMany()) {
                    exists.getOneToManyMgrs().
                        putAll(
                            record.getOneToManyMgrs());
                    record = exists;
                } else if (exists.isOneToMany() && record.isOneToMany()) {
                    record.getOneToManyMgrs().
                        putAll(
                            exists.getOneToManyMgrs());
                } else if (!exists.getOneToManyMgrs().isEmpty() && record.getOneToManyMgrs().isEmpty()) {
                    record.getOneToManyMgrs().
                        putAll(
                            exists.getOneToManyMgrs());
                }
            }
            records.put(
                key,
                record);
            if ( mgr instanceof TemporalMgt.OnAttribute tempMgt) {
                record = AlohaRecordFactory.create(tempMgt);
                records.put(
                    record.getName(),
                    record);
            }
        }

        BusinessMgrContainer.register(mgr);
    }

    private static void register(Graph mgr, List<Class> types) {
        AlohaRecord<Schema<?>, ?> record = AlohaRecordFactory.create(mgr);
        if (record != null) {
            String key = record.getName();
            if (records.containsKey(key)) {
                AlohaRecord<Schema<?>, ?> exists = records.get(key);
                if (exists.isOneToMany() && !record.isOneToMany()) {
                    record.getOneToManyMgrs().putAll(exists.getOneToManyMgrs());
                } else if (!exists.isOneToMany() && record.isOneToMany()) {
                    exists.getOneToManyMgrs().putAll(record.getOneToManyMgrs());
                    record = exists;
                } else if (exists.isOneToMany() && record.isOneToMany()) {
                    record.getOneToManyMgrs().putAll(exists.getOneToManyMgrs());
                } else if (!exists.getOneToManyMgrs().isEmpty() && record.getOneToManyMgrs().isEmpty()) {
                    record.getOneToManyMgrs().putAll(exists.getOneToManyMgrs());
                }
            }

            records.put(key, record);
            BusinessMgrContainer.register(mgr, types);
        }

    }

    private static void register(ITransactionMgt mgr) {
        if (mgr != null) {
            try {
                dataMgrs.put(mgr.getClass(), mgr);
                AlohaRecordFactory.create(mgr).forEach(
                    ReflectiveJoinTool::registerRecord);
                BusinessMgrContainer.register(mgr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void register(CRUD mgr, List<Class> types) throws Exception {
        AlohaRecord<Schema<?>, ?> record = AlohaRecordFactory.create(mgr);
        registerConceptual(record);
        BusinessMgrContainer.register(mgr, types);
    }

    private static void register(CRUD.Family mgr, List<Class> types) throws Exception {
        try {
            AlohaRecord<Schema<?>, ?> record = AlohaRecordFactory.create(mgr);
            registerConceptual(record);
            BusinessMgrContainer.register(mgr, types);
        } catch (Exception var3) {
            var3.printStackTrace();
        }

    }

    private static void registerRecord(AlohaRecord<Schema<?>, ?> record) {
        if (record != null) {
            if (records.containsKey(record.getName())) {
                String var10000 = record.getName();
                System.out.println("[EXISTS]  " + var10000 + " " + records.get(record.getName()));
                System.out.println("     [register ]  " + record);
            }

            if (record.isTxChild()) {
                AlohaColumn parentColumn = record.getColumns().get(1);
                if (records.containsKey(parentColumn.getForeignRecord())) {
                }
            } else if (record.isTx()) {
                List<AlohaRecord<Schema<?>, ?>> child = findChildOrDependant(record.getName());
                if (!child.isEmpty()) {
                    record.setChildOrDependant(child.get(0));
                }
            }

            records.put(record.getName(), record);
        }
    }

    public static
    List<AlohaRecord<Schema<?>, ?>>
    findChildOrDependant(
        String parentName ) {

        List<AlohaRecord<Schema<?>, ?>> childOrDependants = new ArrayList<>();
        records.values().forEach(
            (record)->{
                if (record.getColumns().size() >= 2) {
                    AlohaColumn parentColumn = record.getColumns().get(1);
                    if (parentName.equals(parentColumn.getForeignRecord())) {
                        childOrDependants.add(record);
                    }
                }
            });
        return childOrDependants;
    }

    @SuppressWarnings("unchecked")
    private static
    void
    registerConceptual(AlohaRecord<Schema<?>,?> conceptual) {

        if (conceptual == null)
            return;
        if (conceptuals.containsKey(conceptual.getName())) {
            System.out.println("[EXISTED]  " + conceptual.getName() + " " + conceptuals.get(conceptual.getName()));
        }
        conceptuals.put(conceptual.getName(), conceptual);
    }

    public static
    Collection<AlohaRecord<Schema<?>,?>>
    records() {
        return records.values();
    }

    public static
    Collection<AlohaRecord<Schema<?>,?>>
    conceptuals() {
        return conceptuals.values();
    }

    public static AlohaRecord<Schema<?>, ?> recordOf(String entityName) {
        if (conceptuals.containsKey(entityName)) {
            return conceptuals.get(entityName);
        } else if (records.containsKey(entityName)) {
            return records.get(entityName);
        } else {
            return removedRecords.containsKey(entityName) ? removedRecords.get(entityName) : null;
        }
    }

    public static AlohaRecord<Schema<?>, ?>
    recordByRepsName(
        String repsName) {

        for(AlohaRecord<Schema<?>,?> record : records()) {
            if (record.getReprName().equals(repsName))
                return record;
        }
        throw new RuntimeException("Schema Not Found : " + repsName);
    }

    public static
    ImmutValues<String>
    masters() {

        return collectRecords(
            AlohaRecord::isMaster);
    }

    public static
    ImmutValues<String>
    cores() {

        return collectRecords(
            AlohaRecord::isCore);
    }

    public static
    ImmutValues<String>
    relations() {

        return collectRecords(
            AlohaRecord::isRelation);
    }

    public static
    ImmutValues<String>
    chains() {

        return collectRecords(
            AlohaRecord::isChain);
    }

    public static
    ImmutValues<String>
    arrowTrees() {

        return collectRecords(
            AlohaRecord::isArrowTree);
    }

    public static
    ImmutValues<String>
    distinctTrees() {

        return collectRecords(
            AlohaRecord::isDistinctTree);
    }

    public static
    ImmutValues<String>
    nonCores() {

        return collectRecords(
            AlohaRecord::nonMaster);
    }

    public static
    ImmutValues<String>
    txs() {

        return collectRecords(
            (record)->
                record.isTx() || record.isDerivedTx() || record.isFlowableTx());
    }

    public static
    ImmutValues<String>
    cruds() {

        return collectRecords(
            (record)->
                record.isCrud() || record.isFlowableTx());
    }

    public static
    ImmutValues<String>
    crudFamilies() {

        return collectRecords(
            (record)->
                record.isCrudFamily() || record.isFlowableTx());
    }

    public static
    ImmutValues<String>
    txChilds() {

        return collectRecords(
            AlohaRecord::isTxChild);
    }

    public static
    Class<? extends Schema>
    typeOf(
        String entityName) {

        return
            schemaOf(
                entityName).
            getClass();
    }

    public static
    String
    nameOf(
        Schema<?> schema) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.getEntity() == schema)
                return record.getName();
        }
        throw new RuntimeException("Not Found by : " + schema.getClass().getName());
    }

    public static
    Pivot<?>
    pivotOf(
        String entityName) {

        return
            (Pivot<?>)
                schemaOf(
                    entityName);
    }

    public static AlohaRecord<Schema<?>,?>
    recordOf(
        Pivot<?> pivot) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.getEntity() == pivot)
                return record;
        }
        throw new RuntimeException("Record Not Found : " + pivot);
    }

    public static
    TxEntity<?>
    txOf(
        String entityName) {

        return
            (TxEntity<?>)
                schemaOf(
                    entityName);
    }

    public static
    Schema<?>
    schemaOf(
        String entityName) {

        for(AlohaRecord<Schema<?>,?> record : conceptuals.values()) {
            if (record.getName().equals(entityName))
                return record.getEntity();
        }
        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.getName().equals(entityName))
                return record.getEntity();
        }
        throw new RuntimeException("Schema Not Found : " + entityName);
    }

    public static
    boolean
    existsOf(
        String entityName) {

        return records.containsKey(entityName) || conceptuals.containsKey(entityName);
    }

    @SuppressWarnings("all")
    public static
    <E extends CoreEntity,
    F extends AbstractField & StarView.Field<E>>
    CoreReadMgt.StarView<E,F>
    mdmOf(
        Pivot<?> pivotEntity) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.isMaster() && record.getEntity() == pivotEntity) {
                if (record.getDataMgt() instanceof IMasterDataMgt)
                    return (CoreReadMgt.StarView<E,F>) record.getDataMgt();
                else if (record.getDataMgt() instanceof Graph)
                    return ((Graph) record.getDataMgt()).coreReadMgt();
            }
        }
        throw new RuntimeException("Not Found : " + pivotEntity);
    }

    @SuppressWarnings("all")
    public static <
    E extends CoreEntity,
    H extends HierarchyEntity.Of.Tree<E>,
    F extends AbstractField & StarView.Field<E>,
    HF extends StarView.Hierarchy.FieldOf<H>>
    Graph.Tree.Distinct.StarArrow<E,H,F,HF>
    graphTreeStarArrowMgtOf(
        Pivot<?> pivotEntity) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.isArrowTree() && record.getEntity() == pivotEntity) {
                if (record.getDataMgt() instanceof Graph)
                    return (Graph.Tree.Distinct.StarArrow<E,H,F,HF>) record.getDataMgt();
            }
        }
        throw new RuntimeException("Not Found : " + pivotEntity);
    }

    @SuppressWarnings("all")
    public static <
    E extends CoreEntity,
    H extends HierarchyEntity.Of.Tree<E>,
    F extends AbstractField & StarView.Field<E>>
    Graph.Tree.Distinct<E,H,F>
    graphTreeDistinctMgtOf(
        Pivot<?> pivotEntity) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.isDistinctTree() && record.getEntity() == pivotEntity) {
                if (record.getDataMgt() instanceof Graph)
                    return (Graph.Tree.Distinct<E,H,F>) record.getDataMgt();
            }
        }
        throw new RuntimeException("Not Found : " + pivotEntity);
    }

    @SuppressWarnings("all")
    public static <
        E extends CoreEntity,
        H extends HierarchyEntity.Of.Tree<E>,
        F extends AbstractField & StarView.Field<E>>
    Graph.Tree<E,H,F>
    graphTreeMgtOf(
        Pivot<?> pivotEntity) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.isTree() && record.getEntity() == pivotEntity) {
                if (record.getDataMgt() instanceof Graph)
                    return (Graph.Tree<E,H,F> )record.getDataMgt();
            }
        }
        throw new RuntimeException("Not Found : " + pivotEntity);
    }

    @SuppressWarnings("all")
    public static <
        E extends CoreEntity,
        H extends HierarchyEntity.Of.Chain.Straight<E>,
        F extends AbstractField & StarView.Field<E>>
    Graph.Chain.Straight<E,H,F>
    graphChainMgtOf(
        Pivot<?> pivotEntity) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.isChain() && record.getEntity() == pivotEntity) {
                if (record.getDataMgt() instanceof Graph)
                    return (Graph.Chain.Straight<E,H,F>) record.getDataMgt();
            }
        }
        throw new RuntimeException("Not Found : " + pivotEntity);
    }

    public static
    ITransactionMgt
    txmOf(
        TxEntity<?> txEntity) {

        for(AlohaRecord<Schema<?>,?> record : records.values()) {
            if (record.isCore())
                continue;
            if (record.getEntity() == txEntity)
                return (ITransactionMgt)record.getDataMgt();
        }
        throw new RuntimeException("Not Found : " + txEntity);
    }

    public static
    CRUD
    crudOf(
        TxEntity<?> txEntity) {

        for(AlohaRecord<Schema<?>,?> record : conceptuals.values()) {
            if (record.getEntity() == txEntity)
                return (CRUD)record.getDataMgt();
        }
        throw new RuntimeException("Not Found : " + txEntity);
    }

    public static
    CRUD.Family
    crudChildOf(
        TxEntity<?> txEntity) {

        for(AlohaRecord<Schema<?>,?> record : conceptuals.values()) {
            if (record.getEntity() == txEntity)
                return (CRUD.Family)record.getDataMgt();
        }
        throw new RuntimeException("Not Found : " + txEntity);
    }

    @SuppressWarnings("all")
    public static
    ITransactionMgt
    txmOf(
        ChildTx<?,?> txEntity) {

        for(AlohaRecord record : records.values()) {
            if (record.isTxChild() == false)
                continue;
            if (record.getEntity() == txEntity)
                return (ITransactionMgt)record.getDataMgt();
        }
        throw new RuntimeException("Not Found : " + txEntity);
    }

    public static ImmutableArray<Schema<?>> referTo(Pivot<?> current) {
        List<Schema<?>> buf = new ArrayList();
        AlohaRecord<Schema<?>, ?> currentRecord = recordOf(current);
        Iterator var3 = records.values().iterator();

        while(var3.hasNext()) {
            AlohaRecord<Schema<?>, ?> record = (AlohaRecord)var3.next();
            if (record.getEntity() != current) {
                List<AlohaRecord<Schema<?>, ?>> referRecords = referFrom(record);
                if (referRecords.contains(currentRecord)) {
                    buf.add(record.getEntity());
                }
            }
        }

        if (buf.isEmpty()) {
            return ImmutableArray.emptyArray();
        } else {
            return (ImmutableArray)ImmutableArray.of(Schema.class, buf.toArray(new Schema[0]));
        }
    }

    private static List<AlohaRecord<Schema<?>, ?>> referFrom(AlohaRecord<? extends Schema<?>, ?> record) {
        List<AlohaRecord<Schema<?>, ?>> refers = new ArrayList();
        record.getColumns().forEach((column) -> {
            if (column.isForeign()) {
                AlohaRecord<Schema<?>, ?> refer = recordOf(column.getForeignRecord());
                if (refer != null) {
                    refers.add(refer);
                }
            }

        });
        return refers;
    }

    @SuppressWarnings("all")
    private static
    ImmutValues<String>
    collectRecords(
        Predicate<AlohaRecord> predicate) {

        return
            ImmutValues.of(
                records.values().
                    stream().
                    filter(
                        predicate).
                    map(
                        AlohaRecord::getName).
                    collect(
                        Collectors.toList()).
                    toArray(
                        new String[0]));
    }

    public static boolean workflowEnabled() {
        for (var record : records.values()) {
            if (record.getEntity() instanceof MakeFlowable<?>) {
                return true;
            }
        }
        return false;
    }
}
