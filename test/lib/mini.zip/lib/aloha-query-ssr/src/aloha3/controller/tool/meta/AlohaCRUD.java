package aloha3.controller.tool.meta;

import aloha.mapping.read.IAttributeCondition;
import aloha.mapping.write.Persist;
import aloha.module.Assert;
import aloha.module.func.business.IMasterDataMgt;
import aloha.module.func.business.ITransactionMgt;
import aloha.module.object.DateTime;
import aloha.module.object.DateTime.YMDHMS;
import aloha.module.object.ImmutVOs;
import aloha.module.object.Immutable;
import aloha.module.object.MayNullVO;
import aloha.module.object.MayNullValue;
import aloha.module.object.NonEmptyVOs;
import aloha.module.object.Tuple;
import aloha3.controller.tool.query.crud.GraphMgr;
import aloha3.dml.NaturalTransformation;
import aloha3.mapping.read.Query;
import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.conceptual.WorkFlow;
import aloha3.module.function.business.conceptual.master.Graph;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.master.PivotReadMgt;
import aloha3.module.function.business.master.RelationMgr;
import aloha3.module.function.business.master.coc.StateField;
import aloha3.module.function.business.master.coc.WorkFlowField;
import aloha3.module.function.business.transaction.DerivedTxIntAFKMgt;
import aloha3.module.function.business.transaction.DerivedTxLongAFKMgt;
import aloha3.module.function.business.transaction.DerivedTxMgt;
import aloha3.module.function.business.transaction.TxIntFKMgt;
import aloha3.module.function.business.transaction.TxLongFKMgt;
import aloha3.module.function.business.transaction.TxMgtUnsafe;
import aloha3.module.function.business.transaction.TxStarViewMgt;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.CDC;
import aloha3.module.object.model.read.Chain;
import aloha3.module.object.model.read.Tree;
import aloha3.module.object.record.AbstractColumn;
import aloha3.module.object.record.Instance;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.RelationEntity;
import aloha3.module.object.record.master.SealedPivot;
import aloha3.module.object.record.master.read.coc.Cancel;
import aloha3.module.object.record.master.read.meta.Read;
import aloha3.module.object.record.master.spec.meta.Pivot;
import aloha3.module.object.record.meta.master.Core;
import aloha3.module.object.record.meta.master.FixedAttribute;
import aloha3.module.object.record.meta.master.Relation;
import aloha3.module.object.record.meta.transaction.TxIntFK;
import aloha3.module.object.record.transaction.SealedTxParent;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import aloha3.module.object.record.transaction.opt.spec.MakeFlowable;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractView;
import aloha3.module.object.view.FlowableField;
import aloha3.module.object.view.Isomorphic;
import aloha3.module.object.view.StarView;
import aloha3.module.object.view.TemporalView;
import aloha3.module.object.view.TxStarView;
import aloha3.module.object.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static aloha3.controller.Server.conceptual;
import static aloha3.controller.Server.container;
import static aloha3.controller.tool.meta.MetaManager.decapitalize;

public class AlohaCRUD {
    static final String WORK_FLOW = "WorkFlow";
    static final String STATE = "State";
    static final String GRAPH = "Graph";

    public static final class GraphField
        extends AbstractField {
        public final Member.Mandatory<Integer> GraphId = mandatory("GraphId", Integer.class);
        public final Member.Optional<String> WorkFlowName = optional("WorkFlowName", String.class);
        public final Member.Mandatory<String> Graph = mandatory("Graph", String.class);
    }
    public static final class CancelField
        extends AbstractField {
        public final Member.Mandatory<Integer> ForeignId = mandatory("ForeignId", Integer.class);
        public final Member.Mandatory<YMDHMS> RegTime = mandatory("RegTime", YMDHMS.class);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <
        F extends AbstractField & StarView.Field<?>>
    MayNullVO<StarView.Read<F>>
    starViewOfMaster(
        Number id,
        String mgrName,
        ServiceContainer container) {

        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (
                mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric &&
                    mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    (MayNullVO)mdmGeneric.
                        createView(id.intValue(), YMDHMS.current());
            } else if (
                mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric &&
                    mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    (MayNullVO)mdmGeneric.
                        createView(id.intValue(), YMDHMS.current());
            } else if (
                mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric &&
                    mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    (MayNullVO)mdmGeneric.
                        createView(id.intValue(), YMDHMS.current());
            }
        }

        // tx
        for (ITransactionMgt txm: container.allTxM()) {
            if (txm instanceof TxStarViewMgt<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                throw new RuntimeException("Not support read tx starView for " + mgrName);
            }
        }
        return MayNullVO.nullInstance();
    }

    public static
    MayNullVO<? extends Isomorphic.Read<?>>
    starView(
        Number id,
        String mgrName,
        ServiceContainer container) {

        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (
                mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric &&
                    mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    mdmGeneric.
                        createView(id.intValue(), YMDHMS.current());
            } else if (
                mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric &&
                    mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    mdmGeneric.
                        createView(id.intValue(), YMDHMS.current());
            } else if (
                mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric &&
                    mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    mdmGeneric.
                        createView(id.intValue(), YMDHMS.current());
            }
        }

        // tx
        for (ITransactionMgt txm: container.allTxM()) {
            if (txm instanceof TxStarViewMgt<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    txmGeneric.
                        createView(id.longValue());
            }
        }
        return MayNullVO.nullInstance();
    }

    @SuppressWarnings(value = {"unchecked", "rawtypes"})
    public static <F extends AbstractField & StarView.Field<?>, HF extends StarView.Hierarchy.FieldOf<?>>
    ImmutVOs<StarView.Hierarchy.Read<HF>>
    starViewsOfGraphFK(
        String pivot,
        YMDHMS asOf
    ) {
        List<StarView.Hierarchy.Read<HF>> results = new ArrayList<>();
        conceptual().all().forEach(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm &&
                hm.hierarchyEntity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {

                hm.coreMgr().selectAllCores(asOf);
                String formMgr = hm.coreMgr().entity().getClass().getSimpleName();
                starViewsOfGraph(formMgr, asOf).forEach(pair -> {
                    // getAllNestedElements();
                    var result = getAllNestedElements((Tree.StarArrow)pair.right()).asList();
                    results.addAll(result);
                });
                // HierarchyMgr.Tree.StarArrow mgr = (HierarchyMgr.Tree.StarArrow)hm.hierarchyMgr();
            }
        });
        return ImmutVOs.create(results);
        // throw new RuntimeException("xxx");
    }
    
    public static <F extends AbstractField & StarView.Field<?>, HF extends StarView.Hierarchy.FieldOf<?>>
    ImmutVOs<StarView.Hierarchy.Read<HF>>
    getAllNestedElements(Tree.StarArrow<F, HF> treeRead) {
        List<StarView.Hierarchy.Read<HF>> result = new ArrayList<>();
        collectNestedElements(treeRead, result);
        return ImmutVOs.create(result);
    }

    private static <F extends AbstractField & StarView.Field<?>, HF extends StarView.Hierarchy.FieldOf<?>>
    void collectNestedElements(
        Tree.StarArrow<F, HF> treeRead,
        List<StarView.Hierarchy.Read<HF>> collector) {

        // 1. Collect all leaves NestedElement
        treeRead.arrowToLeaves().asList().forEach(leaf -> {
            collector.add(leaf.left());
        });

        // 2. Recursive collect all branches NestedElement
        treeRead.arrowToBranches().asList().forEach(branch -> {
            collector.add(branch.left());
            collectNestedElements(branch.right(), collector);
        });
    }

    @SuppressWarnings(value = {"unchecked", "rawtypes"})
    public static 
    List<Tuple.Pair<Core.Read<aloha3.module.object.record.master.coc.Graph>, Immutable>>
    starViewsOfGraph(
        String pivot,
        YMDHMS asOf
    ) {
        List<Tuple.Pair<Core.Read<aloha3.module.object.record.master.coc.Graph>, Immutable>> results = new ArrayList<>();
        conceptual().all().forEach(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectAllGraphOfThisConcept(asOf).foreach(graph -> {
                    try {
                        hm.
                            createModel((Core.Read) graph, asOf).
                            unlessNull_((model) -> 
                                results.add(
                                    Tuple.Pair.of(
                                        (Core.Read) graph, 
                                        (Tree.Star)model)));
                    } catch (Exception e) {
                        System.err.println("Never, Tree invalid:" + e.getMessage());
                    }
                });
            }
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectAllGraphOfThisConcept(asOf).foreach(graph -> {
                    try {
                        hm.
                            createModel((Core.Read) graph, asOf).
                            unlessNull_((model) -> 
                                results.add(
                                    Tuple.Pair.of(
                                        (Core.Read) graph, 
                                        (Tree.StarArrow)model)));
                    } catch (Exception e) {
                        System.err.println("Never, StarArrow Tree invalid:" + e.getMessage());
                    }
                });
            }
            // Chain
            if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectAllGraphOfThisConcept(asOf).foreach(graph -> {
                    try {
                        hm.
                            createModel((Core.Read) graph, asOf).
                            unlessNull_((model) -> 
                                results.add(
                                    Tuple.Pair.of(
                                        (Core.Read) graph, 
                                        (Chain.Straight.Star)model)));
                    } catch (Exception e) {
                        System.err.println("Never, Chain invalid:" + e.getMessage());
                    }
                });
            }
            // TODO support more
        });
        return results;
    }

    @SuppressWarnings(value = {"unchecked", "rawtypes"})
    public static 
    void
    deleteOfGraph(
        int id,
        String pivot
    ) {
        YMDHMS asOf = YMDHMS.current();
        conceptual().all().forEach(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectGraph(id, asOf).unlessNull_(graph -> {
                    hm.deleteGraph((Core.Read<aloha3.module.object.record.master.coc.Graph>)graph, asOf);
                });
            }
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectGraph(id, asOf).unlessNull_(graph -> {
                    hm.deleteGraph((Core.Read<aloha3.module.object.record.master.coc.Graph>)graph, asOf);
                });
            }
            // Chain
            if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectGraph(id, asOf).unlessNull_(graph -> {
                    hm.deleteGraph((Core.Read<aloha3.module.object.record.master.coc.Graph>)graph, asOf);
                });
            }
            // TODO support more
        });
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static 
    Optional<Tuple.Pair<Core.Read<aloha3.module.object.record.master.coc.Graph>, Immutable>>
    starViewOfGraph(
        Integer pivotId,
        String pivot,
        YMDHMS asOf
    ) {
        List<Tuple.Pair<Core.Read<aloha3.module.object.record.master.coc.Graph>, Immutable>> results = new ArrayList<>();
        conceptual().all().forEach(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectGraph(pivotId, asOf).unlessNull_(graph ->
                    hm.
                        createModel((Core.Read) graph, asOf).
                        unlessNull_((model) ->
                            results.add(
                                Tuple.Pair.of(
                                    (Core.Read) graph,
                                    (Tree.Star)model))));
            }
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectGraph(pivotId, asOf).unlessNull_(graph ->
                    hm.
                        createModel((Core.Read) graph, asOf).
                        unlessNull_((model) ->
                            results.add(
                                Tuple.Pair.of(
                                    (Core.Read) graph,
                                    (Tree.StarArrow)model))));
            }
            // Chain
            if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.selectGraph(pivotId, asOf).unlessNull_(graph ->
                    hm.
                        createModel((Core.Read) graph, asOf).
                        unlessNull_((model) ->
                            results.add(
                                Tuple.Pair.of(
                                    (Core.Read) graph,
                                    (Chain.Straight.Star)model))));
            }
            // TODO support more
        });
        return results.isEmpty() ? Optional.empty() : Optional.of(results.getFirst());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    MayNullVO<Core.Read<aloha3.module.object.record.master.coc.Graph>>
    coreReadOfGraph(
        Integer pivotId,
        String pivot,
        YMDHMS asOf
    ) {

        return conceptual().all().stream().map(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.selectGraph(pivotId, asOf);
            }
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.selectGraph(pivotId, asOf);
            }
            // Chain
            if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.selectGraph(pivotId, asOf);
            }
            // TODO support more
            return MayNullVO.nullInstance();
        }).filter(it -> it != MayNullVO.nullInstance()).findFirst().orElse(MayNullVO.nullInstance());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <
        F extends AbstractField & StarView.Field<?>>
    void 
    updateOfGraph(
        String pivot,
        Core.Read<aloha3.module.object.record.master.coc.Graph> graphRead, 
        YMDHMS asOf, 
        Tuple.Pair<StarView.Read<F>, StarView.Read<F>>[] newLinks
    ) {
        conceptual().all().forEach(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.update(graphRead, asOf, newLinks);
            }
            // if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
            //     hm.update(graphRead, newLinks);
            // }
            // Chain
            // if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
            //     hm.update(graphRead, asOf, newLinks);
            // }
            // TODO support more
        });
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <
        F extends AbstractField & StarView.Field<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    void
    updateOfGraph(
        String pivot,
        Core.Read<aloha3.module.object.record.master.coc.Graph> graphRead,
        Tuple.Triplet<
            StarView.Read<F>,
            StarView.Read<F>,
            StarView.Hierarchy.Write.New<HF>>[] newLinks
    ) {
        conceptual().all().forEach(c -> {
            // Tree
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.update(graphRead, newLinks);
            }
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                hm.update(graphRead, DateTime.YMDHMS.current(), newLinks);
            }
            // Chain
            // if (c instanceof Graph.Chain.Straight.StarArrow hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
            //     hm.update(graphRead, newLinks);
            // }
            // TODO support more
        });
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    public static <
        F extends AbstractField & StarView.Field<?>>
    Persist.Value<Core.Read<aloha3.module.object.record.master.coc.Graph>> 
    saveOfGraph(
        String pivot,
        Tuple.Pair<StarView.Read<F>, StarView.Read<F>>[] newLinks
    ) {
        // Normal loop
        for (final var c : conceptual().all()) {
            // Tree
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.save(newLinks);
            }
            // if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
            //     return hm.save(newLinks);
            // }
            // Chain
            if (c instanceof Graph.Chain.Straight.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.save(newLinks);
            }
            // TODO support more
        }
        throw new RuntimeException("Not support save graph for " + pivot);
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    public static <
        F extends AbstractField & StarView.Field<?>,
        HF extends StarView.Hierarchy.FieldOf<?>>
    Persist.Value<Core.Read<aloha3.module.object.record.master.coc.Graph>> 
    saveOfGraph(
        String pivot,
        Tuple.Triplet<
            StarView.Read<F>,
            StarView.Read<F>,
            StarView.Hierarchy.Write.New<HF>>[] newLinks
    ) {
        // Normal loop
        for (final var c : conceptual().all()) {
            // Tree
            if (c instanceof Graph.Tree.Distinct.StarArrow.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.save(newLinks);
            }
            if (c instanceof Graph.Tree.Distinct.Generic hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
                return hm.save(newLinks);
            }
            // Chain
            // if (c instanceof Graph.Chain.Straight.StarArrow hm && hm.coreMgr().entity().getClass().getSimpleName().equalsIgnoreCase(pivot)) {
            //     return hm.save(newLinks);
            // }
            // TODO support more
        }
        throw new RuntimeException("Not support save graph for " + pivot);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static
    ImmutVOs<Isomorphic.StarView.Read<?>>
    allStarViewsMaster(
        PivotReadMgt mdm,
        YMDHMS now) {

        if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?,?,?,?,?> mdmGeneric) {
            return
                mdmGeneric.
                    selectAllCores(now).
                    unlessEmpty(
                        allPivots ->
                            mdmGeneric.createViews((NonEmptyVOs)allPivots, now));
        } else if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric) {
            return
                mdmGeneric.
                    selectAllCores(now).
                    unlessEmpty(
                        allPivots ->
                            mdmGeneric.createViews((NonEmptyVOs)allPivots, now));
        } else if (mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric) {
            return
                mdmGeneric.
                    selectAllRelations(now).
                    unlessEmpty(
                        allPivots ->
                            mdmGeneric.createViews((NonEmptyVOs)allPivots, now));
        }
        return ImmutVOs.emptyVOs();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <E extends CoreEntity, F extends AbstractField & StarView.Field<E>>
    ImmutVOs<
        OneToOne.MayZero<
            CDC<E, F>, 
            Cancel<E>>>
    starViewsCDC(
        String mgrName,
        ServiceContainer container) {

        // master
        List<OneToOne.MayZero<CDC<E, F>, Cancel<E>>> histories = new ArrayList();
        for (IMasterDataMgt mdm : container.allMDM()) {
            if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric && mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                
                selectAllCoresMayCancel(mdmGeneric.entity(), YMDHMS.current()).
                    foreach(
                        pivot ->
                            mdmGeneric.cdcMayCancel(pivot.coreId()).unlessNull_(cdc -> 
                                histories.add((OneToOne.MayZero)cdc)));
            } else if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric && mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                selectAllCoresMayCancel(mdmGeneric.entity(), YMDHMS.current()).
                    foreach(
                        pivot ->
                            mdmGeneric.cdcMayCancel(pivot.coreId()).unlessNull_(cdc ->
                                histories.add((OneToOne.MayZero)cdc)));
            }
        }
        return ImmutVOs.create(histories);
    }

    private static <E extends CoreEntity>
    ImmutVOs<Core.Read<E>>
    selectAllCoresMayCancel(
        E entity,
        YMDHMS asOf) {
        return 
            Query.select(
                Core.Read.
                    createCriteria(entity).
                    andRegTime(IAttributeCondition.OPERATOR.LESS_THAN_EQUAL, asOf));
    }

    public static
    ImmutVOs<? extends AbstractView<?>>
    starViews(
        String mgrName,
        ServiceContainer container) {
        return starViewsByTime(mgrName, container, MayNullValue.nullInstance());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <
        E extends MakeFlowable<?> & SealedTxParent<? extends AbstractColumn.PKAndMore<?>>, 
        F extends FlowableField<E>> 
    ImmutVOs<
        OneToOne<
            OneToOne<
                AbstractView<F>, 
                StarView.Read<WorkFlowField>>, 
            StarView.Read<StateField>>>
    workflowTransitions(
        String mgrName,
        ServiceContainer container) {

        return starViews(mgrName, container).map(v -> {
            if (v instanceof TxStarView.Read txv) {
                OneToOne<
                    OneToOne<
                        AbstractView<F>,
                        StarView.Read<WorkFlowField>>,
                    StarView.Read<StateField>> o2o = WorkFlow.currentCompositeView(txv.txRead());
                return OneToOne.of(
                    OneToOne.of(
                        txv, // Use starView, not normal view
                        o2o.left.right
                    ),
                    o2o.right
                );
            } else {
                throw new RuntimeException("Not support read workflow transitions for " + mgrName);
            }
        });
    }
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    MayNullVO<TemporalView.Read<?>>
    temporalViewById(
        Integer id,
        String mgrName,
        Integer rootId,
        MayNullValue<DateTime.YMD> asOf,
        ServiceContainer container) {

        return 
            temporalViews(mgrName, rootId, asOf, container).
                find( temporalRead ->
                    ((TemporalView.Read)temporalRead).mandatoryValue(f->
                        ClassFinder.getFieldMembers((AbstractField) f).getFirst()).equals(id));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    ImmutVOs<TemporalView.Read<?>>
    temporalViews(
        String mgrName,
        Integer rootId,
        MayNullValue<DateTime.YMD> asOf,
        ServiceContainer container) {

        for (IMasterDataMgt mdm: container.allMDM()) {

            if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                return
                    asOf.apply(
                        ymd ->
                            mdmGeneric.selectCoreByPK(rootId).apply(
                                pivotRead ->
                                    mdmGeneric.
                                        createAttributeTemporalViews(
                                            (aloha3.module.object.record.master.read.meta.Read)pivotRead,
                                            ymd),
                                ImmutVOs::emptyVOs),
                        () ->
                            mdmGeneric.selectCoreByPK(rootId).apply(
                                pivotRead ->
                                    mdmGeneric.
                                        createAttributeTemporalViews(
                                            (aloha3.module.object.record.master.read.meta.Read)pivotRead),
                                ImmutVOs::emptyVOs));
            }
        }

        throw new RuntimeException("Not support read temporal Views for " + mgrName);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    ImmutVOs<? extends AbstractView<?>>
    temporalViewsByTime(
        String mgrName,
        Integer id,
        ServiceContainer container,
        DateTime.YMD ymd) {
        
        for (IMasterDataMgt mdm: container.allMDM()) {

            if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                return
                    mdmGeneric.selectCoreByPK(id).apply(
                        pivotRead ->
                            mdmGeneric.
                                createAttributeTemporalViews(
                                    (Read)pivotRead,
                                    ymd),
                        ImmutVOs::emptyVOs);
            }
        }
        throw new RuntimeException("Not support read temporal Views for " + mgrName);
    }


    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    ImmutVOs<? extends AbstractView<?>>
    starViewsByTime(
        String mgrName,
        ServiceContainer container,
        MayNullValue<YMDHMS> txTimeHistory) {

        final var time = txTimeHistory.apply(v -> v,
            YMDHMS::current);
        final var yearMonth = time.getYMD().asYearMonth();

        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (mdm instanceof PivotReadMgt mdmGeneric &&
                mdmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {

                if (mdmGeneric.entity() instanceof aloha3.module.object.record.master.spec.RelationEntity relationEntity) {
                    return
                        relationStarViewJoinFKAndAFK(
                            container,
                            time,
                            mdmGeneric,
                            relationEntity);
                } else {
                    return
                        (ImmutVOs)allStarViewsMaster(
                            mdmGeneric,
                            time
                        );
                }
            }
        }

        // tx
        for (ITransactionMgt txm: container.allTxM()) {
            if (txm instanceof TxIntFKMgt.StarView<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {

                final var mgrNameFK = txmGeneric.entity().getForeignEntity().getSimpleName();

                for (IMasterDataMgt mdm: container.allMDM()) {
                    if (mdm instanceof PivotReadMgt mdmGeneric &&
                        mdmGeneric.entity().getClass().getSimpleName().equals(mgrNameFK)) {

                        if (mdmGeneric.entity() instanceof aloha3.module.object.record.master.spec.RelationEntity) {
                            return
                                allStarViewsMaster(
                                    mdmGeneric,
                                    time
                                ).apply(
                                    fkViews ->
                                        NaturalTransformation.
                                            fromRelation(
                                                (ImmutVOs) fkViews,
                                                time).
                                            join((TxMgtUnsafe.IntFK)txmGeneric).
                                            done().
                                            map(o2o -> ((OneToOne )o2o).right),
                                    ImmutVOs::emptyVOs);
                        } else {
                            return
                                allStarViewsMaster(
                                    mdmGeneric,
                                    time
                                ).apply(
                                    fkViews ->
                                        NaturalTransformation.
                                            fromCore(
                                                (ImmutVOs) fkViews,
                                                time).
                                            join((TxMgtUnsafe.IntFK)txmGeneric).
                                            done().
                                            map(o2o -> ((OneToOne )o2o).right),
                                    ImmutVOs::emptyVOs);
                            // TODO support o2o???
                            //apply(
                            //    o2os ->
                            //        JsonMappingFrom.views(
                            //            (ImmutVOs<OneToOne>) o2os,
                            //            (OneToOne o2o) ->
                            //                JsonMappingFrom.view((Isomorphic.Read)o2o.left).
                            //                    addAll(
                            //                        JsonMappingFrom.view((Isomorphic.Read)o2o.right))),
                            //    () ->
                            //        Json.createArrayBuilder().build()),
                            //() ->
                            //    Json.createArrayBuilder().build());
                        }
                    }
                }

                // StarArrow Support 1: Tx FK of starArrow hierarchy, return starViewsOfGraphFK
                var fkViews = starViewsOfGraphFK(mgrNameFK, YMDHMS.current());
                // Not work by join
                // NaturalTransformation.
                //     fromRelation(
                //         (ImmutVOs) fkViews,
                //         time).
                //     join((TxMgtUnsafe.IntFK)txmGeneric).
                //     done().map(o2o -> ((OneToOne )o2o).right);
                return fkViews.unlessEmpty(
                    vos ->
                        txmGeneric.selectTxsByFK(vos.map(v -> (aloha3.module.object.record.master.read.meta.Read)v.pivotRead())).
                            unlessEmpty(records -> txmGeneric.createViews((NonEmptyVOs)records)));
            }
            else if (txm instanceof TxLongFKMgt.StarView<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                // TODO make DateTime.YMD.today().asYearMonth() as search property
                return
                    //JsonMappingFrom.views(
                        txmGeneric.
                            selectTxsOf(yearMonth).
                            unlessEmpty(
                                txs ->
                                    txmGeneric.createViews((NonEmptyVOs)txs));
            }
            else if (txm instanceof DerivedTxMgt.StarView<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                // TODO make DateTime.YMD.today().asYearMonth() as search property
                return
                    //JsonMappingFrom.views(
                        txmGeneric.
                            selectTxsOf(yearMonth).
                            unlessEmpty(
                                derivedTxs ->
                                    txmGeneric.createViews((NonEmptyVOs)derivedTxs));
            }
            else if (txm instanceof DerivedTxIntAFKMgt.StarView<?,?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    //JsonMappingFrom.views(
                        txmGeneric.
                            selectTxsOf(yearMonth).
                            unlessEmpty(
                                derivedTxs ->
                                    txmGeneric.createViews((NonEmptyVOs)derivedTxs));
            }
            else if (txm instanceof DerivedTxLongAFKMgt.StarView<?,?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    //JsonMappingFrom.views(
                        txmGeneric.
                            selectTxsOf(yearMonth).
                            unlessEmpty(
                                derivedTxs ->
                                    txmGeneric.createViews((NonEmptyVOs)derivedTxs));
            }

            // tx model, return empty
            else if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmGeneric &&
                txmGeneric.childTx().getClass().getSimpleName().equals(mgrName)) {
                return ImmutVOs.emptyVOs();
            }
        }

        // Support workflow meta get all data: aloha-meta/star-views?mgrName=WorkFlow
        if (WORK_FLOW.equals(mgrName)) {
            return WorkFlow.allWorkFlows(time);
        }
        // Support workflow meta get all data: aloha-meta/star-views?mgrName=State
        //TODO WorkFlow.allStates() is YMDHMS.current()
        if (STATE.equals(mgrName)) {
            return WorkFlow.allStates();
        }
        
        if (GRAPH.equals(mgrName)) {
            return GraphMgr.getAllGraphs().map(graphRead ->
                View.Builder.
                    create(GraphField.class).
                    setMandatoryValue(
                        f -> f.GraphId,
                        graphRead.coreId()).
                    setMandatoryValue(
                        f -> f.Graph,
                        "graph LR").
                    build());
        }
        
        // Final try
        // StarArrow Support 2: Tx FK of starArrow hierarchy, return starViewsOfGraphFK
        System.out.println("[WARN] Not support read starViews for" + mgrName);
        return starViewsOfGraphFK(mgrName, YMDHMS.current());
        // throw new RuntimeException("Not support read starViews for " + mgrName);
    }

    private static
    ImmutVOs<? extends AbstractView<?>>
    relationStarViewJoinFKAndAFK(
        ServiceContainer container,
        YMDHMS now,
        PivotReadMgt<?,?> mdmGeneric,
        aloha3.module.object.record.master.spec.RelationEntity<?,?> relationEntity) {

        //final var fkId = decapitalize(relationEntity.getForeignKeyColumn().getJavaName());
        //final var fkStarViews = toIdMap(
        //    starViews(
        //        relationEntity.getForeignEntity().getSimpleName(),
        //        container),
        //    values ->
        //        values.getInt(fkId));
        //
        //final var afkId = decapitalize(relationEntity.getAdditionalForeignKeyColumn().getJavaName());
        //final var afkStarViews =  toIdMap(
        //    starViews(
        //        relationEntity.getAdditionalForeignEntity().getSimpleName(),
        //        container),
        //    values ->
        //        values.getInt(afkId));

        return
            (ImmutVOs)allStarViewsMaster(
                mdmGeneric,
                now
            );
            //.apply(
            //    views ->
            //        toJsonArray(
            //            JsonMappingFrom.views((ImmutVOs) views),
            //            (origin, builder) ->
            //                builder.
            //                    add(noId(fkId), fkStarViews.get(origin.getInt(fkId))).
            //                    add(noId(afkId), afkStarViews.get(origin.getInt(afkId)))),
            //    () ->
            //        Json.createArrayBuilder().build());
    }

    private static String noId(String name) {
        return name.replaceFirst("Id$", "");
    }

    //public static
    //void
    //upsertStarViews(
    //    JsonArray values,
    //    String mgrName,
    //    ServiceContainer container) {
    //
    //    tryGroupingIfNoTxChildDetails(
    //        values,
    //        mgrName,
    //        container
    //    ).forEach(
    //        csvJson ->
    //            tryConvertUniqueKeyToPivotId(csvJson, mgrName, container).
    //                apply(
    //                    id ->
    //                        updateStarView(id, csvJson.asJsonObject(), mgrName, container),
    //                    () ->
    //                        saveStarView(csvJson.asJsonObject(), mgrName, container)));
    //}
    //
    //@SuppressWarnings({"unchecked", "rawtypes"})
    //private static MayNullValue<Integer>
    //tryConvertUniqueKeyToPivotId(
    //    JsonValue json,
    //    String mgrName,
    //    ServiceContainer container) {
    //
    //    for (IMasterDataMgt mdm: container.allMDM()) {
    //        if (mdm instanceof PivotReadMgt mdmGenericR &&
    //            mdm instanceof PivotReadMgt.StarViewConfig<?, ?> starViewConfig &&
    //            mdmGenericR.entity().getClass().getSimpleName().equals(mgrName)) {
    //
    //            for (AttributeEntity.One<?, ?, ?> attr : starViewConfig.attributeTypes().attrs()) {
    //                // isUnique
    //                if (FixedAttributeEntity.UniqueString.class.isAssignableFrom(attr.getClass())) {
    //                    try {
    //                        return
    //                            MayNullValue.of(
    //                                pivotReadOf(
    //                                    (FixedAttributeEntity.UniqueString) attr,
    //                                    json.
    //                                        asJsonObject().
    //                                        getString(
    //                                            decapitalize(attr.getClass().getSimpleName()))
    //                                ).rowId());
    //                    } catch (Exception e) {
    //                        return MayNullValue.nullInstance();
    //                    }
    //                }
    //            }
    //        }
    //    }
    //
    //    return MayNullValue.nullInstance();
    //}
    //
    //private static
    //JsonArray
    //tryGroupingIfNoTxChildDetails(
    //    JsonArray values,
    //    String mgrName,
    //    ServiceContainer container) {
    //
    //    for (ITransactionMgt txm: container.allTxM()) {
    //        // tx model
    //        if (
    //            txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?, ?, ?, ?, ?, ?> txmGeneric &&
    //            txmGeneric.entity().getClass().getSimpleName().equals(mgrName) &&
    //            txmGeneric.entity() instanceof IForeignEntity entityWithFk) {
    //            if (
    //                values.stream().noneMatch(value ->
    //                    value.asJsonObject().containsKey(MappingConst.DETAILS))) {
    //                return groupingTxChildDetails(values, entityWithFk);
    //            }
    //        }
    //    }
    //    return values;
    //}
    //
    //private static class GroupingTxChildKeys {
    //    private final Integer fk;
    //    private final Long txTime;
    //    private final JsonObject parentJsonObj;
    //
    //    public GroupingTxChildKeys(
    //        Map<String, String> values,
    //        IForeignEntity<?> entityWithFk) {
    //
    //        // Integer fk, Integer txTime, JsonObject originJsonObj) {
    //        this.fk = values.getInt(
    //            decapitalize(entityWithFk.getForeignKeyColumn().getJavaName()));
    //        this.txTime = values.getJsonNumber(MappingConst.TX_TIME).longValue();
    //        this.parentJsonObj = values;
    //    }
    //
    //    @Override
    //    public boolean equals(Object o) {
    //        if (this == o) return true;
    //        if (o == null || getClass() != o.getClass()) return false;
    //        GroupingTxChildKeys that = (GroupingTxChildKeys) o;
    //        return fk.equals(that.fk) && txTime.equals(that.txTime);
    //    }
    //
    //    @Override
    //    public int hashCode() {
    //        return Objects.hash(fk, txTime);
    //    }
    //}
    //
    //private static
    //JsonArray
    //groupingTxChildDetails(
    //    JsonArray values,
    //    IForeignEntity<?> entityWithFk) {
    //
    //    // grouping by fk and tx time
    //    return
    //        Func.apply(
    //            Json.createArrayBuilder(),
    //            arrayBuilder ->
    //                values.
    //                    stream().
    //                    collect(
    //                        Collectors.groupingBy(
    //                            value ->
    //                                new GroupingTxChildKeys(
    //                                    value.asJsonObject(),
    //                                    entityWithFk))).
    //                    forEach(
    //                        (groupKey, details) ->
    //                            Func.apply(
    //                                Json.createObjectBuilder(groupKey.parentJsonObj),
    //                                parent ->
    //                                    parent.add(
    //                                        MappingConst.DETAILS,
    //                                        Func.apply(
    //                                            Json.createArrayBuilder(),
    //                                            arrayDetailBuilder ->
    //                                                details.forEach(arrayDetailBuilder::add),
    //                                            JsonArrayBuilder::build)),
    //                                parent ->
    //                                    arrayBuilder.add(parent))),
    //            JsonArrayBuilder::build);
    //}

    // Copy from CsvMappingTo.pivotReadOf
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <
        E extends SealedPivot<?>,
        A extends FixedAttributeEntity.UniqueString<E>>
    Read<E>
    pivotReadOf(A key,String value) {

        return (Read<E>) Query.
            select(
                FixedAttribute.Read.
                    createStringCriteria(key).
                    andEqual(value)).
            apply(
                keyReads-> {
                    FixedAttribute.Read<A> keyRead = Assert.mustUnique(keyReads).mustNonNull();
                    Class<E> pivotClass = key.getForeignEntity();
                    if (CoreEntity.class.isAssignableFrom(pivotClass))
                        return Assert.mustUnique(
                                Query.select(Core.Read.createCriteria(
                                    (CoreEntity) Instance.of(pivotClass)).andPrimaryKey(keyRead.getPivotId()))).
                            mustNonNull();
                    else if ( RelationEntity.class.isAssignableFrom(pivotClass))
                        return Assert.mustUnique(Query.select(
                                (aloha3.module.object.record.meta.master.read.Relation.Criteria)
                                    Relation.Read.createCriteria(
                                            (RelationEntity)Instance.of(pivotClass)).
                                        unsafeAndPrimaryKey(keyRead.getPivotId()))).
                            mustNonNull();
                    else
                        throw new RuntimeException("Not Supported pivot:" + pivotClass.getName());
                },
                ()->
                {
                    throw new RuntimeException("KeyCode Not Found by " + value + "@" + key.getTABLE());
                });
    }
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    Persist.Value<? extends Number>
    saveStarView(
        String mgrName,
        Map<String, String> values,
        ServiceContainer container) {
        // TODO validate Unique / FixedAttr field

        final var now = YMDHMS.current();
        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (mdm instanceof PivotReadMgt mdmGenericR &&
                mdmGenericR.entity().getClass().getSimpleName().equals(mgrName)) {

                if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                    return
                        mdmGeneric.
                            save(
                                ParameterMappingTo.
                                    starView(
                                        values,
                                        (Class)mdmGeneric.field().getClass(),
                                        container),
                                now);
                } else if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric) {
                    return
                        mdmGeneric.
                            save(
                                ParameterMappingTo.
                                    starView(
                                        values,
                                        (Class)mdmGeneric.field().getClass(),
                                        container),
                                now);
                } else if (mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric) {
                    return
                        mdmGeneric.
                            save(
                                ParameterMappingTo.
                                    relationStarView(
                                        values,
                                        (Class)mdmGeneric.field().getClass(),
                                        container),
                                now);
                }
            }
        }

        // tx
        for (ITransactionMgt txm: container.allTxM()) {
            //    // tx model
            //    if (txm instanceof TxStarViewMgt.TxFamilyStarViewMgt<?,?,?, ?,?,?> txmGeneric &&
            //        txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
            //        return
            //            txmGeneric.save(
            //                JsonMappingTo.txModel(
            //                    values,
            //                    (Class)txmGeneric.field().getClass(),
            //                    (Class)txmGeneric.childTx().getClass(),
            //                    container));
            //    }
            //
            // tx star view
            if (txm instanceof TxStarViewMgt<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                return
                    txmGeneric.
                        save(
                            ParameterMappingTo.
                                txStarViewNewWithId(
                                    values,
                                    (Class)txmGeneric.field().getClass(),
                                    container));
            }
        }

        throw new RuntimeException("Not support create starViews for " + mgrName);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <E extends TxEntityIntFK.On<M> & MakeFlowable<E>, M extends Pivot<?>, F extends TxStarView.FieldOf.AndIntFK<E>>
    TxIntFK.Read<E>
    saveTxStarViewWithWorkFlow(
        String mgrName,
        Map<String, String> values,
        ServiceContainer container) {

        // tx
        for (ITransactionMgt txm: container.allTxM()) {
            // tx star view
            if (txm instanceof TxStarViewMgt<?,?,?> txmGeneric &&
                txmGeneric.entity().getClass().getSimpleName().equals(mgrName)) {
                
                return
                    _TxStarViewMapping.newTxStarViewWithTransition(
                        values,
                        (Class) txmGeneric.field().getClass(),
                        container);
            }
        }

        throw new RuntimeException("Not support create starViews for " + mgrName);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    Persist.Value<? extends Number>
    saveTemporalStarView(
        String mgrName,
        Map<String, String> values,
        ServiceContainer container) {

        final var now = YMDHMS.current();
        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (mdm instanceof PivotReadMgt mdmGenericR &&
                mdmGenericR.entity().getClass().getSimpleName().equals(mgrName)) {

                if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                    final var rootId = Integer.parseInt(values.get(decapitalize(mdmGeneric.field().unsafeCenterMember().name())));
                    final var rootRead = mdmGeneric.selectCoreByPK(rootId).mustNonNull();
                    return mdmGeneric.
                            save(
                                ParameterMappingTo.
                                    temporalAttributeView(
                                        values,
                                        (Class)mdmGeneric.temporalField().getClass(),
                                        rootRead,
                                        YMDHMS.current())).
                        then(() -> rootId);
                }
            }
        }
        throw new RuntimeException("Not support create starViews for " + mgrName);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    boolean
    updateStarView(
        Integer id,
        Map<String, String> values,
        String mgrName,
        ServiceContainer container) {
        // TODO validate Unique / FixedAttr field

        final var now = YMDHMS.current();
        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (mdm instanceof PivotReadMgt mdmGenericR &&
                mdmGenericR.entity().getClass().getSimpleName().equals(mgrName)) {

                if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                    return
                        mdmGeneric.
                            selectCoreByPK(id).
                            apply(
                                read ->
                                    mdmGeneric.
                                        save(
                                            ParameterMappingTo.
                                                starView(
                                                    values,
                                                    read,
                                                    (Class) mdmGeneric.field().getClass(),
                                                    now,
                                                    container)).
                                        thenReturn(true),
                                () ->
                                    false);
                } else if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric) {
                    
                    return
                        mdmGeneric.
                            selectCoreByPK(id).
                            apply(
                                read ->
                                    mdmGeneric.
                                        save(
                                            ParameterMappingTo.
                                                starView(
                                                    values,
                                                    read,
                                                    (Class) mdmGeneric.field().getClass(),
                                                    now,
                                                    container)).
                                        thenReturn(true),
                                () ->
                                    false);
                } else if (mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric) {

                    return
                        mdmGeneric.
                            selectRelationByPK(id).
                            apply(
                                read ->
                                    mdmGeneric.
                                        save(
                                            ParameterMappingTo.
                                                relationStarView(
                                                    values,
                                                    read,
                                                    (Class)mdmGeneric.field().getClass(),
                                                    now,
                                                    container)).
                                        thenReturn(true),
                                () ->
                                    false);
                }
            }
        }
        throw new RuntimeException("Not support update starViews for " + mgrName);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    boolean
    updateTemporalStarView(
        Integer id,
        Map<String, String> values,
        String mgrName,
        ServiceContainer container) {

        final var now = YMDHMS.current();
        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (mdm instanceof PivotReadMgt mdmGenericR &&
                mdmGenericR.entity().getClass().getSimpleName().equals(mgrName)) {

                if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                    final var rootId = Integer.parseInt(values.get(decapitalize(mdmGeneric.field().unsafeCenterMember().name())));
                    final var temporalRead = AlohaCRUD.temporalViewById(id, mgrName, rootId, MayNullValue.nullInstance(), container());
                    return
                        mdmGeneric.
                            modify(
                                ParameterMappingTo.
                                    temporalAttributeView(
                                        values,
                                        (TemporalView.Read)temporalRead.mustNonNull(),
                                        now)).
                            thenReturn(true);
                }
            }
        }
        throw new RuntimeException("Not support update starViews for " + mgrName);
    }

    public static
    boolean
    deleteStarView(
        int id,
        String mgrName,
        ServiceContainer container) {
        
        return deleteStarView(id, mgrName, MayNullValue.nullInstance(), container);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static
    boolean
    deleteStarView(
        int id,
        String mgrName,
        MayNullValue<Integer> rootId,
        ServiceContainer container) {
        // TODO validate Unique / FixedAttr field

        final var now = YMDHMS.current();
        // master
        for (IMasterDataMgt mdm: container.allMDM()) {
            if (mdm instanceof PivotReadMgt mdmGenericR &&
                mdmGenericR.entity().getClass().getSimpleName().equals(mgrName)) {
                if (mdm instanceof CoreMgr.StarView.TemporalAttribute.Generic<?, ?, ?, ?, ?> mdmGeneric) {
                    final var temporalRead = AlohaCRUD.
                        temporalViewById(
                            id, 
                            mgrName, 
                            rootId.assertNonNull(), 
                            MayNullValue.nullInstance(), 
                            container());
                    return
                        temporalRead.
                            apply(
                                read ->
                                    mdmGeneric.
                                        delete((TemporalView.Read)read).
                                        thenReturn(true),
                                () ->
                                    false);
                } else if (mdm instanceof CoreMgr.StarView.Generic<?, ?> mdmGeneric) {
                    return
                        mdmGeneric.
                            selectCoreByPK(id).
                            apply(
                                read ->
                                    mdmGeneric.
                                        delete(
                                            (Core.Read)read,
                                            now).
                                        thenReturn(true),
                                () ->
                                    false);
                } else if (mdm instanceof RelationMgr.StarView.Generic<?, ?, ?, ?> mdmGeneric) {

                    return
                        mdmGeneric.
                            createView(id, now).
                            apply(
                                read ->
                                    mdmGeneric.
                                        delete(
                                            (StarView.Relation.Read)read,
                                            now).
                                        thenReturn(true),
                                () ->
                                    false);
                }
            }
        }
        throw new RuntimeException("Not support Delete starViews for " + mgrName);
    }
}
