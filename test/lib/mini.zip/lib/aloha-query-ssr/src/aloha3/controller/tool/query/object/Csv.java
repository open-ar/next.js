package aloha3.controller.tool.query.object;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Csv {

    public static
    List<List<String>>
    parse(
        String csv) {
        
        if (csv == null || csv.isEmpty())
            return new ArrayList<List<String>>(); 
            
        return Array.map(
            csv.split("\n"),
            (line, index)->
                parseLine(line));
    }
    
    public static
    List<String>
    parseLine(
        String line) {

        if (line.endsWith("\n"))
            line = line.substring(0,  line.length()-1);
        if (line.endsWith("\r"))
            line = line.substring(0,  line.length()-1);
            
        List<String> csvLine = new ArrayList<String>();
        if (line.isEmpty())
            return csvLine;

        StringTokenizer st = new StringTokenizer(line, ",", true);
        
        String prevToken = "";
        while(st.hasMoreTokens()){
            String token = st.nextToken();
            if (token.equals(",")){
                csvLine.add(prevToken);
                prevToken = "";
            }else{
                prevToken = token;
            }

            if (prevToken.length() >= 2 &&
                prevToken.startsWith("\"") &&
                prevToken.endsWith("\"")) {
                
                prevToken = prevToken.substring(1,  prevToken.length()-1);
            }else  if (prevToken.startsWith("\"")) {
                StringBuilder sb = new StringBuilder(prevToken);
                while(st.hasMoreTokens()) {
                    token = st.nextToken();
                    sb.append(token);
                    if (token.endsWith("\""))
                        break;
                }
                prevToken = sb.toString();
                prevToken = prevToken.substring(1, prevToken.length() - 1);
            }
        }
        csvLine.add(prevToken);
        
        return csvLine;
    }

    public static
    String
    toCsv(
        List<List<String>> data) {
        
        StringBuilder csv = new StringBuilder();
        for(List<String> row : data){
            boolean first = true;
            for(String col : row){
                if (first)
                    first = false;
                else
                    csv.append(",");
                csv.append(col);
            }
            csv.append("\n");
        }
        
        return csv.toString();
    }

    public static
    String
    toCsvLine(
        List<String> row) {

        StringBuilder csv = new StringBuilder();
        boolean first = true;
        for(String col : row){
            if (first)
                first = false;
            else
                csv.append(",");
            csv.append(col);
        }

        return csv.toString();
    }

    public static
    List<List<String>>
    readCsv(
        Path path) {
        
        try{
            return Array.map(
                Files.readAllLines(path),
                (line, index)->
                    parseLine(line));
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }

    public static
    List<List<String>>
    readCsv(
        Path path,
        Charset encode) {

        try{
            return Array.map(
                Files.readAllLines(path, encode),
                (line, index)->
                    parseLine(line));
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }

    public static
    String
    readContext(
        Path path) {
        
        try{
            return new String(
                    Files.
                        readAllBytes(
                            path));
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }
    
}
