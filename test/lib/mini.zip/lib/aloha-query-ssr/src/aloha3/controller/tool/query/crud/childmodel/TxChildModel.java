package aloha3.controller.tool.query.crud.childmodel;

import aloha.module.object.ImmutVOs;
import aloha.module.object.ValueObject;
import aloha3.module.object.model.OneToOne;
import aloha3.module.object.model.read.TxModel.AbstractFlatField;
import aloha3.module.object.record.transaction.read.meta.Read;
import aloha3.module.object.view.AbstractField;
import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.TxStarView.Field;
import aloha3.module.object.view.View;

import java.util.Collections;
import java.util.List;

public abstract class TxChildModel<F extends AbstractField & Field<?>, T extends ValueObject, FF extends AbstractFlatField<F, ?>> implements ValueObject {

    public Mandatory<Long> PK() {
        ImmutVOs<View<FF>> views = this.getFlatViews();
        return views.size() == 0 ? null : ((AbstractFlatField)((View)views.eltAt(0)).field()).PK();
    }

    public abstract T view();

    public abstract ImmutVOs<View<FF>> getFlatViews();

    public abstract ImmutVOs<? extends Read<?>> children();

    public aloha3.module.object.view.TxStarView.Read<F> getTxView() {
        return this.view() instanceof OneToOne ? (aloha3.module.object.view.TxStarView.Read)((OneToOne)this.view()).left : (aloha3.module.object.view.TxStarView.Read)this.view();
    }

    public Read getTx() {
        return this.getTxView().unsafeTx();
    }

    public abstract List<Mandatory> childMembers();

    public List<Optional> childOptionalMembers() {
        return Collections.EMPTY_LIST;
    }
}
