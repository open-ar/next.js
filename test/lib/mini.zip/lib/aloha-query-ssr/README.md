# aloha-queryのSSR（サーバーサイドレンダリング）バージョン

## 動作環境

- Java 25以上

## 動作確認方法

IntelliJで本プロジェクトを開く（pom.xmlまで選択し、プロジェクトとして開く）

1) InitDB.javaを実行する（初回のみ）

注意: 下記のエラーが出る場合は、

```log
Exception in thread "Thread-2" java.lang.UnsupportedClassVersionError: Preview features are not enabled for aloha/mapping/Incubator (class file version 67.65535). Try running with '--enable-preview'
```

実行する際に、VM Optionに
[--enable-preview](https://medium.com/javarevisited/enabling-the-preview-feature-in-intellij-735067948d6e)
オプションを付けて実施してください。

2) Main.javaを実行する

下記のログが表示されると、サーバーが起動完了。
```log
Click http://localhost:8081 for Out-Of-Order streaming by template engine without JavaScript
```

3) ブラウザで、http://localhost:8081 を開く

Google Chrome（お勧め）もしくはMicrosoft Edgeで
http://localhost:8081 をアクセスし、ブラウザで確認できます。

4) JSなしの場合の動作確認する

下記のGoogle Chromeの拡張機能: [Toggle JavaScript](https://chromewebstore.google.com/detail/toggle-javascript/cidlcjdalomndpeagkjpnefhljffbnlo)
はお勧めです。
